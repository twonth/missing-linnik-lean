"""Run from the project root with the pinned Lake environment available."""
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent.parent
out=root/'verification-exports'
out.mkdir(exist_ok=True)
names=['MissingLinnik.CurrentPaper.'+n for n in ['one_parameter','proposition_two_effective','linnik','rough_numbers_sieve']]
roots=['Nat.add','Nat.sub','Nat.mul','Nat.pow','Nat.gcd','Nat.div','Nat.mod','Nat.beq','Nat.ble','Nat.land','Nat.lor','Nat.xor','Nat.shiftLeft','Nat.shiftRight','String.ofList','Char.ofNat','List','eagerReduce','Nat','String','String.mk','Char','optParam','autoParam','semiOutParam','outParam','Quot','Quot.mk','Quot.lift','Quot.ind','propext','Classical.choice','Quot.sound']
for module in ['ChallengeCurrent','Audit']:
    subprocess.run(['lake','build',module],cwd=root,check=True)
    with (out/(module+'.export')).open('wb') as stream:
        subprocess.run(['lake','env','leanexport',module,'--']+names+roots,cwd=root,stdout=stream,check=True)
subprocess.run(['lake','comparator','--config','comparator-current.json','--challenge-from-export',str(out/'ChallengeCurrent.export'),'--solution-from-export',str(out/'Audit.export')],cwd=root,check=True)

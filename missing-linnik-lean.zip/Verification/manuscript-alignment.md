# Manuscript alignment: 25 October 2026

The current manuscript is the latest October 25 upload in the author's
“Final Version Review” chat, `Pasted text(20261025-215914).txt`, copied
byte-for-byte to `paper/main.tex`. SHA-256: `94bd4b7a846a2c5cdf5938aa4fe915f7f7bbd6cdab4309a66752663679b1e997`.
The previous certified snapshot hash was `2269410ba44813446435e2495bf15f21cf94557f5c481e6af309c324d01e3ced`.
The full whitespace-normalized diff is in `2026-10-25/manuscript-changes.diff`.

## Mathematical changes since October 23

- **Direct negative-mass exclusion of positive bias.** Equation (sign) now
  sums the two-prime formula on the negative character coset, giving
  (1/2+o(1)) log² Z. Its left side is bounded by
  M_- log Z + 2 M_- times the total prime weight. Added
  `negative_symmetry_mass_bound` (normalized form U_-+V_- <= 3 M_-)
  and `negative_symmetry_mass_identity` in `MissingLinnik/SignExclusion.lean`.
  The latter says twice the negative mass is the unsigned minus signed
  total. Together with the existing symmetry estimates this supplies the
  lower bound on negative mass. `positive_sign_excluded` now uses these
  lemmas, so this is integrated into the Linnik proof. The new Comparator
  target is `MissingLinnik.CurrentPaper.negative_mass_sign_bound`.
  The residue symmetry infrastructure still supplies the equivalent
  unsigned/signed totals, rather than a separately packaged half-coset
  prime-sum asymptotic. All its inputs are proved in the existing pipeline.
- **Explicit real h in the sieve lemma.** Added
  `MissingLinnik.CurrentPaper.rough_numbers_sieve_real_h` for real h>=18.
  Applying the old theorem at floor(h) gives relative error 16 exp(33-h)
  and additive error z^(3h). This is the manuscript's O(exp(-h)) form.
  Integer z and the 0<=n<N convention remain; arbitrary real z and endpoint
  conversions are not separately formalized.
- **Reverse triangle and roadmap.** The explicit lower bound on the
  nonprincipal cubic moment was already part of the spectral-concentration
  proof. The rewritten exposition changes no hypothesis or conclusion.
- **Sieve lower bound.** The text now explicitly restricts p to p not
  dividing q. The formal sieve already uses this restriction.
- The main theorem, primitive-character anti-concentration statement,
  unrestricted-x symmetry formulas, and determinant inequalities have
  unchanged mathematical statements.

## Other changes

The draft changes margins, headings and wording, expands the disclosure,
adds specific Selberg references and a comparison with Selberg's norm
product, and revises explanatory transitions. These are included in the
snapshot but historical/bibliographic claims are not checked by Lean.
The commented-out old sign paragraph is preserved exactly as uploaded.

## Remaining correspondence conventions

The symmetry targets use von Mangoldt weights with B=170k; the relation to
prime-only formulas uses the existing prime-power estimates. There is no
upper cutoff on x. The internal determinant slope is 1024t. The character
bridge uses a bounded integer representative rather than the manuscript's
exact fundamental discriminant. The main proof retains earlier sufficient
sieve constants; the sharper appendix sieve is separate. These are the
same conventions as the previous run except for the new real-h extension.

## Verification

All 163 modules rebuilt; eight Comparator targets accepted; independent
kernel replay accepted. Only propext, Classical.choice, Quot.sound.
The dated directory contains authoritative run evidence. Comparator
compares Lean statements and axiom dependencies, not the manuscript text.

# Manuscript alignment: 23 October 2026

The snapshot checked in this run is [paper/main.tex](../paper/main.tex), copied
byte-for-byte from the author's latest uploaded manuscript. Its SHA-256 is
`2269410ba44813446435e2495bf15f21cf94557f5c481e6af309c324d01e3ced`.

## Changes since the previous verification

- The main Linnik argument precedes the symmetry-formula proofs. Its
  Brun--Titchmarsh citation is a forward reference; this does not change the
  dependency order in Lean.
- Proposition 3 now states both symmetry formulas for **every x >= Z**, with
  no condition x <= Z^3. This change is addressed below.
- The final manuscript retains **primitive** real characters and the
  fundamental discriminant d = psi(-1)f. The intermediate imprimitive and
  squarefree-d drafts are not the snapshot certified here.
- Other changes concern exposition, local variable names, references, and the
  repository description. Bibliographical and historical claims are outside
  the formal verification.

## Proposition 3: the unbounded range

Two additional challenge statements make the range explicit:

1. `MissingLinnik.CurrentPaper.symmetry_two_unbounded` has only x >= 1.
   It proves an error at most 10^42 log(Y) log(x) / phi(q).
2. `MissingLinnik.CurrentPaper.symmetry_three_unbounded` has only x >= Y.
   It proves an error at most 10^46 log(Y) log(x)^2 / phi(q).

Here Y = q^(170k), k >= 1. These declarations reuse `rough_two_real` in
`MissingLinnik/RealRoughSymmetry.lean` and `rough_three_real` in
`MissingLinnik/ThreeRoughSymmetry.lean`. Neither theorem assumes an upper
bound on x. Both are included explicitly in `comparator-current.json`.

For the manuscript's scale, put B = 170k and Z = q^(B^2). Whenever x >= Z,
log(Y)/log(x) <= 1/B. Thus the displayed quantitative bounds have relative
error O(1/B) uniformly on this entire unbounded interval. The formal family
uses B in multiples of 170, sufficient for choosing an effective B in the
Linnik argument; it is not a separately packaged theorem for every integer B.

These two formal declarations retain von Mangoldt weights on Y-rough prime
powers. They are the quantitative counterparts used by the existing proof,
not literal prime-only restatements of the two displays in Proposition 3.
`rough_proper_prime_power_mass` in `MissingLinnik/RoughPrimePowers.lean`
bounds the omitted mass by 72/Y for every cutoff N, also without an upper
restriction. The existing Linnik assembly uses prime-power error estimates
where needed. A general prime-only two-/three-prime reformulation of these
two declarations is not separately packaged in this repository. The paper's
prime-power removal argument likewise uses no upper bound x <= Z^3.

## Other correspondence conventions

- `one_parameter` proves the appendix bound with explicit coefficient
  1/2 + 70000/t, using internal triangular slope 1024t.
- The formal character bridge constructs a bounded integer representative
  with the necessary implication at odd primes where the character is -1.
  It does not assert that this representative is the paper's specific
  fundamental discriminant. This weaker input suffices for the determinant
  proof. The published main statements retain their primitive hypotheses.
- `proposition_two_effective` supplies the computable exponent
  (70000(k+1))^2. `linnik` uses this anti-concentration result and the prior
  symmetry proof; the sharper appendix sieve is proved separately.
- `rough_numbers_sieve` uses natural parameters and the interval 0 <= n < N.
  The paper's real-parameter and endpoint conversions are not separately
  formalized. This limitation is unchanged from the previous verification.

Comparator checks agreement with the explicit Lean challenge statements and
permitted axioms. It does not read or independently interpret the TeX paper;
the correspondence described here is a mathematical review of those statements.

import SharpLower

namespace MissingLinnik.CurrentPaper

open Finset

/-- A fully explicit fundamental-lemma estimate, obtained by the manuscript's
Selberg upper sieve and least-prime partition. The conservative coefficient
bound gives z^(4h) per removed prime rather than z^(2h). -/
theorem finite_fundamental_sieve (N q b z h : ℕ) (P : Finset ℕ)
    (hq : 0 < q) (hz : 2 ≤ z) (hh : 17 ≤ h)
    (hp : ∀ p ∈ P, p.Prime) (hcop : ∀ p ∈ P, q.Coprime p)
    (hpz : ∀ p ∈ P, p ≤ z) :
    |((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ P, ¬p ∣ n)).card:ℝ) - ((N:ℝ)/q)*sieveDensity P| ≤
      16*Real.exp (32-(h:ℝ))*((N:ℝ)/q)*sieveDensity P +
        ((P.card:ℝ)+1)*(z:ℝ)^(2*h) := by
  have hz0 : (0:ℝ) < z := by exact_mod_cast (show 0<z by omega)
  have hlz : 0 < Real.log (z:ℝ) := Real.log_pos (by exact_mod_cast (show 1<z by omega))
  have hR : 1 ≤ z^h := one_le_pow₀ (by omega : 1≤z)
  have hpow : (((z^h:ℕ):ℝ)^2) = (z:ℝ)^(2*h) := by
    rw [Nat.cast_pow,← pow_mul,Nat.mul_comm]
  have hlR : Real.log ((z^h:ℕ):ℝ) = (h:ℝ)*Real.log z := by rw [Nat.cast_pow,Real.log_pow]
  have hratio : Real.log ((z^h:ℕ):ℝ)/Real.log z = h := by rw [hlR]; field_simp
  have hhR : (17:ℝ) ≤ h := by exact_mod_cast hh
  have hupper := finite_sieve_upper N q b (z^h) z P hq hR hz hp hcop hpz
    (by rw [hratio]; exact hhR)
  rw [hratio,hpow] at hupper
  have hlower := finite_sieve_lower_of_counts
    ((Finset.range N).filter (fun n => Nat.ModEq q n b)) P z (z^h) hz hp hpz
    ((N:ℝ)/q) (h:ℝ) (by positivity) hhR
    (by have hc := (abs_le.mp (progression_count_error N q b hq)).1; linarith)
    (by
      intro p hpm
      have hp0 : (0:ℝ) < p := by exact_mod_cast (hp p hpm).pos
      have hlp : 0 < Real.log (p:ℝ) := Real.log_pos (by exact_mod_cast (hp p hpm).one_lt)
      have hlog : Real.log (p:ℝ) ≤ Real.log z := Real.log_le_log hp0 (by exact_mod_cast hpz p hpm)
      have hu : 1 ≤ Real.log (z:ℝ)/Real.log p := (le_div_iff₀ hlp).mpr (by simpa)
      have he : Real.log ((z^h:ℕ):ℝ)/Real.log p = (h:ℝ)*(Real.log z/Real.log p) := by rw [hlR]; ring
      have ht := first_divisor_progression_upper N q b (z^h) z p P hq hR hz hp hcop hpz hpm
        (by rw [he]; nlinarith)
      rw [he] at ht
      convert ht using 1 <;> ring)
  rw [hpow] at hlower
  have hpow1 : (1:ℝ) ≤ (z:ℝ)^(2*h) := one_le_pow₀ (by exact_mod_cast (show 1≤z by omega))
  have hv : 0 < sieveDensity P := sieveDensity_pos P hp
  have ht : (0:ℝ) ≤ (N:ℝ)/q := by positivity
  have hc : (0:ℝ) ≤ P.card := Nat.cast_nonneg _
  have he : 2*Real.exp (16-(h:ℝ)) ≤ 16*Real.exp (32-(h:ℝ)) := by
    have hm := Real.exp_le_exp.mpr (show 16-(h:ℝ) ≤ 32-h by linarith)
    have hn := Real.exp_pos (32-(h:ℝ))
    linarith
  have herr := mul_le_mul_of_nonneg_right he (show 0 ≤ ((N:ℝ)/q)*sieveDensity P by positivity)
  have herrR : 0 ≤ (P.card:ℝ)*(z:ℝ)^(2*h) := by positivity
  apply abs_le.mpr
  constructor <;> nlinarith only [hlower,hupper,hpow1,herr,herrR]

end MissingLinnik.CurrentPaper


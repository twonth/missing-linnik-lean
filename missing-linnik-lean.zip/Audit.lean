import CurrentPaper
import SharpRough
#print axioms MissingLinnik.CurrentPaper.one_parameter
#print axioms MissingLinnik.CurrentPaper.proposition_two_effective
#print axioms MissingLinnik.CurrentPaper.linnik
#print axioms MissingLinnik.CurrentPaper.sieveWeight_abs_le_one
#print axioms MissingLinnik.CurrentPaper.selberg_progression_upper
#print axioms MissingLinnik.CurrentPaper.rough_numbers_sieve

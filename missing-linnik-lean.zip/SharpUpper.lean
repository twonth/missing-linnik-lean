import SharpSieve
import MissingLinnik.FiniteSieveUpper
namespace MissingLinnik.CurrentPaper
open Finset
theorem finite_sieve_upper (N q b R z : ℕ) (P : Finset ℕ) (hq : 0 < q)
    (hR : 1 ≤ R) (hz : 2 ≤ z) (hp : ∀ p ∈ P, p.Prime)
    (hcop : ∀ p ∈ P, q.Coprime p) (hpz : ∀ p ∈ P, p ≤ z)
    (hlevel : 17 ≤ Real.log (R:ℝ)/Real.log z) :
    ((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ P, ¬ p ∣ n)).card:ℝ) ≤
      ((N:ℝ)/q)*sieveDensity P*(1+2*Real.exp (16-Real.log R/Real.log z))+(R:ℝ)^2 := by
  let Q := ∏ p ∈ P, p
  have hQ := squarefree_prime_product P hp
  have hc : q.Coprime Q := Nat.coprime_prod_right_iff.mpr hcop
  have hh := selberg_progression_upper N q b Q R hq hQ hc hR
  have hi := sieveH_inverse_general Q R z hQ hR hz
    (by simpa only [Q,Nat.primeFactors_prod hp] using hpz) hlevel
  have he : (1+2*Real.exp (16-Real.log (R:ℝ)/Real.log z))/fullSieveH Q =
      sieveDensity P*(1+2*Real.exp (16-Real.log R/Real.log z)) := by
    rw [div_eq_mul_inv,inverse_fullSieveH_eq_density P hp,mul_comm]
  rw [he] at hi
  have ht := mul_le_mul_of_nonneg_left hi (show 0 ≤ (N:ℝ)/q by positivity)
  have he' : (N:ℝ)/(q*sieveH Q R) = ((N:ℝ)/q)*(1/sieveH Q R) := by ring
  rw [he'] at hh
  have hc' : (fun n => n.Coprime Q) = (fun n => ∀ p ∈ P, ¬p ∣ n) := by
    funext n
    exact propext (coprime_prime_product_iff P hp n)
  simp only [hc'] at hh
  nlinarith only [hh,ht]

end MissingLinnik.CurrentPaper


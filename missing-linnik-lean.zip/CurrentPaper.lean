import OneParameter
import MissingLinnik.LinnikConclusion

namespace MissingLinnik.CurrentPaper

def exponent (k : ℕ) : ℕ := (70000*(k+1))^2

theorem exponent_computable : Computable exponent := by
  have h : Primrec (fun k : ℕ => 70000*(k+1)) :=
    Primrec.nat_mul.comp (Primrec.const 70000)
      (Primrec.nat_add.comp Primrec.id (Primrec.const 1))
  change Computable (fun k : ℕ => (70000*(k+1))^2)
  simp only [pow_two]
  exact (Primrec.nat_mul.comp h h).to_comp

theorem exponent_bounds : AntiConcentrationBounds exponent := by
  intro k f hf ψ hp hn x hx
  have hf2 : 2 ≤ f := by
    have hfne : f ≠ 1 := fun he => hn (DirichletCharacter.level_one' ψ he)
    omega
  have h := one_parameter (70000*(k+1)) f (by omega) hf2 ψ hp x hx
  have he : (70000:ℝ) / ((70000*(k+1):ℕ):ℝ) = 1/((k:ℝ)+1) := by
    push_cast
    field_simp
    <;> ring
  rwa [he] at h

/-- Proposition 2 using the new one-parameter triangular estimate. -/
theorem proposition_two_effective : EffectiveAntiConcentration :=
  ⟨exponent, exponent_computable, exponent_bounds⟩

theorem proposition_two : AntiConcentration :=
  effectiveAntiConcentration_implies_antiConcentration proposition_two_effective

/-- Theorem 1 assembled using the appendix's one-parameter proof. -/
theorem linnik : Linnik :=
  linnik_of_effectiveAntiConcentration proposition_two_effective

#print axioms MissingLinnik.CurrentPaper.one_parameter
#print axioms MissingLinnik.CurrentPaper.proposition_two_effective
#print axioms MissingLinnik.CurrentPaper.proposition_two
#print axioms MissingLinnik.CurrentPaper.linnik

end MissingLinnik.CurrentPaper


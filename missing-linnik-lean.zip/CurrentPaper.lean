import OneParameter
import MissingLinnik.LinnikConclusion
import MissingLinnik.ThreeRoughSymmetry

namespace MissingLinnik.CurrentPaper

def exponent (k : ℕ) : ℕ := (70000*(k+1))^2

theorem exponent_computable : Computable exponent := by
  have h : Primrec (fun k : ℕ => 70000*(k+1)) :=
    Primrec.nat_mul.comp (Primrec.const 70000)
      (Primrec.nat_add.comp Primrec.id (Primrec.const 1))
  change Computable (fun k : ℕ => (70000*(k+1))^2)
  simp only [pow_two]
  exact (Primrec.nat_mul.comp h h).to_comp

theorem exponent_bounds : AntiConcentrationBounds exponent := by
  intro k f hf ψ hp hn x hx
  have hf2 : 2 ≤ f := by
    have hfne : f ≠ 1 := fun he => hn (DirichletCharacter.level_one' ψ he)
    omega
  have h := one_parameter (70000*(k+1)) f (by omega) hf2 ψ hp x hx
  have he : (70000:ℝ) / ((70000*(k+1):ℕ):ℝ) = 1/((k:ℝ)+1) := by
    push_cast
    field_simp
    <;> ring
  rwa [he] at h

/-- Proposition 2 using the new one-parameter triangular estimate. -/
theorem proposition_two_effective : EffectiveAntiConcentration :=
  ⟨exponent, exponent_computable, exponent_bounds⟩

theorem proposition_two : AntiConcentration :=
  effectiveAntiConcentration_implies_antiConcentration proposition_two_effective

/-- Theorem 1 assembled using the appendix's one-parameter proof. -/
theorem linnik : Linnik :=
  linnik_of_effectiveAntiConcentration proposition_two_effective

/-- Quantitative two-term symmetry, with no upper restriction on x.
This is the von Mangoldt version underlying Proposition 3. -/
theorem symmetry_two_unbounded (q k c : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hc : c.Coprime q) (x : ℝ) (hx : 1 ≤ x) :
    |roughQ q c (q^(170*k)) x - (Real.log x)^2/q.totient| ≤
      (10:ℝ)^42 * Real.log ((q^(170*k):ℕ):ℝ) * Real.log x/q.totient :=
  rough_two_real q k c hq hk hc x hx

/-- Quantitative three-term symmetry for every x >= Y, without an upper cutoff.
Prime powers are retained, as in the existing formal symmetry proof. -/
theorem symmetry_three_unbounded (q k c : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hc : c.Coprime q) (x : ℝ) (hx : ((q^(170*k):ℕ):ℝ) ≤ x) :
    |2 * arithmeticClassSum (roughRestriction (q^(170*k)) ArithmeticFunction.vonMangoldt *
      roughRestriction (q^(170*k)) ArithmeticFunction.vonMangoldt *
      roughRestriction (q^(170*k)) ArithmeticFunction.vonMangoldt) q c x -
      arithmeticClassSum (logWeight (logWeight
        (roughRestriction (q^(170*k)) ArithmeticFunction.vonMangoldt))) q c x| ≤
      (10:ℝ)^46 * Real.log ((q^(170*k):ℕ):ℝ) * (Real.log x)^2/q.totient :=
  rough_three_real q k c hq hk hc x hx

#print axioms MissingLinnik.CurrentPaper.one_parameter
#print axioms MissingLinnik.CurrentPaper.proposition_two_effective
#print axioms MissingLinnik.CurrentPaper.proposition_two
#print axioms MissingLinnik.CurrentPaper.linnik
#print axioms MissingLinnik.CurrentPaper.symmetry_two_unbounded
#print axioms MissingLinnik.CurrentPaper.symmetry_three_unbounded

end MissingLinnik.CurrentPaper


namespace MissingLinnik.CurrentPaper
theorem negative_mass_sign_bound {I : Type*} [Fintype I]
    (w u : I → ℝ) (v : I → I → ℝ) (a : I → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hmass : ∑ i, w i = 1)
    (hu : ∀ i, 0 ≤ u i ∧ u i ≤ w i)
    (hv : ∀ i j, 0 ≤ v i j ∧ v i j ≤ w i * w j)
    (ha : ∀ i, a i = 1 ∨ a i = -1) :
    (∑ i ∈ Finset.univ.filter (fun i => a i = -1), u i) +
      (∑ i, ∑ j ∈ Finset.univ.filter (fun j => a i * a j = -1), v i j) ≤
      3 * (∑ i ∈ Finset.univ.filter (fun i => a i = -1), w i) := by
  exact MissingLinnik.negative_symmetry_mass_bound w u v a hw hmass hu hv ha
end MissingLinnik.CurrentPaper

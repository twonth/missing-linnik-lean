import SharpFundamental
import MissingLinnik.RoughSieve
namespace MissingLinnik.CurrentPaper
open Finset
/-- Explicit rough-number equidistribution in a reduced residue class.
The interval convention is 0 ≤ n < N; no asymptotic notation or
unproved sieve input is used. -/
theorem rough_numbers_sieve (N q b z h : ℕ) (hq : 0 < q) (hz : 2 ≤ z)
    (hqz : q ≤ z) (hb : b.Coprime q) (hh : 17 ≤ h) :
    |((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ Nat.primesLE z, ¬p ∣ n)).card:ℝ) -
        ((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)| ≤
      16*Real.exp (32-(h:ℝ))*((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)+
        (z:ℝ)^(3*h) := by
  let P := (Nat.primesLE z).filter (fun p => ¬p ∣ q)
  have hp : ∀ p ∈ P, p.Prime := fun p hpm => (Nat.mem_primesLE.mp (Finset.mem_filter.mp hpm).1).2
  have hpz : ∀ p ∈ P, p ≤ z := fun p hpm => (Nat.mem_primesLE.mp (Finset.mem_filter.mp hpm).1).1
  have hc : ∀ p ∈ P, q.Coprime p := by
    intro p hpm
    exact ((hp p hpm).coprime_iff_not_dvd.mpr (Finset.mem_filter.mp hpm).2).symm
  have hs := finite_fundamental_sieve N q b z h P hq hz hh hp hc hpz
  have hset : (((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ P, ¬p ∣ n)) =
      (((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ Nat.primesLE z, ¬p ∣ n)) := by
    ext n
    simp only [Finset.mem_filter]
    constructor
    · rintro ⟨⟨hn,hnq⟩,hrough⟩
      refine ⟨⟨hn,hnq⟩,?_⟩
      intro p hpm hpn
      by_cases hpq : p ∣ q
      · have hnc := coprime_of_modEq n b q hb hnq
        have hd : p ∣ 1 := by rw [← hnc]; exact Nat.dvd_gcd hpn hpq
        exact (Nat.mem_primesLE.mp hpm).2.ne_one (Nat.dvd_one.mp hd)
      · exact hrough p (Finset.mem_filter.mpr ⟨hpm,hpq⟩) hpn
    · rintro ⟨hn,hrough⟩
      exact ⟨hn,fun p hpm => hrough p (Finset.mem_filter.mp hpm).1⟩
  have hmain : ((N:ℝ)/q)*sieveDensity P =
      ((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z) := by
    rw [sieveDensity_away_modulus q z hq hqz]
    have hq0 : (q:ℝ) ≠ 0 := by exact_mod_cast hq.ne'
    field_simp
  rw [hset,hmain] at hs
  have hsub : P ⊆ Finset.Icc 1 z := by
    intro p hpm
    exact Finset.mem_Icc.mpr ⟨(hp p hpm).one_le,hpz p hpm⟩
  have hcard : P.card ≤ z := by simpa using Finset.card_le_card hsub
  have hpow : (P.card:ℝ)+1 ≤ (z:ℝ)^h := by
    have hzR : (2:ℝ) ≤ z := by exact_mod_cast hz
    have hcR : (P.card:ℝ) ≤ z := by exact_mod_cast hcard
    have hm : (z:ℝ)^2 ≤ (z:ℝ)^h := pow_le_pow_right₀ (by linarith : (1:ℝ)≤z) (by omega : 2≤h)
    nlinarith
  have herr := mul_le_mul_of_nonneg_right hpow (show 0 ≤ (z:ℝ)^(2*h) by positivity)
  have he : (z:ℝ)^h*(z:ℝ)^(2*h) = (z:ℝ)^(3*h) := by rw [← pow_add]; congr 1; omega
  rw [he] at herr
  have hmain' : 16*Real.exp (32-(h:ℝ))*((N:ℝ)/q)*sieveDensity P =
      16*Real.exp (32-(h:ℝ))*((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z) := by
    calc
      _ = 16*Real.exp (32-(h:ℝ))*(((N:ℝ)/q)*sieveDensity P) := by ring
      _ = _ := by rw [hmain]; ring
  rw [hmain'] at hs
  linarith

end MissingLinnik.CurrentPaper


namespace MissingLinnik.CurrentPaper
theorem rough_numbers_sieve_real_h (N q b z : ℕ) (h : ℝ)
    (hq : 0 < q) (hz : 2 ≤ z) (hqz : q ≤ z) (hb : b.Coprime q) (hh : 18 ≤ h) :
    |((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ Nat.primesLE z, ¬p ∣ n)).card:ℝ) -
        ((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)| ≤
      16*Real.exp (33-h)*((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)+
        (z:ℝ)^(3*h) := by
  have h0 : 0 ≤ h := by linarith
  have hf : 17 ≤ Nat.floor h := Nat.le_floor (by norm_num; linarith)
  have hs := rough_numbers_sieve N q b z (Nat.floor h) hq hz hqz hb hf
  have hfl := Nat.floor_le h0
  have hlt := Nat.lt_floor_add_one h
  have he : Real.exp (32-(Nat.floor h:ℝ)) ≤ Real.exp (33-h) :=
    Real.exp_le_exp.mpr (by linarith)
  have hd : 0 ≤ sieveDensity (Nat.primesLE z) :=
    (sieveDensity_pos _ (fun p hp => (Nat.mem_primesLE.mp hp).2)).le
  have hm := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left he (by norm_num : (0:ℝ)≤16))
      (by positivity : 0 ≤ (N:ℝ)/q.totient)) hd
  have hp : (z:ℝ)^(3*Nat.floor h) ≤ (z:ℝ)^(3*h) := by
    rw [← Real.rpow_natCast]
    apply Real.rpow_le_rpow_of_exponent_le (by exact_mod_cast (show 1 ≤ z by omega))
    push_cast
    linarith
  exact hs.trans (add_le_add hm hp)
end MissingLinnik.CurrentPaper

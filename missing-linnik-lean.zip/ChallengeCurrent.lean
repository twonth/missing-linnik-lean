import MissingLinnik.LinnikConclusion
import MissingLinnik.RoughSieve
namespace MissingLinnik.CurrentPaper
theorem one_parameter (t f : ℕ) (ht : 3 ≤ t) (hf : 2 ≤ f)
    (ψ : DirichletCharacter ℝ f) (hprim : ψ.IsPrimitive)
    (x : ℝ) (hx : (f : ℝ)^(t^2) ≤ x) :
    negativePrimeMass ψ x ≤ (1/2 + 70000/(t:ℝ))*Real.log x  := by sorry
 theorem proposition_two_effective : EffectiveAntiConcentration := by sorry
 theorem linnik : Linnik := by sorry
theorem rough_numbers_sieve (N q b z h : ℕ) (hq : 0 < q) (hz : 2 ≤ z)
    (hqz : q ≤ z) (hb : b.Coprime q) (hh : 17 ≤ h) :
    |((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ Nat.primesLE z, ¬p ∣ n)).card:ℝ) -
        ((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)| ≤
      16*Real.exp (32-(h:ℝ))*((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)+
        (z:ℝ)^(3*h)  := by sorry
end MissingLinnik.CurrentPaper


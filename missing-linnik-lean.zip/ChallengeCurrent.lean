import MissingLinnik.LinnikConclusion
import MissingLinnik.RoughSieve
import MissingLinnik.ThreeRoughSymmetry
namespace MissingLinnik.CurrentPaper
theorem one_parameter (t f : ℕ) (ht : 3 ≤ t) (hf : 2 ≤ f)
    (ψ : DirichletCharacter ℝ f) (hprim : ψ.IsPrimitive)
    (x : ℝ) (hx : (f : ℝ)^(t^2) ≤ x) :
    negativePrimeMass ψ x ≤ (1/2 + 70000/(t:ℝ))*Real.log x  := by sorry
 theorem proposition_two_effective : EffectiveAntiConcentration := by sorry
 theorem linnik : Linnik := by sorry
theorem rough_numbers_sieve (N q b z h : ℕ) (hq : 0 < q) (hz : 2 ≤ z)
    (hqz : q ≤ z) (hb : b.Coprime q) (hh : 17 ≤ h) :
    |((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ Nat.primesLE z, ¬p ∣ n)).card:ℝ) -
        ((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)| ≤
      16*Real.exp (32-(h:ℝ))*((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)+
        (z:ℝ)^(3*h)  := by sorry
end MissingLinnik.CurrentPaper

namespace MissingLinnik.CurrentPaper
theorem symmetry_two_unbounded (q k c : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hc : c.Coprime q) (x : ℝ) (hx : 1 ≤ x) :
    |roughQ q c (q^(170*k)) x - (Real.log x)^2/q.totient| ≤
      (10:ℝ)^42 * Real.log ((q^(170*k):ℕ):ℝ) * Real.log x/q.totient := by sorry

theorem symmetry_three_unbounded (q k c : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hc : c.Coprime q) (x : ℝ) (hx : ((q^(170*k):ℕ):ℝ) ≤ x) :
    |2 * arithmeticClassSum (roughRestriction (q^(170*k)) ArithmeticFunction.vonMangoldt *
      roughRestriction (q^(170*k)) ArithmeticFunction.vonMangoldt *
      roughRestriction (q^(170*k)) ArithmeticFunction.vonMangoldt) q c x -
      arithmeticClassSum (logWeight (logWeight
        (roughRestriction (q^(170*k)) ArithmeticFunction.vonMangoldt))) q c x| ≤
      (10:ℝ)^46 * Real.log ((q^(170*k):ℕ):ℝ) * (Real.log x)^2/q.totient := by sorry
end MissingLinnik.CurrentPaper


namespace MissingLinnik.CurrentPaper
theorem negative_mass_sign_bound {I : Type*} [Fintype I]
    (w u : I → ℝ) (v : I → I → ℝ) (a : I → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hmass : ∑ i, w i = 1)
    (hu : ∀ i, 0 ≤ u i ∧ u i ≤ w i)
    (hv : ∀ i j, 0 ≤ v i j ∧ v i j ≤ w i * w j)
    (ha : ∀ i, a i = 1 ∨ a i = -1) :
    (∑ i ∈ Finset.univ.filter (fun i => a i = -1), u i) +
      (∑ i, ∑ j ∈ Finset.univ.filter (fun j => a i * a j = -1), v i j) ≤
      3 * (∑ i ∈ Finset.univ.filter (fun i => a i = -1), w i) := by sorry
end MissingLinnik.CurrentPaper

namespace MissingLinnik.CurrentPaper
theorem rough_numbers_sieve_real_h (N q b z : ℕ) (h : ℝ)
    (hq : 0 < q) (hz : 2 ≤ z) (hqz : q ≤ z) (hb : b.Coprime q) (hh : 18 ≤ h) :
    |((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ Nat.primesLE z, ¬p ∣ n)).card:ℝ) -
        ((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)| ≤
      16*Real.exp (33-h)*((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)+
        (z:ℝ)^(3*h) := by sorry
end MissingLinnik.CurrentPaper

import MissingLinnik.SieveEulerProduct
import Mathlib.Data.Nat.Squarefree

namespace MissingLinnik.CurrentPaper
open Finset ArithmeticFunction
open scoped ArithmeticFunction.Moebius
set_option maxHeartbeats 1200000

theorem reciprocal_totient_sum (d : ℕ) (hd : Squarefree d) :
    (∑ j ∈ d.divisors, (1:ℝ)/j.totient) = (d:ℝ)/d.totient := by
  have hφ : (d.totient:ℝ) ≠ 0 := by
    exact_mod_cast (Nat.totient_pos.mpr (Nat.pos_of_ne_zero hd.ne_zero)).ne'
  rw [← Nat.sum_div_divisors d (fun j => (1:ℝ)/j.totient)]
  calc
    _ = ∑ j ∈ d.divisors, (j.totient:ℝ)/d.totient := by
      apply Finset.sum_congr rfl
      intro j hj
      have hjd := Nat.dvd_of_mem_divisors hj
      have hc : j.Coprime (d/j) := Nat.coprime_of_squarefree_mul
        (by simpa [Nat.mul_div_cancel' hjd] using hd)
      have he := Nat.totient_mul hc
      rw [Nat.mul_div_cancel' hjd] at he
      have her : (d.totient:ℝ) = (j.totient:ℝ)*(d/j).totient := by exact_mod_cast he
      have hjφ : (j.totient:ℝ) ≠ 0 := by
        exact_mod_cast (Nat.totient_pos.mpr (Nat.pos_of_mem_divisors hj)).ne'
      rw [her]
      field_simp
    _ = (d:ℝ)/d.totient := by
      simp only [div_eq_mul_inv]
      rw [← Finset.sum_mul]
      congr 1
      exact_mod_cast Nat.sum_totient d

theorem sieve_denominator_dominates (P R d : ℕ) (hP : Squarefree P) (hd : d ∣ P) :
    (d:ℝ) * (∑ k ∈ (P/d).divisors,
      if d*k ≤ R then (1:ℝ)/(d*k).totient else 0) ≤ sieveH P R := by
  classical
  have hd0 : 0 < d := Nat.pos_of_dvd_of_pos hd (Nat.pos_of_ne_zero hP.ne_zero)
  have hsf := hP.squarefree_of_dvd hd
  have hcop : d.Coprime (P/d) := Nat.coprime_of_squarefree_mul
    (by simpa [Nat.mul_div_cancel' hd] using hP)
  let K := (P/d).divisors.filter (fun k => d*k ≤ R)
  let S := d.divisors ×ˢ K
  have hc : ∀ j ∈ d.divisors, ∀ k ∈ K, j.Coprime k := by
    intro j hj k hk
    exact (hcop.of_dvd_left (Nat.dvd_of_mem_divisors hj)).of_dvd_right
      (Nat.dvd_of_mem_divisors (Finset.mem_filter.mp hk).1)
  have hinj : Set.InjOn (fun a : ℕ × ℕ => a.1*a.2) S := by
    intro a ha b hb he
    change a.1*a.2 = b.1*b.2 at he
    obtain ⟨haj,hak⟩ := Finset.mem_product.mp ha
    obtain ⟨hbj,hbk⟩ := Finset.mem_product.mp hb
    have hab : a.1 ∣ b.1 := (hc a.1 haj b.2 hbk).dvd_mul_right.mp
      (he ▸ dvd_mul_right a.1 a.2)
    have hba : b.1 ∣ a.1 := (hc b.1 hbj a.2 hak).dvd_mul_right.mp
      (he.symm ▸ dvd_mul_right b.1 b.2)
    have hj : a.1 = b.1 := Nat.dvd_antisymm hab hba
    have hk : a.2 = b.2 := by
      rw [hj] at he
      exact Nat.eq_of_mul_eq_mul_left (Nat.pos_of_mem_divisors hbj) he
    exact Prod.ext hj hk
  have hsub : S.image (fun a : ℕ × ℕ => a.1*a.2) ⊆ P.divisors := by
    intro n hn
    obtain ⟨⟨j,k⟩,hjk,rfl⟩ := Finset.mem_image.mp hn
    obtain ⟨hj,hk⟩ := Finset.mem_product.mp hjk
    have hdiv := Nat.mul_dvd_mul (Nat.dvd_of_mem_divisors hj)
      (Nat.dvd_of_mem_divisors (Finset.mem_filter.mp hk).1)
    rw [Nat.mul_div_cancel' hd] at hdiv
    exact Nat.mem_divisors.mpr ⟨hdiv,hP.ne_zero⟩
  have hs : (∑ a ∈ S, (1:ℝ)/(a.1*a.2).totient) ≤ sieveH P R := by
    apply Finset.sum_le_sum_of_injOn (fun a : ℕ × ℕ => a.1*a.2) hinj hsub
    · intro a ha
      obtain ⟨hj,hk⟩ := Finset.mem_product.mp ha
      have hle : a.1*a.2 ≤ R := (Nat.mul_le_mul_right a.2
        (Nat.le_of_dvd hd0 (Nat.dvd_of_mem_divisors hj))).trans (Finset.mem_filter.mp hk).2
      simp [hle]
    · intro a ha hn
      split_ifs <;> positivity
  have he : (∑ a ∈ S, (1:ℝ)/(a.1*a.2).totient) =
      ((d:ℝ)/d.totient) * ∑ k ∈ K, (1:ℝ)/k.totient := by
    rw [← reciprocal_totient_sum d hsf, Finset.sum_mul]
    simp only [S,Finset.sum_product]
    apply Finset.sum_congr rfl
    intro j hj
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro k hk
    rw [Nat.totient_mul (hc j hj k hk), Nat.cast_mul]
    ring
  have he' : (d:ℝ) * (∑ k ∈ (P/d).divisors,
      if d*k ≤ R then (1:ℝ)/(d*k).totient else 0) =
      ((d:ℝ)/d.totient) * ∑ k ∈ K, (1:ℝ)/k.totient := by
    rw [← Finset.sum_filter]
    change (d:ℝ)*(∑ k ∈ K, (1:ℝ)/(d*k).totient) = _
    rw [Finset.mul_sum,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro k hk
    rw [Nat.totient_mul (hcop.of_dvd_right
      (Nat.dvd_of_mem_divisors (Finset.mem_filter.mp hk).1)),Nat.cast_mul]
    ring
  rw [he']
  rwa [he] at hs




theorem sieveWeight_abs_le_one (P R d : ℕ) (hP : Squarefree P)
    (hR : 1 ≤ R) (hd : d ∣ P) : |sieveWeight P R d| ≤ 1 := by
  have hH := sieveH_pos P R hP.ne_zero hR
  have hsum : |∑ a ∈ (P/d).divisorsAntidiagonal,
      (μ a.1:ℝ)*sieveTarget P R (P/a.2)| ≤
      (∑ k ∈ (P/d).divisors, if d*k ≤ R then (1:ℝ)/(d*k).totient else 0) / sieveH P R := by
    rw [Nat.sum_divisorsAntidiagonal (fun a b => (μ a:ℝ)*sieveTarget P R (P/b))]
    calc
      _ ≤ ∑ k ∈ (P/d).divisors, |(μ k:ℝ)*sieveTarget P R (P/((P/d)/k))| :=
        Finset.abs_sum_le_sum_abs _ _
      _ = _ := by
        simp only [div_eq_mul_inv, Finset.sum_mul]
        apply Finset.sum_congr rfl
        intro k hk
        have hkd := Nat.dvd_of_mem_divisors hk
        have hdk : d*k ∣ P := (Nat.dvd_div_iff_mul_dvd hd).mp hkd
        have hsf := hP.squarefree_of_dvd hdk
        have hsfk := hP.squarefree_of_dvd (hkd.trans (Nat.div_dvd_of_dvd hd))
        have hm : |(μ k:ℝ)| = 1 := by
          exact_mod_cast ArithmeticFunction.abs_moebius_eq_one_of_squarefree hsfk
        have hmd : |(μ (d*k):ℝ)| = 1 := by
          exact_mod_cast ArithmeticFunction.abs_moebius_eq_one_of_squarefree hsf
        rw [Nat.div_div_eq_div_mul, Nat.div_div_self hdk hP.ne_zero]
        simp only [sieveTarget]
        split_ifs <;> simp [abs_mul,abs_div,hm,hmd,abs_of_pos hH,
          abs_of_nonneg (Nat.cast_nonneg (d*k).totient : (0:ℝ) ≤ (d*k).totient),
          div_eq_mul_inv,mul_comm,mul_left_comm,mul_assoc]
  have hbound := mul_le_mul_of_nonneg_left hsum (Nat.cast_nonneg d : (0:ℝ) ≤ d)
  change |(d:ℝ)*_| ≤ 1
  rw [abs_mul,abs_of_nonneg (Nat.cast_nonneg d : (0:ℝ) ≤ d)]
  apply hbound.trans
  rw [← mul_div_assoc]
  exact (div_le_one hH).mpr (sieve_denominator_dominates P R d hP hd)

#print axioms sieveWeight_abs_le_one

theorem sieveWeight_abs_sum_le (P R : ℕ) (hP : Squarefree P) (hR : 1 ≤ R) :
    (∑ d ∈ P.divisors, |sieveWeight P R d|) ≤ (R:ℝ) := by
  let D := P.divisors.filter (fun d => d ≤ R)
  have he : (∑ d ∈ P.divisors, |sieveWeight P R d|) = ∑ d ∈ D, |sieveWeight P R d| := by
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro d hd hn
    have hgt : R < d := by
      simp only [D,Finset.mem_filter,hd,true_and,not_le] at hn
      exact hn
    rw [sieveWeight_support P R d hP.ne_zero (Nat.dvd_of_mem_divisors hd) hgt,abs_zero]
  have hsub : D ⊆ Finset.Icc 1 R := by
    intro d hd
    obtain ⟨hd,hle⟩ := Finset.mem_filter.mp hd
    exact Finset.mem_Icc.mpr ⟨Nat.pos_of_mem_divisors hd,hle⟩
  have hc : D.card ≤ R := by
    have hh := Finset.card_le_card hsub
    simpa using hh
  have hs : (∑ d ∈ D, |sieveWeight P R d|) ≤ (D.card:ℝ) := by
    calc
      _ ≤ ∑ _d ∈ D, (1:ℝ) := by
        apply Finset.sum_le_sum
        intro d hd
        obtain ⟨hd,hle⟩ := Finset.mem_filter.mp hd
        exact sieveWeight_abs_le_one P R d hP hR (Nat.dvd_of_mem_divisors hd)
      _ = _ := by simp
  rw [he]
  have hcR : (D.card:ℝ) ≤ R := by exact_mod_cast hc
  exact hs.trans hcR

/-- The optimized Selberg main term for a progression, with a conservative
polynomial error from the coefficient bound above. -/
theorem selberg_progression_upper (N q b P R : ℕ) (hq : 0 < q)
    (hP : Squarefree P) (hcop : q.Coprime P) (hR : 1 ≤ R) :
    ((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => n.Coprime P)).card:ℝ) ≤
      (N:ℝ)/(q*sieveH P R) + (R:ℝ)^2 := by
  have hh := selberg_progression_square_bound N q b P hq
    (Nat.pos_of_ne_zero hP.ne_zero) hcop P.divisors
    (fun d hd => Nat.dvd_of_mem_divisors hd)
    (Nat.mem_divisors.mpr ⟨one_dvd _,hP.ne_zero⟩) (sieveWeight P R)
    (sieveWeight_one P R hP hR)
  rw [sieveWeight_quad_sum P R hP hR] at hh
  have hs := sieveWeight_abs_sum_le P R hP hR
  have hs0 : 0 ≤ ∑ d ∈ P.divisors, |sieveWeight P R d| :=
    Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  have he : (N:ℝ)/q*(1/sieveH P R) = (N:ℝ)/(q*sieveH P R) := by ring
  rw [he] at hh
  nlinarith [sq_nonneg ((R:ℝ) - ∑ d ∈ P.divisors, |sieveWeight P R d|)]

end MissingLinnik.CurrentPaper


import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Analysis.Complex.Basic
import Mathlib.Data.Fintype.Perm

namespace MissingLinnik

/-- The elementary Leibniz bound used for the archimedean estimate.
Each row may have its own upper bound. -/
theorem norm_det_le_factorial_mul_row_bounds {ι : Type*}
    [Fintype ι] [DecidableEq ι] (A : Matrix ι ι ℂ) (b : ι → ℝ)
    (hb : ∀ i, 0 ≤ b i) (hA : ∀ i j, ‖A i j‖ ≤ b i) :
    ‖A.det‖ ≤ (Fintype.card ι).factorial * ∏ i, b i := by
  classical
  rw [← Matrix.det_transpose A, Matrix.det_apply']
  calc
    ‖∑ σ : Equiv.Perm ι, _‖ ≤ ∑ σ : Equiv.Perm ι, ‖_‖ := norm_sum_le _ _
    _ ≤ ∑ _σ : Equiv.Perm ι, ∏ i, b i := by
      apply Finset.sum_le_sum
      intro σ _
      simp only [norm_mul, norm_prod]
      have hs : ‖(↑(Equiv.Perm.sign σ) : ℂ)‖ = 1 := by
        rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with h | h <;> simp [h]
      rw [hs, one_mul]
      exact Finset.prod_le_prod₀ (fun i _ => norm_nonneg _) (fun i _ => hA i (σ i))
    _ = _ := by simp [Fintype.card_perm]

end MissingLinnik




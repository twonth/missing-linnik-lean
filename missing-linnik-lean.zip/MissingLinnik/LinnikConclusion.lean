import MissingLinnik.LinnikAssembly
import MissingLinnik.LinnikCutoffs

namespace MissingLinnik
open scoped Classical
set_option maxHeartbeats 1000000
set_option maxRecDepth 10000

/-- Linnik's conclusion, with an explicit exponent in terms of the effective
anti-concentration exponent, using the manuscript's symmetry argument. -/
theorem linnik_from_anti_concentration (A : ℕ → ℕ) (hA : AntiConcentrationBounds A) :
    ∀ q : ℕ,2≤q → ∀ a : ℤ,IsCoprime a (q:ℤ) →
      ∃ p : ℕ,p.Prime ∧ p≤q^linnikCandidateExponent (A 7) ∧ Int.ModEq q (p:ℤ) a := by
  intro q hq a ha
  letI : NeZero q := ⟨by omega⟩
  let B := linnikB (A 7)
  let k := linnikSieveIndex (A 7)
  let Y := q^B
  let Z : ℝ := (q:ℝ)^(B*B)
  have hBk : B=170*k := linnikB_eq_sieve_index (A 7)
  have hk : 1≤k := linnikSieveIndex_pos (A 7)
  obtain ⟨hqY,hY,hYZ,hZ1,hL,hlY,hlogs,hφY,hAZ⟩ := linnik_cutoffs (A 7) q hq
  change q≤Y at hqY
  change 2≤Y at hY
  change (Y:ℝ)≤Z at hYZ
  change 1≤Z at hZ1
  change (B:ℝ)≤Real.log Z at hL
  change Real.log (Y:ℝ)=Real.log Z/B at hlY
  change 1+Real.log (Real.log Z)-Real.log (Real.log (Y:ℝ))=1+Real.log (B:ℝ) at hlogs
  have hBbig : (10:ℝ)^60≤B := by exact_mod_cast (linnikB_large (A 7)).1
  have hB0 : (0:ℝ)<B := by linarith only [hBbig]
  have hlarge : (10:ℝ)^9≤Real.log Z := by linarith only [hBbig,hL]
  have hL0 : 0≤Real.log Z := Real.log_nonneg hZ1
  have herror : (10:ℝ)^46*Real.log (Y:ℝ)≤Real.log Z/1000000 := by
    have hh := mul_le_mul_of_nonneg_right (linnik_constant_error (A 7)) hL0
    rw [hlY]
    convert hh using 1 <;> ring
  have hBT : (10:ℝ)^42*Real.log (Y:ℝ)*
      (1+Real.log (Real.log Z)-Real.log (Real.log (Y:ℝ)))≤Real.log Z/1000000 := by
    rw [hlogs,hlY]
    have hh := mul_le_mul_of_nonneg_right (linnik_logarithmic_error (A 7)) hL0
    have hlogB : 0≤1+Real.log (B:ℝ) := by
      have := Real.log_nonneg (show (1:ℝ)≤B by linarith only [hBbig])
      linarith
    have he : (10:ℝ)^42*(Real.log Z/B)*(1+Real.log (B:ℝ))≤
        (10:ℝ)^46*(1+Real.log (B:ℝ))/(B:ℝ)*Real.log Z := by
      have hp : 0≤(Real.log Z/B)*(1+Real.log (B:ℝ)) := mul_nonneg (div_nonneg hL0 hB0.le) hlogB
      have hc := mul_le_mul_of_nonneg_right (show (10:ℝ)^42≤10^46 by norm_num) hp
      convert hc using 1 <;> ring
    exact he.trans (by convert hh using 1 <;> ring)
  have hau : IsUnit (a:ZMod q) := by
    have hh := ha.map (Int.castRingHom (ZMod q))
    simpa only [Int.coe_castRingHom,Int.cast_natCast,ZMod.natCast_self,isCoprime_zero_right] using hh
  obtain ⟨u,hu⟩ := hau
  by_contra hno
  apply linnik_contradiction_at_cutoff A hA q k hq hk Z
    (by simpa only [← hBk] using hYZ) hAZ hlarge
    (by simpa only [← hBk] using herror)
    (by simpa only [← hBk] using hBT) u
  intro p hp hpZ hpu
  apply hno
  refine ⟨p,hp,?_,?_⟩
  · have hpow : Z^3=((q^linnikCandidateExponent (A 7):ℕ):ℝ) := by
      simp only [Z,linnikCandidateExponent,← pow_mul,Nat.cast_pow]
      exact congrArg (fun n : ℕ => (q:ℝ)^n) (Nat.mul_comm (B*B) 3)
    rw [hpow] at hpZ
    exact_mod_cast hpZ
  · apply (ZMod.intCast_eq_intCast_iff _ _ q).mp
    have hh := (ZMod.natCast_eq_natCast_iff p (u:ZMod q).val q).mpr hpu
    simpa only [Int.cast_natCast,ZMod.natCast_zmod_val,hu] using hh

theorem linnik_of_effectiveAntiConcentration (h : EffectiveAntiConcentration) : Linnik := by
  obtain ⟨A,hcomp,hA⟩ := h
  exact ⟨linnikCandidateExponent (A 7),linnik_from_anti_concentration A hA⟩

end MissingLinnik


import MissingLinnik.LinnikParameters
import MissingLinnik.RealRoughSymmetry

namespace MissingLinnik
set_option maxRecDepth 10000

/-- The real cutoffs used in the final application. -/
theorem linnik_cutoffs (a q : ℕ) (hq : 2≤q) :
    let B := linnikB a
    let Y := q^B
    let Z : ℝ := (q:ℝ)^(B*B)
    q≤Y ∧ 2≤Y ∧ (Y:ℝ)≤Z ∧ 1≤Z ∧
    (B:ℝ)≤Real.log Z ∧ Real.log (Y:ℝ)=Real.log Z/B ∧
    1+Real.log (Real.log Z)-Real.log (Real.log (Y:ℝ))=1+Real.log (B:ℝ) ∧
    (q.totient:ℝ)≤Y ∧ (q:ℝ)^a≤Z := by
  dsimp only
  let B := linnikB a
  have hBbig := (linnikB_large a).1
  have hB2 : 2≤B := by dsimp [B]; omega
  have hB0 : (0:ℝ)<B := by exact_mod_cast (show 0<B by omega)
  have hB2r : (2:ℝ)≤B := by exact_mod_cast hB2
  have hq0 : (0:ℝ)<q := by exact_mod_cast (show 0<q by omega)
  have hq1 : (1:ℝ)≤q := by exact_mod_cast (show 1≤q by omega)
  have hlogq := log_nat_ge_half q hq
  have hqY : q≤q^B := (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hYZ : ((q^B:ℕ):ℝ)≤(q:ℝ)^(B*B) := by
    rw [Nat.cast_pow]
    exact pow_le_pow_right₀ hq1 (by nlinarith only [hB2])
  have hZ1 : (1:ℝ)≤(q:ℝ)^(B*B) := one_le_pow₀ hq1
  have hlZ : Real.log ((q:ℝ)^(B*B))=(B:ℝ)^2*Real.log q := by rw [Real.log_pow,Nat.cast_mul,pow_two]
  have hlY : Real.log ((q^B:ℕ):ℝ)=(B:ℝ)*Real.log q := by rw [Nat.cast_pow,Real.log_pow]
  have hL : (B:ℝ)≤Real.log ((q:ℝ)^(B*B)) := by
    rw [hlZ]
    have hm := mul_le_mul_of_nonneg_left hlogq (sq_nonneg (B:ℝ))
    have hn := mul_nonneg hB0.le (show 0≤(B:ℝ)-2 by linarith)
    nlinarith only [hm,hn]
  refine ⟨hqY,hq.trans hqY,hYZ,hZ1,hL,?_,?_,?_,?_⟩
  · rw [hlY,hlZ]
    field_simp
    rfl
  · rw [hlY,hlZ,Real.log_mul (by positivity : (B:ℝ)^2≠0) (by linarith : Real.log (q:ℝ)≠0),
      Real.log_mul hB0.ne' (by linarith : Real.log (q:ℝ)≠0),Real.log_pow]
    norm_num only [Nat.cast_ofNat]
    ring
  · exact_mod_cast (Nat.totient_le q).trans hqY
  · apply pow_le_pow_right₀ hq1
    simpa only [pow_two] using linnikB_covers_anti_exponent a

end MissingLinnik


import MissingLinnik.SelbergIdentity
import Mathlib.Tactic.FieldSimp

namespace MissingLinnik

open Finset

/-- Selberg's square majorizes the coprimality indicator. -/
theorem selberg_square_majorant (P : ℕ) (D : Finset ℕ)
    (hD : ∀ d ∈ D, d ∣ P) (h1 : 1 ∈ D)
    (ρ : ℕ → ℝ) (hρ : ρ 1 = 1) (n : ℕ) :
    (if n.Coprime P then (1:ℝ) else 0) ≤
      (∑ d ∈ D, if d ∣ n then ρ d else 0)^2 := by
  classical
  split_ifs with hn
  · have he : (∑ d ∈ D, if d ∣ n then ρ d else 0) = 1 := by
      rw [Finset.sum_eq_single 1]
      · simp [hρ]
      · intro d hd hd1
        have hdn : ¬ d ∣ n := by
          intro hdn
          have hh : d ∣ 1 := by
            rw [← hn]
            exact Nat.dvd_gcd hdn (hD d hd)
          exact hd1 (Nat.dvd_one.mp hh)
        simp [hdn]
      · exact fun h => (h h1).elim
    rw [he]; norm_num
  · exact sq_nonneg _

/-- Exact expansion of the square into counts of multiples of least common
multiples; no distribution estimate is built into this identity. -/
theorem sum_selberg_square (A D : Finset ℕ) (ρ : ℕ → ℝ) :
    (∑ n ∈ A, (∑ d ∈ D, if d ∣ n then ρ d else 0)^2) =
      ∑ d ∈ D, ∑ e ∈ D, ρ d * ρ e *
        ((A.filter (fun n => d.lcm e ∣ n)).card:ℝ) := by
  classical
  simp only [pow_two, Finset.sum_mul, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro d hd
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e he
  rw [show ((A.filter (fun n => d.lcm e ∣ n)).card:ℝ) =
      ∑ n ∈ A, if d.lcm e ∣ n then (1:ℝ) else 0 by simp]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro n hn
  simp only [Nat.lcm_dvd_iff]
  split_ifs <;> simp_all [mul_comm]

/-- The upper-bound square with an error at most one for each progression
count, exactly the first inequality in the manuscript's sieve appendix. -/
theorem selberg_square_bound (A D : Finset ℕ) (P : ℕ)
    (hD : ∀ d ∈ D, d ∣ P) (h1 : 1 ∈ D)
    (ρ : ℕ → ℝ) (hρ : ρ 1 = 1) (t : ℝ)
    (hcount : ∀ d ∈ D, ∀ e ∈ D,
      |((A.filter (fun n => d.lcm e ∣ n)).card:ℝ) - t/(d.lcm e)| ≤ 1) :
    ((A.filter (fun n => n.Coprime P)).card:ℝ) ≤
      t*(∑ d ∈ D, ∑ e ∈ D, ρ d * ρ e / (d.lcm e)) +
        (∑ d ∈ D, |ρ d|)^2 := by
  classical
  have hmajor : ((A.filter (fun n => n.Coprime P)).card:ℝ) ≤
      ∑ n ∈ A, (∑ d ∈ D, if d ∣ n then ρ d else 0)^2 := by
    calc
      _ = ∑ n ∈ A, if n.Coprime P then (1:ℝ) else 0 := by simp
      _ ≤ _ := Finset.sum_le_sum (fun n _ => selberg_square_majorant P D hD h1 ρ hρ n)
  rw [sum_selberg_square] at hmajor
  have ht (d : ℕ) (hd : d ∈ D) (e : ℕ) (he : e ∈ D) :
      ρ d*ρ e*((A.filter (fun n => d.lcm e ∣ n)).card:ℝ) ≤
        t*(ρ d*ρ e/(d.lcm e)) + |ρ d| *|ρ e| := by
    have hh := mul_le_mul_of_nonneg_left (hcount d hd e he) (abs_nonneg (ρ d*ρ e))
    have hl := le_abs_self (ρ d*ρ e*
      (((A.filter (fun n => d.lcm e ∣ n)).card:ℝ)-t/(d.lcm e)))
    simp only [abs_mul] at hl hh
    have heq : ρ d*ρ e*(t/(d.lcm e)) = t*(ρ d*ρ e/(d.lcm e)) := by ring
    nlinarith only [hh,hl,heq]
  have hs := Finset.sum_le_sum (fun d hd => Finset.sum_le_sum (fun e he => ht d hd e he))
  have heq : (∑ d ∈ D, ∑ e ∈ D, (t*(ρ d*ρ e/(d.lcm e)) + |ρ d| *|ρ e|)) =
      t*(∑ d ∈ D, ∑ e ∈ D, ρ d*ρ e/(d.lcm e))+(∑ d ∈ D, |ρ d|)^2 := by
    simp only [Finset.sum_add_distrib, ← Finset.mul_sum, pow_two, Finset.sum_mul]
  exact hmajor.trans (heq ▸ hs)

end MissingLinnik


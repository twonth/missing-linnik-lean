import Mathlib.NumberTheory.Zsqrtd.Basic
import Mathlib.Tactic.Ring
import Lean.Elab.Tactic.Omega

namespace MissingLinnik

/-- Taking the quadratic norm doubles the exponent of an integer row factor. -/
theorem prime_power_dvd_quadratic_norm {d : ℤ} (p h : ℕ) (Δ : Zsqrtd d)
    (hΔ : (p : Zsqrtd d) ^ h ∣ Δ) :
    (p : ℤ) ^ (2 * h) ∣ Δ.norm := by
  obtain ⟨u, hu⟩ := hΔ
  refine ⟨u.norm, ?_⟩
  rw [hu, Zsqrtd.norm_mul]
  congr 1
  rw [← Nat.cast_pow, Zsqrtd.norm_natCast, Nat.cast_pow, ← pow_add]
  congr 1
  omega

/-- A nonzero quadratic integer has positive absolute norm when d is nonsquare. -/
theorem quadratic_norm_natAbs_pos {d : ℤ}
    (hd : ∀ n : ℤ, d ≠ n * n) (Δ : Zsqrtd d) (hΔ : Δ ≠ 0) :
    0 < Δ.norm.natAbs := by
  exact Int.natAbs_pos.mpr ((Zsqrtd.norm_eq_zero hd Δ).not.mpr hΔ)

end MissingLinnik

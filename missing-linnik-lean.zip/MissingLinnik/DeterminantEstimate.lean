import MissingLinnik.RectangleSums
import MissingLinnik.WeightedFloorBound
import Mathlib.NumberTheory.Chebyshev
import Mathlib.Tactic.FieldSimp

namespace MissingLinnik

theorem log_factorial_le (n : ℕ) : Real.log (n.factorial : ℝ) ≤ n * Real.log n := by
  have hh : (n.factorial : ℝ) ≤ (n : ℝ)^n := by exact_mod_cast Nat.factorial_le_pow n
  have hl := Real.log_le_log (show (0:ℝ) < n.factorial by exact_mod_cast Nat.factorial_pos n) hh
  simpa only [Real.log_pow] using hl

theorem prime_log_sum_le (P : Finset ℕ) (S : ℕ)
    (hp : ∀ p ∈ P, p.Prime) (hS : ∀ p ∈ P, p ≤ S) :
    (∑ p ∈ P, Real.log p) ≤ Real.log 4 * S := by
  have hsub : P ⊆ Nat.primesLE S := by
    intro p h
    exact Nat.mem_primesLE.mpr ⟨hS p h, hp p h⟩
  have hh := Finset.sum_le_sum_of_subset_of_nonneg (f := fun p : ℕ => Real.log p) hsub
    (fun p hp _ => Real.log_nonneg (by exact_mod_cast (Nat.mem_primesLE.mp hp).2.one_le))
  exact hh.trans (by simpa only [Chebyshev.theta_eq_sum_primesLE_log] using
    Chebyshev.theta_le_log4_mul_x (x := (S : ℝ)) (by positivity))

/-- A common, explicit numerical consequence of either determinant construction.
This form isolates all the parameters needed in the final effective estimates. -/
theorem normalized_determinant_bound (R S T : ℕ) (B M θ : ℝ)
    (hR : 2 ≤ R) (hT : 0 < T) (hB : 1 ≤ B)
    (hbound : (T : ℝ) * R * (R - 1) * M ≤
      2 * Real.log ((R * S).factorial : ℝ) +
      2 * ∑ i : Fin R × Fin S, ((S : ℝ) * Real.log R +
        ((i.1.val + i.2.val : ℕ) : ℝ) * Real.log B) + 2 * T * R * θ) :
    M ≤ ((S : ℝ) / T) *
      (((R : ℝ) + S) / (R - 1) * Real.log B +
        2 * S / (R - 1) * Real.log R + 2 * Real.log (R * S) / (R - 1)) +
      2 * θ / (R - 1) := by
  have hf := log_factorial_le (R*S)
  push_cast at hf
  have hs := rectangular_log_bound R S B hB
  have hr : (0 : ℝ) < R := by exact_mod_cast (show 0 < R by omega)
  have hr1 : (0 : ℝ) < R - 1 := by
    have : (2 : ℝ) ≤ R := by exact_mod_cast hR
    linarith
  have ht : (0 : ℝ) < T := by exact_mod_cast hT
  apply (mul_le_mul_iff_right₀ (show (0:ℝ) < T * R * (R-1) by positivity)).mp
  have he : (((S : ℝ) / T) *
      (((R : ℝ) + S) / (R - 1) * Real.log B +
        2 * S / (R - 1) * Real.log R + 2 * Real.log (R * S) / (R - 1)) +
      2 * θ / (R - 1)) * (T * R * (R-1)) =
      2 * (R*S) * Real.log (R*S) + 2 * S * (R*S) * Real.log R +
      (R*S) * (R+S) * Real.log B + 2 * T * R * θ := by
    field_simp
    <;> ring
  nlinarith [he]

end MissingLinnik

import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Data.Nat.Prime.Basic

namespace MissingLinnik

/-- Combining distinct-prime divisibilities and taking logarithms. -/
theorem sum_valuation_log_le (s : Finset ℕ) (e : ℕ → ℕ) (D : ℕ)
    (hD : 0 < D) (hprime : ∀ p ∈ s, p.Prime)
    (hdiv : ∀ p ∈ s, p ^ e p ∣ D) :
    (∑ p ∈ s, (e p : ℝ) * Real.log p) ≤ Real.log D := by
  have hprod : (∏ p ∈ s, p ^ e p) ∣ D := by
    apply Finset.prod_dvd_of_isRelPrime _ hdiv
    intro p hp q hq hpq
    apply Nat.coprime_iff_isRelPrime.mp
    exact ((hprime p hp).coprime_iff_not_dvd.mpr
      (fun hd => hpq ((hprime q hq).eq_one_or_self_of_dvd p hd |>.resolve_left
        (hprime p hp).ne_one))).pow _ _
  have hpos : (0 : ℝ) < (∏ p ∈ s, p ^ e p : ℕ) := by
    exact_mod_cast Finset.prod_pos (fun p hp => pow_pos (hprime p hp).pos _)
  have hle : ((∏ p ∈ s, p ^ e p : ℕ) : ℝ) ≤ D := by
    exact_mod_cast Nat.le_of_dvd hD hprod
  have hl := Real.log_le_log hpos hle
  rw [Nat.cast_prod, Real.log_prod] at hl
  · simpa only [Nat.cast_pow, Real.log_pow] using hl
  · intro p hp
    exact_mod_cast pow_ne_zero _ (hprime p hp).ne_zero

end MissingLinnik

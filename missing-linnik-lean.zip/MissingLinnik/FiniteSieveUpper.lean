import MissingLinnik.SieveKernel
import MissingLinnik.BuchstabPartition

namespace MissingLinnik

open Finset

theorem sieveH_tail_general (P R z : ℕ) (hP : Squarefree P) (hR : 1 ≤ R)
    (hz : 2 ≤ z) (hpz : ∀ p ∈ P.primeFactors, p ≤ z) :
    fullSieveH P-sieveH P R ≤ fullSieveH P*Real.exp (16-Real.log R/Real.log z) := by
  have hR0 : (0:ℝ) < R := by exact_mod_cast (show 0<R by omega)
  have hlz : 0 < Real.log (z:ℝ) := Real.log_pos (by exact_mod_cast (show 1<z by omega))
  have hh := sieveH_tail_rankin P R hR ((Real.log z)⁻¹) (by positivity)
  have ht := mul_le_mul_of_nonneg_left (rankin_euler_product_bound P z hP hz hpz)
    (Real.rpow_nonneg (Nat.cast_nonneg R) (-((Real.log z)⁻¹)))
  have he : (R:ℝ)^(-((Real.log z)⁻¹)) = Real.exp (-Real.log R/Real.log z) := by
    rw [Real.rpow_def_of_pos hR0]
    congr 1
    ring
  rw [he] at hh ht
  have he' : Real.exp (-Real.log (R:ℝ)/Real.log z)*(fullSieveH P*Real.exp 16) =
      fullSieveH P*Real.exp (16-Real.log R/Real.log z) := by
    rw [← mul_assoc,mul_comm (Real.exp (-Real.log (R:ℝ)/Real.log z)),mul_assoc,← Real.exp_add]
    congr 2
    ring
  exact hh.trans (he' ▸ ht)

theorem sieveH_inverse_general (P R z : ℕ) (hP : Squarefree P) (hR : 1 ≤ R)
    (hz : 2 ≤ z) (hpz : ∀ p ∈ P.primeFactors, p ≤ z)
    (hlevel : 17 ≤ Real.log (R:ℝ)/Real.log z) :
    1/sieveH P R ≤ (1+2*Real.exp (16-Real.log R/Real.log z))/fullSieveH P := by
  have hδ : Real.exp (16-Real.log (R:ℝ)/Real.log z) ≤ 1/2 := by
    apply (Real.exp_le_exp.mpr (show 16-Real.log (R:ℝ)/Real.log z ≤ 16-(17:ℕ) by norm_num; linarith)).trans
    exact exp_sixteen_sub_le_half 17 le_rfl
  exact inverse_truncation_bound _ _ _ (sieveH_pos P R hP.ne_zero hR)
    (fullSieveH_pos P hP.ne_zero) (Real.exp_pos _).le hδ
    (sieveH_tail_general P R z hP hR hz hpz)

theorem squarefree_prime_product (P : Finset ℕ) (hp : ∀ p ∈ P, p.Prime) :
    Squarefree (∏ p ∈ P, p) := by
  apply Finset.squarefree_prod_of_pairwise_isCoprime
  · intro p hpm l hlm hne
    exact Nat.coprime_iff_isRelPrime.mp ((Nat.coprime_primes (hp p hpm) (hp l hlm)).mpr hne)
  · exact fun p hpm => (hp p hpm).squarefree

theorem inverse_fullSieveH_eq_density (P : Finset ℕ) (hp : ∀ p ∈ P, p.Prime) :
    (fullSieveH (∏ p ∈ P, p))⁻¹ = sieveDensity P := by
  rw [fullSieveH_product _ (squarefree_prime_product P hp),Nat.primeFactors_prod hp]
  simp only [sieveDensity,← Finset.prod_inv_distrib,inv_inv]

/-- The optimized upper sieve for any finite set of primes bounded by z,
with a common truncation level R. -/
theorem finite_sieve_upper (N q b R z : ℕ) (P : Finset ℕ) (hq : 0 < q)
    (hR : 1 ≤ R) (hz : 2 ≤ z) (hp : ∀ p ∈ P, p.Prime)
    (hcop : ∀ p ∈ P, q.Coprime p) (hpz : ∀ p ∈ P, p ≤ z)
    (hlevel : 17 ≤ Real.log (R:ℝ)/Real.log z) :
    ((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => ∀ p ∈ P, ¬ p ∣ n)).card:ℝ) ≤
      ((N:ℝ)/q)*sieveDensity P*(1+2*Real.exp (16-Real.log R/Real.log z))+(R:ℝ)^4 := by
  let Q := ∏ p ∈ P, p
  have hQ := squarefree_prime_product P hp
  have hc : q.Coprime Q := Nat.coprime_prod_right_iff.mpr hcop
  have hh := selberg_progression_upper N q b Q R hq hQ hc hR
  have hi := sieveH_inverse_general Q R z hQ hR hz
    (by simpa only [Q,Nat.primeFactors_prod hp] using hpz) hlevel
  have he : (1+2*Real.exp (16-Real.log (R:ℝ)/Real.log z))/fullSieveH Q =
      sieveDensity P*(1+2*Real.exp (16-Real.log R/Real.log z)) := by
    rw [div_eq_mul_inv,inverse_fullSieveH_eq_density P hp,mul_comm]
  rw [he] at hi
  have ht := mul_le_mul_of_nonneg_left hi (show 0 ≤ (N:ℝ)/q by positivity)
  have he' : (N:ℝ)/(q*sieveH Q R) = ((N:ℝ)/q)*(1/sieveH Q R) := by ring
  rw [he'] at hh
  have hc' : (fun n => n.Coprime Q) = (fun n => ∀ p ∈ P, ¬p ∣ n) := by
    funext n
    exact propext (coprime_prime_product_iff P hp n)
  simp only [hc'] at hh
  nlinarith only [hh,ht]

end MissingLinnik

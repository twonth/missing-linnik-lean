import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.LinearAlgebra.Matrix.ToLin
import Mathlib.LinearAlgebra.Basis.VectorSpace

namespace MissingLinnik

open Matrix

theorem det_rectangular_mul {K m n : Type*} [CommRing K]
    [Fintype m] [Fintype n] [DecidableEq m]
    (A : Matrix m n K) (B : Matrix n m K) :
    (A * B).det = ∑ f : m → n, (∏ i, A i (f i)) * (B.submatrix f id).det := by
  classical
  have heq : A * B = fun i => ∑ j, A i j • B j := by
    ext i k
    simp [Matrix.mul_apply]
  rw [heq]
  change Matrix.detRowAlternating.toMultilinearMap (fun i => ∑ j, A i j • B j) = _
  rw [Matrix.detRowAlternating.toMultilinearMap.map_sum]
  apply Finset.sum_congr rfl
  intro f _
  exact Matrix.det_mul_column (fun i => A i (f i)) (B.submatrix f id)

theorem exists_nonzero_minor {K m n : Type*} [Field K]
    [Fintype m] [Fintype n] [DecidableEq m]
    (A : Matrix m n K) (hA : LinearIndependent K A.row) :
    ∃ f : m → n, (A.submatrix id f).det ≠ 0 := by
  classical
  obtain ⟨g, hg⟩ := A.vecMulLinear.exists_leftInverse_of_injective
    (LinearMap.ker_eq_bot.mpr (Matrix.vecMul_injective_iff.mpr hA))
  let B : Matrix n m K := fun j i => g (Pi.single j 1) i
  have hprod : A * B = 1 := by
    ext i k
    have hgi : g (A.row i) = Pi.single i 1 := by
      have hh := LinearMap.congr_fun hg (Pi.single i 1)
      simpa using hh
    have hsum : A.row i = ∑ j, A i j • Pi.single j (1 : K) := by
      ext j
      simp [Matrix.row, Pi.single_apply]
    have hh := congrFun hgi k
    rw [hsum, map_sum] at hh
    change (∑ j, A i j * g (Pi.single j 1) k) = _
    simpa [Matrix.one_apply, Pi.single_apply, eq_comm] using hh
  by_contra hn
  push Not at hn
  have hz : (B.transpose * A.transpose).det = 0 := by
    rw [det_rectangular_mul]
    apply Finset.sum_eq_zero
    intro f _
    have heq : A.transpose.submatrix f id = (A.submatrix id f).transpose := rfl
    rw [heq, Matrix.det_transpose, hn f, mul_zero]
  rw [← Matrix.transpose_mul, hprod, Matrix.transpose_one, Matrix.det_one] at hz
  exact one_ne_zero hz

end MissingLinnik



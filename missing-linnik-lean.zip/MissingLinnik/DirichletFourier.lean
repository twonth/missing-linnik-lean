import MissingLinnik.FiniteFourier
import Mathlib.NumberTheory.DirichletCharacter.Orthogonality
import Mathlib.NumberTheory.MulChar.Lemmas

namespace MissingLinnik

open Classical

local instance complexEnoughRoots (n : ℕ) [NeZero n] : HasEnoughRootsOfUnity ℂ n :=
  HasEnoughRootsOfUnity.of_card_le (by rw [Complex.card_rootsOfUnity])

theorem dirichlet_unit_star {q : ℕ} [NeZero q] (χ : DirichletCharacter ℂ q)
    (u : (ZMod q)ˣ) : star (χ (u : ZMod q)) = χ ((u : ZMod q)⁻¹) := by
  rw [MulChar.star_apply', MulChar.inv_apply, Ring.inverse_unit, ZMod.inv_coe_unit]

theorem dirichlet_unit_orthogonality (q : ℕ) [NeZero q] (u v : (ZMod q)ˣ) :
    (∑ χ : DirichletCharacter ℂ q, star (χ (u : ZMod q)) * χ (v : ZMod q)) =
      if u = v then (q.totient : ℂ) else 0 := by
  simp_rw [dirichlet_unit_star]
  rw [DirichletCharacter.sum_char_inv_mul_char_eq ℂ u.isUnit]
  simp only [Units.val_inj]

noncomputable def residueCoefficient {q : ℕ} [NeZero q]
    (w : (ZMod q)ˣ → ℝ) (χ : DirichletCharacter ℂ q) : ℂ :=
  finiteCoefficient (fun χ u => χ (u : ZMod q)) w χ

theorem residue_parseval {q : ℕ} [NeZero q] (w : (ZMod q)ˣ → ℝ) :
    (∑ χ : DirichletCharacter ℂ q, ‖residueCoefficient w χ‖^2) =
      (q.totient : ℝ) * ∑ u, (w u)^2 := by
  exact finite_parseval _ w q.totient (by
    intro u v
    simpa only [Complex.ofReal_natCast] using dirichlet_unit_orthogonality q u v)

theorem residue_energy_bound {q : ℕ} [NeZero q] (w : (ZMod q)ˣ → ℝ) (K : ℝ)
    (hw : ∀ u, 0 ≤ w u) (hmax : ∀ u, q.totient * w u ≤ K) :
    (∑ χ : DirichletCharacter ℂ q, ‖residueCoefficient w χ‖^2) ≤ K * ∑ u, w u := by
  exact finite_energy_bound _ w q.totient K (by positivity) hw hmax (by
    intro u v
    simpa only [Complex.ofReal_natCast] using dirichlet_unit_orthogonality q u v)

theorem residueCoefficient_principal {q : ℕ} [NeZero q] (w : (ZMod q)ˣ → ℝ) :
    residueCoefficient w 1 = ((∑ u, w u : ℝ) : ℂ) := by
  simp [residueCoefficient, finiteCoefficient, MulChar.one_apply]

theorem residueCoefficient_conjugate {q : ℕ} [NeZero q] (w : (ZMod q)ˣ → ℝ)
    (χ : DirichletCharacter ℂ q) :
    residueCoefficient w (star χ) = star (residueCoefficient w χ) := by
  exact finiteCoefficient_star (fun c u => c (u : ZMod q)) w star
    (fun c i => MulChar.star_apply c (i : ZMod q)) χ

/-- The exact triple-product orthogonality used before the manuscript's cubic
coefficient estimate. -/
theorem residue_cubic_identity {q : ℕ} [NeZero q]
    (w : (ZMod q)ˣ → ℝ) (a : (ZMod q)ˣ) :
    (∑ χ : DirichletCharacter ℂ q, star (χ (a : ZMod q)) * (residueCoefficient w χ)^3) =
      (q.totient : ℂ) * ∑ u, ∑ v, ∑ z,
        if u*v*z = a then (w u : ℂ)*w v*w z else 0 := by
  rw [show residueCoefficient w = finiteCoefficient (fun χ u => χ (u : ZMod q)) w by rfl,
    finite_cubic_identity]
  simp_rw [dirichlet_unit_star, ← map_mul,
    DirichletCharacter.sum_characters_eq ℂ, ZMod.inv_mul_eq_one_of_isUnit a.isUnit]
  simp only [← Units.val_mul, Units.val_inj]
  simp [Finset.mul_sum, eq_comm, mul_comm, mul_assoc]

end MissingLinnik

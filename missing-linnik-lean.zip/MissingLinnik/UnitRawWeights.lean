import MissingLinnik.WeightedRoughSymmetry
import MissingLinnik.UnitPairWeights
import MissingLinnik.PrimePowerErrors
import MissingLinnik.ResidueNormalization

namespace MissingLinnik
open Finset ArithmeticFunction
open scoped Classical

theorem logWeight_nonneg (f : ArithmeticFunction ℝ) (hf : ∀ n,0≤f n) :
    ∀ n,0≤logWeight f n := by
  intro n
  by_cases hn : n=0
  · simp [hn]
  · exact mul_nonneg (Real.log_nonneg (by exact_mod_cast (show 1≤n by omega))) (hf n)

theorem logWeight_support_coprime {q : ℕ} (f : ArithmeticFunction ℝ)
    (hf : ∀ n,f n≠0 → n.Coprime q) (n : ℕ) (hn : logWeight f n≠0) : n.Coprime q := by
  exact hf n (right_ne_zero_of_mul hn)

theorem unitArithmeticMass_log_le {q : ℕ} (f : ArithmeticFunction ℝ)
    (hf : ∀ n,0≤f n) (x : ℝ) (hx : 1≤x) (u : (ZMod q)ˣ) :
    unitArithmeticMass (logWeight f) x u≤Real.log x*unitArithmeticMass f x u := by
  unfold unitArithmeticMass arithmeticClassSum
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro n hn
  have hn1 := (mem_Icc.mp (mem_filter.mp hn).1).1
  have hn0 : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hnx : (n:ℝ)≤x := (show (n:ℝ)≤Nat.floor x by exact_mod_cast (mem_Icc.mp (mem_filter.mp hn).1).2).trans (Nat.floor_le (by linarith))
  have hh := mul_le_mul_of_nonneg_right (Real.log_le_log hn0 hnx) (div_nonneg (hf n) hn0.le)
  simpa only [logWeight_apply,mul_div_assoc] using hh

theorem rough_unit_mass_total {q : ℕ} [NeZero q] (Y : ℕ) (hqY : q≤Y) (x : ℝ) :
    (∑ u : (ZMod q)ˣ,unitArithmeticMass (roughRestriction Y vonMangoldt) x u)=roughMangoldtMass Y x := by
  rw [unitArithmeticMass_total _ (roughRestriction_support_coprime q Y (NeZero.pos q) hqY)]
  simp only [roughRestriction_mangoldt_div]
  unfold roughMangoldtMass
  rw [sum_Icc_zero_eq_one (roughMangoldtCoefficient_zero Y)]

theorem unit_two_mass_weighted {q : ℕ} [NeZero q] (f : ArithmeticFunction ℝ)
    (hf : ∀ n,f n≠0 → n.Coprime q) (x : ℝ) (H : (ZMod q)ˣ → ℝ) :
    (∑ u,unitArithmeticMass (logWeight f) x u*H u)+
      (∑ u,∑ v,unitPairMass f x u v*H (u*v))=
        ∑ u,unitArithmeticMass (twoKernel f) x u*H u := by
  rw [← unitPairMass_weighted_sum f hf,← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro u hu
  simp only [twoKernel,unitArithmeticMass,arithmeticClassSum_add,add_mul]

theorem rough_unit_two_total {q : ℕ} [NeZero q] (Y : ℕ) (hqY : q≤Y) (x : ℝ) :
    (∑ u : (ZMod q)ˣ,unitArithmeticMass (logWeight (roughRestriction Y vonMangoldt)) x u)+
      (∑ u : (ZMod q)ˣ,∑ v,unitPairMass (roughRestriction Y vonMangoldt) x u v)=roughQ 1 0 Y x := by
  have hf := roughRestriction_support_coprime q Y (NeZero.pos q) hqY
  have ht : ∀ n,twoKernel (roughRestriction Y vonMangoldt) n≠0 → n.Coprime q := by
    intro n hn
    by_cases hl : logWeight (roughRestriction Y vonMangoldt) n=0
    · apply arithmetic_mul_support_coprime _ _ hf hf n
      simpa only [twoKernel,ArithmeticFunction.add_apply,hl,zero_add] using hn
    · exact logWeight_support_coprime _ hf n hl
  have hh := unit_two_mass_weighted (roughRestriction Y vonMangoldt) hf x (fun _ : (ZMod q)ˣ => 1)
  simp only [mul_one] at hh
  rw [hh,unitArithmeticMass_total _ ht,roughQ_eq_arithmeticClassSum]
  simp only [arithmeticClassSum,Nat.ModEq,Nat.mod_one,Finset.filter_true]

theorem rough_negative_unit_mass {q : ℕ} [NeZero q] (Y : ℕ) (hqY : q≤Y)
    (x : ℝ) (ψ : DirichletCharacter ℝ q) :
    (∑ u ∈ univ.filter (fun u : (ZMod q)ˣ => ψ (u:ZMod q)=-1),
      unitArithmeticMass (roughRestriction Y vonMangoldt) x u)=negativeRoughMass ψ Y x := by
  have hf := roughRestriction_support_coprime q Y (NeZero.pos q) hqY
  rw [Finset.sum_filter]
  have he : (∑ u : (ZMod q)ˣ,if ψ (u:ZMod q)=-1 then unitArithmeticMass (roughRestriction Y vonMangoldt) x u else 0)=
      ∑ u : (ZMod q)ˣ,unitArithmeticMass (roughRestriction Y vonMangoldt) x u*(if ψ (u:ZMod q)=-1 then 1 else 0) := by
    apply Finset.sum_congr rfl
    intro u hu
    split_ifs <;> simp
  rw [he,unitArithmeticMass_weighted_sum _ hf]
  unfold negativeRoughMass
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hfn : roughRestriction Y vonMangoldt n=0
  · simp [hfn]
  · rw [unitResidue_coe q n (hf n hfn)]
    split_ifs <;> simp

theorem rough_signed_two_bound (q k : ℕ) [NeZero q] (hq : 2≤q) (hk : 1≤k)
    (x : ℝ) (hx : 1≤x) (ψ : DirichletCharacter ℝ q) (hψ : ψ≠1) :
    (∑ u : (ZMod q)ˣ,unitArithmeticMass (logWeight (roughRestriction (q^(170*k)) vonMangoldt)) x u*ψ (u:ZMod q))+
      (∑ u : (ZMod q)ˣ,∑ v,unitPairMass (roughRestriction (q^(170*k)) vonMangoldt) x u v*(ψ (u:ZMod q)*ψ (v:ZMod q)))≤
        (10:ℝ)^42*Real.log ((q^(170*k):ℕ):ℝ)*Real.log x := by
  have hqY : q≤q^(170*k) := (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hf := roughRestriction_support_coprime q (q^(170*k)) (NeZero.pos q) hqY
  have hh := unit_two_mass_weighted (roughRestriction (q^(170*k)) vonMangoldt) hf x (fun u : (ZMod q)ˣ => ψ (u:ZMod q))
  simp only [Units.val_mul,map_mul] at hh
  rw [hh]
  have he : (∑ u : (ZMod q)ˣ,unitArithmeticMass (twoKernel (roughRestriction (q^(170*k)) vonMangoldt)) x u*ψ (u:ZMod q))=
      ∑ u : (ZMod q)ˣ,(roughQ q (u:ZMod q).val (q^(170*k)) x-(Real.log x)^2/q.totient)*ψ (u:ZMod q) := by
    simp only [sub_mul,Finset.sum_sub_distrib,← Finset.mul_sum,real_character_sum_units ψ hψ,mul_zero,sub_zero,roughQ_eq_arithmeticClassSum,unitArithmeticMass]
  rw [he]
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (by omega : 0<q)
  calc
    _ ≤ ∑ u : (ZMod q)ˣ, (10:ℝ)^42*Real.log ((q^(170*k):ℕ):ℝ)*Real.log x/q.totient := by
      apply Finset.sum_le_sum
      intro u hu
      have hb := rough_two_real q k (u:ZMod q).val hq hk (ZMod.val_coe_unit_coprime u) x hx
      have habs : |ψ (u:ZMod q)|=1 := by
        rcases real_character_quadratic ψ (u:ZMod q) with hz | hp | hn
        · exact ((MulChar.apply_ne_zero_iff.mpr u.isUnit) hz).elim
        · simp [hp]
        · simp [hn]
      exact (le_abs_self _).trans (by rw [abs_mul,habs,mul_one]; exact hb)
    _ = _ := by simp only [Finset.sum_const,Finset.card_univ,ZMod.card_units_eq_totient,nsmul_eq_mul]; field_simp

end MissingLinnik




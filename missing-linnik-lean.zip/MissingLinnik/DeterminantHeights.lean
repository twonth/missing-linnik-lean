import MissingLinnik.JetDeterminant
import MissingLinnik.Frobenius
import MissingLinnik.QuadraticNorm

namespace MissingLinnik

def greenHeight (p S : ℕ) (i : ℕ × ℕ) : ℕ := min (i.1 / p) (S - 1 - i.2)

theorem greenHeight_mul_le (p S : ℕ) (i : ℕ × ℕ) : p * greenHeight p S i ≤ i.1 := by
  exact (Nat.mul_le_mul_left p (min_le_left _ _)).trans (Nat.mul_div_le i.1 p)

theorem greenHeight_add_lt (p S : ℕ) (i : ℕ × ℕ) (hs : i.2 < S) :
    i.2 + greenHeight p S i < S := by
  have h := min_le_right (i.1 / p) (S - 1 - i.2)
  unfold greenHeight
  omega

def vanDijkHeight (p T : ℕ) (i : ℕ × ℕ) : ℕ := if i.2 < T then i.1 / p else 0

theorem vanDijkHeight_mul_le (p T : ℕ) (i : ℕ × ℕ) : p * vanDijkHeight p T i ≤ i.1 := by
  unfold vanDijkHeight
  split_ifs
  · exact Nat.mul_div_le _ _
  · simp

theorem vanDijkHeight_add_lt (p m T S : ℕ) (i : ℕ × ℕ)
    (hp : 0 < p) (hr : i.1 < p * m) (hs : i.2 < S) (hT : T + m ≤ S) :
    i.2 + vanDijkHeight p T i < S := by
  have hd : i.1 / p < m := (Nat.div_lt_iff_lt_mul hp).mpr (by simpa [mul_comm] using hr)
  unfold vanDijkHeight
  split_ifs <;> omega

/-- Green's unrestricted choice of row heights gives simultaneous divisibility
at every inert odd prime. -/
theorem green_norm_dvd (p R S : ℕ) (d : ℤ) [Fact p.Prime]
    (hp2 : p ≠ 2) (hd : legendreSym p d = -1)
    (z : (Fin R × Fin S) → Zsqrtd d) (j : (Fin R × Fin S) → ℕ) :
    (p : ℤ) ^ (2 * ∑ i : Fin R × Fin S, greenHeight p S (i.1.val, i.2.val)) ∣
      ((Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c) i.1.val i.2.val)).det).norm := by
  apply prime_power_dvd_quadratic_norm
  apply prime_power_dvd_jet_determinant p R S z (fun c => star (z c)) j
    (fun i => greenHeight p S (i.1.val, i.2.val)) (Nat.Prime.pos Fact.out)
  · intro i; exact greenHeight_mul_le p S _
  · intro i; exact greenHeight_add_lt p S (i.1.val, i.2.val) i.2.isLt
  · intro c; exact inert_frobenius_congruence p hp2 d hd (z c)

theorem vanDijkHeight_sum (p R S T : ℕ) (hT : T ≤ S) :
    (∑ i : Fin R × Fin S, vanDijkHeight p T (i.1.val, i.2.val)) =
      T * ∑ r ∈ Finset.range R, r / p := by
  have hf : (Finset.range S).filter (fun s => s < T) = Finset.range T := by
    ext s
    simp only [Finset.mem_filter, Finset.mem_range]
    omega
  have hinner (r : Fin R) : (∑ s : Fin S, if s.val < T then r.val / p else 0) = T * (r.val / p) := by
    rw [Fin.sum_univ_eq_sum_range (fun s => if s < T then r.val / p else 0) S]
    rw [← Finset.sum_filter, hf]
    simp
  rw [Fintype.sum_prod_type]
  change (∑ r : Fin R, ∑ s : Fin S, if s.val < T then r.val / p else 0) = _
  simp_rw [hinner]
  rw [Fin.sum_univ_eq_sum_range (fun r => T * (r / p)) R, Finset.mul_sum]
theorem vanDijk_norm_dvd (p m R S T : ℕ) (d : ℤ) [Fact p.Prime]
    (hp2 : p ≠ 2) (hd : legendreSym p d = -1) (hR : R ≤ p * m) (hT : T + m ≤ S)
    (z : (Fin R × Fin S) → Zsqrtd d) (j : (Fin R × Fin S) → ℕ) :
    (p : ℤ) ^ (2 * (T * ∑ r ∈ Finset.range R, r / p)) ∣
      ((Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c) i.1.val i.2.val)).det).norm := by
  rw [← vanDijkHeight_sum p R S T (by omega)]
  apply prime_power_dvd_quadratic_norm
  apply prime_power_dvd_jet_determinant p R S z (fun c => star (z c)) j
    (fun i => vanDijkHeight p T (i.1.val, i.2.val)) (Nat.Prime.pos Fact.out)
  · intro i; exact vanDijkHeight_mul_le p T _
  · intro i
    exact vanDijkHeight_add_lt p m T S (i.1.val, i.2.val)
      (Nat.Prime.pos Fact.out) (lt_of_lt_of_le i.1.isLt hR) i.2.isLt hT
  · intro c; exact inert_frobenius_congruence p hp2 d hd (z c)

end MissingLinnik




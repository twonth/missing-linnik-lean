import MissingLinnik.ResultantDegree
import Mathlib.RingTheory.Polynomial.GaussLemma
import Mathlib.FieldTheory.Separable
import Mathlib.RingTheory.Localization.FractionRing

namespace MissingLinnik.Green

theorem specialization_ne_zero {K : Type*} [Field K]
    (f : Polynomial (Polynomial K)) (hf : Irreducible f) (hdeg : f.natDegree ≠ 0) (w : K) :
    f.map (Polynomial.evalRingHom w) ≠ 0 := by
  intro hz
  apply Polynomial.not_isUnit_X_sub_C w
  apply hf.isPrimitive hdeg
  rw [Polynomial.C_dvd_iff_dvd_coeff]
  intro i
  rw [Polynomial.dvd_iff_isRoot]
  have hi := congrArg (fun p : Polynomial K => p.coeff i) hz
  simpa only [Polynomial.coeff_map, Polynomial.coeff_zero,
    Polynomial.coe_evalRingHom, Polynomial.IsRoot] using hi

theorem derivative_resultant_ne_zero {K : Type*} [Field K] [CharZero K]
    (f : Polynomial (Polynomial K)) (hf : Irreducible f) (hdeg : f.natDegree ≠ 0) :
    f.resultant f.derivative ≠ 0 := by
  let L := FractionRing (Polynomial K)
  let φ : Polynomial K →+* L := algebraMap (Polynomial K) L
  have hφ : Function.Injective φ := IsFractionRing.injective (Polynomial K) L
  have hi : Irreducible (f.map φ) :=
    (hf.isPrimitive hdeg).irreducible_iff_irreducible_map_fraction_map.mp hf
  have hres := Polynomial.resultant_ne_zero (f.map φ) (f.map φ).derivative hi.separable
  intro hz
  apply hres
  rw [Polynomial.derivative_map]
  rw [Polynomial.natDegree_map_eq_of_injective hφ,
    Polynomial.natDegree_map_eq_of_injective hφ, Polynomial.resultant_map_map, hz, map_zero]

theorem specialization_multiplicity_le {K : Type*} [Field K] [CharZero K]
    (f : Polynomial (Polynomial K)) (hf : Irreducible f) (hdeg : f.natDegree ≠ 0) (z w : K) :
    (f.map (Polynomial.evalRingHom w)).rootMultiplicity z ≤
      1 + (f.resultant f.derivative).rootMultiplicity w :=
  green_resultant_multiplicity f z w (specialization_ne_zero f hf hdeg w)
    (derivative_resultant_ne_zero f hf hdeg)

end MissingLinnik.Green


import MissingLinnik.GreenIrreducible
import Mathlib.Algebra.Polynomial.Roots

namespace MissingLinnik.Green
open Classical

theorem sum_rootMultiplicity_le {K : Type*} [Field K]
    (f : Polynomial K) (s : Finset K) :
    (∑ x ∈ s, f.rootMultiplicity x) ≤ f.natDegree := by
  classical
  have he : (∑ x ∈ s ∩ f.roots.toFinset, f.roots.count x) = ∑ x ∈ s, f.roots.count x := by
    apply Finset.sum_subset Finset.inter_subset_left
    intro x hx hnot
    have hn : x ∉ f.roots := by
      intro hm
      exact hnot (Finset.mem_inter.mpr ⟨hx, Multiset.mem_toFinset.mpr hm⟩)
    exact Multiset.count_eq_zero.mpr hn
  simp_rw [← Polynomial.count_roots]
  rw [← he]
  exact (Finset.sum_le_sum_of_subset Finset.inter_subset_right).trans
    ((Multiset.toFinset_sum_count_eq f.roots).le.trans (Polynomial.card_roots' f))

theorem sum_rootMultiplicity_comp_le {K ι : Type*} [Field K] [Fintype ι]
    (f : Polynomial K) (w : ι → K) (hw : Function.Injective w) :
    (∑ i, f.rootMultiplicity (w i)) ≤ f.natDegree := by
  classical
  have h := sum_rootMultiplicity_le f (Finset.univ.image w)
  simpa only [Finset.sum_image (fun a _ b _ hab => hw hab)] using h

/-- Equation (3.6) of Green's argument. The zero-count hypothesis is isolated
here so it can be supplied by the grid's polynomial zero bound. -/
theorem irreducible_multiplicity_sum_bound {K ι : Type*} [Field K] [CharZero K] [Fintype ι]
    (f : Polynomial (Polynomial K)) (hf : Irreducible f) (hdeg : f.natDegree ≠ 0)
    (z w : ι → K) (hw : Function.Injective w) (J D : ℕ)
    (hcoeff : ∀ j, (f.coeff j).natDegree ≤ D)
    (hzero : (Finset.univ.filter (fun i => (f.map (Polynomial.evalRingHom (w i))).eval (z i) = 0)).card ≤
      J * (f.natDegree + D)) :
    (∑ i, (f.map (Polynomial.evalRingHom (w i))).rootMultiplicity (z i)) ≤
      J * (f.natDegree + D) + 2 * f.natDegree * D := by
  classical
  have hi (i : ι) : (f.map (Polynomial.evalRingHom (w i))).rootMultiplicity (z i) ≤
      (if (f.map (Polynomial.evalRingHom (w i))).eval (z i) = 0 then 1 else 0) +
        (f.resultant f.derivative).rootMultiplicity (w i) := by
    split_ifs with h
    · exact specialization_multiplicity_le f hf hdeg (z i) (w i)
    · rw [Polynomial.rootMultiplicity_eq_zero h]
      exact Nat.zero_le _
  have hs := Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => hi i)
  rw [Finset.sum_add_distrib] at hs
  have hr := sum_rootMultiplicity_comp_le (f.resultant f.derivative) w hw
  have hd := green_resultant_degree_le f D hcoeff
  have hc : (∑ i : ι, if (f.map (Polynomial.evalRingHom (w i))).eval (z i) = 0 then 1 else 0) =
      (Finset.univ.filter (fun i => (f.map (Polynomial.evalRingHom (w i))).eval (z i) = 0)).card := by
    simp
  rw [hc] at hs
  omega

end MissingLinnik.Green


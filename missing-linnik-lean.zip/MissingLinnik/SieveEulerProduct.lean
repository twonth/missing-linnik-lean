import MissingLinnik.SelbergWeights
import Mathlib.Analysis.SpecialFunctions.Pow.Real

namespace MissingLinnik

open Finset ArithmeticFunction

noncomputable def weightedTotientReciprocal (α : ℝ) : ArithmeticFunction ℝ :=
  ⟨fun n => (n:ℝ)^α / n.totient, by simp⟩

theorem weightedTotientReciprocal_multiplicative (α : ℝ) :
    (weightedTotientReciprocal α).IsMultiplicative := by
  constructor
  · simp [weightedTotientReciprocal]
  · intro m n hmn
    change ((m*n:ℕ):ℝ)^α / (m*n).totient =
      ((m:ℝ)^α/m.totient)*((n:ℝ)^α/n.totient)
    rw [Nat.totient_mul hmn, Nat.cast_mul, Nat.cast_mul,
      Real.mul_rpow (Nat.cast_nonneg m) (Nat.cast_nonneg n)]
    ring

/-- The finite Euler product used in Rankin's estimate for the sieve denominator. -/
theorem weighted_totient_divisor_product (P : ℕ) (hP : Squarefree P) (α : ℝ) :
    (∑ r ∈ P.divisors, (r:ℝ)^α/r.totient) =
      ∏ p ∈ P.primeFactors, (1+(p:ℝ)^α/((p:ℝ)-1)) := by
  have hh := (weightedTotientReciprocal_multiplicative α).prodPrimeFactors_one_add_of_squarefree hP
  change (∏ p ∈ P.primeFactors, (1+(p:ℝ)^α/p.totient)) =
    (∑ r ∈ P.divisors, (r:ℝ)^α/r.totient) at hh
  rw [← hh]
  apply Finset.prod_congr rfl
  intro p hp
  have hprime := Nat.prime_of_mem_primeFactors hp
  rw [Nat.totient_prime hprime, Nat.cast_sub hprime.one_le, Nat.cast_one]

noncomputable def fullSieveH (P : ℕ) : ℝ := ∑ r ∈ P.divisors, (1:ℝ)/r.totient

theorem fullSieveH_product (P : ℕ) (hP : Squarefree P) :
    fullSieveH P = ∏ p ∈ P.primeFactors, (1-1/(p:ℝ))⁻¹ := by
  have hh := weighted_totient_divisor_product P hP 0
  simp only [Real.rpow_zero] at hh
  rw [fullSieveH,hh]
  apply Finset.prod_congr rfl
  intro p hp
  have hpR : (1:ℝ) < p := by exact_mod_cast (Nat.prime_of_mem_primeFactors hp).one_lt
  have hp0 : (p:ℝ) ≠ 0 := by linarith
  have hp1 : (p:ℝ)-1 ≠ 0 := by linarith
  field_simp
  ring

theorem fullSieveH_pos (P : ℕ) (hP : P ≠ 0) : 0 < fullSieveH P := by
  apply Finset.sum_pos'
  · intro r hr; positivity
  · exact ⟨1,Nat.mem_divisors.mpr ⟨one_dvd _,hP⟩,by norm_num⟩

theorem sieveH_le_full (P R : ℕ) : sieveH P R ≤ fullSieveH P := by
  apply Finset.sum_le_sum
  intro r hr
  split_ifs
  · exact le_rfl
  · positivity

/-- Rankin's trick, before choosing the positive exponent. -/
theorem sieveH_tail_rankin (P R : ℕ) (hR : 1 ≤ R) (α : ℝ) (hα : 0 ≤ α) :
    fullSieveH P - sieveH P R ≤
      (R:ℝ)^(-α) * ∑ r ∈ P.divisors, (r:ℝ)^α/r.totient := by
  have hR0 : (0:ℝ) < R := by exact_mod_cast (show 0<R by omega)
  have hpow : 0 < (R:ℝ)^α := Real.rpow_pos_of_pos hR0 _
  rw [fullSieveH,sieveH,← Finset.sum_sub_distrib,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro r hr
  by_cases hle : r ≤ R
  · rw [if_pos hle,sub_self]
    positivity
  · rw [if_neg hle,sub_zero,Real.rpow_neg hR0.le]
    have hm : (R:ℝ)^α ≤ (r:ℝ)^α := Real.rpow_le_rpow hR0.le (by exact_mod_cast (Nat.le_of_lt (not_le.mp hle))) hα
    have hh : (1:ℝ) ≤ ((R:ℝ)^α)⁻¹*(r:ℝ)^α := by
      rw [← div_eq_inv_mul,le_div_iff₀ hpow]
      simpa using hm
    have hn : (0:ℝ) ≤ (r.totient:ℝ)⁻¹ := by positivity
    have ht := mul_le_mul_of_nonneg_right hh hn
    convert ht using 1 <;> ring

end MissingLinnik

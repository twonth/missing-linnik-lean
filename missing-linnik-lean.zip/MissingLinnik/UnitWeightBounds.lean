import MissingLinnik.UnitRawWeights
import MissingLinnik.ThreeRoughSymmetry

namespace MissingLinnik
open Finset ArithmeticFunction
open scoped Classical

theorem rough_unit_two_lower (q k : ℕ) [NeZero q] (hq : 2≤q) (hk : 1≤k)
    (x : ℝ) (hx : 1≤x) :
    (Real.log x)^2-(10:ℝ)^42*Real.log ((q^(170*k):ℕ):ℝ)*Real.log x≤
      (∑ u : (ZMod q)ˣ,unitArithmeticMass (logWeight (roughRestriction (q^(170*k)) vonMangoldt)) x u)+
      (∑ u : (ZMod q)ˣ,∑ v,unitPairMass (roughRestriction (q^(170*k)) vonMangoldt) x u v) := by
  have hqY : q≤q^(170*k) := (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hh := unit_two_mass_weighted (roughRestriction (q^(170*k)) vonMangoldt)
    (roughRestriction_support_coprime q (q^(170*k)) (NeZero.pos q) hqY) x (fun _ : (ZMod q)ˣ => 1)
  simp only [mul_one] at hh
  rw [hh]
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (by omega : 0<q)
  calc
    _ = ∑ u : (ZMod q)ˣ, ((Real.log x)^2-(10:ℝ)^42*Real.log ((q^(170*k):ℕ):ℝ)*Real.log x)/q.totient := by
      simp only [Finset.sum_const,Finset.card_univ,ZMod.card_units_eq_totient,nsmul_eq_mul]
      field_simp
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro u hu
      have hb := (abs_le.mp (rough_two_real q k (u:ZMod q).val hq hk (ZMod.val_coe_unit_coprime u) x hx)).1
      rw [roughQ_eq_arithmeticClassSum] at hb
      change _≤unitArithmeticMass (twoKernel (roughRestriction (q^(170*k)) vonMangoldt)) x u
      rw [sub_div]
      unfold unitArithmeticMass
      linarith only [hb]

theorem rough_unit_cube_bound (q k : ℕ) [NeZero q] (hq : 2≤q) (hk : 1≤k)
    (x : ℝ) (hx : ((q^(170*k):ℕ):ℝ)≤x) (a : (ZMod q)ˣ)
    (hno : ∀ p : ℕ,p.Prime → (p:ℝ)≤x^3 → ¬Nat.ModEq q p (a:ZMod q).val) :
    ‖∑ χ : DirichletCharacter ℂ q, star (χ (a:ZMod q))*
      (residueCoefficient (unitArithmeticMass (roughRestriction (q^(170*k)) vonMangoldt) x) χ)^3‖≤
      (9/2:ℝ)*(72+(10:ℝ)^46*Real.log ((q^(170*k):ℕ):ℝ))*(Real.log x)^2 := by
  let Y := q^(170*k)
  let f := roughRestriction Y vonMangoldt
  have hqY : q≤Y := (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2≤Y := hq.trans hqY
  have hx1 : 1≤x := (show (1:ℝ)≤Y by exact_mod_cast (show 1≤Y by omega)).trans hx
  have hx0 : 0<x := by linarith
  have hx3 : (Y:ℝ)≤x^3 := hx.trans (by nlinarith [sq_nonneg (x-1)])
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (by omega : 0<q)
  have hf := roughRestriction_mangoldt_nonneg Y
  have hc := roughRestriction_support_coprime q Y (NeZero.pos q) hqY
  have hs := (abs_le.mp (rough_three_real q k (a:ZMod q).val hq hk (ZMod.val_coe_unit_coprime a) (x^3) hx3)).2
  have hp := single_log_square_of_no_primes q (a:ZMod q).val Y (by omega) (x^3) (one_le_pow₀ hx1) hno
  have hbox := unitArithmeticMass_cube_bound f hc hf x hx1 a
  rw [residue_cubic_norm _ (fun u => unitArithmeticMass_nonneg f hf x u)]
  have hφY : (q.totient:ℝ)≤Y := by exact_mod_cast (Nat.totient_le q).trans hqY
  have hY0 : (0:ℝ)<Y := by exact_mod_cast (show 0<Y by omega)
  have hsingle : (q.totient:ℝ)*arithmeticClassSum (logWeight (logWeight f)) q (a:ZMod q).val (x^3)≤72*(Real.log (x^3))^2 := by
    apply (mul_le_mul_of_nonneg_left hp hφ.le).trans
    have hm := mul_le_mul_of_nonneg_right hφY (show 0≤72*(Real.log (x^3))^2 by positivity)
    rw [← mul_div_assoc]
    apply (div_le_iff₀ hY0).mpr
    nlinarith only [hm]
  have hsym := mul_le_mul_of_nonneg_left hs hφ.le
  have hb := mul_le_mul_of_nonneg_left hbox hφ.le
  have hcancel : (q.totient:ℝ)*((10:ℝ)^46*Real.log (Y:ℝ)*(Real.log (x^3))^2/q.totient)=
      (10:ℝ)^46*Real.log (Y:ℝ)*(Real.log (x^3))^2 := by field_simp
  change (q.totient:ℝ)*(2*unitArithmeticMass (f*f*f) (x^3) a-unitArithmeticMass (logWeight (logWeight f)) (x^3) a)≤_ at hsym
  rw [hcancel,Real.log_pow] at hsym
  rw [Real.log_pow] at hsingle
  change (q.totient:ℝ)*unitArithmeticMass (logWeight (logWeight f)) (x^3) a≤_ at hsingle
  norm_num only [Nat.cast_ofNat] at hsym hsingle
  change (q.totient:ℝ)*groupConvolution (unitArithmeticMass f x) (groupConvolution (unitArithmeticMass f x) (unitArithmeticMass f x)) a≤_
  change _≤(9/2:ℝ)*(72+(10:ℝ)^46*Real.log (Y:ℝ))*(Real.log x)^2
  nlinarith only [hsym,hsingle,hb]

end MissingLinnik



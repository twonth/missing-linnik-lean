import MissingLinnik.RealRoughSymmetry

namespace MissingLinnik

open ArithmeticFunction Finset
open scoped Classical

noncomputable def roughRestriction (Y : ℕ) (f : ArithmeticFunction ℝ) : ArithmeticFunction ℝ :=
  ⟨fun n => if IsRough Y n then f n else 0,by simp⟩

theorem roughRestriction_apply (Y : ℕ) (f : ArithmeticFunction ℝ) (n : ℕ) :
    roughRestriction Y f n = if IsRough Y n then f n else 0 := rfl

theorem roughRestriction_add (Y : ℕ) (f g : ArithmeticFunction ℝ) :
    roughRestriction Y (f+g)=roughRestriction Y f+roughRestriction Y g := by
  ext n
  simp only [roughRestriction_apply,ArithmeticFunction.add_apply]
  split_ifs <;> ring

theorem roughRestriction_mul (Y : ℕ) (f g : ArithmeticFunction ℝ) :
    roughRestriction Y (f*g)=roughRestriction Y f*roughRestriction Y g := by
  ext n
  rw [roughRestriction_apply,ArithmeticFunction.mul_apply,ArithmeticFunction.mul_apply]
  by_cases hr : IsRough Y n
  · rw [if_pos hr]
    apply Finset.sum_congr rfl
    intro a ha
    have hp := (Nat.mem_divisorsAntidiagonal.mp ha).1
    have hrough := (isRough_mul Y a.1 a.2).mp (hp ▸ hr)
    rw [roughRestriction_apply,roughRestriction_apply,if_pos hrough.1,if_pos hrough.2]
  · rw [if_neg hr]
    symm
    apply Finset.sum_eq_zero
    intro a ha
    have hp := (Nat.mem_divisorsAntidiagonal.mp ha).1
    have hrough : ¬(IsRough Y a.1 ∧ IsRough Y a.2) := fun h => hr (hp ▸ (isRough_mul Y a.1 a.2).mpr h)
    rw [roughRestriction_apply,roughRestriction_apply]
    split_ifs <;> first | (solve | ring) | tauto

theorem roughRestriction_logWeight (Y : ℕ) (f : ArithmeticFunction ℝ) :
    roughRestriction Y (logWeight f)=logWeight (roughRestriction Y f) := by
  ext n
  simp only [roughRestriction_apply,logWeight_apply]
  split_ifs <;> ring

theorem logWeight_add (f g : ArithmeticFunction ℝ) : logWeight (f+g)=logWeight f+logWeight g := by
  ext n
  simp only [logWeight_apply,ArithmeticFunction.add_apply]
  ring

noncomputable def twoKernel (f : ArithmeticFunction ℝ) : ArithmeticFunction ℝ := logWeight f+f*f

theorem triple_kernel_identity (f : ArithmeticFunction ℝ) :
    logWeight (twoKernel f)+2 • (f*f*f) = logWeight (logWeight f)+2 • (f*twoKernel f) := by
  unfold twoKernel
  rw [logWeight_add,logWeight_mul]
  simp only [two_smul]
  ring

noncomputable def arithmeticClassSum (f : ArithmeticFunction ℝ) (q c : ℕ) (x : ℝ) : ℝ :=
  ∑ n ∈ (Icc 1 (Nat.floor x)).filter (fun n => Nat.ModEq q n c), f n/(n:ℝ)

theorem arithmeticClassSum_add (f g : ArithmeticFunction ℝ) (q c : ℕ) (x : ℝ) :
    arithmeticClassSum (f+g) q c x=arithmeticClassSum f q c x+arithmeticClassSum g q c x := by
  simp only [arithmeticClassSum,ArithmeticFunction.add_apply,add_div,Finset.sum_add_distrib]

theorem arithmeticClassSum_two_smul (f : ArithmeticFunction ℝ) (q c : ℕ) (x : ℝ) :
    arithmeticClassSum (2 • f) q c x=2*arithmeticClassSum f q c x := by
  rw [two_smul,arithmeticClassSum_add,two_mul]

theorem roughQ_eq_arithmeticClassSum (q c Y : ℕ) (x : ℝ) :
    roughQ q c Y x=arithmeticClassSum (twoKernel (roughRestriction Y vonMangoldt)) q c x := by
  have he : twoKernel (roughRestriction Y vonMangoldt)=
      roughRestriction Y (logWeight vonMangoldt+vonMangoldt*vonMangoldt) := by
    rw [roughRestriction_add,roughRestriction_mul,roughRestriction_logWeight]
    rfl
  rw [he]
  unfold roughQ roughSelbergClassSum arithmeticClassSum
  rw [Finset.sum_filter,Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro n hn
  rw [roughRestriction_apply]
  change (if IsRough Y n ∧ Nat.ModEq q n c then selbergKernel n/(n:ℝ) else 0) =
    if Nat.ModEq q n c then (if IsRough Y n then selbergKernel n else 0)/(n:ℝ) else 0
  split_ifs <;> first | (solve | ring) | tauto

end MissingLinnik


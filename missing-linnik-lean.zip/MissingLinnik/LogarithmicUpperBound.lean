import MissingLinnik.ThreeRoughSymmetry

namespace MissingLinnik

open Finset MeasureTheory

noncomputable def inverseLogDeriv (t : ℝ) : ℝ := -t⁻¹*(Real.log t)⁻¹^2

theorem inverseLog_hasDerivAt (t : ℝ) (ht : 1<t) :
    HasDerivAt (fun t : ℝ => (Real.log t)⁻¹) (inverseLogDeriv t) t := by
  have ht0 : t≠0 := by linarith
  have hl0 : Real.log t≠0 := (Real.log_pos ht).ne'
  convert (Real.hasDerivAt_log ht0).inv hl0 using 1 <;> simp [inverseLogDeriv,div_eq_mul_inv,inv_pow]

theorem sum_cutoff_zero (c : ℕ → ℝ) (Y N : ℕ) (hYN : Y≤N) (hc : ∀ n≤Y, c n=0) :
    (∑ n ∈ Icc 0 N, c n)=∑ n ∈ Ioc Y N, c n := by
  symm
  apply Finset.sum_subset
  · intro n hn
    exact mem_Icc.mpr ⟨Nat.zero_le _,(mem_Ioc.mp hn).2⟩
  · intro n hn hnot
    apply hc
    simp only [mem_Icc,mem_Ioc] at hn hnot
    omega

theorem inverseLog_abel (c : ℕ → ℝ) (Y : ℕ) (hY : 2≤Y)
    (hc : ∀ n≤Y, c n=0) (x : ℝ) (hx : (Y:ℝ)≤x) :
    coefficientMass c x=(Real.log x)⁻¹*coefficientLogMoment c x+
      ∫ t in Set.Ioc (Y:ℝ) x, t⁻¹*(Real.log t)⁻¹^2*coefficientLogMoment c t := by
  have hcont : ContinuousOn inverseLogDeriv (Set.Icc (Y:ℝ) x) := by
    intro t ht
    have ht1 : 1<t := lt_of_lt_of_le (by exact_mod_cast (show 1<Y by omega)) ht.1
    have ht0 : t≠0 := by linarith
    have hl0 : Real.log t≠0 := (Real.log_pos ht1).ne'
    unfold inverseLogDeriv
    fun_prop
  have hd (t : ℝ) (ht : t∈Set.Icc (Y:ℝ) x) : deriv (fun t : ℝ => (Real.log t)⁻¹) t=inverseLogDeriv t :=
    (inverseLog_hasDerivAt t (lt_of_lt_of_le (by exact_mod_cast (show 1<Y by omega)) ht.1)).deriv
  have hi : IntegrableOn (deriv (fun t : ℝ => (Real.log t)⁻¹)) (Set.Icc (Y:ℝ) x) :=
    hcont.integrableOn_Icc.congr_fun (fun t ht => (hd t ht).symm) measurableSet_Icc
  have hh := sum_mul_eq_sub_sub_integral_mul (fun n : ℕ => Real.log n*c n) (Nat.cast_nonneg Y) hx
    (f := fun t : ℝ => (Real.log t)⁻¹)
    (fun t ht => (inverseLog_hasDerivAt t (lt_of_lt_of_le (by exact_mod_cast (show 1<Y by omega)) ht.1)).differentiableAt) hi
  rw [Nat.floor_natCast] at hh
  have hzero : (∑ n ∈ Icc 0 Y, Real.log n*c n)=0 := by
    apply Finset.sum_eq_zero
    intro n hn
    rw [hc n (mem_Icc.mp hn).2,mul_zero]
  rw [hzero,mul_zero,sub_zero] at hh
  have hleft : (∑ n ∈ Ioc Y (Nat.floor x), (Real.log (n:ℝ))⁻¹*(Real.log n*c n))=coefficientMass c x := by
    unfold coefficientMass
    rw [sum_cutoff_zero c Y (Nat.floor x) (Nat.le_floor hx) hc]
    apply Finset.sum_congr rfl
    intro n hn
    have hn1 : 1<(n:ℝ) := by exact_mod_cast (show 1<n by have := (mem_Ioc.mp hn).1; omega)
    have hl0 := (Real.log_pos hn1).ne'
    field_simp
  rw [hleft] at hh
  have he : (∫ t in Set.Ioc (Y:ℝ) x, deriv (fun t : ℝ => (Real.log t)⁻¹) t*
      (∑ n ∈ Icc 0 (Nat.floor t), Real.log n*c n)) =
      -(∫ t in Set.Ioc (Y:ℝ) x, t⁻¹*(Real.log t)⁻¹^2*coefficientLogMoment c t) := by
    rw [← MeasureTheory.integral_neg]
    apply MeasureTheory.setIntegral_congr_fun measurableSet_Ioc
    intro t ht
    dsimp only
    rw [hd t (Set.Ioc_subset_Icc_self ht)]
    unfold inverseLogDeriv coefficientLogMoment
    ring
  rw [he,sub_neg_eq_add] at hh
  exact hh

theorem logarithmic_upper_bound (c : ℕ → ℝ) (Y : ℕ) (hY : 2≤Y)
    (hc : ∀ n≤Y, c n=0) (A D : ℝ) (hA : 0≤A)
    (hbound : ∀ t : ℝ, (Y:ℝ)≤t → coefficientLogMoment c t≤A*(Real.log t)^2+D*Real.log t)
    (x : ℝ) (hx : (Y:ℝ)≤x) :
    coefficientMass c x≤2*A*Real.log x+D*(1+Real.log (Real.log x)-Real.log (Real.log Y)) := by
  have hY1 : (1:ℝ)<Y := by exact_mod_cast (show 1<Y by omega)
  have hx1 : 1<x := hY1.trans_le hx
  have hlY : 0<Real.log (Y:ℝ) := Real.log_pos hY1
  have hlx : 0<Real.log x := Real.log_pos hx1
  have hg : ContinuousOn (fun t : ℝ => t⁻¹*(Real.log t)⁻¹^2) (Set.Icc (Y:ℝ) x) := by
    intro t ht
    have ht1 := hY1.trans_le ht.1
    have ht0 : t≠0 := by linarith
    have hlt0 := (Real.log_pos ht1).ne'
    fun_prop
  have hl : ContinuousOn (fun t : ℝ => t⁻¹*(Real.log t)⁻¹) (Set.Icc (Y:ℝ) x) := by
    intro t ht
    have ht1 := hY1.trans_le ht.1
    have ht0 : t≠0 := by linarith
    have hlt0 := (Real.log_pos ht1).ne'
    fun_prop
  have hi : ContinuousOn (fun t : ℝ => t⁻¹) (Set.Icc (Y:ℝ) x) := by
    intro t ht
    exact (continuousAt_inv₀ (by linarith [ht.1] : t≠0)).continuousWithinAt
  have hgint : IntegrableOn (fun t : ℝ => t⁻¹*(Real.log t)⁻¹^2*coefficientLogMoment c t) (Set.Ioc (Y:ℝ) x) :=
    (integrableOn_mul_sum_Icc (fun n : ℕ => Real.log n*c n) (m := 0)
      (Nat.cast_nonneg Y) hg.integrableOn_Icc).mono_set Set.Ioc_subset_Icc_self
  have hAi : IntegrableOn (fun t : ℝ => A*t⁻¹) (Set.Ioc (Y:ℝ) x) :=
    (hi.integrableOn_Icc.mono_set Set.Ioc_subset_Icc_self).const_mul A
  have hDl : IntegrableOn (fun t : ℝ => D*(t⁻¹*(Real.log t)⁻¹)) (Set.Ioc (Y:ℝ) x) :=
    (hl.integrableOn_Icc.mono_set Set.Ioc_subset_Icc_self).const_mul D
  have hmajor := MeasureTheory.setIntegral_mono_on hgint (hAi.add hDl) measurableSet_Ioc (fun t ht => by
    have ht1 := hY1.trans ht.1
    have hlt0 := (Real.log_pos ht1).ne'
    have hm := mul_le_mul_of_nonneg_left (hbound t ht.1.le)
      (show 0≤t⁻¹*(Real.log t)⁻¹^2 by positivity)
    dsimp only [Pi.add_apply]
    convert hm using 1 <;> field_simp <;> ring)
  have hint : (∫ t in Set.Ioc (Y:ℝ) x, (t:ℝ)⁻¹)=Real.log x-Real.log Y := by
    have hh := integral_inv_of_pos (by linarith : (0:ℝ)<Y) (by linarith : 0<x)
    rwa [intervalIntegral.integral_of_le hx,Real.log_div (by linarith : x≠0) (by linarith : (Y:ℝ)≠0)] at hh
  have hlint : (∫ t in Set.Ioc (Y:ℝ) x, t⁻¹*(Real.log t)⁻¹)=Real.log (Real.log x)-Real.log (Real.log Y) := by
    have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt
      (f := fun t : ℝ => Real.log (Real.log t)) (f' := fun t : ℝ => t⁻¹*(Real.log t)⁻¹)
      (a := (Y:ℝ)) (b := x) (by
        intro t ht
        rw [Set.uIcc_of_le hx] at ht
        have ht1 := hY1.trans_le ht.1
        convert (Real.hasDerivAt_log (by linarith : t≠0)).log (Real.log_pos ht1).ne' using 1 <;> ring)
      (hl.intervalIntegrable_of_Icc hx)
    rwa [intervalIntegral.integral_of_le hx] at hh
  simp only [Pi.add_apply] at hmajor
  rw [MeasureTheory.integral_add hAi hDl,MeasureTheory.integral_const_mul,
    MeasureTheory.integral_const_mul,hint,hlint] at hmajor
  have hb := mul_le_mul_of_nonneg_left (hbound x hx) (inv_nonneg.mpr hlx.le)
  have hbe : (Real.log x)⁻¹*(A*(Real.log x)^2+D*Real.log x)=A*Real.log x+D := by field_simp <;> ring
  rw [hbe] at hb
  rw [inverseLog_abel c Y hY hc x hx]
  have hpos := mul_nonneg hA hlY.le
  nlinarith only [hmajor,hb,hpos]

end MissingLinnik

import MissingLinnik.UnitArithmetic

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

noncomputable def groupConvolution {G : Type*} [Group G] [Fintype G] (W V : G → ℝ) (a : G) : ℝ :=
  ∑ u,W u*V (u⁻¹*a)

theorem groupConvolution_nonneg {G : Type*} [Group G] [Fintype G] (W V : G → ℝ)
    (hW : ∀ u,0≤W u) (hV : ∀ u,0≤V u) (a : G) : 0≤groupConvolution W V a := by
  exact Finset.sum_nonneg (fun u _ => mul_nonneg (hW u) (hV _))

theorem residue_cubic_norm {q : ℕ} [NeZero q] (W : (ZMod q)ˣ → ℝ)
    (hW : ∀ u,0≤W u) (a : (ZMod q)ˣ) :
    ‖∑ χ : DirichletCharacter ℂ q, star (χ (a:ZMod q))*(residueCoefficient W χ)^3‖ =
      q.totient*groupConvolution W (groupConvolution W W) a := by
  rw [residue_cubic_identity]
  have he : (∑ u,∑ v,∑ z : (ZMod q)ˣ, if u*v*z=a then (W u:ℂ)*W v*W z else 0) =
      ((groupConvolution W (groupConvolution W W) a):ℂ) := by
    have hcond (u v z : (ZMod q)ˣ) : u*v*z=a ↔ z=(u*v)⁻¹*a := by
      exact eq_inv_mul_iff_mul_eq.symm
    simp only [hcond,Finset.sum_ite_eq',Finset.mem_univ,ite_true]
    simp only [groupConvolution,Complex.ofReal_sum,Complex.ofReal_mul,Finset.mul_sum,mul_inv_rev,mul_assoc]
  rw [he]
  have hh : 0≤(q.totient:ℝ)*groupConvolution W (groupConvolution W W) a :=
    mul_nonneg (Nat.cast_nonneg _) (groupConvolution_nonneg W _ hW (groupConvolution_nonneg W W hW hW) a)
  rw [← Complex.ofReal_natCast,← Complex.ofReal_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hh]

theorem unitArithmeticMass_box_convolution {q : ℕ} [NeZero q]
    (f g : ArithmeticFunction ℝ) (hf : ∀ n,f n≠0 → n.Coprime q)
    (hfn : ∀ n,0≤f n) (hgn : ∀ n,0≤g n) (x y : ℝ) (hx : 1≤x) (hy : 1≤y)
    (a : (ZMod q)ˣ) :
    groupConvolution (unitArithmeticMass f x) (unitArithmeticMass g y) a≤unitArithmeticMass (f*g) (x*y) a := by
  unfold groupConvolution
  rw [unitArithmeticMass_weighted_sum f hf x (fun u => unitArithmeticMass g y (u⁻¹*a)),
    unitArithmeticMass_convolution f g hf]
  have hx0 : 0≤x := by linarith
  have hy0 : 0≤y := by linarith
  have hxy : x≤x*y := by nlinarith
  apply (Finset.sum_le_sum (fun d hd => ?_)).trans
    (Finset.sum_le_sum_of_subset_of_nonneg
      (by intro d hd; exact mem_Icc.mpr ⟨(mem_Icc.mp hd).1,(mem_Icc.mp hd).2.trans (Nat.floor_mono hxy)⟩)
      (fun d hd _ => mul_nonneg (div_nonneg (hfn d) (Nat.cast_nonneg _)) (unitArithmeticMass_nonneg g hgn _ _)))
  have hd0 : (0:ℝ)<d := by exact_mod_cast (mem_Icc.mp hd).1
  have hdx : (d:ℝ)≤x := (show (d:ℝ)≤Nat.floor x by exact_mod_cast (mem_Icc.mp hd).2).trans (Nat.floor_le hx0)
  have hscale : y≤x*y/(d:ℝ) := (le_div_iff₀ hd0).mpr (by nlinarith)
  exact mul_le_mul_of_nonneg_left (unitArithmeticMass_mono g hgn y (x*y/d) hscale _)
    (div_nonneg (hfn d) hd0.le)

theorem unitArithmeticMass_cube_bound {q : ℕ} [NeZero q]
    (f : ArithmeticFunction ℝ) (hf : ∀ n,f n≠0 → n.Coprime q)
    (hfn : ∀ n,0≤f n) (x : ℝ) (hx : 1≤x) (a : (ZMod q)ˣ) :
    groupConvolution (unitArithmeticMass f x)
      (groupConvolution (unitArithmeticMass f x) (unitArithmeticMass f x)) a≤unitArithmeticMass (f*f*f) (x^3) a := by
  have hfirst : groupConvolution (unitArithmeticMass f x)
      (groupConvolution (unitArithmeticMass f x) (unitArithmeticMass f x)) a≤
      groupConvolution (unitArithmeticMass f x) (unitArithmeticMass (f*f) (x*x)) a := by
    apply Finset.sum_le_sum
    intro u hu
    exact mul_le_mul_of_nonneg_left (unitArithmeticMass_box_convolution f f hf hfn hfn x x hx hx _)
      (unitArithmeticMass_nonneg f hfn x u)
  have hsecond := unitArithmeticMass_box_convolution f (f*f) hf hfn
    (arithmetic_mul_nonneg f f hfn hfn) x (x*x) hx (by nlinarith) a
  apply hfirst.trans
  convert hsecond using 1 <;> congr 1 <;> ring

end MissingLinnik

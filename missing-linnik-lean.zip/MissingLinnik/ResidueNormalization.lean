import MissingLinnik.ResidueContradiction
import Mathlib.Tactic.FieldSimp

namespace MissingLinnik

open scoped Classical

theorem residueCoefficient_div {q : ℕ} [NeZero q] (W : (ZMod q)ˣ → ℝ) (M : ℝ)
    (χ : DirichletCharacter ℂ q) :
    residueCoefficient (fun i => W i/M) χ=residueCoefficient W χ/(M:ℂ) := by
  unfold residueCoefficient finiteCoefficient
  simp only [Complex.ofReal_div,div_mul_eq_mul_div,← Finset.sum_div]

theorem residue_cubic_div {q : ℕ} [NeZero q] (W : (ZMod q)ˣ → ℝ) (M : ℝ)
    (a : (ZMod q)ˣ) :
    (∑ χ : DirichletCharacter ℂ q, star (χ (a:ZMod q))*(residueCoefficient (fun i => W i/M) χ)^3)=
      (∑ χ : DirichletCharacter ℂ q, star (χ (a:ZMod q))*(residueCoefficient W χ)^3)/(M:ℂ)^3 := by
  simp only [residueCoefficient_div,div_pow,← mul_div_assoc,← Finset.sum_div]

/-- A quantitative normalization of the final character argument. All inputs
are raw masses; this lemma accounts for their deviation from log Z. -/
theorem residue_contradiction_of_raw_bounds {q : ℕ} [NeZero q]
    (W U : (ZMod q)ˣ → ℝ) (V : (ZMod q)ˣ → (ZMod q)ˣ → ℝ)
    (a : (ZMod q)ˣ) (L M : ℝ) (hL : 0<L)
    (hMl : (999/1000:ℝ)*L≤M) (hMu : M≤(1001/1000:ℝ)*L)
    (hW : ∀ i, 0≤W i) (hmass : ∑ i, W i=M)
    (hU : ∀ i, 0≤U i ∧ U i≤L*W i)
    (hV : ∀ i j, 0≤V i j ∧ V i j≤W i*W j)
    (hmax : ∀ i, q.totient*W i≤(2001/1000:ℝ)*L)
    (hcube : ‖∑ χ : DirichletCharacter ℂ q, star (χ (a:ZMod q))*(residueCoefficient W χ)^3‖≤L^3/1000)
    (htotal : (999/1000:ℝ)*L^2≤(∑ i,U i)+(∑ i,∑ j,V i j))
    (hsigned : ∀ ψ : DirichletCharacter ℝ q, ψ≠1 →
      (∑ i,U i*ψ (i:ZMod q))+(∑ i,∑ j,V i j*(ψ (i:ZMod q)*ψ (j:ZMod q)))≤L^2/1000)
    (hanti : ∀ ψ : DirichletCharacter ℝ q, ψ≠1 →
      (∑ i ∈ Finset.univ.filter (fun i : (ZMod q)ˣ => ψ (i:ZMod q)=-1), W i)≤(313/500:ℝ)*L) : False := by
  let T := max L M
  have hM : 0<M := by linarith
  have hT : 0<T := hL.trans_le (le_max_left _ _)
  have hTL : L≤T := le_max_left _ _
  have hTM : M≤T := le_max_right _ _
  have hTu : T≤(1001/1000:ℝ)*L := max_le (by linarith) hMu
  have hP : 0<T*M := mul_pos hT hM
  have hPl : (999/1000:ℝ)*L^2≤T*M := by nlinarith [mul_le_mul hTL hMl (by linarith : 0≤(999/1000:ℝ)*L) hT.le]
  have hPu : T*M≤((1001/1000:ℝ)^2)*L^2 := by nlinarith [mul_le_mul hTu hMu hM.le (by positivity : 0≤(1001/1000:ℝ)*L)]
  apply residue_linnik_contradiction (fun i => W i/M) (fun i => U i/(T*M))
    (fun i j => V i j/(T*M)) a
  · intro i; exact div_nonneg (hW i) hM.le
  · rw [← Finset.sum_div,hmass,div_self hM.ne']
  · intro i
    refine ⟨div_nonneg (hU i).1 hP.le,?_⟩
    apply (div_le_iff₀ hP).mpr
    have he : W i/M*(T*M)=T*W i := by field_simp <;> ring
    rw [he]
    exact (hU i).2.trans (mul_le_mul_of_nonneg_right hTL (hW i))
  · intro i j
    refine ⟨div_nonneg (hV i j).1 hP.le,?_⟩
    apply (div_le_iff₀ hP).mpr
    have he : W i/M*(W j/M)*(T*M)=W i*W j*(T/M) := by field_simp <;> ring
    rw [he]
    have hratio : 1≤T/M := (le_div_iff₀ hM).mpr (by simpa)
    exact (hV i j).2.trans (by nlinarith [mul_le_mul_of_nonneg_left hratio (mul_nonneg (hW i) (hW j))])
  · intro i
    rw [← mul_div_assoc]
    apply (div_le_iff₀ hM).mpr
    have hh := hmax i
    nlinarith only [hh,hMl,hL]
  · rw [residue_cubic_div,norm_div,norm_pow,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hM]
    apply (div_le_iff₀ (show 0<M^3 by positivity)).mpr
    have hm3 := pow_le_pow_left₀ (by positivity : 0≤(999/1000:ℝ)*L) hMl 3
    have hL3 : 0≤L^3 := by positivity
    nlinarith only [hcube,hm3,hL3]
  · simp only [← Finset.sum_div,← add_div]
    apply (le_div_iff₀ hP).mpr
    have hL2 := sq_nonneg L
    nlinarith only [htotal,hPu,hL2]
  · intro ψ hψ
    simp only [div_mul_eq_mul_div,← Finset.sum_div,← add_div]
    apply (div_le_iff₀ hP).mpr
    have hh := hsigned ψ hψ
    have hL2 := sq_nonneg L
    nlinarith only [hh,hPl,hL2]
  · intro ψ hψ
    rw [← Finset.sum_div]
    apply (div_le_iff₀ hM).mpr
    have hh := hanti ψ hψ
    nlinarith only [hh,hMl,hL]

end MissingLinnik


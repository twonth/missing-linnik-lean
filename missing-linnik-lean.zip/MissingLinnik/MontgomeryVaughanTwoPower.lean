import MissingLinnik.MontgomeryVaughanTwo

namespace MissingLinnik

/-- Elementary lifting of odd square roots: every integer congruent to one
modulo eight is a square modulo every power of two. -/
theorem square_root_two_power (a : ℤ) (ha : 8 ∣ a-1) (n : ℕ) :
    ∃ b : ℤ, Odd b ∧ (2:ℤ)^(n+3) ∣ b^2-a := by
  induction n with
  | zero =>
    refine ⟨1, by decide, ?_⟩
    norm_num
    convert dvd_neg.mpr ha using 1 <;> ring
  | succ n ih =>
    obtain ⟨b, hb, t, ht⟩ := ih
    obtain ⟨c, hc⟩ := hb
    let e : ℤ := t % 2
    have he : 2 ∣ t + b*e := by
      refine ⟨t/2 + e*(c+1), ?_⟩
      have hmod := Int.emod_add_ediv_mul t 2
      dsimp [e]
      rw [hc]
      nlinarith
    obtain ⟨v, hv⟩ := he
    refine ⟨b + 2^(n+2)*e, ?_, ?_⟩
    · refine ⟨c + 2^(n+1)*e, ?_⟩
      rw [hc]
      ring
    · refine ⟨v + 2^n*e^2, ?_⟩
      have hh : b^2-a = 2^(n+3)*t := ht
      calc
        (b+2^(n+2)*e)^2-a =
            2^(n+3)*(t+b*e) + 2^(2*n+4)*e^2 := by
          rw [show 2*n+4 = (n+2)+(n+2) by omega]
          simp only [pow_add] at hh ⊢
          nlinarith only [hh]
        _ = 2^(n+1+3)*(v+2^n*e^2) := by
          rw [hv]
          simp only [pow_add, pow_one]
          ring

/-- The kernel of reduction modulo eight consists of squares. -/
theorem isSquare_of_cast_eight_eq_one (n : ℕ) (x : ZMod (2^(n+3)))
    (hx : (ZMod.cast x : ZMod 8) = 1) : IsSquare x := by
  have hd : 8 ∣ 2^(n+3) := by
    convert pow_dvd_pow 2 (show 3 ≤ n+3 by omega) using 1
  have ha : (8:ℤ) ∣ (x.val:ℤ)-1 := by
    apply (ZMod.intCast_zmod_eq_zero_iff_dvd _ 8).mp
    push_cast
    have he : ((x.val:ℕ):ZMod 8) = 1 := by
      calc
        (x.val:ZMod 8) = ZMod.cast (x.val:ZMod (2^(n+3))) :=
          (ZMod.cast_natCast hd x.val).symm
        _ = 1 := by simpa only [ZMod.natCast_zmod_val] using hx
    rw [he, sub_self]
  obtain ⟨b, _, hb⟩ := square_root_two_power (x.val:ℤ) ha n
  have hb' : ((b^2-(x.val:ℤ):ℤ):ZMod (2^(n+3))) = 0 := by
    apply (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mpr
    simpa using hb
  push_cast at hb'
  rw [ZMod.natCast_val, sub_eq_zero] at hb'
  exact ⟨(b:ZMod (2^(n+3))), by simpa [pow_two] using hb'.symm⟩

/-- The higher-power-of-two step of the textbook classification. -/
theorem real_character_two_power_factors_eight (n : ℕ)
    (ψ : DirichletCharacter ℝ (2^(n+3))) : ψ.FactorsThrough 8 := by
  have hd : 8 ∣ 2^(n+3) := by
    convert pow_dvd_pow 2 (show 3 ≤ n+3 by omega) using 1
  letI : NeZero (2^(n+3)) := ⟨by positivity⟩
  apply (DirichletCharacter.factorsThrough_iff_ker_unitsMap (χ := ψ) hd).mpr
  intro u hu
  rw [MonoidHom.mem_ker] at hu ⊢
  have hu' : (ZMod.cast (u:ZMod (2^(n+3))) : ZMod 8) = 1 := by
    have hh := congrArg (fun v : (ZMod 8)ˣ => (v:ZMod 8)) hu
    simpa only [ZMod.unitsMap_val, Units.val_one] using hh
  obtain ⟨b, hb⟩ := isSquare_of_cast_eight_eq_one n _ hu'
  apply Units.ext
  change ψ (u:ZMod (2^(n+3))) = 1
  have hn : ψ (u:ZMod (2^(n+3))) ≠ 0 := MulChar.apply_ne_zero_iff.mpr u.isUnit
  rw [hb, map_mul]
  rcases real_character_quadratic ψ b with h | h | h
  · rw [hb, map_mul, h, zero_mul] at hn
    exact (hn rfl).elim
  · rw [h]; norm_num
  · rw [h]; norm_num

theorem primitive_real_two_power_exponent (k : ℕ)
    (ψ : DirichletCharacter ℝ (2^k)) (hprim : ψ.IsPrimitive) : k ≤ 3 := by
  by_contra hk
  obtain ⟨n, rfl⟩ : ∃ n, k = n+3 := ⟨k-3, by omega⟩
  have hf := real_character_two_power_factors_eight n ψ
  have hle : ψ.conductor ≤ 8 := Nat.sInf_le hf
  change ψ.conductor = 2^(n+3) at hprim
  rw [hprim] at hle
  have hp : (2:ℕ)^3 < 2^(n+3) := pow_lt_pow_right₀ (by norm_num) (by omega)
  norm_num at hp
  omega

end MissingLinnik

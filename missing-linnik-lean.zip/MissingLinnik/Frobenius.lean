import Mathlib.Algebra.QuadraticAlgebra.Basic
import Mathlib.Algebra.CharP.Algebra
import Mathlib.Algebra.CharP.Lemmas
import Mathlib.NumberTheory.Zsqrtd.Basic
import Mathlib.NumberTheory.LegendreSymbol.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.Tactic.Ring
import Lean.Elab.Tactic.Omega

namespace MissingLinnik

open scoped QuadraticAlgebra

/-- The reduction of Z[sqrt(d)] modulo p, retaining its two coordinates. -/
noncomputable def quadraticReduction (p : ℕ) (d : ℤ) :
    Zsqrtd d →+* QuadraticAlgebra (ZMod p) (d : ZMod p) 0 where
  toFun x := ⟨(x.re : ZMod p), (x.im : ZMod p)⟩
  map_one' := by ext <;> simp
  map_zero' := by ext <;> simp
  map_add' x y := by ext <;> simp
  map_mul' x y := by ext <;> simp

theorem integer_dvd_quadratic_iff {d : ℤ} (p : ℕ) (x : Zsqrtd d) :
    (p : Zsqrtd d) ∣ x ↔ (p : ℤ) ∣ x.re ∧ (p : ℤ) ∣ x.im := by
  constructor
  · rintro ⟨y, rfl⟩
    constructor
    · simp
    · simp
  · rintro ⟨⟨u, hu⟩, ⟨v, hv⟩⟩
    refine ⟨⟨u, v⟩, ?_⟩
    ext <;> simp [hu, hv]

theorem quadraticReduction_eq_zero_iff (p : ℕ) (d : ℤ) (x : Zsqrtd d) :
    quadraticReduction p d x = 0 ↔ (p : Zsqrtd d) ∣ x := by
  rw [integer_dvd_quadratic_iff]
  simp [QuadraticAlgebra.ext_iff, quadraticReduction,
    ZMod.intCast_zmod_eq_zero_iff_dvd]

theorem quadraticReduction_star (p : ℕ) (d : ℤ) (x : Zsqrtd d) :
    quadraticReduction p d (star x) = star (quadraticReduction p d x) := by
  ext <;> simp [quadraticReduction]

theorem quadratic_frobenius_eq_star (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (d : ℤ) (hd : legendreSym p d = -1)
    (x : QuadraticAlgebra (ZMod p) (d : ZMod p) 0) : x ^ p = star x := by
  let K := QuadraticAlgebra (ZMod p) (d : ZMod p) 0
  let root : K := QuadraticAlgebra.omega
  let φ : ZMod p →+* K := algebraMap (ZMod p) K
  let : CharP K p := charP_of_injective_algebraMap
    QuadraticAlgebra.algebraMap_injective p
  have hpodd : p % 2 = 1 := by
    obtain ⟨k, hk⟩ := Nat.Prime.odd_of_ne_two Fact.out hp2
    omega
  have hpdecomp : p = 2 * (p / 2) + 1 := by omega
  have hdPow : (d : ZMod p) ^ (p / 2) = -1 := by
    rw [← legendreSym.eq_pow p d, hd]
    simp
  have hωsq : root ^ 2 = φ (d : ZMod p) := by
    ext <;> simp [root, φ, K, pow_two, QuadraticAlgebra.omega]
  have hω : root ^ p = -root := by
    calc
      root ^ p = (root ^ 2) ^ (p / 2) * root := by
        rw [← pow_mul, ← pow_succ, ← hpdecomp]
      _ = φ ((d : ZMod p) ^ (p / 2)) * root := by rw [hωsq, map_pow]
      _ = -root := by rw [hdPow, map_neg, map_one, neg_one_mul]
  have hφ : ∀ a : ZMod p, φ a ^ p = φ a := by
    intro a
    rw [← map_pow, ZMod.pow_card]
  have hx : x = φ x.re + φ x.im * root := by
    ext <;> simp [φ, root, K]
  rw [hx, add_pow_char, mul_pow, hφ, hφ, hω]
  ext <;> simp [φ, root, K]

/-- The Frobenius congruence used in both source papers, as actual divisibility
inside Z[sqrt(d)], rather than as an unproved local hypothesis. -/
theorem inert_frobenius_congruence (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (d : ℤ) (hd : legendreSym p d = -1) (x : Zsqrtd d) :
    (p : Zsqrtd d) ∣ x ^ p - star x := by
  rw [← quadraticReduction_eq_zero_iff p d]
  rw [map_sub, map_pow, quadraticReduction_star]
  exact sub_eq_zero.mpr (quadratic_frobenius_eq_star p hp2 d hd _)

end MissingLinnik


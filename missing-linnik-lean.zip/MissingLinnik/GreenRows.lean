import MissingLinnik.GreenInterpolation
import MissingLinnik.JetDeterminant
import Mathlib.LinearAlgebra.LinearIndependent.Defs

namespace MissingLinnik.Green

open Classical

noncomputable def rectanglePolynomial {K : Type*} [CommRing K] (R S : ℕ)
    (c : Fin R × Fin S → K) : Polynomial (Polynomial K) :=
  ∑ i, Polynomial.monomial i.1.val (Polynomial.monomial i.2.val (c i))

theorem rectanglePolynomial_coeff {K : Type*} [CommRing K] (R S : ℕ)
    (c : Fin R × Fin S → K) (i : Fin R × Fin S) :
    ((rectanglePolynomial R S c).coeff i.1.val).coeff i.2.val = c i := by
  simp only [rectanglePolynomial, Polynomial.finsetSum_coeff]
  rw [Finset.sum_eq_single i]
  · simp
  · intro k _ hki
    by_cases h1 : k.1.val = i.1.val
    · have h2 : k.2.val ≠ i.2.val := by
        intro h2
        exact hki (Prod.ext (Fin.ext h1) (Fin.ext h2))
      simp [Polynomial.coeff_monomial, h1, h2]
    · simp [Polynomial.coeff_monomial, h1]
  · simp

theorem rectanglePolynomial_degree_le {K : Type*} [CommRing K] (R S : ℕ)
    (c : Fin R × Fin S → K) : (rectanglePolynomial R S c).natDegree ≤ R := by
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro i _
  exact (Polynomial.natDegree_monomial_le _).trans (Nat.le_of_lt i.1.isLt)

theorem rectanglePolynomial_yDegree_le {K : Type*} [CommRing K] (R S : ℕ)
    (c : Fin R × Fin S → K) : yDegree (rectanglePolynomial R S c) ≤ S := by
  unfold yDegree rectanglePolynomial
  rw [map_sum]
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro i _
  rw [Polynomial.Bivariate.swap_monomial_monomial]
  exact (Polynomial.natDegree_monomial_le _).trans (Nat.le_of_lt i.2.isLt)

theorem rectanglePolynomial_jet {K : Type*} [CommRing K] (R S : ℕ)
    (c : Fin R × Fin S → K) (z w : K) (j : ℕ) :
    (Polynomial.derivative^[j]
      ((rectanglePolynomial R S c).map (Polynomial.evalRingHom w))).eval z =
      ∑ i, c i * monomialJet z w j i.1.val i.2.val := by
  unfold rectanglePolynomial
  rw [Polynomial.map_sum, Polynomial.iterate_derivative_sum, Polynomial.eval_finsetSum]
  apply Finset.sum_congr rfl
  intro i _
  rw [Polynomial.map_monomial]
  simp only [Polynomial.coe_evalRingHom, Polynomial.eval_monomial]
  rw [← Polynomial.C_mul_X_pow_eq_monomial, Polynomial.iterate_derivative_C_mul]
  simp only [Polynomial.eval_mul, Polynomial.eval_C, monomialJet]
  ring

/-- Green's Lemma 3.1 in matrix form. The two geometric hypotheses and the
numerical size condition are the only assumptions on the points. -/
theorem rows_linearIndependent {K ι : Type*} [Field K] [CharZero K] [Fintype ι]
    (z w : ι → K) (hw : Function.Injective w) (J R S : ℕ) (hJ : 0 < J)
    (hzero : ∀ f : Polynomial (Polynomial K), f ≠ 0 →
      (Finset.univ.filter (fun i => (f.map (Polynomial.evalRingHom (w i))).eval (z i) = 0)).card ≤
        J * (f.natDegree + yDegree f))
    (hsize : 2 * R * S + J * (R + S) < Fintype.card ι * J) :
    LinearIndependent K (fun i : Fin R × Fin S => fun col : ι × Fin J =>
      monomialJet (z col.1) (w col.1) col.2.val i.1.val i.2.val) := by
  rw [Fintype.linearIndependent_iff]
  intro c hc
  have hp : rectanglePolynomial R S c = 0 := by
    apply polynomial_eq_zero_of_jets z w hw J R S hJ hzero hsize _
      (rectanglePolynomial_degree_le R S c) (rectanglePolynomial_yDegree_le R S c)
    intro i j hj
    rw [rectanglePolynomial_jet]
    have hh := congrFun hc (i, ⟨j, hj⟩)
    simpa only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul, Pi.zero_apply] using hh
  intro i
  have hcoeff := rectanglePolynomial_coeff R S c i
  rw [hp, Polynomial.coeff_zero, Polynomial.coeff_zero] at hcoeff
  exact hcoeff.symm

end MissingLinnik.Green


import MissingLinnik.SelbergAverage

namespace MissingLinnik

open Finset MeasureTheory

noncomputable def coefficientMass (c : ℕ → ℝ) (x : ℝ) : ℝ := ∑ n ∈ Icc 0 (Nat.floor x), c n
noncomputable def coefficientLogMoment (c : ℕ → ℝ) (x : ℝ) : ℝ :=
  ∑ n ∈ Icc 0 (Nat.floor x), Real.log n*c n
noncomputable def coefficientPairMass (c : ℕ → ℝ) (x : ℝ) : ℝ :=
  ∑ n ∈ Icc 1 (Nat.floor x), c n*coefficientMass c (x/n)

theorem coefficientLogMoment_identity (c : ℕ → ℝ) (hc : c 0=0) (x : ℝ) :
    coefficientLogMoment c x = Real.log x*coefficientMass c x-
      ∫ t in Set.Ioc 1 x, t⁻¹*coefficientMass c t := by
  have hh := sum_mul_eq_sub_integral_mul₀ c hc x (f := Real.log)
    (fun t ht => Real.differentiableAt_log (by linarith [ht.1]))
    (by simpa only [Real.deriv_log'] using inv_integrableOn_Icc_one x)
  simpa only [coefficientLogMoment,coefficientMass,Real.deriv_log] using hh

theorem coefficientMass_integral_error (c : ℕ → ℝ) (K : ℝ)
    (hmertens : ∀ t : ℝ, 1≤t → |coefficientMass c t-Real.log t|≤K)
    (x : ℝ) (hx : 1≤x) :
    |(∫ t in Set.Ioc 1 x, t⁻¹*coefficientMass c t)-(Real.log x)^2/2| ≤ K*Real.log x := by
  have hi := (inv_integrableOn_Icc_one x).mono_set Set.Ioc_subset_Icc_self
  have hl : IntegrableOn (fun t : ℝ => t⁻¹*Real.log t) (Set.Ioc 1 x) :=
    (log_inv_continuousOn_Icc_one x).integrableOn_Icc.mono_set Set.Ioc_subset_Icc_self
  have hm : IntegrableOn (fun t : ℝ => t⁻¹*coefficientMass c t) (Set.Ioc 1 x) :=
    (integrableOn_mul_sum_Icc c (m := 0) (by norm_num : (0:ℝ)≤1)
      (inv_integrableOn_Icc_one x)).mono_set Set.Ioc_subset_Icc_self
  have hconst := hi.const_mul K
  have hlo := MeasureTheory.setIntegral_mono_on (hl.sub hconst) hm measurableSet_Ioc
    (fun t ht => by
      have herr := (abs_le.mp (hmertens t ht.1.le)).1
      have hh := mul_le_mul_of_nonneg_left herr (inv_nonneg.mpr (by linarith [ht.1] : 0≤t))
      dsimp
      nlinarith only [hh])
  have hhi := MeasureTheory.setIntegral_mono_on hm (hl.add hconst) measurableSet_Ioc
    (fun t ht => by
      have herr := (abs_le.mp (hmertens t ht.1.le)).2
      have hh := mul_le_mul_of_nonneg_left herr (inv_nonneg.mpr (by linarith [ht.1] : 0≤t))
      dsimp
      nlinarith only [hh])
  have he : (∫ t in Set.Ioc 1 x, (t:ℝ)⁻¹) = Real.log x := by
    have hh := integral_inv_of_pos (by norm_num : (0:ℝ)<1) (show 0<x by linarith)
    rw [intervalIntegral.integral_of_le hx] at hh
    simpa using hh
  simp only [Pi.sub_apply,Pi.add_apply] at hlo hhi
  rw [MeasureTheory.integral_sub hl hconst,MeasureTheory.integral_const_mul,he,integral_log_inv_one x hx] at hlo
  rw [MeasureTheory.integral_add hl hconst,MeasureTheory.integral_const_mul,he,integral_log_inv_one x hx] at hhi
  exact abs_le.mpr ⟨by linarith,by linarith⟩

theorem coefficientLogMoment_estimate (c : ℕ → ℝ) (hc : c 0=0) (K : ℝ)
    (hmertens : ∀ t : ℝ, 1≤t → |coefficientMass c t-Real.log t|≤K)
    (x : ℝ) (hx : 1≤x) :
    |coefficientLogMoment c x-(Real.log x)^2/2|≤2*K*Real.log x := by
  have hm := mul_le_mul_of_nonneg_left (hmertens x hx) (Real.log_nonneg hx)
  have hi := coefficientMass_integral_error c K hmertens x hx
  rw [coefficientLogMoment_identity c hc]
  have he : Real.log x*coefficientMass c x-(∫ t in Set.Ioc 1 x, t⁻¹*coefficientMass c t)-(Real.log x)^2/2 =
      Real.log x*(coefficientMass c x-Real.log x)-
        ((∫ t in Set.Ioc 1 x, t⁻¹*coefficientMass c t)-(Real.log x)^2/2) := by ring
  rw [he]
  apply (abs_sub _ _).trans
  rw [abs_mul,abs_of_nonneg (Real.log_nonneg hx)]
  linarith

theorem coefficientPairMass_linearization (c : ℕ → ℝ) (hc : c 0=0)
    (hcn : ∀ n, 0≤c n) (K : ℝ)
    (hmertens : ∀ t : ℝ, 1≤t → |coefficientMass c t-Real.log t|≤K)
    (x : ℝ) (hx : 1≤x) :
    |coefficientPairMass c x-(Real.log x*coefficientMass c x-coefficientLogMoment c x)| ≤ K*coefficientMass c x := by
  have he : Real.log x*coefficientMass c x-coefficientLogMoment c x =
      ∑ n ∈ Icc 1 (Nat.floor x), c n*Real.log (x/n) := by
    unfold coefficientMass coefficientLogMoment
    rw [sum_Icc_zero_eq_one hc,sum_Icc_zero_eq_one (f := fun n : ℕ => Real.log n*c n) (by simp),
      Finset.mul_sum,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro n hn
    have hn0 : (n:ℝ)≠0 := by exact_mod_cast (show n≠0 by have := (mem_Icc.mp hn).1; omega)
    rw [Real.log_div (by linarith : x≠0) hn0]
    ring
  rw [he,coefficientPairMass,← Finset.sum_sub_distrib]
  have hsum := Finset.abs_sum_le_sum_abs
    (fun n => c n*coefficientMass c (x/n)-c n*Real.log (x/n)) (Icc 1 (Nat.floor x))
  apply hsum.trans
  unfold coefficientMass
  rw [sum_Icc_zero_eq_one hc,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro n hn
  have hn0 : (0:ℝ)<n := by exact_mod_cast (mem_Icc.mp hn).1
  have hnx : (n:ℝ)≤x := (show (n:ℝ)≤Nat.floor x by exact_mod_cast (mem_Icc.mp hn).2).trans
    (Nat.floor_le (by linarith))
  have hm := mul_le_mul_of_nonneg_left (hmertens (x/n) ((le_div_iff₀ hn0).mpr (by simpa))) (hcn n)
  rw [← mul_sub,abs_mul,abs_of_nonneg (hcn n)]
  exact hm.trans_eq (mul_comm _ _)

theorem coefficient_two_symmetry (c : ℕ → ℝ) (hc : c 0=0)
    (hcn : ∀ n, 0≤c n) (K : ℝ) (hK : 0≤K)
    (hmertens : ∀ t : ℝ, 1≤t → |coefficientMass c t-Real.log t|≤K)
    (x : ℝ) (hx : 1≤x) :
    |coefficientLogMoment c x+coefficientPairMass c x-(Real.log x)^2| ≤ 2*K*Real.log x+K^2 := by
  have hp := coefficientPairMass_linearization c hc hcn K hmertens x hx
  have hm := mul_le_mul_of_nonneg_left (hmertens x hx) (Real.log_nonneg hx)
  have hu := mul_le_mul_of_nonneg_left (abs_le.mp (hmertens x hx)).2 hK
  have he : coefficientLogMoment c x+coefficientPairMass c x-(Real.log x)^2 =
      (coefficientPairMass c x-(Real.log x*coefficientMass c x-coefficientLogMoment c x))+
      Real.log x*(coefficientMass c x-Real.log x) := by ring
  rw [he]
  apply (abs_add_le _ _).trans
  rw [abs_mul,abs_of_nonneg (Real.log_nonneg hx)]
  nlinarith only [hp,hm,hu]

end MissingLinnik


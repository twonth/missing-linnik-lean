import MissingLinnik.TrianglePrimeBound
import MissingLinnik.EffectiveQuadraticBounds

namespace MissingLinnik

set_option maxRecDepth 4096
set_option maxHeartbeats 800000

def triangleExponent (j : ℕ) : ℕ := quadraticExponent (256*(j+1))

theorem triangleExponent_computable : Computable triangleExponent := by
  have ht : Primrec (fun j : ℕ => j+1) := Primrec.nat_add.comp Primrec.id (Primrec.const 1)
  have hn : Primrec (fun j : ℕ => 256*(j+1)) := Primrec.nat_mul.comp (Primrec.const 256) ht
  exact quadraticExponent_computable.comp hn.to_comp

/-- The triangular variant has its own determinant construction and its own
effective exponent. It shares only arithmetic estimates and the quadratic
prime specification with the rectangular routes. -/
theorem triangle_quadratic_bounds : QuadraticPrimeBounds triangleExponent := by
  intro j q x hq hx d _hd a ha haq P hprime hupper hinert
  let n := 256*(j+1)
  let Y := 16*(n+1)
  have hY : 1024 ≤ Y := by dsimp [Y,n]; omega
  have hx1 : 1 ≤ x := le_trans (one_le_pow₀ (by linarith : (1:ℝ) ≤ q)) hx
  have hf1 : 1 ≤ ⌊x⌋₊ := Nat.le_floor (by simpa using hx1)
  have hh := Triangle.prime_set_bound Y ⌊x⌋₊ hY hf1 d a ha q (by linarith) haq P
    hprime (fun p hp => Nat.le_floor (hupper p hp)) hinert
  have hlog : Real.log (⌊x⌋₊:ℝ) ≤ Real.log x :=
    Real.log_le_log (by exact_mod_cast (show 0 < ⌊x⌋₊ by omega))
      (Nat.floor_le (by linarith))
  have hm := mul_le_mul_of_nonneg_left hlog (show (0:ℝ) ≤ 1/2+2048/(Y:ℝ) by positivity)
  have he := effective_error_absorption n q x hq hx
  have hcoef : 1/((n:ℝ)+1) + 2040/(Y:ℝ) ≤ 1/((j:ℝ)+1) := by
    dsimp [Y,n]
    push_cast
    have ht : 0 < (j:ℝ)+1 := by positivity
    have hn : 0 < 256*((j:ℝ)+1)+1 := by positivity
    field_simp
    nlinarith only [ht,hn]
  have hcm := mul_le_mul_of_nonneg_right hcoef (Real.log_nonneg hx1)
  change (1/2+8/(Y:ℝ))*Real.log x + Real.log q + 128*(Y:ℝ)^2 ≤ _ at he
  have hid : (1/2+2048/(Y:ℝ))*Real.log x =
      (1/2+8/(Y:ℝ))*Real.log x + 2040/(Y:ℝ)*Real.log x := by ring
  nlinarith only [hh,hm,he,hcm,hid,sq_nonneg (Y:ℝ)]

end MissingLinnik

import MissingLinnik.RealCharacterLift

namespace MissingLinnik

theorem primitive_of_unit_kernel_imp {N : ℕ} [NeZero N]
    {R K : Type*} [CommRing R] [CommRing K]
    (ψ : DirichletCharacter R N) (χ : DirichletCharacter K N)
    (hψ : ψ.IsPrimitive)
    (himp : ∀ u : (ZMod N)ˣ, χ (u:ZMod N) = 1 → ψ (u:ZMod N) = 1) :
    χ.IsPrimitive := by
  have hfac := χ.factorsThrough_conductor
  have hfacψ : ψ.FactorsThrough χ.conductor := by
    apply (DirichletCharacter.factorsThrough_iff_ker_unitsMap hfac.dvd).mpr
    intro u hu
    have hh := (DirichletCharacter.factorsThrough_iff_ker_unitsMap hfac.dvd).mp hfac hu
    rw [MonoidHom.mem_ker] at hh ⊢
    apply Units.ext
    apply himp u
    exact congrArg Units.val hh
  have hcond : ψ.conductor ≤ χ.conductor := Nat.sInf_le hfacψ
  change χ.conductor = N
  change ψ.conductor = N at hψ
  rw [hψ] at hcond
  exact le_antisymm (Nat.le_of_dvd (NeZero.pos N) χ.conductor_dvd_level) hcond

theorem quadratic_int_cast_eq_one {K : Type*} [CommRing K] [Nontrivial K]
    (h2 : (2:K) ≠ 0) (z : ℤ) (hz : z=0 ∨ z=1 ∨ z= -1)
    (hcast : (z:K)=1) : z=1 := by
  rcases hz with hz | hz | hz
  · subst z
    simpa using hcast
  · exact hz
  · subst z
    have hh : (-1:K)=1 := by simpa using hcast
    have he : (2:K)=0 := by calc
      (2:K) = 1-(-1) := by ring
      _ = 0 := by rw [hh]; ring
    exact (h2 he).elim

noncomputable def reducedCharacter {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) (K : Type*) [CommRing K] : DirichletCharacter K N :=
  (integerCharacter ψ).ringHomComp (Int.castRingHom K)

theorem reducedCharacter_primitive {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) (hψ : ψ.IsPrimitive)
    (K : Type*) [CommRing K] [Nontrivial K] (h2 : (2:K) ≠ 0) :
    (reducedCharacter ψ K).IsPrimitive := by
  apply primitive_of_unit_kernel_imp ψ _ hψ
  intro u hu
  have hz : integerCharacter ψ (u:ZMod N)=1 :=
    quadratic_int_cast_eq_one h2 _ (integerCharacter_quadratic ψ (u:ZMod N)) hu
  have hh := integerCharacter_cast ψ (u:ZMod N)
  rw [hz,Int.cast_one] at hh
  exact hh.symm

theorem reducedCharacter_quadratic {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) (K : Type*) [CommRing K] :
    (reducedCharacter ψ K).IsQuadratic :=
  (integerCharacter_quadratic ψ).comp (Int.castRingHom K)

end MissingLinnik

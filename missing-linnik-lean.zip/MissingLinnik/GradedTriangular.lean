import MissingLinnik.DeterminantDivisibility
import Mathlib.Tactic.Linarith

namespace MissingLinnik

/-- A transformation that adds only rows of strictly smaller degree is
unitriangular, even when several rows have the same degree. -/
theorem det_eq_one_of_degree_lower {R ι : Type*} [CommRing R]
    [Fintype ι] [DecidableEq ι] (U : Matrix ι ι R) (degree : ι → ℕ)
    (hdiag : ∀ i, U i i = 1)
    (hlower : ∀ i j, i ≠ j → degree i ≤ degree j → U i j = 0) : U.det = 1 := by
  classical
  rw [Matrix.det_apply']
  rw [Finset.sum_eq_single (1 : Equiv.Perm ι)]
  · simp [hdiag]
  · intro σ _ hσ
    have hz : ∃ i, U (σ i) i = 0 := by
      by_contra hn
      push Not at hn
      have hle (i : ι) : degree i ≤ degree (σ i) := by
        by_cases he : σ i = i
        · simp [he]
        · exact Nat.le_of_lt (Nat.lt_of_not_ge (fun h => hn i (hlower _ _ he h)))
      have hex : ∃ i, σ i ≠ i := by
        by_contra hh
        push Not at hh
        apply hσ
        ext i
        exact hh i
      obtain ⟨i, hi⟩ := hex
      have hlt : degree i < degree (σ i) :=
        Nat.lt_of_not_ge (fun h => hn i (hlower _ _ hi h))
      have hs := Finset.sum_lt_sum (fun j (_ : j ∈ Finset.univ) => hle j)
        ⟨i, Finset.mem_univ i, hlt⟩
      simpa [Equiv.sum_comp σ] using hs
    obtain ⟨i, hi⟩ := hz
    rw [Finset.prod_eq_zero (f := fun j => U (σ j) j) (Finset.mem_univ i) hi, mul_zero]
  · simp

end MissingLinnik


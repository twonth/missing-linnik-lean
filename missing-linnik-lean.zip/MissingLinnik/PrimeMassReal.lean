import MissingLinnik.PrimeMertens

namespace MissingLinnik

open Finset ArithmeticFunction

noncomputable def primeMass (x : ℝ) : ℝ :=
  ∑ p ∈ Nat.primesLE (Nat.floor x), Real.log p/(p:ℝ)

noncomputable def primeCoefficient (n : ℕ) : ℝ :=
  if n.Prime then Real.log n/(n:ℝ) else 0

theorem primeCoefficient_nonneg (n : ℕ) : 0 ≤ primeCoefficient n := by
  unfold primeCoefficient
  split_ifs with hn
  · exact div_nonneg (Real.log_nonneg (by exact_mod_cast hn.one_le)) (Nat.cast_nonneg n)
  · exact le_rfl

theorem sum_primeCoefficient (x : ℝ) :
    (∑ n ∈ Finset.Icc 0 (Nat.floor x), primeCoefficient n) = primeMass x := by
  simp only [primeCoefficient,primeMass,← Finset.sum_filter,Nat.primesLE_eq_filter_Icc_zero]

theorem log_floor_gap (x : ℝ) (hx : 1 ≤ x) :
    0 ≤ Real.log x-Real.log (Nat.floor x) ∧ Real.log x-Real.log (Nat.floor x) ≤ 1 := by
  have hN : 1 ≤ Nat.floor x := Nat.le_floor (by simpa using hx)
  have hNpos : (0:ℝ) < Nat.floor x := by exact_mod_cast (show 0<Nat.floor x by omega)
  have hf : (Nat.floor x:ℝ) ≤ x := Nat.floor_le (by linarith)
  have hlog := Real.log_le_log hNpos hf
  have hN1 : (1:ℝ) ≤ Nat.floor x := by exact_mod_cast hN
  have hxlt := Nat.lt_floor_add_one x
  have hxu : x ≤ 2*(Nat.floor x:ℝ) := by linarith
  have hlogu := Real.log_le_log (show 0<x by linarith) hxu
  rw [Real.log_mul (by norm_num) hNpos.ne'] at hlogu
  have hlog2 := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
  constructor <;> linarith

theorem prime_mass_mertens (x : ℝ) (hx : 1 ≤ x) :
    |primeMass x-Real.log x| ≤ 79 := by
  have hn : 1 ≤ Nat.floor x := Nat.le_floor (by simpa using hx)
  have hm := abs_le.mp (prime_weighted_mertens (Nat.floor x) hn)
  have hg := log_floor_gap x hx
  unfold primeMass
  apply abs_le.mpr
  constructor <;> linarith

theorem primeMass_nonneg (x : ℝ) : 0 ≤ primeMass x := by
  rw [← sum_primeCoefficient]
  exact Finset.sum_nonneg (fun n hn => primeCoefficient_nonneg n)

end MissingLinnik



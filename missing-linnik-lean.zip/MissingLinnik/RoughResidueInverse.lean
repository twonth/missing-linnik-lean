import MissingLinnik.RoughCoefficients
import Mathlib.Data.ZMod.Basic

namespace MissingLinnik

theorem isRough_coprime (q Y d : ℕ) (hq : 0<q) (hqY : q≤Y) (hd : IsRough Y d) : d.Coprime q := by
  apply Nat.coprime_of_dvd
  intro p hp hpd hpq
  exact hd p (Nat.mem_primesLE.mpr ⟨(Nat.le_of_dvd hq hpq).trans hqY,hp⟩) hpd

noncomputable def inverseResidue (q c d : ℕ) : ℕ := ((c:ZMod q)*(d:ZMod q)⁻¹).val

theorem inverseResidue_congruence (q c d m : ℕ) (hq : 0<q) (hd : d.Coprime q) :
    Nat.ModEq q (d*m) c ↔ Nat.ModEq q m (inverseResidue q c d) := by
  letI : NeZero q := ⟨hq.ne'⟩
  rw [← ZMod.natCast_eq_natCast_iff,← ZMod.natCast_eq_natCast_iff]
  simp only [Nat.cast_mul,inverseResidue,ZMod.natCast_zmod_val]
  have hi := ZMod.coe_mul_inv_eq_one d hd
  constructor
  · intro h
    calc
      (m:ZMod q) = ((d:ZMod q)*(d:ZMod q)⁻¹)*m := by rw [hi,one_mul]
      _ = ((d:ZMod q)*m)*(d:ZMod q)⁻¹ := by ring
      _ = (c:ZMod q)*(d:ZMod q)⁻¹ := by rw [h]
  · intro h
    rw [h]
    calc
      (d:ZMod q)*((c:ZMod q)*(d:ZMod q)⁻¹) = (c:ZMod q)*((d:ZMod q)*(d:ZMod q)⁻¹) := by ring
      _ = c := by rw [hi,mul_one]

theorem inverseResidue_coprime (q c d : ℕ) (hq : 0<q) (hc : c.Coprime q) (hd : d.Coprime q) :
    (inverseResidue q c d).Coprime q := by
  letI : NeZero q := ⟨hq.ne'⟩
  apply (ZMod.isUnit_iff_coprime _ _).mp
  simp only [inverseResidue,ZMod.natCast_zmod_val]
  exact ((ZMod.unitOfCoprime c hc).isUnit).mul (by
    have hi := ZMod.coe_mul_inv_eq_one d hd
    exact isUnit_iff_exists_inv.mpr ⟨(d:ZMod q),by simpa [mul_comm] using hi⟩)

end MissingLinnik

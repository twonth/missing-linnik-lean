import MissingLinnik.ResultantMultiplicity

namespace MissingLinnik

theorem natDegree_det_le_sum_columns {K ι : Type*} [CommRing K]
    [Fintype ι] [DecidableEq ι] (M : Matrix ι ι (Polynomial K)) (b : ι → ℕ)
    (hb : ∀ i j, (M i j).natDegree ≤ b j) : M.det.natDegree ≤ ∑ j, b j := by
  rw [Matrix.det_apply']
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro σ _
  apply (Polynomial.natDegree_mul_le).trans
  simp only [Polynomial.natDegree_intCast, zero_add]
  exact (Polynomial.natDegree_prod_le _ _).trans (Finset.sum_le_sum (fun i _ => hb (σ i) i))

theorem resultant_degree_le {K : Type*} [CommRing K]
    (f g : Polynomial (Polynomial K)) (m n D : ℕ)
    (hf : ∀ i, (f.coeff i).natDegree ≤ D) (hg : ∀ i, (g.coeff i).natDegree ≤ D) :
    (f.resultant g m n).natDegree ≤ (m + n) * D := by
  have h := natDegree_det_le_sum_columns (f.sylvester g m n) (fun _ => D)
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul] at h
  apply h
  intro i j
  induction j using Fin.addCases with
  | left j =>
    simp only [Polynomial.sylvester, Matrix.of_apply, Fin.addCases_left]
    split_ifs
    · exact hg _
    · simp
  | right j =>
    simp only [Polynomial.sylvester, Matrix.of_apply, Fin.addCases_right]
    split_ifs
    · exact hf _
    · simp

/-- Green's bound (A.1), with a uniform bound D on the degrees of the
coefficient polynomials in the other variable. -/
theorem green_resultant_degree_le {K : Type*} [CommRing K]
    (f : Polynomial (Polynomial K)) (D : ℕ)
    (hf : ∀ i, (f.coeff i).natDegree ≤ D) :
    (f.resultant f.derivative).natDegree ≤ 2 * f.natDegree * D := by
  have hg : ∀ i, (f.derivative.coeff i).natDegree ≤ D := by
    intro i
    rw [Polynomial.coeff_derivative]
    exact (Polynomial.natDegree_mul_le).trans (by simpa using hf (i+1))
  have h := resultant_degree_le f f.derivative f.natDegree f.derivative.natDegree D hf hg
  have hd := Polynomial.natDegree_derivative_le f
  apply h.trans
  exact Nat.mul_le_mul_right D (by omega)

end MissingLinnik

import MissingLinnik.ClassConvolution
import MissingLinnik.SquaredLogRemainder

namespace MissingLinnik

open Finset ArithmeticFunction

theorem roughRestriction_mangoldt_div (Y n : ℕ) :
    roughRestriction Y vonMangoldt n/(n:ℝ)=roughMangoldtCoefficient Y n := by
  rw [roughRestriction_apply]
  unfold roughMangoldtCoefficient
  split_ifs <;> ring

theorem roughRestriction_support_coprime (q Y : ℕ) (hq : 0<q) (hqY : q≤Y)
    (d : ℕ) (hd : roughRestriction Y vonMangoldt d≠0) : d.Coprime q := by
  apply isRough_coprime q Y d hq hqY
  by_contra hr
  exact hd (by rw [roughRestriction_apply,if_neg hr])

theorem roughQ_log_weight (q k c : ℕ) (hq : 2≤q) (hk : 1≤k) (hc : c.Coprime q)
    (x : ℝ) (hx : 1≤x) :
    |arithmeticClassSum (logWeight (twoKernel (roughRestriction (q^(170*k)) vonMangoldt))) q c x-
      2*(Real.log x)^3/(3*q.totient)| ≤
      2*(10:ℝ)^42*Real.log ((q^(170*k):ℕ):ℝ)*(Real.log x)^2/q.totient := by
  let Y := q^(170*k)
  have hY : 2≤Y := by
    apply hq.trans
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hlY : 0≤Real.log (Y:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤Y by omega))
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have hb (t : ℝ) (ht : 1≤t) :
      |coefficientMass (arithmeticClassCoefficient (twoKernel (roughRestriction Y vonMangoldt)) q c) t-
        (1/(q.totient:ℝ))*(Real.log t)^2| ≤ ((10:ℝ)^42*Real.log Y/q.totient)*Real.log t := by
    rw [coefficientMass_class,← roughQ_eq_arithmeticClassSum]
    convert rough_two_real q k c hq hk hc t ht using 1
    · dsimp only [Y]
      congr 1
      ring
    · dsimp only [Y]
      ring
  have hh := quadratic_mass_log_weight
    (arithmeticClassCoefficient (twoKernel (roughRestriction Y vonMangoldt)) q c)
    (arithmeticClassCoefficient_zero _ _ _) (1/(q.totient:ℝ)) ((10:ℝ)^42*Real.log Y/q.totient)
    (by positivity) hb x hx
  rw [coefficientLogMoment_class] at hh
  convert hh using 1
  · dsimp only [Y]
    congr 1
    ring
  · dsimp only [Y]
    ring

theorem roughQ_convolution_error (q k c : ℕ) (hq : 2≤q) (hk : 1≤k) (hc : c.Coprime q)
    (x : ℝ) (hx : 1≤x) :
    |arithmeticClassSum (roughRestriction (q^(170*k)) vonMangoldt*
      twoKernel (roughRestriction (q^(170*k)) vonMangoldt)) q c x-
      (∑ d ∈ Icc 1 (Nat.floor x), roughMangoldtCoefficient (q^(170*k)) d*(Real.log (x/d))^2)/q.totient| ≤
      (10:ℝ)^42*Real.log ((q^(170*k):ℕ):ℝ)*Real.log x*roughMangoldtMass (q^(170*k)) x/q.totient := by
  let Y := q^(170*k)
  have hqY : q≤Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hlY : 0≤Real.log (Y:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤Y by omega))
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  rw [arithmeticClassSum_convolution _ _ q c (by omega)
    (roughRestriction_support_coprime q Y (by omega) hqY),Finset.sum_div,← Finset.sum_sub_distrib]
  simp_rw [roughRestriction_mangoldt_div,← roughQ_eq_arithmeticClassSum]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  have hsum : (∑ d ∈ Icc 1 (Nat.floor x),
      |roughMangoldtCoefficient Y d*roughQ q (inverseResidue q c d) Y (x/d)-
        roughMangoldtCoefficient Y d*(Real.log (x/d))^2/q.totient|) ≤
      ∑ d ∈ Icc 1 (Nat.floor x), ((10:ℝ)^42*Real.log Y*Real.log x/q.totient)*roughMangoldtCoefficient Y d := by
    apply Finset.sum_le_sum
    intro d hd
    by_cases ha : roughMangoldtCoefficient Y d=0
    · simp only [ha,zero_mul,zero_div,sub_self,abs_zero,mul_zero,le_refl]
    · have hr : IsRough Y d := by
        by_contra hr
        exact ha (by unfold roughMangoldtCoefficient; rw [if_neg hr])
      have hdc := isRough_coprime q Y d (by omega) hqY hr
      have hb := inverseResidue_coprime q c d (by omega) hc hdc
      have hd1 : (1:ℝ)≤d := by exact_mod_cast (mem_Icc.mp hd).1
      have hdx : (d:ℝ)≤x := (show (d:ℝ)≤Nat.floor x by exact_mod_cast (mem_Icc.mp hd).2).trans
        (Nat.floor_le (by linarith))
      have hxdiv : 1≤x/(d:ℝ) := (le_div_iff₀ (by linarith : (0:ℝ)<d)).mpr (by simpa)
      have herr := rough_two_real q k (inverseResidue q c d) hq hk hb (x/d) hxdiv
      have hlog : Real.log (x/(d:ℝ))≤Real.log x := Real.log_le_log (by linarith : 0<x/(d:ℝ))
        ((div_le_self (by linarith : 0≤x) hd1))
      have hscale := mul_le_mul_of_nonneg_left hlog (show 0≤(10:ℝ)^42*Real.log Y/q.totient by positivity)
      have herror : |roughQ q (inverseResidue q c d) Y (x/d)-(Real.log (x/d))^2/q.totient| ≤
          (10:ℝ)^42*Real.log Y*Real.log x/q.totient := herr.trans (by convert hscale using 1 <;> ring)
      have hm := mul_le_mul_of_nonneg_left herror (roughMangoldtCoefficient_nonneg Y d)
      have he : roughMangoldtCoefficient Y d*roughQ q (inverseResidue q c d) Y (x/d)-
          roughMangoldtCoefficient Y d*(Real.log (x/d))^2/q.totient =
          roughMangoldtCoefficient Y d*(roughQ q (inverseResidue q c d) Y (x/d)-(Real.log (x/d))^2/q.totient) := by ring
      rw [he,abs_mul,abs_of_nonneg (roughMangoldtCoefficient_nonneg Y d)]
      exact hm.trans_eq (mul_comm _ _)
  apply hsum.trans_eq
  rw [← Finset.mul_sum]
  unfold roughMangoldtMass
  rw [sum_Icc_zero_eq_one (roughMangoldtCoefficient_zero Y)]
  ring

end MissingLinnik

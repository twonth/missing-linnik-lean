import MissingLinnik.GreenFiniteBound
import MissingLinnik.GreenParameters
import MissingLinnik.ParameterizedPrimeBound
import MissingLinnik.PrimeTailBounds

namespace MissingLinnik.Green

/-- An explicit middle-window estimate from Green's characteristic-zero
interpolation proof. No largest inert prime or finite-field independence is used. -/
theorem window_prime_bound (k m : ℕ) (hk : 8 ≤ k) (hm : 64 ≤ m)
    (d : ℤ) (hd : ∀ n : ℤ, d ≠ n*n)
    (a : ℂ) (ha : a^2=d) (q : ℝ) (hq : 1 ≤ q) (haq : ‖a‖^2 ≤ q)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime)
    (hlower : ∀ p ∈ P, k^2 ≤ p) (hupper : ∀ p ∈ P, p ≤ k*m)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) :
    (∑ p ∈ P, Real.log p / p) ≤
      (1/2+8/(k:ℝ))*Real.log (k^2*m) + Real.log q + 8 := by
  have hR : 2 ≤ k^2*m := by nlinarith
  have hS : 0 < k*m := by positivity
  obtain ⟨hNJ,hsize⟩ := grid_parameter_conditions k m hk hm
  let B := 8*Real.sqrt ((k^2*m : ℕ) : ℝ)*Real.sqrt q
  obtain ⟨hB,hNB,hlogB⟩ := doubled_grid_archimedean_bound (k^2*m) hR q hq a haq
  have hT : (k-1)*m+m ≤ k*m := by
    rw [← Nat.succ_mul, Nat.succ_eq_add_one, Nat.sub_add_cancel (by omega)]
  have hfinite := finite_inert_prime_bound (2*((k^2*m).sqrt+1)) (k*m) (k^2*m) (k*m) m
    ((k-1)*m) d hd a ha hS hNJ le_rfl (by omega) hsize B hB hNB P hprime
    (fun p hp => by have := hlower p hp; nlinarith) hinert
    (fun p hp => Nat.mul_le_mul_right m (hlower p hp)) hT
  have hparam := parameterized_prime_bound k m hk (by omega) B hB P hprime hupper (by
    simpa only [Nat.cast_mul, Nat.cast_pow] using hfinite)
  apply logarithmic_parameter_bound (k:ℝ) (Real.log ((k:ℝ)^2*m)) (Real.log q) (Real.log B)
    (∑ p ∈ P, Real.log p / p) (by exact_mod_cast hk)
    (Real.log_nonneg (by exact_mod_cast (show 1 ≤ k^2*m by omega))) (Real.log_nonneg hq)
    (by simpa only [B, Nat.cast_mul, Nat.cast_pow] using hlogB.le) hparam

end MissingLinnik.Green

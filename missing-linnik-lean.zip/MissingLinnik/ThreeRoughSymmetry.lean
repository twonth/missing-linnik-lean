import MissingLinnik.WeightedRoughSymmetry

namespace MissingLinnik

open Finset ArithmeticFunction

theorem roughQ_convolution_estimate (q k c : ℕ) (hq : 2≤q) (hk : 1≤k) (hc : c.Coprime q)
    (x : ℝ) (hx : ((q^(170*k):ℕ):ℝ)≤x) :
    |arithmeticClassSum (roughRestriction (q^(170*k)) vonMangoldt*
      twoKernel (roughRestriction (q^(170*k)) vonMangoldt)) q c x-(Real.log x)^3/(3*q.totient)| ≤
      (10:ℝ)^45*Real.log ((q^(170*k):ℕ):ℝ)*(Real.log x)^2/q.totient := by
  let Y := q^(170*k)
  have hY : 2≤Y := by
    apply hq.trans
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hx1 : 1≤x := (show (1:ℝ)≤Y by exact_mod_cast (show 1≤Y by omega)).trans hx
  have hlY := log_nat_ge_half Y hY
  have hlx := Real.log_le_log (by exact_mod_cast (show 0<Y by omega) : (0:ℝ)<Y) hx
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have herr := roughQ_convolution_error q k c hq hk hc x hx1
  have hmain := squared_log_remainder_estimate (roughMangoldtCoefficient Y)
    (roughMangoldtCoefficient_zero Y) (Real.log Y+157) (by linarith)
    (fun t ht => rough_mangoldt_mertens Y hY t ht) x hx1
  have hmass := (abs_le.mp (rough_mangoldt_mertens Y hY x hx1)).2
  have hK : Real.log (Y:ℝ)+157 ≤ 315*Real.log Y := by linarith
  have hmass' : roughMangoldtMass Y x ≤ 316*Real.log x := by linarith
  have herr' := mul_le_mul_of_nonneg_left hmass'
    (show 0≤(10:ℝ)^42*Real.log Y*Real.log x/q.totient by positivity [Real.log_nonneg hx1])
  have hmain' := mul_le_mul_of_nonneg_right hK (show 0≤9*(Real.log x)^2/q.totient by positivity)
  let S := ∑ d ∈ Icc 1 (Nat.floor x), roughMangoldtCoefficient Y d*(Real.log (x/d))^2
  have he : arithmeticClassSum (roughRestriction Y vonMangoldt*twoKernel (roughRestriction Y vonMangoldt)) q c x-
      (Real.log x)^3/(3*q.totient) =
      (arithmeticClassSum (roughRestriction Y vonMangoldt*twoKernel (roughRestriction Y vonMangoldt)) q c x-S/q.totient)+
      (S-(Real.log x)^3/3)/q.totient := by ring
  change |arithmeticClassSum (roughRestriction Y vonMangoldt*twoKernel (roughRestriction Y vonMangoldt)) q c x-
    (Real.log x)^3/(3*q.totient)| ≤ _
  rw [he]
  apply (abs_add_le _ _).trans
  rw [abs_div,abs_of_pos hφ]
  apply (add_le_add herr (div_le_div_of_nonneg_right hmain hφ.le)).trans
  have hp : 0≤Real.log (Y:ℝ)*(Real.log x)^2/q.totient := by positivity
  have hconst := mul_le_mul_of_nonneg_right (show (316:ℝ)*10^42+2835≤10^45 by norm_num) hp
  change (10:ℝ)^42*Real.log Y*Real.log x*roughMangoldtMass Y x/q.totient+
    9*(Real.log Y+157)*(Real.log x)^2/q.totient ≤ (10:ℝ)^45*Real.log Y*(Real.log x)^2/q.totient
  ring_nf at herr' hmain' hconst ⊢
  linarith only [herr',hmain',hconst]

/-- Quantitative three-term symmetry, retaining prime powers until the final
error estimate. This follows the manuscript's logarithmic weighting and
convolution subtraction, with the pair cancellation checked algebraically. -/
theorem rough_three_real (q k c : ℕ) (hq : 2≤q) (hk : 1≤k) (hc : c.Coprime q)
    (x : ℝ) (hx : ((q^(170*k):ℕ):ℝ)≤x) :
    |2*arithmeticClassSum (roughRestriction (q^(170*k)) vonMangoldt*
      roughRestriction (q^(170*k)) vonMangoldt*roughRestriction (q^(170*k)) vonMangoldt) q c x-
      arithmeticClassSum (logWeight (logWeight (roughRestriction (q^(170*k)) vonMangoldt))) q c x| ≤
      (10:ℝ)^46*Real.log ((q^(170*k):ℕ):ℝ)*(Real.log x)^2/q.totient := by
  let Y := q^(170*k)
  let f := roughRestriction Y vonMangoldt
  have hY : 2≤Y := by
    apply hq.trans
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hx1 : 1≤x := (show (1:ℝ)≤Y by exact_mod_cast (show 1≤Y by omega)).trans hx
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have hlog := roughQ_log_weight q k c hq hk hc x hx1
  have hconv := roughQ_convolution_estimate q k c hq hk hc x hx
  have hid := congrArg (fun g : ArithmeticFunction ℝ => arithmeticClassSum g q c x) (triple_kernel_identity f)
  simp only [arithmeticClassSum_add,arithmeticClassSum_two_smul] at hid
  have he : 2*arithmeticClassSum (f*f*f) q c x-arithmeticClassSum (logWeight (logWeight f)) q c x =
      2*(arithmeticClassSum (f*twoKernel f) q c x-(Real.log x)^3/(3*q.totient))-
      (arithmeticClassSum (logWeight (twoKernel f)) q c x-2*(Real.log x)^3/(3*q.totient)) := by
    ring_nf at hid ⊢
    linarith only [hid]
  change |2*arithmeticClassSum (f*f*f) q c x-arithmeticClassSum (logWeight (logWeight f)) q c x| ≤ _
  rw [he]
  apply (abs_sub _ _).trans
  rw [abs_mul,abs_of_pos (by norm_num : (0:ℝ)<2)]
  apply (add_le_add (mul_le_mul_of_nonneg_left hconv (by norm_num : (0:ℝ)≤2)) hlog).trans
  have hlY := Real.log_nonneg (show (1:ℝ)≤Y by exact_mod_cast (show 1≤Y by omega))
  have hp : 0≤Real.log (Y:ℝ)*(Real.log x)^2/q.totient := by positivity
  have hh := mul_le_mul_of_nonneg_right (show (2:ℝ)*10^45+2*10^42≤10^46 by norm_num) hp
  convert hh using 1 <;> ring

end MissingLinnik

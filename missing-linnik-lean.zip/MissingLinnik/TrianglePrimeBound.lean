import MissingLinnik.TriangleWindowBound
import MissingLinnik.PrimeTailBounds

namespace MissingLinnik.Triangle

/-- The triangular variant, adapted from the uploaded Linnik proof to an
arbitrary finite set of inert primes, with explicit uniform error terms. -/
theorem prime_set_bound (Y X : ℕ) (hY : 1024 ≤ Y) (hX : 1 ≤ X)
    (d : ℤ) (a : ℂ) (ha : a^2=d) (q : ℝ) (hq : 1 ≤ q) (haq : ‖a‖^2 ≤ q)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime) (hupper : ∀ p ∈ P, p ≤ X)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) :
    (∑ p ∈ P, Real.log p/p) ≤
      (1/2+2048/(Y:ℝ))*Real.log X + Real.log q + 4*(Y:ℝ)^2 := by
  classical
  have hYr : (1024:ℝ) ≤ Y := by exact_mod_cast hY
  have hlogX := Real.log_nonneg (show (1:ℝ) ≤ X by exact_mod_cast hX)
  have hlogq := Real.log_nonneg hq
  have hmain : 0 ≤ (1/2+2048/(Y:ℝ))*Real.log X := by positivity
  have hl4 : Real.log (4:ℝ) ≤ 2 := by
    have hl2 := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    rw [show (4:ℝ)=2^2 by norm_num,Real.log_pow]
    norm_num
    linarith
  by_cases hP : P.Nonempty
  · let L := P.max' hP
    have hLP : L ∈ P := Finset.max'_mem P hP
    have hPL : ∀ p ∈ P, p ≤ L := fun p hp => Finset.le_max' P p hp
    letI : Fact L.Prime := ⟨hprime L hLP⟩
    by_cases hL : 8*Y ≤ L
    · let Q := P.filter (fun p => Y ≤ p)
      have hh := window_prime_bound Y L hY hL d (hinert L hLP) a ha q hq haq Q
        (fun p hp => hprime p (Finset.mem_filter.mp hp).1)
        (fun p hp => (Finset.mem_filter.mp hp).2)
        (fun p hp => hPL p (Finset.mem_filter.mp hp).1)
        (fun p hp => hinert p (Finset.mem_filter.mp hp).1)
      have hsmall := prime_mass_small_le (P.filter (fun p => ¬Y ≤ p)) Y
        (fun p hp => hprime p (Finset.mem_filter.mp hp).1)
        (fun p hp => by have := (Finset.mem_filter.mp hp).2; omega)
      have hsmall' := mul_le_mul_of_nonneg_right hl4 (Nat.cast_nonneg Y : (0:ℝ) ≤ Y)
      have he := Finset.sum_filter_add_sum_filter_not P (fun p => Y ≤ p)
        (fun p : ℕ => Real.log p/p)
      have hlog := Real.log_le_log
        (show (0:ℝ) < L by exact_mod_cast (hprime L hLP).pos)
        (show (L:ℝ) ≤ X by exact_mod_cast hupper L hLP)
      have hm := mul_le_mul_of_nonneg_left hlog (show (0:ℝ) ≤ 1/2+2048/(Y:ℝ) by positivity)
      dsimp only [Q] at hh
      nlinarith
    · have hsmall := prime_mass_small_le P (8*Y) hprime (fun p hp => by
        have := hPL p hp; omega)
      have hh := mul_le_mul_of_nonneg_right hl4 (show (0:ℝ) ≤ 8*Y by positivity)
      push_cast at hsmall
      nlinarith
  · have he : P=∅ := Finset.not_nonempty_iff_eq_empty.mp hP
    rw [he,Finset.sum_empty]
    positivity

end MissingLinnik.Triangle

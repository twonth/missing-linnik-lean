import MissingLinnik.SelbergIdentity
import MissingLinnik.RoughCoefficients

namespace MissingLinnik

open Finset

def hyperbolaPairs (N : ℕ) : Finset (ℕ × ℕ) :=
  ((Icc 1 N).product (Icc 1 N)).filter (fun a => a.1*a.2 ≤ N)

theorem mem_hyperbolaPairs (N d m : ℕ) : (d,m) ∈ hyperbolaPairs N ↔ 0<d ∧ 0<m ∧ d*m≤N := by
  constructor
  · intro h
    obtain ⟨hmem,hp⟩ := Finset.mem_filter.mp h
    obtain ⟨hd,hm⟩ := Finset.mem_product.mp hmem
    obtain ⟨hd,_⟩ := Finset.mem_Icc.mp hd
    obtain ⟨hm,_⟩ := Finset.mem_Icc.mp hm
    exact ⟨hd,hm,hp⟩
  · rintro ⟨hd,hm,hp⟩
    have hdN : d≤N := (Nat.le_mul_of_pos_right d hm).trans hp
    have hmN : m≤N := (Nat.le_mul_of_pos_left m hd).trans hp
    exact Finset.mem_filter.mpr ⟨Finset.mem_product.mpr
      ⟨Finset.mem_Icc.mpr ⟨hd,hdN⟩,Finset.mem_Icc.mpr ⟨hm,hmN⟩⟩,hp⟩

theorem sum_divisor_pairs (N : ℕ) (F : ℕ → ℕ → ℝ) :
    (∑ n ∈ Icc 1 N, ∑ a ∈ n.divisorsAntidiagonal, F a.1 a.2) =
      ∑ a ∈ hyperbolaPairs N, F a.1 a.2 := by
  rw [← Finset.sum_sigma (Icc 1 N) (fun n => n.divisorsAntidiagonal)
    (fun a : Σ _ : ℕ, ℕ × ℕ => F a.2.1 a.2.2)]
  apply Finset.sum_bij (fun a _ => a.2)
  · intro a ha
    obtain ⟨hn,ha⟩ := Finset.mem_sigma.mp ha
    obtain ⟨hp,hn0⟩ := Nat.mem_divisorsAntidiagonal.mp ha
    have hd : 0<a.2.1 := Nat.pos_of_ne_zero (by intro he; simp [he] at hp; exact hn0 hp.symm)
    have hm : 0<a.2.2 := Nat.pos_of_ne_zero (by intro he; simp [he] at hp; exact hn0 hp.symm)
    exact (mem_hyperbolaPairs N a.2.1 a.2.2).mpr ⟨hd,hm,hp ▸ (mem_Icc.mp hn).2⟩
  · intro a ha b hb hab
    obtain ⟨_,ha⟩ := Finset.mem_sigma.mp ha
    obtain ⟨_,hb⟩ := Finset.mem_sigma.mp hb
    have hn : a.1=b.1 := by
      rw [← (Nat.mem_divisorsAntidiagonal.mp ha).1,← (Nat.mem_divisorsAntidiagonal.mp hb).1,hab]
    exact Sigma.ext hn (heq_of_eq hab)
  · intro a ha
    obtain ⟨hd,hm,hp⟩ := (mem_hyperbolaPairs N a.1 a.2).mp ha
    refine ⟨⟨a.1*a.2,a⟩,?_,rfl⟩
    exact Finset.mem_sigma.mpr ⟨mem_Icc.mpr ⟨Nat.mul_pos hd hm,hp⟩,
      Nat.mem_divisorsAntidiagonal.mpr ⟨rfl,(Nat.mul_pos hd hm).ne'⟩⟩
  · intro a ha
    rfl

theorem sum_hyperbolaPairs (N : ℕ) (F : ℕ → ℕ → ℝ) :
    (∑ a ∈ hyperbolaPairs N, F a.1 a.2) = ∑ d ∈ Icc 1 N, ∑ m ∈ Icc 1 (N/d), F d m := by
  symm
  rw [← Finset.sum_sigma (Icc 1 N) (fun d => Icc 1 (N/d))
    (fun a : Σ _ : ℕ, ℕ => F a.1 a.2)]
  apply Finset.sum_bij (fun a _ => (a.1,a.2))
  · intro a ha
    obtain ⟨hd,hm⟩ := Finset.mem_sigma.mp ha
    exact (mem_hyperbolaPairs N a.1 a.2).mpr ⟨(mem_Icc.mp hd).1,(mem_Icc.mp hm).1,
      by simpa [Nat.mul_comm] using (Nat.le_div_iff_mul_le (mem_Icc.mp hd).1).mp (mem_Icc.mp hm).2⟩
  · intro a ha b hb hab
    have hd := congrArg Prod.fst hab
    have hm := congrArg Prod.snd hab
    exact Sigma.ext hd (heq_of_eq hm)
  · intro a ha
    obtain ⟨hd,hm,hp⟩ := (mem_hyperbolaPairs N a.1 a.2).mp ha
    refine ⟨⟨a.1,a.2⟩,?_,rfl⟩
    exact Finset.mem_sigma.mpr ⟨mem_Icc.mpr ⟨hd,(Nat.le_mul_of_pos_right _ hm).trans hp⟩,
      mem_Icc.mpr ⟨hm,(Nat.le_div_iff_mul_le hd).mpr (by simpa [Nat.mul_comm] using hp)⟩⟩
  · intro a ha
    rfl

theorem isRough_mul (Y d m : ℕ) : IsRough Y (d*m) ↔ IsRough Y d ∧ IsRough Y m := by
  constructor
  · intro h
    exact ⟨fun p hp hd => h p hp (dvd_mul_of_dvd_left hd m),
      fun p hp hm => h p hp (dvd_mul_of_dvd_right hm d)⟩
  · rintro ⟨hd,hm⟩ p hp hdiv
    rcases ((Nat.mem_primesLE.mp hp).2.dvd_mul.mp hdiv) with hdv | hmv
    · exact hd p hp hdv
    · exact hm p hp hmv

end MissingLinnik

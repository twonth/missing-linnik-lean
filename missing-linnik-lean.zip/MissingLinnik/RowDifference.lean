import MissingLinnik.GradedTriangular
import Lean.Elab.Tactic.Omega

namespace MissingLinnik

def rowDifference {V : Type*} [Sub V] (p : ℕ) (B : ℕ → ℕ → V) :
    ℕ → ℕ → ℕ → V
  | 0, r, s => B r s
  | h + 1, r, s => rowDifference p B h r s - rowDifference p B h (r - p) (s + 1)

def rowDifferenceCoeff {K : Type*} [Ring K] (p : ℕ) (h r s u v : ℕ) : K :=
  rowDifference p (fun r s => if r = u ∧ s = v then 1 else 0) h r s

theorem rowDifferenceCoeff_zero_of_lt {K : Type*} [Ring K]
    (p h r s u v : ℕ) (hr : r < u) :
    rowDifferenceCoeff (K := K) p h r s u v = 0 := by
  induction h generalizing r s with
  | zero => simp [rowDifferenceCoeff, rowDifference, Nat.ne_of_lt hr]
  | succ h ih =>
    change rowDifferenceCoeff p h r s u v - rowDifferenceCoeff p h (r-p) (s+1) u v = 0
    rw [ih r s hr, ih (r-p) (s+1) (lt_of_le_of_lt (Nat.sub_le _ _) hr), sub_self]

theorem rowDifferenceCoeff_at_or_above {K : Type*} [Ring K]
    (p h r s u v : ℕ) (hp : 0 < p) (hpr : p * h ≤ r) (hru : r ≤ u) :
    rowDifferenceCoeff (K := K) p h r s u v = if r = u ∧ s = v then 1 else 0 := by
  induction h generalizing r s with
  | zero => rfl
  | succ h ih =>
    have hpR : p ≤ r := by rw [Nat.mul_succ] at hpr; omega
    have hh : p * h ≤ r := by rw [Nat.mul_succ] at hpr; omega
    change rowDifferenceCoeff p h r s u v - rowDifferenceCoeff p h (r-p) (s+1) u v = _
    rw [ih r s hh hru, rowDifferenceCoeff_zero_of_lt p h (r-p) (s+1) u v (by omega), sub_zero]

theorem rowDifference_eq_sum {K : Type*} [CommRing K]
    (p h r s R S : ℕ) (B : ℕ → ℕ → K)
    (hr : r < R) (hs : s + h < S) :
    rowDifference p B h r s =
      ∑ i : Fin R × Fin S, rowDifferenceCoeff p h r s i.1.val i.2.val * B i.1.val i.2.val := by
  classical
  induction h generalizing r s with
  | zero =>
    simp only [rowDifference, rowDifferenceCoeff]
    rw [Finset.sum_eq_single (⟨r, hr⟩, ⟨s, by omega⟩)]
    · simp
    · intro i _ hi
      have hn : ¬(r = i.1.val ∧ s = i.2.val) := by
        rintro ⟨hu, hv⟩
        apply hi
        exact Prod.ext (Fin.ext hu.symm) (Fin.ext hv.symm)
      simp [hn]
    · simp
  | succ h ih =>
    change rowDifference p B h r s - rowDifference p B h (r-p) (s+1) = _
    rw [ih r s hr (by omega), ih (r-p) (s+1) (by omega) (by omega), ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    simp only [rowDifferenceCoeff, rowDifference]
    ring

theorem rowDifference_map {K V W : Type*} [Ring K]
    [AddCommGroup V] [AddCommGroup W] [Module K V] [Module K W]
    (L : V →ₗ[K] W) (p h r s : ℕ) (B : ℕ → ℕ → V) :
    L (rowDifference p B h r s) = rowDifference p (fun r s => L (B r s)) h r s := by
  induction h generalizing r s with
  | zero => rfl
  | succ h ih => simp only [rowDifference, map_sub, ih]

theorem rowDifference_polynomial {K : Type*} [CommRing K]
    (p h r s : ℕ) (w : K) (hr : p * h ≤ r) :
    rowDifference p (fun r s => (Polynomial.X : Polynomial K) ^ r * Polynomial.C (w ^ s)) h r s =
      (Polynomial.X ^ p - Polynomial.C w) ^ h *
        Polynomial.X ^ (r - p * h) * Polynomial.C (w ^ s) := by
  induction h generalizing r s with
  | zero => simp [rowDifference]
  | succ h ih =>
    have hh : p * h ≤ r := by rw [Nat.mul_succ] at hr; omega
    have hh' : p * h ≤ r - p := by rw [Nat.mul_succ] at hr; omega
    have he : r - p * h = p + (r - p * (h + 1)) := by rw [Nat.mul_succ] at *; omega
    have he' : r - p - p * h = r - p * (h + 1) := by omega
    rw [rowDifference, ih r s hh, ih (r-p) (s+1) hh', he, he', pow_add,
      pow_succ w s, Polynomial.C_mul, pow_succ]
    ring

theorem det_rowDifference {K : Type*} [CommRing K]
    (p R S : ℕ) (B : ℕ → ℕ → (Fin R × Fin S) → K)
    (h : (Fin R × Fin S) → ℕ) (hp : 0 < p)
    (hr : ∀ i, p * h i ≤ i.1.val) (hs : ∀ i, i.2.val + h i < S) :
    (Matrix.of (fun i j => rowDifference p (fun r s => B r s j) (h i) i.1.val i.2.val)).det =
      (Matrix.of (fun i j => B i.1.val i.2.val j)).det := by
  classical
  let U : Matrix (Fin R × Fin S) (Fin R × Fin S) K :=
    Matrix.of (fun i j => rowDifferenceCoeff p (h i) i.1.val i.2.val j.1.val j.2.val)
  have hU : U.det = 1 := by
    apply det_eq_one_of_degree_lower U (fun i => i.1.val)
    · intro i
      simp [U, rowDifferenceCoeff_at_or_above p (h i) i.1.val i.2.val
        i.1.val i.2.val hp (hr i) le_rfl]
    · intro i j hij hdeg
      change rowDifferenceCoeff p (h i) i.1.val i.2.val j.1.val j.2.val = 0
      rw [rowDifferenceCoeff_at_or_above p (h i) i.1.val i.2.val
        j.1.val j.2.val hp (hr i) hdeg]
      split_ifs with he
      · exact (hij (Prod.ext (Fin.ext he.1) (Fin.ext he.2))).elim
      · rfl
  have heq : Matrix.of (fun i j => rowDifference p (fun r s => B r s j) (h i) i.1.val i.2.val) =
      U * Matrix.of (fun i j => B i.1.val i.2.val j) := by
    apply Matrix.ext
    intro i j
    exact rowDifference_eq_sum p (h i) i.1.val i.2.val R S
      (fun r s => B r s j) i.1.isLt (hs i)
  rw [heq, Matrix.det_mul, hU, one_mul]

end MissingLinnik



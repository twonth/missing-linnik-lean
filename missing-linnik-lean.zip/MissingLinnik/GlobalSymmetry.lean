import MissingLinnik.PrimeLogMoment

namespace MissingLinnik

open Finset

/-- The inner prime-mass sum restricts the second prime by pr ≤ x. -/
noncomputable def primePairMass (x : ℝ) : ℝ :=
  ∑ p ∈ Nat.primesLE (Nat.floor x), (Real.log p/(p:ℝ))*primeMass (x/p)

theorem primePairMass_linearization (x : ℝ) (hx : 1 ≤ x) :
    |primePairMass x-(Real.log x*primeMass x-primeLogMoment x)| ≤ 79*primeMass x := by
  have hx0 : 0 < x := by linarith
  have he : Real.log x*primeMass x-primeLogMoment x =
      ∑ p ∈ Nat.primesLE (Nat.floor x), (Real.log p/(p:ℝ))*Real.log (x/p) := by
    rw [primeMass,primeLogMoment,Finset.mul_sum,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro p hp
    have hp0 : (p:ℝ) ≠ 0 := by exact_mod_cast (Nat.mem_primesLE.mp hp).2.ne_zero
    rw [Real.log_div hx0.ne' hp0]
    ring
  rw [he,primePairMass,← Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ p ∈ Nat.primesLE (Nat.floor x),
        |(Real.log p/(p:ℝ))*primeMass (x/p)-(Real.log p/(p:ℝ))*Real.log (x/p)| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ p ∈ Nat.primesLE (Nat.floor x), 79*(Real.log p/(p:ℝ)) := by
      apply Finset.sum_le_sum
      intro p hp
      obtain ⟨hpN,hprime⟩ := Nat.mem_primesLE.mp hp
      have hp0 : (0:ℝ) < p := by exact_mod_cast hprime.pos
      have hpx : (p:ℝ) ≤ x := (show (p:ℝ) ≤ Nat.floor x by exact_mod_cast hpN).trans
        (Nat.floor_le hx0.le)
      have hxp : 1 ≤ x/(p:ℝ) := (le_div_iff₀ hp0).mpr (by simpa)
      have hw : 0 ≤ Real.log p/(p:ℝ) :=
        div_nonneg (Real.log_nonneg (by exact_mod_cast hprime.one_le)) hp0.le
      rw [← mul_sub,abs_mul,abs_of_nonneg hw]
      have hh := mul_le_mul_of_nonneg_left (prime_mass_mertens (x/p) hxp) hw
      nlinarith only [hh]
    _ = _ := by rw [← Finset.mul_sum]; rfl

/-- The global two-prime symmetry estimate with explicit constants. Its
main terms cancel before any partial summation is required. -/
theorem global_two_prime_symmetry (x : ℝ) (hx : 1 ≤ x) :
    |primeLogMoment x+primePairMass x-(Real.log x)^2| ≤ 158*Real.log x+6241 := by
  have hp := abs_le.mp (primePairMass_linearization x hx)
  have hm := abs_le.mp (prime_mass_mertens x hx)
  have hl : 0 ≤ Real.log x := Real.log_nonneg hx
  have hlo := mul_le_mul_of_nonneg_left hm.1 hl
  have hhi := mul_le_mul_of_nonneg_left hm.2 hl
  apply abs_le.mpr
  constructor <;> nlinarith only [hp.1,hp.2,hm.1,hm.2,hlo,hhi]

end MissingLinnik

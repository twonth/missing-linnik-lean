import MissingLinnik.SpectralConcentration
import MissingLinnik.SignExclusion

namespace MissingLinnik

open Classical

/-- The finite, quantitative contradiction underlying the manuscript's final
section. Analytic symmetry, sieve, and anti-concentration estimates must still
be supplied to apply this theorem to the prime weights. -/
theorem finite_linnik_contradiction {I C : Type*} [Fintype I] [Fintype C]
    (χ : C → I → ℂ) (w u : I → ℝ) (v : I → I → ℝ)
    (phase : C → ℂ) (c₀ : C) (τ : C → C)
    (hw : ∀ i, 0 ≤ w i) (hmass : ∑ i, w i = 1)
    (hu : ∀ i, 0 ≤ u i ∧ u i ≤ w i)
    (hv : ∀ i j, 0 ≤ v i j ∧ v i j ≤ w i * w j)
    (hprincipal : finiteCoefficient χ w c₀ = 1)
    (hphase₀ : phase c₀ = 1) (hphase : ∀ c, ‖phase c‖ ≤ 1)
    (hτ : ∀ c, τ (τ c) = c) (hτ₀ : τ c₀ = c₀)
    (hconj : ∀ c i, χ (τ c) i = star (χ c i))
    (henergy : ∑ c, ‖finiteCoefficient χ w c‖^2 ≤ 201/100)
    (hcube : ‖∑ c, phase c * (finiteCoefficient χ w c)^3‖ ≤ 1/100)
    (htotal : 9/10 ≤ (∑ i, u i) + (∑ i, ∑ j, v i j))
    (hreal : ∀ c, c ≠ c₀ → τ c = c → ∃ a : I → ℝ,
      (∀ i, a i = 1 ∨ a i = -1) ∧ (∀ i, χ c i = (a i : ℂ)) ∧
      ((∑ i, u i * a i) + (∑ i, ∑ j, v i j * (a i * a j)) ≤ 1/10) ∧
      (∑ i ∈ Finset.univ.filter (fun i => a i = -1), w i) ≤ 3/4) : False := by
  obtain ⟨c, hc, hlarge, hfixed⟩ := spectral_concentration
    (finiteCoefficient χ w) phase c₀ τ hprincipal hphase₀ hphase hτ hτ₀
    (finiteCoefficient_star χ w τ hconj) henergy hcube
  obtain ⟨a, ha, hχ, hsigned, hanti⟩ := hreal c hc hfixed
  have hb : finiteCoefficient χ w c = ((∑ i, w i * a i : ℝ) : ℂ) := by
    simp only [finiteCoefficient, hχ, Complex.ofReal_sum, Complex.ofReal_mul]
  rw [hb, Complex.norm_real, Real.norm_eq_abs] at hlarge
  have hpositive := positive_sign_excluded w u v a hw hmass hu hv ha htotal hsigned
  have hnegative := negative_mass_of_large_abs_bias w a ha hmass hpositive hlarge
  linarith

end MissingLinnik

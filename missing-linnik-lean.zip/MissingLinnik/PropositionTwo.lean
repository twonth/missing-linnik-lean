import MissingLinnik.GaussRepresentative
import MissingLinnik.MontgomeryVaughanAssembly
import MissingLinnik.CharacterBridge
import MissingLinnik.EffectiveTriangleBound

namespace MissingLinnik

theorem primitive_weak_quadratic_representative (f : ℕ) (hf : 1 ≤ f)
    (ψ : DirichletCharacter ℝ f) (hψ : ψ.IsPrimitive) :
    HasWeakQuadraticRepresentative ψ := by
  letI : NeZero f := ⟨by omega⟩
  refine ⟨characterDiscriminant ψ, (characterDiscriminant_natAbs ψ).le, ?_⟩
  intro p hp hp2 hneg
  letI : Fact p.Prime := ⟨hp⟩
  exact negative_odd_prime_inert ψ hψ p hp2 hneg

theorem effective_antiConcentration_of_quadratic_bounds
    (A : ℕ → ℕ) (hcomp : Computable A) (hA : QuadraticPrimeBounds A) :
    EffectiveAntiConcentration := by
  refine ⟨bridgeExponent A,bridgeExponent_computable A hcomp,?_⟩
  apply antiConcentration_of_weak_quadratic_representatives A hA
  intro f hf ψ hψ _hn
  exact montgomeryVaughan_representative f hf ψ

/-- Proposition 2 via Green's resultant and interpolation argument. -/
theorem green_proposition2 : EffectiveAntiConcentration :=
  effective_antiConcentration_of_quadratic_bounds quadraticExponent
    quadraticExponent_computable green_quadratic_bounds

/-- Proposition 2 via van Dijk's rectangular finite-field argument. -/
theorem vanDijk_proposition2 : EffectiveAntiConcentration :=
  effective_antiConcentration_of_quadratic_bounds quadraticExponent
    quadraticExponent_computable vanDijk_quadratic_bounds

/-- Proposition 2 via the triangular variant in the uploaded working note. -/
theorem triangle_proposition2 : EffectiveAntiConcentration :=
  effective_antiConcentration_of_quadratic_bounds triangleExponent
    triangleExponent_computable triangle_quadratic_bounds

end MissingLinnik

import MissingLinnik.GreenCoordinateChange
import MissingLinnik.GreenRows
import MissingLinnik.VanDijkDeterminant

namespace MissingLinnik.Green

open Classical

/-- A slightly wasteful Cartesian-grid bound suffices for Green's parameters. -/
theorem tilted_grid_zero_count {K : Type*} [Field K] [CharZero K]
    (a : K) (ha : a ≠ 0) (N : ℕ)
    (f : Polynomial (Polynomial K)) (hf : f ≠ 0) :
    (Finset.univ.filter (fun i : Fin N × Fin N =>
      (f.map (Polynomial.evalRingHom ((i.1.val : K) - a * i.2.val))).eval
        ((i.1.val : K) + a * i.2.val) = 0)).card ≤
      2 * N * (f.natDegree + yDegree f) := by
  have hinj : Function.Injective (fun i : Fin N => (i.val : K)) := by
    intro i j h
    exact Fin.ext (Nat.cast_injective h)
  have hne : coordinateChange a f ≠ 0 := by
    intro h
    apply hf
    apply coordinateChange_injective a ha
    simpa using h
  have hc := cartesian_zero_count (coordinateChange a f) hne
    (fun i : Fin N => (i.val : K)) (fun i : Fin N => (i.val : K)) hinj hinj
  simp only [coordinateChange_eval, Fintype.card_fin] at hc
  exact hc.trans (by
    have hx := coordinateChange_degree_le a f
    have hy := coordinateChange_yDegree_le a f
    nlinarith)

theorem quadraticComplexEmbedding_injective (d : ℤ) (a : ℂ) (ha : a ^ 2 = d)
    (hd : ∀ n : ℤ, d ≠ n * n) : Function.Injective (quadraticComplexEmbedding d a ha) := by
  intro x y hxy
  have hx : quadraticComplexEmbedding d a ha (x - y) = 0 := by
    rw [map_sub, hxy, sub_self]
  have hn := quadratic_norm_complex_product d a ha (x - y)
  rw [hx, zero_mul] at hn
  have hn' : (x-y).norm = 0 := by exact_mod_cast hn
  exact sub_eq_zero.mp ((Zsqrtd.norm_eq_zero hd (x-y)).mp hn')

theorem integerGrid_injective (N : ℕ) (d : ℤ) :
    Function.Injective (VanDijk.integerGrid N d) := by
  intro i j h
  have hr := congrArg Zsqrtd.re h
  have hi := congrArg Zsqrtd.im h
  change (i.1.val : ℤ) = j.1.val at hr
  change (i.2.val : ℤ) = j.2.val at hi
  apply Prod.ext <;> apply Fin.ext
  · exact_mod_cast hr
  · exact_mod_cast hi

theorem grid_rows_linearIndependent (N J R S : ℕ) (d : ℤ)
    (hd : ∀ n : ℤ, d ≠ n * n) (a : ℂ) (ha : a ^ 2 = d)
    (hJ : 0 < J) (hNJ : 2 * N ≤ J)
    (hsize : 2 * R * S + J * (R + S) < (N * N) * J) :
    LinearIndependent ℂ (fun i : Fin R × Fin S =>
      fun col : (Fin N × Fin N) × Fin J =>
        quadraticComplexEmbedding d a ha
          (monomialJet (VanDijk.integerGrid N d col.1)
            (star (VanDijk.integerGrid N d col.1)) col.2.val i.1.val i.2.val)) := by
  let e := quadraticComplexEmbedding d a ha
  have ha0 : a ≠ 0 := by
    intro h
    have hd0 : d = 0 := by rw [h, zero_pow (by decide)] at ha; exact_mod_cast ha.symm
    exact hd 0 (by simpa using hd0)
  have hw : Function.Injective (fun i : Fin N × Fin N => e (star (VanDijk.integerGrid N d i))) :=
    (quadraticComplexEmbedding_injective d a ha hd).comp
      (star_injective.comp (integerGrid_injective N d))
  have hzeros (f : Polynomial (Polynomial ℂ)) (hf : f ≠ 0) :
      (Finset.univ.filter (fun i : Fin N × Fin N =>
        (f.map (Polynomial.evalRingHom (e (star (VanDijk.integerGrid N d i))))).eval
          (e (VanDijk.integerGrid N d i)) = 0)).card ≤ J * (f.natDegree + yDegree f) := by
    have hh := tilted_grid_zero_count a ha0 N f hf
    simp only [e, quadraticComplexEmbedding, RingHom.coe_mk, MonoidHom.coe_mk,
      OneHom.coe_mk, VanDijk.integerGrid, Zsqrtd.re_star, Zsqrtd.im_star,
      Int.cast_neg, Int.cast_natCast, neg_mul] 
    convert hh.trans (Nat.mul_le_mul_right _ hNJ) using 1 <;> simp [sub_eq_add_neg, mul_comm]
  have hh := rows_linearIndependent
    (fun i => e (VanDijk.integerGrid N d i))
    (fun i => e (star (VanDijk.integerGrid N d i))) hw J R S hJ hzeros
    (by simpa using hsize)
  simpa only [map_monomialJet] using hh

end MissingLinnik.Green

import Mathlib.Algebra.Polynomial.Bivariate
import Mathlib.Algebra.Polynomial.Degree.Lemmas
import Mathlib.Tactic.Ring

namespace MissingLinnik.Green

open Polynomial

theorem swap_coeff_coeff {K : Type*} [CommRing K]
    (f : Polynomial (Polynomial K)) (i j : ℕ) :
    ((Bivariate.swap f).coeff j).coeff i = (f.coeff i).coeff j := by
  induction f using Polynomial.induction_on' with
  | add f g hf hg => simp only [map_add, coeff_add, hf, hg]
  | monomial n p =>
    rw [Bivariate.swap_monomial, coeff_mul_C, coeff_map]
    rw [C_mul_X_pow_eq_monomial]
    simp only [coeff_monomial]
    split_ifs <;> simp_all

noncomputable def yDegree {K : Type*} [CommRing K] (f : Polynomial (Polynomial K)) : ℕ :=
  (Bivariate.swap f).natDegree

theorem coeff_natDegree_le_yDegree {K : Type*} [CommRing K]
    (f : Polynomial (Polynomial K)) (i : ℕ) : (f.coeff i).natDegree ≤ yDegree f := by
  apply Polynomial.natDegree_le_iff_coeff_eq_zero.mpr
  intro j hj
  rw [← swap_coeff_coeff f i j]
  rw [Polynomial.coeff_eq_zero_of_natDegree_lt hj, Polynomial.coeff_zero]

theorem yDegree_mul {K : Type*} [CommRing K] [IsDomain K]
    (f g : Polynomial (Polynomial K)) (hf : f ≠ 0) (hg : g ≠ 0) :
    yDegree (f * g) = yDegree f + yDegree g := by
  unfold yDegree
  rw [map_mul, Polynomial.natDegree_mul]
  · exact (Bivariate.swap.map_ne_zero_iff).mpr hf
  · exact (Bivariate.swap.map_ne_zero_iff).mpr hg

theorem yDegree_C {K : Type*} [CommRing K] (f : Polynomial K) :
    yDegree (Polynomial.C f) = f.natDegree := by
  rw [yDegree, Bivariate.swap_C]
  exact Polynomial.natDegree_map_eq_of_injective Polynomial.C_injective _

end MissingLinnik.Green


import MissingLinnik.ProgressionCount
import Mathlib.Data.Nat.GCD.BigOperators

namespace MissingLinnik

open Finset

/-- Each integer removed by a finite sieve has a unique first divisor in
the ordered set of sieving primes. This combinatorial identity does not
require the divisors to be prime. -/
theorem first_divisor_indicator (P : Finset ℕ) (n : ℕ) :
    (∑ p ∈ P, if p ∣ n ∧ ∀ l ∈ P, l < p → ¬ l ∣ n then (1:ℕ) else 0) =
      if ∀ p ∈ P, ¬ p ∣ n then 0 else 1 := by
  classical
  by_cases hn : ∀ p ∈ P, ¬ p ∣ n
  · simp only [if_pos hn]
    apply Finset.sum_eq_zero
    intro p hp
    simp [(hn p hp)]
  · rw [if_neg hn]
    have hne : (P.filter (fun p => p ∣ n)).Nonempty := by
      push_neg at hn
      obtain ⟨p,hp,hpn⟩ := hn
      exact ⟨p,Finset.mem_filter.mpr ⟨hp,hpn⟩⟩
    let p := (P.filter (fun p => p ∣ n)).min' hne
    have hpm := Finset.min'_mem (P.filter (fun p => p ∣ n)) hne
    have hpP : p ∈ P := (Finset.mem_filter.mp hpm).1
    have hpn : p ∣ n := (Finset.mem_filter.mp hpm).2
    have hmin (l : ℕ) (hl : l ∈ P) (hln : l ∣ n) : p ≤ l :=
      Finset.min'_le _ l (Finset.mem_filter.mpr ⟨hl,hln⟩)
    rw [Finset.sum_eq_single p]
    · rw [if_pos ⟨hpn,fun l hl hlp hln => (not_lt_of_ge (hmin l hl hln)) hlp⟩]
    · intro l hl hlp
      apply if_neg
      rintro ⟨hln,hfirst⟩
      have hpl : p < l := lt_of_le_of_ne (hmin l hl hln) (Ne.symm hlp)
      exact hfirst p hpP hpl hpn
    · exact fun hp => (hp hpP).elim

theorem buchstab_partition (A P : Finset ℕ) :
    (A.filter (fun n => ∀ p ∈ P, ¬ p ∣ n)).card +
      ∑ p ∈ P, (A.filter (fun n => p ∣ n ∧ ∀ l ∈ P, l < p → ¬ l ∣ n)).card =
      A.card := by
  classical
  have hc (Q : ℕ → Prop) [DecidablePred Q] :
      (A.filter Q).card = ∑ n ∈ A, if Q n then (1:ℕ) else 0 := by simp
  rw [hc]
  simp_rw [hc]
  rw [Finset.sum_comm,← Finset.sum_add_distrib]
  simp_rw [first_divisor_indicator]
  calc
    _ = ∑ n ∈ A, (1:ℕ) := by
      apply Finset.sum_congr rfl
      intro n hn
      split_ifs <;> norm_num
    _ = _ := by simp

theorem coprime_prime_product_iff (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime) (n : ℕ) :
    n.Coprime (∏ p ∈ P, p) ↔ ∀ p ∈ P, ¬ p ∣ n := by
  rw [Nat.coprime_prod_right_iff]
  apply forall₂_congr
  intro p hp
  rw [Nat.coprime_comm]
  exact (hprime p hp).coprime_iff_not_dvd

noncomputable def sieveDensity (P : Finset ℕ) : ℝ := ∏ p ∈ P, (1-1/(p:ℝ))

theorem sieveDensity_pos (P : Finset ℕ) (hp : ∀ p ∈ P, p.Prime) :
    0 < sieveDensity P := by
  apply Finset.prod_pos
  intro p hpm
  have hp1 : (1:ℝ) < p := by exact_mod_cast (hp p hpm).one_lt
  have hi : 1/(p:ℝ) < 1 := (div_lt_one (by linarith)).mpr hp1
  linarith

/-- The density version of the least-prime-factor partition. -/
theorem buchstab_density (P : Finset ℕ) :
    sieveDensity P + ∑ p ∈ P, sieveDensity (P.filter (fun l => l < p))/(p:ℝ) = 1 := by
  have h := Finset.prod_one_add_ordered P (fun p : ℕ => -(1/(p:ℝ)))
  have he : (∑ p ∈ P, -(1/(p:ℝ)) * ∏ l ∈ P with l < p, (1 + -(1/(l:ℝ)) )) =
      -(∑ p ∈ P, sieveDensity (P.filter (fun l => l < p))/(p:ℝ)) := by
    rw [← Finset.sum_neg_distrib]
    apply Finset.sum_congr rfl
    intro p hp
    simp only [sieveDensity,sub_eq_add_neg]
    ring
  rw [he] at h
  change sieveDensity P = _ at h
  linarith

end MissingLinnik

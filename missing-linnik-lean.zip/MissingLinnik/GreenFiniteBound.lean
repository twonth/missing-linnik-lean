import MissingLinnik.GreenDeterminant
import MissingLinnik.WeightedFloorBound

namespace MissingLinnik.Green

theorem truncated_height_le (p R S m T : ℕ) (hp : 0 < p)
    (hR : R ≤ p * m) (hT : T + m ≤ S) (i : Fin R × Fin S) :
    vanDijkHeight p T (i.1.val, i.2.val) ≤ greenHeight p S (i.1.val, i.2.val) := by
  have hr : i.1.val / p < m :=
    (Nat.div_lt_iff_lt_mul hp).mpr (by simpa [mul_comm] using lt_of_lt_of_le i.1.isLt hR)
  unfold vanDijkHeight greenHeight
  dsimp only
  split_ifs with hs
  · apply le_min le_rfl
    omega
  · exact Nat.zero_le _

/-- A usable lower bound for Green's full height sum, obtained by retaining
only the first T horizontal rows. -/
theorem height_sum_lower (p R S m T : ℕ) (hp : 0 < p)
    (hR : R ≤ p * m) (hT : T + m ≤ S) :
    T * ∑ r ∈ Finset.range R, r / p ≤
      ∑ i : Fin R × Fin S, greenHeight p S (i.1.val, i.2.val) := by
  rw [← vanDijkHeight_sum p R S T (by omega)]
  exact Finset.sum_le_sum (fun i _ => truncated_height_le p R S m T hp hR hT i)

/-- The finite prime-sum inequality from Green's characteristic-zero
interpolation argument, before choosing the effective parameters. -/
theorem finite_inert_prime_bound (N J R S m T : ℕ) (d : ℤ)
    (hd : ∀ n : ℤ, d ≠ n * n) (a : ℂ) (ha : a ^ 2 = d)
    (hJ : 0 < J) (hNJ : 2 * N ≤ J) (hJS : J ≤ S) (hR : 1 ≤ R)
    (hsize : 2 * R * S + J * (R + S) < (N * N) * J)
    (B : ℝ) (hB : 1 ≤ B) (hNB : (N : ℝ) * (1 + ‖a‖) ≤ B)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime)
    (hpodd : ∀ p ∈ P, p ≠ 2)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1)
    (hRp : ∀ p ∈ P, R ≤ p * m) (hT : T + m ≤ S) :
    (T : ℝ) * R * (R - 1) * (∑ p ∈ P, Real.log p / p) ≤
      2 * Real.log ((R * S).factorial : ℝ) +
      2 * ∑ i : Fin R × Fin S, ((S : ℝ) * Real.log R +
        ((i.1.val + i.2.val : ℕ) : ℝ) * Real.log B) +
      2 * T * R * (∑ p ∈ P, Real.log p) := by
  obtain ⟨D, hD, hdiv, hupper⟩ := exists_positive_determinant_norm N J R S d hd a ha
    hJ hNJ hJS hR hsize B hB hNB
  have hsmall (p : ℕ) (hp : p ∈ P) :
      p ^ (2 * (T * ∑ r ∈ Finset.range R, r / p)) ∣ D := by
    apply dvd_trans (pow_dvd_pow p (Nat.mul_le_mul_left 2
      (height_sum_lower p R S m T (hprime p hp).pos (hRp p hp) hT)))
    exact hdiv p (hprime p hp) (hpodd p hp) (hinert p hp)
  have hvaluation := sum_valuation_log_le P
    (fun p => 2 * (T * ∑ r ∈ Finset.range R, r / p)) D hD hprime hsmall
  have hlower := weighted_floor_sum_lower P R T (fun p hp => (hprime p hp).pos)
  linarith

end MissingLinnik.Green

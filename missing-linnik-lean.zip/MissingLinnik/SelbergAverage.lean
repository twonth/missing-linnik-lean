import MissingLinnik.ConvolutionSummation
import MissingLinnik.RoughResidueInverse
import MissingLinnik.RoughWeightedSums

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

noncomputable def selbergKernel (n : ℕ) : ℝ :=
  (logWeight vonMangoldt+vonMangoldt*vonMangoldt) n

theorem selbergKernel_div (n : ℕ) : selbergKernel n/(n:ℝ) =
    ∑ a ∈ n.divisorsAntidiagonal, (moebius a.1:ℝ)/(a.1:ℝ)*logSquareOver a.2 := by
  have he := congrArg (fun f : ArithmeticFunction ℝ => f n) selberg_identity
  change _ = selbergKernel n at he
  rw [← he,ArithmeticFunction.mul_apply,Finset.sum_div]
  apply Finset.sum_congr rfl
  intro a ha
  have hp := (Nat.mem_divisorsAntidiagonal.mp ha).1
  simp only [ArithmeticFunction.intCoe_apply,logWeight_apply,ArithmeticFunction.log_apply,logSquareOver]
  rw [← hp,Nat.cast_mul]
  ring

noncomputable def roughSelbergClassSum (N q c Y : ℕ) : ℝ :=
  ∑ n ∈ (Icc 1 N).filter (fun n => IsRough Y n ∧ Nat.ModEq q n c), selbergKernel n/(n:ℝ)

theorem sum_Icc_zero_eq_one {f : ℕ → ℝ} (hf : f 0=0) (N : ℕ) :
    (∑ n ∈ Icc 0 N, f n) = ∑ n ∈ Icc 1 N, f n := by
  symm
  apply Finset.sum_subset
  · intro n hn
    exact mem_Icc.mpr ⟨Nat.zero_le _,(mem_Icc.mp hn).2⟩
  · intro n hn hnot
    have hn0 : n=0 := by simp only [mem_Icc] at hn hnot; omega
    simpa [hn0] using hf

theorem roughWeightedClassSum_nat_div (N d q b Y : ℕ) :
    roughWeightedClassSum q b Y ((N:ℝ)/d) =
      ∑ m ∈ Icc 1 (N/d), if IsRough Y m ∧ Nat.ModEq q m b then logSquareOver m else 0 := by
  unfold roughWeightedClassSum
  rw [Nat.floor_div_natCast,Nat.floor_natCast,Finset.sum_filter]
  apply sum_Icc_zero_eq_one
  simp [logSquareOver]

/-- Exact separation of the Möbius factor and the inner rough progression. -/
theorem roughSelbergClassSum_convolution (N q c Y : ℕ) (hq : 0<q) (hqY : q≤Y) :
    roughSelbergClassSum N q c Y =
      ∑ d ∈ (Icc 1 N).filter (IsRough Y),
        (moebius d:ℝ)/(d:ℝ)*roughWeightedClassSum q (inverseResidue q c d) Y ((N:ℝ)/d) := by
  let F : ℕ → ℕ → ℝ := fun d m =>
    if IsRough Y (d*m) ∧ Nat.ModEq q (d*m) c then (moebius d:ℝ)/(d:ℝ)*logSquareOver m else 0
  have hfirst : roughSelbergClassSum N q c Y =
      ∑ n ∈ Icc 1 N, ∑ a ∈ n.divisorsAntidiagonal, F a.1 a.2 := by
    unfold roughSelbergClassSum
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro n hn
    rw [selbergKernel_div]
    by_cases h : IsRough Y n ∧ Nat.ModEq q n c
    · rw [if_pos h]
      apply Finset.sum_congr rfl
      intro a ha
      dsimp [F]
      rw [(Nat.mem_divisorsAntidiagonal.mp ha).1,if_pos h]
    · rw [if_neg h]
      symm
      apply Finset.sum_eq_zero
      intro a ha
      dsimp [F]
      rw [(Nat.mem_divisorsAntidiagonal.mp ha).1,if_neg h]
  rw [hfirst,sum_divisor_pairs,sum_hyperbolaPairs,Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro d hd
  by_cases hr : IsRough Y d
  · rw [if_pos hr,roughWeightedClassSum_nat_div,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro m hm
    have hdc := isRough_coprime q Y d hq hqY hr
    dsimp [F]
    simp only [isRough_mul,hr,true_and,inverseResidue_congruence q c d m hq hdc]
    split_ifs <;> simp <;> tauto
  · rw [if_neg hr]
    apply Finset.sum_eq_zero
    intro m hm
    dsimp [F]
    have hnr : ¬IsRough Y (d*m) := fun h => hr ((isRough_mul Y d m).mp h).1
    simp only [hnr,false_and,ite_false]

end MissingLinnik


import MissingLinnik.PrimeTailBounds

namespace MissingLinnik

open Classical

theorem prime_window_decomposition (P : Finset ℕ) (K S : ℕ) :
    (∑ p ∈ P, Real.log p / p) =
      (∑ p ∈ P.filter (fun p => p < K), Real.log p / p) +
      (∑ p ∈ P.filter (fun p => K ≤ p ∧ p ≤ S), Real.log p / p) +
      (∑ p ∈ P.filter (fun p => K ≤ p ∧ S < p), Real.log p / p) := by
  simp only [Finset.sum_filter]
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro p _
  by_cases hK : K ≤ p <;> by_cases hS : p ≤ S <;>
    simp [hK, hS, Nat.lt_of_not_ge, Nat.not_lt_of_ge]

theorem prime_window_extension (P : Finset ℕ) (k S X : ℕ)
    (hS : 0 < S) (hprime : ∀ p ∈ P, p.Prime) (hupper : ∀ p ∈ P, p ≤ X)
    (hX : X ≤ 2*k*S) (M : ℝ)
    (hmiddle : (∑ p ∈ P.filter (fun p => k^2 ≤ p ∧ p ≤ S), Real.log p / p) ≤ M) :
    (∑ p ∈ P, Real.log p / p) ≤ M + Real.log 4 * ((k:ℝ)^2 + 2*k) := by
  have hlow := prime_mass_small_le (P.filter (fun p => p < k^2)) (k^2)
    (fun p hp => hprime p (Finset.mem_filter.mp hp).1)
    (fun p hp => Nat.le_of_lt (Finset.mem_filter.mp hp).2)
  have hhigh := prime_mass_tail_le (P.filter (fun p => k^2 ≤ p ∧ S < p)) X S
    (by exact_mod_cast hS)
    (fun p hp => hprime p (Finset.mem_filter.mp hp).1)
    (fun p hp => by exact_mod_cast Nat.le_of_lt (Finset.mem_filter.mp hp).2.2)
    (fun p hp => hupper p (Finset.mem_filter.mp hp).1)
  have htail : Real.log 4 * (X:ℝ) / S ≤ Real.log 4 * (2*k) := by
    apply (div_le_iff₀ (by exact_mod_cast hS : (0:ℝ)<S)).mpr
    have hh : (X:ℝ) ≤ 2*k*S := by exact_mod_cast hX
    have hl : 0 ≤ Real.log (4:ℝ) := Real.log_nonneg (by norm_num)
    nlinarith [mul_le_mul_of_nonneg_left hh hl]
  rw [prime_window_decomposition P (k^2) S]
  push_cast at hlow
  nlinarith

end MissingLinnik

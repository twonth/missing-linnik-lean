import MissingLinnik.TriangleParameters
import MissingLinnik.GridSizeEstimates

namespace MissingLinnik.Triangle

theorem window_prime_bound (Y L : ℕ) (hY : 1024 ≤ Y) (hL : 8*Y ≤ L)
    [Fact L.Prime] (d : ℤ) (hd : legendreSym L d = -1)
    (a : ℂ) (ha : a^2=d) (q : ℝ) (hq : 1 ≤ q) (haq : ‖a‖^2 ≤ q)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime)
    (hlower : ∀ p ∈ P, Y ≤ p) (hupper : ∀ p ∈ P, p ≤ L)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) :
    (∑ p ∈ P, Real.log p/p) ≤
      (1/2+2048/(Y:ℝ))*Real.log L + Real.log q + 1030 := by
  let S := L/Y+1
  obtain ⟨hS,hSL,hcover,hYS⟩ := slope_parameters Y L hY hL
  have hL8 : 8 ≤ L := by omega
  have hp2 : 2 ≤ L := by omega
  letI : Fact (¬ IsSquare (d : ZMod L)) := ⟨(legendreSym.eq_neg_one_iff L).mp hd⟩
  let B := 4*Real.sqrt L*Real.sqrt q
  obtain ⟨hB,hMB,hlogB⟩ := grid_archimedean_bound L hp2 q hq a haq
  obtain ⟨hcard,hM,_⟩ := sqrt_grid_bounds L hp2
  have hfinite := finite_inert_prime_bound L Y S (L.sqrt+1) d (by omega) hd
    hM hcard (by dsimp [S]; omega) hSL hcover a ha B hB hMB P hprime
    (fun p hp => by have := hlower p hp; omega) hinert hlower
  have hl4 : Real.log (4:ℝ) ≤ 2 := by
    have hl2 := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    rw [show (4:ℝ)=2^2 by norm_num,Real.log_pow]
    norm_num
    linarith
  have hθ : (∑ p ∈ P, Real.log p) ≤ 2*(L:ℝ) :=
    (prime_log_sum_le P L hprime hupper).trans
      (mul_le_mul_of_nonneg_right hl4 (Nat.cast_nonneg _))
  have hn := normalized_bound L Y S B (∑ p ∈ P, Real.log p/p)
    (∑ p ∈ P, Real.log p) hL8 hS (Nat.le_of_lt hSL) hYS hB hθ hfinite
  have hl8 : Real.log (8:ℝ) ≤ 3 := by
    have hl2 := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    rw [show (8:ℝ)=2^3 by norm_num,Real.log_pow]
    norm_num
    linarith
  apply scalar_bound (Y:ℝ) L S (Real.log B) (Real.log L) (Real.log q)
    (∑ p ∈ P, Real.log p/p) (by exact_mod_cast hY) (by exact_mod_cast hL)
    (by positivity) (by exact_mod_cast hYS)
    (Real.log_nonneg (by exact_mod_cast (show 1≤L by omega))) (Real.log_nonneg hq)
    (by dsimp only [B]; linarith) hn

end MissingLinnik.Triangle

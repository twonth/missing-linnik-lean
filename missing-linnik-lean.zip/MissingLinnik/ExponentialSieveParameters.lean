import MissingLinnik.RoughDiscrepancy

namespace MissingLinnik

theorem log_nat_ge_half (z : ℕ) (hz : 2 ≤ z) : (1:ℝ)/2 ≤ Real.log z := by
  have hh := Real.one_sub_inv_le_log_of_pos (by norm_num : (0:ℝ)<2)
  have hm := Real.log_le_log (by norm_num : (0:ℝ)<2) (show (2:ℝ)≤z by exact_mod_cast hz)
  norm_num at hh
  linarith

theorem sieve_remainder_absorption (N z h : ℕ) (hz : 2 ≤ z) (hh : 1 ≤ h)
    (hN : z^(10*h) ≤ N) (F : ℝ) (hF : 0 < F) (hFz : F ≤ z) :
    (z:ℝ)^(5*h) ≤ ((N:ℝ)/(F*Real.log z))*Real.exp (-(h:ℝ)) := by
  have hz0 : (0:ℝ) < z := by exact_mod_cast (show 0<z by omega)
  have hlz := log_nat_ge_half z hz
  have hlz0 : 0 < Real.log (z:ℝ) := by linarith
  have he : Real.exp (h:ℝ) ≤ (z:ℝ)^(2*h) := by
    have hlog : (h:ℝ) ≤ Real.log ((z:ℝ)^(2*h)) := by
      rw [Real.log_pow]
      push_cast
      have ht := mul_le_mul_of_nonneg_left hlz (show 0 ≤ 2*(h:ℝ) by positivity)
      nlinarith only [ht]
    have ht := Real.exp_le_exp.mpr hlog
    rwa [Real.exp_log (pow_pos hz0 _)] at ht
  have hFlog : F*Real.log (z:ℝ) ≤ (z:ℝ)^2 := by
    have hh := mul_le_mul hFz (Real.log_le_self hz0.le) hlz0.le hz0.le
    nlinarith only [hh]
  have hmul := mul_le_mul hFlog he (Real.exp_pos (h:ℝ)).le (sq_nonneg (z:ℝ))
  have hmul' := mul_le_mul_of_nonneg_left hmul (show 0 ≤ (z:ℝ)^(5*h) by positivity)
  have hpow : (z:ℝ)^(5*h)*((z:ℝ)^2*(z:ℝ)^(2*h)) = (z:ℝ)^(7*h+2) := by
    rw [← pow_add,← pow_add]
    congr 1
    omega
  rw [hpow] at hmul'
  have horder : (z:ℝ)^(7*h+2) ≤ (z:ℝ)^(10*h) :=
    pow_le_pow_right₀ (by exact_mod_cast (show 1≤z by omega)) (by omega)
  have hNR : (z:ℝ)^(10*h) ≤ N := by exact_mod_cast hN
  rw [Real.exp_neg]
  have hfrac : ((N:ℝ)/(F*Real.log z))*(Real.exp (h:ℝ))⁻¹ =
      (N:ℝ)/(F*Real.log z*Real.exp (h:ℝ)) := by ring
  rw [hfrac]
  apply (le_div_iff₀ (by positivity : 0 < F*Real.log (z:ℝ)*Real.exp (h:ℝ))).mpr
  nlinarith only [hmul',horder,hNR]

theorem rough_discrepancy_exponential_level (N q b z h : ℕ) (hq : 0 < q) (hz : 2 ≤ z)
    (hqz : q ≤ z) (hb : b.Coprime q) (hh : 17 ≤ h) (hN : z^(10*h) ≤ N) :
    |(roughProgressionCount N q b z:ℝ)-(roughCount N z:ℝ)/q.totient| ≤
      (32*Real.exp 32+2)*((N:ℝ)/(q.totient*Real.log z))*Real.exp (-(h:ℝ)) := by
  have hs := rough_discrepancy_log_bound N q b z h hq hz hqz hb hh
  have hr := sieve_remainder_absorption N z h hz (by omega) hN q.totient
    (by exact_mod_cast Nat.totient_pos.mpr hq)
    (by exact_mod_cast (Nat.totient_le q).trans hqz)
  have he : Real.exp (32-(h:ℝ)) = Real.exp 32*Real.exp (-(h:ℝ)) := by rw [← Real.exp_add]; congr 1
  rw [he] at hs
  have he' : 32*(Real.exp 32*Real.exp (-(h:ℝ)))*(N:ℝ)/(q.totient*Real.log z) =
      32*Real.exp 32*((N:ℝ)/(q.totient*Real.log z))*Real.exp (-(h:ℝ)) := by ring
  rw [he'] at hs
  nlinarith only [hs,hr]

theorem rough_discrepancy_large (N q b z : ℕ) (hq : 0 < q) (hz : 2 ≤ z)
    (hqz : q ≤ z) (hb : b.Coprime q) (hN : z^170 ≤ N) :
    |(roughProgressionCount N q b z:ℝ)-(roughCount N z:ℝ)/q.totient| ≤
      ((32*Real.exp 32+2)*Real.exp 1)*((N:ℝ)/(q.totient*Real.log z))*
        Real.exp (-Real.log N/(10*Real.log z)) := by
  have hz1 : 1 < z := by omega
  have hz0 : 0 < z := by omega
  have hN0 : 0 < N := lt_of_lt_of_le (Nat.pow_pos hz0) hN
  let h := Nat.log z N/10
  have hlog : 170 ≤ Nat.log z N := Nat.le_log_of_pow_le hz1 hN
  have hh : 17 ≤ h := (Nat.le_div_iff_mul_le (by omega : 0<10)).mpr (by omega)
  have hlevel : z^(10*h) ≤ N := Nat.pow_le_of_le_log hN0.ne'
    (by have := Nat.div_mul_le_self (Nat.log z N) 10; dsimp [h]; omega)
  have hupper : N < z^(10*(h+1)) := Nat.lt_pow_of_log_lt hz1 (by
    have := Nat.mod_lt (Nat.log z N) (by omega : 0<10)
    have := Nat.mod_add_div (Nat.log z N) 10
    dsimp [h]
    omega)
  have hs := rough_discrepancy_exponential_level N q b z h hq hz hqz hb hh hlevel
  have hlz : 0 < Real.log (z:ℝ) := Real.log_pos (by exact_mod_cast hz1)
  have hlogupper := Real.log_le_log (show (0:ℝ)<N by exact_mod_cast hN0)
    (show (N:ℝ) ≤ (z:ℝ)^(10*(h+1)) by exact_mod_cast hupper.le)
  rw [Real.log_pow] at hlogupper
  push_cast at hlogupper
  have hratio : Real.log (N:ℝ)/(10*Real.log z) ≤ (h:ℝ)+1 := by
    apply (div_le_iff₀ (by positivity : 0<10*Real.log (z:ℝ))).mpr
    nlinarith only [hlogupper]
  have he : Real.exp (-(h:ℝ)) ≤ Real.exp 1*Real.exp (-Real.log N/(10*Real.log z)) := by
    rw [← Real.exp_add]
    apply Real.exp_le_exp.mpr
    simp only [neg_div]
    linarith
  have ht := mul_le_mul_of_nonneg_left he
    (show 0 ≤ (32*Real.exp 32+2)*((N:ℝ)/(q.totient*Real.log z)) by positivity)
  have he' : (32*Real.exp 32+2)*((N:ℝ)/(q.totient*Real.log z))*
      (Real.exp 1*Real.exp (-Real.log N/(10*Real.log z))) =
      ((32*Real.exp 32+2)*Real.exp 1)*((N:ℝ)/(q.totient*Real.log z))*
        Real.exp (-Real.log N/(10*Real.log z)) := by ring
  rw [he'] at ht
  exact hs.trans ht

end MissingLinnik

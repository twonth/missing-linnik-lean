import MissingLinnik.WeightedDiscrepancy

namespace MissingLinnik

open Finset MeasureTheory

theorem inv_square_integrableOn_Icc_one (x : ℝ) :
    IntegrableOn (fun t : ℝ => t⁻¹^2) (Set.Icc 1 x) := by
  apply ContinuousOn.integrableOn_Icc
  intro t ht
  have ht0 : t ≠ 0 := by linarith [ht.1]
  exact ((continuousAt_inv₀ ht0).pow 2).continuousWithinAt

theorem harmonic_abel (c : ℕ → ℝ) (hc : c 0 = 0) (x : ℝ) :
    (∑ n ∈ Finset.Icc 0 (Nat.floor x), (n:ℝ)⁻¹*c n) =
      x⁻¹*(∑ n ∈ Finset.Icc 0 (Nat.floor x), c n)+
      ∫ t in Set.Ioc 1 x, t⁻¹^2*(∑ n ∈ Finset.Icc 0 (Nat.floor t), c n) := by
  have hd (t : ℝ) (ht : t ∈ Set.Icc 1 x) :
      deriv (fun t : ℝ => t⁻¹) t = -(t⁻¹^2) := by
    have ht0 : t ≠ 0 := by linarith [ht.1]
    convert (hasDerivAt_inv ht0).deriv using 1 <;> simp [inv_pow]
  have hi : IntegrableOn (deriv (fun t : ℝ => t⁻¹)) (Set.Icc 1 x) := by
    exact (inv_square_integrableOn_Icc_one x).neg.congr_fun (fun t ht => (hd t ht).symm) measurableSet_Icc
  have hh := sum_mul_eq_sub_integral_mul₀ c hc x
    (f := fun t : ℝ => t⁻¹)
    (fun t ht => (hasDerivAt_inv (by linarith [ht.1])).differentiableAt) hi
  have he : (∫ t in Set.Ioc 1 x, deriv (fun t : ℝ => t⁻¹) t*(∑ n ∈ Finset.Icc 0 (Nat.floor t), c n)) =
      -(∫ t in Set.Ioc 1 x, t⁻¹^2*(∑ n ∈ Finset.Icc 0 (Nat.floor t), c n)) := by
    rw [← MeasureTheory.integral_neg]
    apply MeasureTheory.setIntegral_congr_fun measurableSet_Ioc
    intro t ht
    dsimp only
    rw [hd t (Set.Ioc_subset_Icc_self ht)]
    ring
  rw [he,sub_neg_eq_add] at hh
  exact hh

/-- A linear counting bound gives a logarithmic harmonic-sum bound. -/
theorem harmonic_counting_bound (c : ℕ → ℝ) (hc : c 0 = 0)
    (K : ℝ) (hcount : ∀ t : ℝ, 1 ≤ t → (∑ n ∈ Finset.Icc 0 (Nat.floor t), c n) ≤ K*t)
    (x : ℝ) (hx : 1 ≤ x) :
    (∑ n ∈ Finset.Icc 0 (Nat.floor x), (n:ℝ)⁻¹*c n) ≤ K*(1+Real.log x) := by
  have hi := (integrableOn_mul_sum_Icc c (m := 0) (by norm_num : (0:ℝ)≤1)
    (inv_square_integrableOn_Icc_one x)).mono_set Set.Ioc_subset_Icc_self
  have hK : IntegrableOn (fun t : ℝ => K*t⁻¹) (Set.Ioc 1 x) :=
    ((inv_integrableOn_Icc_one x).mono_set Set.Ioc_subset_Icc_self).const_mul K
  have hint := MeasureTheory.setIntegral_mono_on hi hK measurableSet_Ioc (fun t ht => by
    have hm := mul_le_mul_of_nonneg_left (hcount t ht.1.le) (sq_nonneg t⁻¹)
    have ht0 : t ≠ 0 := by linarith [ht.1]
    convert hm using 1 <;> field_simp <;> ring)
  have he : (∫ t in Set.Ioc 1 x, (t:ℝ)⁻¹) = Real.log x := by
    have hh := integral_inv_of_pos (by norm_num : (0:ℝ)<1) (show 0<x by linarith)
    rw [intervalIntegral.integral_of_le hx] at hh
    simpa using hh
  rw [MeasureTheory.integral_const_mul,he] at hint
  have hb := mul_le_mul_of_nonneg_left (hcount x hx) (inv_nonneg.mpr (by linarith : 0≤x))
  have hxe : x⁻¹*(K*x) = K := by field_simp
  rw [hxe] at hb
  rw [harmonic_abel c hc]
  nlinarith only [hint,hb]

end MissingLinnik



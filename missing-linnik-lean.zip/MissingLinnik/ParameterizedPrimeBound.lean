import MissingLinnik.ParameterBounds

namespace MissingLinnik

/-- The common quantitative prime bound with the parameters of van Dijk's
paper. Green's determinant can use the same rectangle. -/
theorem parameterized_prime_bound (k m : ℕ) (hk : 8 ≤ k) (hm : 1 ≤ m)
    (B : ℝ) (hB : 1 ≤ B) (P : Finset ℕ)
    (hp : ∀ p ∈ P, p.Prime) (hpS : ∀ p ∈ P, p ≤ k*m)
    (hbound : (((k-1)*m : ℕ) : ℝ) * (k^2*m) * ((k^2*m : ℝ)-1) *
      (∑ p ∈ P, Real.log p / p) ≤
      2 * Real.log (((k^2*m)*(k*m)).factorial : ℝ) +
      2 * ∑ i : Fin (k^2*m) × Fin (k*m), (((k*m : ℕ) : ℝ) * Real.log (k^2*m) +
        ((i.1.val+i.2.val : ℕ) : ℝ) * Real.log B) +
      2 * (((k-1)*m : ℕ) : ℝ) * (k^2*m) * (∑ p ∈ P, Real.log p)) :
    (∑ p ∈ P, Real.log p / p) ≤
      (1+5/(k:ℝ))*Real.log B + (5/(k:ℝ))*Real.log (k^2*m) + (3/(k:ℝ))*Real.log 4 := by
  have hk1 : 1 ≤ k := by omega
  have hkR : (2 : ℕ) ≤ k^2*m := by nlinarith
  have hT : 0 < (k-1)*m := Nat.mul_pos (by omega) (by omega)
  have hθ := prime_log_sum_le P (k*m) hp hpS
  have hθ' := mul_le_mul_of_nonneg_left hθ
    (show (0:ℝ) ≤ 2 * (((k-1)*m : ℕ) : ℝ) * (k^2*m) by positivity)
  have hnorm := normalized_determinant_bound (k^2*m) (k*m) ((k-1)*m) B
    (∑ p ∈ P, Real.log p / p) (Real.log 4 * (k*m)) hkR hT hB (by
      push_cast
      push_cast at hbound hθ'
      linarith)
  have hr : (1:ℝ) ≤ (k:ℝ)^2*m := by exact_mod_cast (show 1 ≤ k^2*m by omega)
  have hsR : (k:ℝ)*m ≤ (k:ℝ)^2*m := by
    have hkn : (1:ℝ) ≤ k := by exact_mod_cast hk1
    nlinarith [mul_nonneg (show (0:ℝ) ≤ m by positivity) (show (0:ℝ) ≤ k*(k-1) by positivity)]
  have hlog : Real.log (((k:ℝ)^2*m)*(k*m)) ≤ 2*Real.log ((k:ℝ)^2*m) := by
    have hl := Real.log_le_log (show (0:ℝ) < ((k:ℝ)^2*m)*(k*m) by positivity)
      (mul_le_mul_of_nonneg_left hsR (by positivity : (0:ℝ) ≤ (k:ℝ)^2*m))
    simpa only [← pow_two, Real.log_pow, Nat.cast_ofNat] using hl
  apply parameter_bound_simplified (k:ℝ) (m:ℝ) (Real.log B) (Real.log ((k:ℝ)^2*m))
    (Real.log (((k:ℝ)^2*m)*(k*m))) (Real.log 4)
    (∑ p ∈ P, Real.log p / p) (by exact_mod_cast hk) (by exact_mod_cast hm)
    (Real.log_nonneg hB) (Real.log_nonneg hr) (Real.log_nonneg (by norm_num)) hlog
  push_cast [Nat.cast_sub hk1] at hnorm
  convert hnorm using 1 <;> ring

end MissingLinnik

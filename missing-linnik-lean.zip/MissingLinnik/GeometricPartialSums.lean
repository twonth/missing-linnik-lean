import MissingLinnik.MertensMangoldt

namespace MissingLinnik

open Finset

/-- A finite, discrete summation estimate: square-root growth of partial
sums implies a uniform bound for reciprocal-weighted sums. -/
theorem weighted_sum_four_power (a : ℕ → ℝ) (C : ℝ) (hC : 0 ≤ C)
    (ha : ∀ n, 0 ≤ a n) (ha1 : a 1 = 0)
    (hsum : ∀ k : ℕ, (∑ n ∈ Finset.Ioc 0 (4^k), a n) ≤ C*(2:ℝ)^k) (k : ℕ) :
    (∑ n ∈ Finset.Ioc 0 (4^k), a n/(n:ℝ)) ≤ 4*C*(1-(2:ℝ)⁻¹^k) := by
  induction k with
  | zero => norm_num [show Finset.Ioc 0 1 = {1} by rfl,ha1]
  | succ k ih =>
    have hpow : 4^k ≤ 4^(k+1) := Nat.pow_le_pow_right (by omega) (by omega)
    have hsplit := Finset.sum_Ioc_consecutive (f := fun n : ℕ => a n/(n:ℝ))
      (show 0 ≤ 4^k by omega) hpow
    have htail : (∑ n ∈ Finset.Ioc (4^k) (4^(k+1)), a n/(n:ℝ)) ≤
        (C*(2:ℝ)^(k+1))/(4:ℝ)^k := by
      calc
        _ ≤ ∑ n ∈ Finset.Ioc (4^k) (4^(k+1)), a n/(4:ℝ)^k := by
          apply Finset.sum_le_sum
          intro n hn
          apply div_le_div_of_nonneg_left (ha n) (by positivity)
          exact_mod_cast (Finset.mem_Ioc.mp hn).1.le
        _ = (∑ n ∈ Finset.Ioc (4^k) (4^(k+1)), a n)/(4:ℝ)^k := by rw [Finset.sum_div]
        _ ≤ (∑ n ∈ Finset.Ioc 0 (4^(k+1)), a n)/(4:ℝ)^k := by
          apply div_le_div_of_nonneg_right _ (by positivity)
          apply Finset.sum_le_sum_of_subset_of_nonneg
          · intro n hn
            exact Finset.mem_Ioc.mpr ⟨lt_of_le_of_lt (Nat.zero_le _) (Finset.mem_Ioc.mp hn).1,(Finset.mem_Ioc.mp hn).2⟩
          · intro n hn hn'; exact ha n
        _ ≤ _ := div_le_div_of_nonneg_right (hsum (k+1)) (by positivity)
    have he : 4*C*(1-(2:ℝ)⁻¹^k)+(C*(2:ℝ)^(k+1))/(4:ℝ)^k =
        4*C*(1-(2:ℝ)⁻¹^(k+1)) := by
      have h4 : (4:ℝ)^k = ((2:ℝ)^k)^2 := by rw [pow_two,← mul_pow]; norm_num
      rw [h4]
      simp only [pow_succ,inv_pow]
      field_simp
      ring
    rw [← hsplit]
    exact (add_le_add ih htail).trans he.le

theorem weighted_sum_of_sqrt_growth (a : ℕ → ℝ) (C : ℝ) (hC : 0 ≤ C)
    (ha : ∀ n, 0 ≤ a n) (ha1 : a 1 = 0)
    (hsum : ∀ N : ℕ, (∑ n ∈ Finset.Ioc 0 N, a n) ≤ C*Real.sqrt N) (N : ℕ) :
    (∑ n ∈ Finset.Ioc 0 N, a n/(n:ℝ)) ≤ 4*C := by
  have hs (k : ℕ) : (∑ n ∈ Finset.Ioc 0 (4^k), a n) ≤ C*(2:ℝ)^k := by
    have hh := hsum (4^k)
    have he : Real.sqrt ((4^k:ℕ):ℝ) = (2:ℝ)^k := by
      push_cast
      have h4 : (4:ℝ)^k = ((2:ℝ)^k)^2 := by rw [pow_two,← mul_pow]; norm_num
      rw [h4,Real.sqrt_sq_eq_abs,abs_of_nonneg (by positivity)]
    rwa [he] at hh
  have hN : N ≤ 4^N := by
    exact (Nat.lt_pow_self (by omega : 1<4)).le
  have hh := weighted_sum_four_power a C hC ha ha1 hs N
  have hsub : (∑ n ∈ Finset.Ioc 0 N, a n/(n:ℝ)) ≤
      ∑ n ∈ Finset.Ioc 0 (4^N), a n/(n:ℝ) := by
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · intro n hn; exact Finset.mem_Ioc.mpr ⟨(Finset.mem_Ioc.mp hn).1,(Finset.mem_Ioc.mp hn).2.trans hN⟩
    · intro n hn hn'; exact div_nonneg (ha n) (Nat.cast_nonneg n)
  have he : 0 ≤ 4*C*((2:ℝ)⁻¹^N) := by positivity
  linarith

end MissingLinnik

import MissingLinnik.MobiusComparison
import Mathlib.Analysis.Complex.ExponentialBounds

namespace MissingLinnik

theorem exp_nat_le_three_pow (n : ℕ) : Real.exp n ≤ (3:ℝ)^n := by
  have hh := pow_le_pow_left₀ (Real.exp_pos 1).le Real.exp_one_lt_three.le n
  simpa only [← Real.exp_nat_mul,mul_one] using hh

theorem roughUpperConstant_le : roughUpperConstant ≤ (10:ℝ)^12 := by
  have hh := exp_nat_le_three_pow 15
  norm_num at hh
  unfold roughUpperConstant
  norm_num
  linarith

theorem roughDiscrepancyConstant_le : roughDiscrepancyConstant ≤ (10:ℝ)^22 := by
  have h15 := roughUpperConstant_le
  have h1 := exp_nat_le_three_pow 1
  have h17 := exp_nat_le_three_pow 17
  have h32 := exp_nat_le_three_pow 32
  norm_num at h1 h17 h32 h15
  have hleft := mul_le_mul (show 32*Real.exp 32+2 ≤ 32*1853020188851841+2 by linarith) h1
    (Real.exp_pos 1).le (by norm_num : (0:ℝ)≤32*1853020188851841+2)
  have hright := mul_le_mul (show 2*roughUpperConstant ≤ (2:ℝ)*1000000000000 by linarith) h17
    (Real.exp_pos 17).le (by norm_num : (0:ℝ)≤2*1000000000000)
  unfold roughDiscrepancyConstant
  norm_num at hleft hright ⊢
  linarith

theorem symmetryComparisonConstant_le : symmetryComparisonConstant ≤ (10:ℝ)^40 := by
  have hC := roughDiscrepancyConstant_le
  have hU := roughUpperConstant_le
  have hU0 : 0 ≤ roughUpperConstant := by unfold roughUpperConstant; positivity
  have hm := mul_le_mul (show 9000*(2*roughDiscrepancyConstant+1) ≤ 9000*(2*(10:ℝ)^22+1) by linarith)
    (show 1+6*roughUpperConstant ≤ 1+6*(10:ℝ)^12 by linarith)
    (show 0≤1+6*roughUpperConstant by positivity) (by positivity : 0≤9000*(2*(10:ℝ)^22+1))
  unfold symmetryComparisonConstant
  exact hm.trans (by norm_num)

end MissingLinnik

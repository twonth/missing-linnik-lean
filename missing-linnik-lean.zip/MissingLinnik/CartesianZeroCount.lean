import MissingLinnik.GreenMultiplicitySum
import MissingLinnik.BivariateDegree

namespace MissingLinnik.Green

open Classical

theorem card_zeros_le_natDegree {K ι : Type*} [Field K] [Fintype ι]
    (f : Polynomial K) (hf : f ≠ 0) (z : ι → K) (hz : Function.Injective z) :
    (Finset.univ.filter (fun i => f.eval (z i) = 0)).card ≤ f.natDegree := by
  have hi (i : ι) : (if f.eval (z i) = 0 then 1 else 0) ≤ f.rootMultiplicity (z i) := by
    split_ifs with he
    · exact (Polynomial.rootMultiplicity_pos hf).mpr he
    · exact Nat.zero_le _
  have hs := Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => hi i)
  have hh := sum_rootMultiplicity_comp_le f z hz
  have hc : (∑ i : ι, if f.eval (z i) = 0 then 1 else 0) =
      (Finset.univ.filter (fun i => f.eval (z i) = 0)).card := by simp
  rw [hc] at hs
  exact hs.trans hh

/-- A Cartesian grid zero count in terms of the two separate degrees. -/
theorem cartesian_zero_count {K α β : Type*} [Field K] [Fintype α] [Fintype β]
    (f : Polynomial (Polynomial K)) (hf : f ≠ 0)
    (z : α → K) (w : β → K) (hz : Function.Injective z) (hw : Function.Injective w) :
    (Finset.univ.filter (fun i : α × β =>
      (f.map (Polynomial.evalRingHom (w i.2))).eval (z i.1) = 0)).card ≤
      Fintype.card α * yDegree f + Fintype.card β * f.natDegree := by
  have hlead : f.leadingCoeff ≠ 0 := Polynomial.leadingCoeff_ne_zero.mpr hf
  have hbad := (card_zeros_le_natDegree f.leadingCoeff hlead w hw).trans
    (coeff_natDegree_le_yDegree f f.natDegree)
  have hfiber (b : β) :
      (Finset.univ.filter (fun a : α => (f.map (Polynomial.evalRingHom (w b))).eval (z a) = 0)).card ≤
        (if f.leadingCoeff.eval (w b) = 0 then Fintype.card α else 0) + f.natDegree := by
    by_cases hb : f.leadingCoeff.eval (w b) = 0
    · rw [ite_eq_left hb]
      exact (Finset.card_filter_le _ _).trans (by simp)
    · rw [ite_eq_right hb, zero_add]
      have hspec : f.map (Polynomial.evalRingHom (w b)) ≠ 0 := by
        intro hzero
        apply hb
        have hc := congrArg (fun p : Polynomial K => p.coeff f.natDegree) hzero
        simpa only [Polynomial.coeff_map, Polynomial.coeff_zero, Polynomial.coe_evalRingHom,
          Polynomial.leadingCoeff] using hc
      exact (card_zeros_le_natDegree _ hspec z hz).trans Polynomial.natDegree_map_le
  have hsum := Finset.sum_le_sum (fun b (_ : b ∈ Finset.univ) => hfiber b)
  have hcount : (Finset.univ.filter (fun i : α × β =>
      (f.map (Polynomial.evalRingHom (w i.2))).eval (z i.1) = 0)).card =
      ∑ b : β, (Finset.univ.filter (fun a : α =>
        (f.map (Polynomial.evalRingHom (w b))).eval (z a) = 0)).card := by
    simp only [Finset.card_filter]
    rw [Fintype.sum_prod_type, Finset.sum_comm]
  rw [hcount]
  have hind : (∑ b : β, if f.leadingCoeff.eval (w b) = 0 then Fintype.card α else 0) =
      Fintype.card α * (Finset.univ.filter (fun b => f.leadingCoeff.eval (w b) = 0)).card := by
    rw [← Finset.sum_filter]
    simp [mul_comm]
  rw [Finset.sum_add_distrib, hind] at hsum
  simp only [Finset.sum_const, Finset.card_univ, smul_eq_mul] at hsum
  exact hsum.trans (Nat.add_le_add_right (Nat.mul_le_mul_left _ hbad) _)

end MissingLinnik.Green


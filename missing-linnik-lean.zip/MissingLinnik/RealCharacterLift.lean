import Mathlib.NumberTheory.DirichletCharacter.Basic
import Mathlib.NumberTheory.MulChar.Lemmas
import Mathlib.Tactic.NormNum

namespace MissingLinnik

theorem real_character_quadratic {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) : ψ.IsQuadratic := by
  intro x
  by_cases hx : IsUnit x
  · let χ := ψ.ringHomComp Complex.ofRealHom
    have hn := Complex.norm_eq_one_of_mem_rootsOfUnity (χ.apply_mem_rootsOfUnity hx.unit)
    change ‖(ψ (hx.unit:ZMod N):ℂ)‖ = 1 at hn
    rw [hx.unit_spec] at hn
    have habs : |ψ x| = 1 := by
      simpa using hn
    rcases (abs_eq (by norm_num : (0:ℝ) ≤ 1)).mp habs with h | h
    · exact Or.inr (Or.inl h)
    · exact Or.inr (Or.inr h)
  · exact Or.inl (MulChar.map_nonunit ψ hx)

noncomputable def integerCharacterValue {N : ℕ} (ψ : DirichletCharacter ℝ N) (x : ZMod N) : ℤ :=
  if ψ x = 0 then 0 else if ψ x = 1 then 1 else -1

theorem integerCharacterValue_cast {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) (x : ZMod N) :
    (integerCharacterValue ψ x:ℝ) = ψ x := by
  rcases real_character_quadratic ψ x with h | h | h <;>
    norm_num [integerCharacterValue,h]

/-- The integral lift of a real Dirichlet character. -/
noncomputable def integerCharacter {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) : DirichletCharacter ℤ N where
  toFun := integerCharacterValue ψ
  map_one' := by
    apply Int.cast_injective (α := ℝ)
    rw [integerCharacterValue_cast,map_one,Int.cast_one]
  map_mul' := by
    intro x y
    apply Int.cast_injective (α := ℝ)
    rw [Int.cast_mul,integerCharacterValue_cast,integerCharacterValue_cast,integerCharacterValue_cast,map_mul]
  map_nonunit' := by
    intro x hx
    simp [integerCharacterValue,MulChar.map_nonunit ψ hx]

theorem integerCharacter_cast {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) (x : ZMod N) : (integerCharacter ψ x:ℝ) = ψ x :=
  integerCharacterValue_cast ψ x

theorem integerCharacter_quadratic {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) : (integerCharacter ψ).IsQuadratic := by
  intro x
  rcases real_character_quadratic ψ x with h | h | h
  · left; apply Int.cast_injective (α := ℝ); simpa only [integerCharacter_cast,Int.cast_zero] using h
  · right; left; apply Int.cast_injective (α := ℝ); simpa only [integerCharacter_cast,Int.cast_one] using h
  · right; right; apply Int.cast_injective (α := ℝ); simpa only [integerCharacter_cast,Int.cast_neg,Int.cast_one] using h

end MissingLinnik


import MissingLinnik.Frobenius
import MissingLinnik.VanDijkPolynomial
import Mathlib.Data.Nat.Prime.Factorial

namespace MissingLinnik.VanDijk

open scoped BigOperators QuadraticAlgebra

noncomputable def gridPoint (p M : ℕ) (d : ℤ) (i : Fin M × Fin M) :
    QuadraticAlgebra (ZMod p) (d : ZMod p) 0 := ⟨i.1.val, i.2.val⟩

theorem gridPoint_injective {p M : ℕ} (d : ℤ) (hM : M ≤ p) :
    Function.Injective (gridPoint p M d) := by
  intro i j h
  have hre := congrArg QuadraticAlgebra.re h
  have him := congrArg QuadraticAlgebra.im h
  have hre' := congrArg ZMod.val hre
  have him' := congrArg ZMod.val him
  simp only [gridPoint, ZMod.val_natCast_of_lt (i.1.isLt.trans_le hM),
    ZMod.val_natCast_of_lt (j.1.isLt.trans_le hM)] at hre'
  simp only [gridPoint, ZMod.val_natCast_of_lt (i.2.isLt.trans_le hM),
    ZMod.val_natCast_of_lt (j.2.isLt.trans_le hM)] at him'
  exact Prod.ext (Fin.ext hre') (Fin.ext him')

noncomputable def grid (p M : ℕ) (d : ℤ) :
    Finset (QuadraticAlgebra (ZMod p) (d : ZMod p) 0) := by
  classical
  exact Finset.univ.image (gridPoint p M d)

theorem grid_card {p M : ℕ} (d : ℤ) (hM : M ≤ p) :
    (grid p M d).card = M * M := by
  classical
  rw [grid, Finset.card_image_of_injective _ (gridPoint_injective d hM)]
  simp

theorem factorial_cast_ne_zero {K : Type*} [Field K] (p : ℕ) [Fact p.Prime]
    [CharP K p] {n : ℕ} (hn : n < p) : (n.factorial : K) ≠ 0 := by
  rw [ne_eq, CharP.cast_eq_zero_iff K p, Nat.Prime.dvd_factorial Fact.out]
  omega

/-- The grid has enough points to apply the multiplicity argument.
This is stated with the nonsquare hypothesis explicitly; Euler's criterion in
Frobenius.lean supplies it when the prime is inert. -/
theorem grid_coefficients_zero (p M R S : ℕ) (d : ℤ) [Fact p.Prime]
    [Fact (¬ IsSquare (d : ZMod p))]
    (hM : M ≤ p) (hcard : p ≤ M * M) (hR : R ≤ p)
    (hS : 0 < S) (hSp : S < p)
    (c : Fin R × Fin S → QuadraticAlgebra (ZMod p) (d : ZMod p) 0)
    (hv : ∀ i : Fin M × Fin M, ∀ j < S,
      (Polynomial.derivative^[j] (encodedPolynomial p R S c)).eval
        (gridPoint p M d i) = 0) :
    ∀ i, c i = 0 := by
  let K := QuadraticAlgebra (ZMod p) (d : ZMod p) 0
  let : CharP K p := charP_of_injective_algebraMap
    QuadraticAlgebra.algebraMap_injective p
  apply coefficients_zero_of_encoded_derivatives_vanish
    (Nat.Prime.pos Fact.out) hS hR c (grid p M d)
  · simpa only [grid_card d hM] using hcard
  · exact factorial_cast_ne_zero p ((Nat.sub_le S 1).trans_lt hSp)
  · intro a ha j hj
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp ha
    exact hv i j hj

end MissingLinnik.VanDijk

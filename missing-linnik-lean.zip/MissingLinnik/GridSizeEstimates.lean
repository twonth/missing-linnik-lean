import MissingLinnik.QuadraticEmbedding
import Mathlib.Data.Nat.Sqrt
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.Linarith

namespace MissingLinnik

theorem sqrt_grid_bounds (p : ℕ) (hp : 2 ≤ p) :
    p ≤ (p.sqrt+1)*(p.sqrt+1) ∧ p.sqrt+1 ≤ p ∧
      ((p.sqrt+1 : ℕ) : ℝ) ≤ 2*Real.sqrt p := by
  refine ⟨(Nat.succ_le_succ_sqrt p).trans' (Nat.le_succ p), ?_, ?_⟩
  · exact Nat.succ_le_of_lt (Nat.sqrt_lt_self (by omega))
  · have hs : (p.sqrt : ℝ)^2 ≤ (p : ℝ) := by exact_mod_cast Nat.sqrt_le' p
    have hroot := Real.sq_sqrt (show (0:ℝ) ≤ p by positivity)
    have hroot0 := Real.sqrt_nonneg (p:ℝ)
    have hp1 : (1:ℝ) ≤ p := by exact_mod_cast (show 1 ≤ p by omega)
    have hroot1 : 1 ≤ Real.sqrt (p:ℝ) := by nlinarith
    have hle : (p.sqrt : ℝ) ≤ Real.sqrt p := by nlinarith [Nat.cast_nonneg (α := ℝ) p.sqrt]
    push_cast
    linarith

theorem grid_archimedean_bound (p : ℕ) (hp : 2 ≤ p) (q : ℝ) (hq : 1 ≤ q)
    (a : ℂ) (ha : ‖a‖^2 ≤ q) :
    1 ≤ 4*Real.sqrt p*Real.sqrt q ∧
      (((p.sqrt+1 : ℕ) : ℝ) * (1+‖a‖) ≤ 4*Real.sqrt p*Real.sqrt q) ∧
      Real.log (4*Real.sqrt p*Real.sqrt q) ≤
        Real.log p/2 + Real.log q/2 + Real.log 8 := by
  have hp1 : (1:ℝ) ≤ p := by exact_mod_cast (show 1 ≤ p by omega)
  have hsp : 1 ≤ Real.sqrt (p:ℝ) := by simpa using Real.sqrt_le_sqrt hp1
  have hsq : 1 ≤ Real.sqrt q := by simpa using Real.sqrt_le_sqrt hq
  have haq : ‖a‖ ≤ Real.sqrt q := by
    nlinarith [Real.sq_sqrt (show 0 ≤ q by linarith), Real.sqrt_nonneg q, norm_nonneg a]
  refine ⟨?_, ?_, ?_⟩
  · nlinarith [mul_le_mul hsp hsq (by norm_num) (by positivity : 0 ≤ Real.sqrt (p:ℝ))]
  · have hh := mul_le_mul (sqrt_grid_bounds p hp).2.2
      (show 1+‖a‖ ≤ 2*Real.sqrt q by linarith) (by positivity) (by positivity)
    nlinarith
  · rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by norm_num) (by positivity),
      Real.log_sqrt (show (0:ℝ) ≤ p by positivity), Real.log_sqrt (show 0 ≤ q by linarith)]
    have hh : Real.log (4:ℝ) ≤ Real.log 8 := Real.log_le_log (by norm_num) (by norm_num)
    linarith

end MissingLinnik

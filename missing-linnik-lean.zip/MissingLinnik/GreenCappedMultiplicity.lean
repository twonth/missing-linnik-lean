import MissingLinnik.GreenMultiplicitySum
import MissingLinnik.BivariateDegree
import Mathlib.RingTheory.Polynomial.UniqueFactorization

namespace MissingLinnik.Green

open Classical

noncomputable def cappedOrder {K : Type*} [Field K] (J : ℕ) (z : K) (f : Polynomial K) : ℕ :=
  if f = 0 then J else min J (f.rootMultiplicity z)

theorem cappedOrder_le {K : Type*} [Field K] (J : ℕ) (z : K) (f : Polynomial K) :
    cappedOrder J z f ≤ J := by
  unfold cappedOrder
  split_ifs <;> omega

theorem cappedOrder_mul_le {K : Type*} [Field K] (J : ℕ) (z : K) (f g : Polynomial K) :
    cappedOrder J z (f * g) ≤ cappedOrder J z f + cappedOrder J z g := by
  by_cases hf : f = 0
  · simp [cappedOrder, hf]
  by_cases hg : g = 0
  · simp [cappedOrder, hg]
  simp only [cappedOrder, hf, hg, mul_ne_zero hf hg, ite_false,
    Polynomial.rootMultiplicity_mul (mul_ne_zero hf hg)]
  omega

theorem cappedOrder_unit {K : Type*} [Field K] (J : ℕ) (z : K) (f : Polynomial K)
    (hf : IsUnit f) : cappedOrder J z f = 0 := by
  obtain ⟨a, ha, rfl⟩ := Polynomial.isUnit_iff.mp hf
  simp [cappedOrder, ha.ne_zero]

theorem constant_capped_sum_le {K ι : Type*} [Field K] [Fintype ι]
    (f : Polynomial K) (hf : f ≠ 0) (z w : ι → K) (hw : Function.Injective w) (J : ℕ) :
    (∑ i, cappedOrder J (z i) ((Polynomial.C f).map (Polynomial.evalRingHom (w i)))) ≤
      J * f.natDegree := by
  have hterm (i : ι) : cappedOrder J (z i)
      ((Polynomial.C f).map (Polynomial.evalRingHom (w i))) ≤ J * f.rootMultiplicity (w i) := by
    by_cases hi : f.eval (w i) = 0
    · have hm : 1 ≤ f.rootMultiplicity (w i) := (Polynomial.rootMultiplicity_pos hf).mpr hi
      simp [Polynomial.map_C, Polynomial.coe_evalRingHom, hi, cappedOrder]
      nlinarith
    · simp [Polynomial.map_C, Polynomial.coe_evalRingHom, cappedOrder, hi]
  have hs := Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => hterm i)
  rw [← Finset.mul_sum] at hs
  exact hs.trans (Nat.mul_le_mul_left J (sum_rootMultiplicity_comp_le f w hw))

/-- The factorization step in Green's interpolation argument. Capping the
multiplicity at J handles the factors depending only on the second coordinate
without making an exceptional set of indices. -/
theorem capped_multiplicity_sum_bound {K ι : Type*} [Field K] [CharZero K] [Fintype ι]
    (z w : ι → K) (hw : Function.Injective w) (J : ℕ)
    (hzero : ∀ f : Polynomial (Polynomial K), f ≠ 0 →
      (Finset.univ.filter (fun i => (f.map (Polynomial.evalRingHom (w i))).eval (z i) = 0)).card ≤
        J * (f.natDegree + yDegree f))
    (f : Polynomial (Polynomial K)) (hf : f ≠ 0) :
    (∑ i, cappedOrder J (z i) (f.map (Polynomial.evalRingHom (w i)))) ≤
      J * (f.natDegree + yDegree f) + 2 * f.natDegree * yDegree f := by
  induction f using WfDvdMonoid.induction_on_irreducible with
  | zero => exact (hf rfl).elim
  | unit f hunit =>
    have hh (i : ι) : cappedOrder J (z i) (f.map (Polynomial.evalRingHom (w i))) = 0 :=
      cappedOrder_unit J (z i) _ (hunit.map (Polynomial.mapRingHom (Polynomial.evalRingHom (w i))))
    simp only [hh, Finset.sum_const_zero]
    exact Nat.zero_le _
  | mul g h hg hh ih =>
    have hb : (∑ i, cappedOrder J (z i) (h.map (Polynomial.evalRingHom (w i)))) ≤
        J * (h.natDegree + yDegree h) + 2 * h.natDegree * yDegree h := by
      by_cases hd : h.natDegree = 0
      · have he := Polynomial.eq_C_of_natDegree_eq_zero hd
        have hcoef : h.coeff 0 ≠ 0 := by
          intro hc
          apply hh.ne_zero
          rw [he, hc, Polynomial.C_0]
        have hc := constant_capped_sum_le (h.coeff 0) hcoef z w hw J
        have hy : yDegree h = (h.coeff 0).natDegree := (congrArg yDegree he).trans (yDegree_C _)
        rw [← he] at hc
        simpa only [hd, hy, zero_add, mul_zero, zero_mul, add_zero] using hc
      · have hc := irreducible_multiplicity_sum_bound h hh hd z w hw J (yDegree h)
          (coeff_natDegree_le_yDegree h) (hzero h hh.ne_zero)
        apply (Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => ?_)).trans hc
        rw [cappedOrder, ite_eq_right (specialization_ne_zero h hh hd (w i))]
        exact min_le_right _ _
    have hmul : (∑ i, cappedOrder J (z i) ((h*g).map (Polynomial.evalRingHom (w i)))) ≤
        (∑ i, cappedOrder J (z i) (h.map (Polynomial.evalRingHom (w i)))) +
        (∑ i, cappedOrder J (z i) (g.map (Polynomial.evalRingHom (w i)))) := by
      rw [← Finset.sum_add_distrib]
      apply Finset.sum_le_sum
      intro i _
      rw [Polynomial.map_mul]
      exact cappedOrder_mul_le J (z i) _ _
    have hgBound := ih hg
    rw [Polynomial.natDegree_mul hh.ne_zero hg, yDegree_mul h g hh.ne_zero hg]
    nlinarith

end MissingLinnik.Green



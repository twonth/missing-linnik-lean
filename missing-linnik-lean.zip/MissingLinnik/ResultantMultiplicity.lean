import MissingLinnik.DeterminantDivisibility
import Mathlib.RingTheory.Polynomial.Resultant.Basic
import Mathlib.Algebra.Polynomial.FieldDivision
import Lean.Elab.Tactic.Omega

namespace MissingLinnik

theorem pow_dvd_det_of_initial_rows {K : Type*} [CommRing K]
    (N k : ℕ) (M : Matrix (Fin N) (Fin N) K) (a : K) (hk : k ≤ N)
    (hrow : ∀ i j, i.val < k → a ∣ M i j) : a ^ k ∣ M.det := by
  classical
  have hf : (Finset.range N).filter (fun i => i < k) = Finset.range k := by
    ext i
    simp only [Finset.mem_filter, Finset.mem_range]
    omega
  have hs : (∑ i : Fin N, if i.val < k then 1 else 0) = k := by
    rw [Fin.sum_univ_eq_sum_range (fun i => if i < k then 1 else 0) N,
      ← Finset.sum_filter, hf]
    simp
  rw [← hs]
  apply row_prime_powers_dvd_det
  intro i j
  split_ifs with hi
  · simpa using hrow i j hi
  · simp

theorem pow_dvd_resultant_of_initial_coefficients {K : Type*} [CommRing K]
    (f g : Polynomial K) (m n k : ℕ) (a : K) (hk : k ≤ m + n)
    (hf : ∀ i < k, a ∣ f.coeff i) (hg : ∀ i < k, a ∣ g.coeff i) :
    a ^ k ∣ f.resultant g m n := by
  apply pow_dvd_det_of_initial_rows (m+n) k (f.sylvester g m n) a hk
  intro i j hi
  induction j using Fin.addCases with
  | left j =>
    simp only [Polynomial.sylvester, Matrix.of_apply, Fin.addCases_left]
    split_ifs
    · exact hg _ (lt_of_le_of_lt (Nat.sub_le _ _) hi)
    · exact dvd_zero _
  | right j =>
    simp only [Polynomial.sylvester, Matrix.of_apply, Fin.addCases_right]
    split_ifs
    · exact hf _ (lt_of_le_of_lt (Nat.sub_le _ _) hi)
    · exact dvd_zero _

theorem taylor_coefficient_specialization_dvd {K : Type*} [Field K]
    (f : Polynomial (Polynomial K)) (z w : K) (k : ℕ)
    (hf : (Polynomial.X - Polynomial.C z) ^ k ∣ f.map (Polynomial.evalRingHom w))
    (i : ℕ) (hi : i < k) :
    Polynomial.X - Polynomial.C w ∣ (f.taylor (Polynomial.C z)).coeff i := by
  have ht : (Polynomial.X : Polynomial K) ^ k ∣
      (f.map (Polynomial.evalRingHom w)).taylor z := by
    simpa using (Polynomial.taylorAlgHom z).map_dvd hf
  have hc := Polynomial.X_pow_dvd_iff.mp ht i hi
  rw [Polynomial.dvd_iff_isRoot]
  have he : ((f.taylor (Polynomial.C z)).map (Polynomial.evalRingHom w)).coeff i = 0 := by
    rw [Polynomial.map_taylor]
    simpa using hc
  simpa only [Polynomial.coeff_map, Polynomial.coe_evalRingHom, Polynomial.IsRoot] using he

/-- A common factor of order k at a specialization forces order k in the
resultant as a polynomial in the remaining variable. -/
theorem common_specialization_factor_dvd_resultant {K : Type*} [Field K]
    (f g : Polynomial (Polynomial K)) (z w : K) (k : ℕ)
    (hk : k ≤ f.natDegree + g.natDegree)
    (hf : (Polynomial.X - Polynomial.C z) ^ k ∣ f.map (Polynomial.evalRingHom w))
    (hg : (Polynomial.X - Polynomial.C z) ^ k ∣ g.map (Polynomial.evalRingHom w)) :
    (Polynomial.X - Polynomial.C w) ^ k ∣ f.resultant g := by
  have h := pow_dvd_resultant_of_initial_coefficients
    (f.taylor (Polynomial.C z)) (g.taylor (Polynomial.C z))
    f.natDegree g.natDegree k (Polynomial.X - Polynomial.C w) hk
    (taylor_coefficient_specialization_dvd f z w k hf)
    (taylor_coefficient_specialization_dvd g z w k hg)
  simpa only [← Polynomial.natDegree_taylor f (Polynomial.C z),
    ← Polynomial.natDegree_taylor g (Polynomial.C z), Polynomial.resultant_taylor] using h

/-- Green's Lemma A.1, stated for a bivariate polynomial represented as a
polynomial whose coefficients are polynomials. The resultant is taken in
the outer variable. -/
theorem green_resultant_multiplicity {K : Type*} [Field K]
    (f : Polynomial (Polynomial K)) (z w : K)
    (hf : f.map (Polynomial.evalRingHom w) ≠ 0)
    (hres : f.resultant f.derivative ≠ 0) :
    (f.map (Polynomial.evalRingHom w)).rootMultiplicity z ≤
      1 + (f.resultant f.derivative).rootMultiplicity w := by
  let f₀ := f.map (Polynomial.evalRingHom w)
  let μ := f₀.rootMultiplicity z
  have hroot : (Polynomial.X - Polynomial.C z) ^ μ ∣ f₀ := f₀.pow_rootMultiplicity_dvd z
  have hdeg : μ ≤ f₀.natDegree := by
    have hh := Polynomial.natDegree_le_of_dvd hroot hf
    simpa using hh
  have hmap : f₀.natDegree ≤ f.natDegree := Polynomial.natDegree_map_le
  have hk : μ - 1 ≤ f.natDegree + f.derivative.natDegree := by omega
  have hfdiv : (Polynomial.X - Polynomial.C z) ^ (μ - 1) ∣ f₀ :=
    (pow_dvd_pow _ (Nat.sub_le μ 1)).trans hroot
  have hgdiv : (Polynomial.X - Polynomial.C z) ^ (μ - 1) ∣
      f.derivative.map (Polynomial.evalRingHom w) := by
    rw [← Polynomial.derivative_map]
    exact Polynomial.pow_sub_one_dvd_derivative_of_pow_dvd hroot
  have hdiv := common_specialization_factor_dvd_resultant f f.derivative z w (μ - 1) hk hfdiv hgdiv
  have hle := (Polynomial.le_rootMultiplicity_iff hres).mpr hdiv
  change μ ≤ 1 + _
  omega

end MissingLinnik




import MissingLinnik.PrimitiveGaussSquare
import MissingLinnik.CharacterReduction
import Mathlib.NumberTheory.LegendreSymbol.Basic

namespace MissingLinnik

noncomputable def characterDiscriminant {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) : ℤ := integerCharacter ψ (-1)*(N:ℤ)

theorem characterDiscriminant_natAbs {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) : (characterDiscriminant ψ).natAbs = N := by
  have hsign : integerCharacter ψ (-1)*integerCharacter ψ (-1) = 1 := by
    rw [← map_mul]
    simp
  rcases integerCharacter_quadratic ψ (-1) with h | h | h
  · rw [h] at hsign
    norm_num at hsign
  · simp [characterDiscriminant,h]
  · simp [characterDiscriminant,h]

theorem negative_prime_isUnit {N : ℕ} (ψ : DirichletCharacter ℝ N)
    (p : ℕ) (hp : ψ (p:ZMod N) = -1) : IsUnit (p:ZMod N) := by
  by_contra hn
  have hh := MulChar.map_nonunit ψ hn
  rw [hp] at hh
  norm_num at hh

/-- Gauss sums identify every negative odd prime with an inert prime for the
integer chi(-1) times the modulus. This avoids assuming a classification
theorem about fundamental discriminants. -/
theorem negative_odd_prime_inert {N : ℕ} [NeZero N]
    (ψ : DirichletCharacter ℝ N) (hψ : ψ.IsPrimitive)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) (hp : ψ (p:ZMod N) = -1) :
    legendreSym p (characterDiscriminant ψ) = -1 := by
  have hu := negative_prime_isUnit ψ p hp
  have hcop := (ZMod.isUnit_iff_coprime p N).mp hu
  have hN : (N:ZMod p) ≠ 0 := by
    intro hz
    exact (Nat.Prime.coprime_iff_not_dvd (Fact.out : p.Prime)).mp hcop
      ((ZMod.natCast_eq_zero_iff N p).mp hz)
  let e := AddChar.primitiveZModChar ⟨N,NeZero.pos N⟩ (ZMod p) hN
  let K := CyclotomicField N (ZMod p)
  letI : CharP K p := charP_of_injective_algebraMap (algebraMap (ZMod p) K).injective p
  have h2 : (2:K) ≠ 0 := by
    intro hz
    have hdiv := (CharP.cast_eq_zero_iff K p 2).mp (by simpa using hz)
    exact hp2 ((Nat.dvd_prime Nat.prime_two).mp hdiv |>.resolve_left (Fact.out : p.Prime).ne_one)
  let χ := reducedCharacter ψ K
  have hχ : χ.IsPrimitive := reducedCharacter_primitive ψ hψ K h2
  have hquad : χ.IsQuadratic := reducedCharacter_quadratic ψ K
  have hg := primitive_gauss_square χ hχ hquad e.char e.prim
  have hpow := Char.card_pow_char_pow hquad e.char p 1 hu hp2 (by simpa [ZMod.card] using hg)
  have hpint : integerCharacter ψ (p:ZMod N) = -1 := by
    apply Int.cast_injective (α := ℝ)
    simpa only [integerCharacter_cast,Int.cast_neg,Int.cast_one] using hp
  have hpow' : (characterDiscriminant ψ:K)^(p/2) = -1 := by
    change ((Int.castRingHom K) (integerCharacter ψ (-1)*(N:ℤ)))^(p/2) = -1
    rw [map_mul,map_natCast]
    simpa [χ,reducedCharacter,hpint] using hpow
  have hbase : (characterDiscriminant ψ:ZMod p)^(p/2) = -1 := by
    apply (algebraMap (ZMod p) K).injective
    simpa using hpow'
  have hleg : (legendreSym p (characterDiscriminant ψ):ZMod p) = (-1:ℤ) := by
    rw [legendreSym.eq_pow]
    simpa using hbase
  apply Int.cast_injOn_of_ringChar_ne_two (R := ZMod p)
    (by simpa only [ZMod.ringChar_zmod_n] using hp2) (quadraticChar_isQuadratic (ZMod p) (characterDiscriminant ψ))
    (Or.inr (Or.inr rfl)) hleg

end MissingLinnik

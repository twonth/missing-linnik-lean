import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Algebra.Polynomial.Eval.SMul
import Mathlib.Tactic.Ring

/-! Algebraic divisibility machinery shared by the two determinant arguments. -/

namespace MissingLinnik

open scoped BigOperators

/-- Divisibility of each row gives divisibility of the determinant by the
product of all row factors. No nonvanishing hypothesis is needed here. -/
theorem product_row_factors_dvd_det {R ι : Type*} [CommRing R]
    [Fintype ι] [DecidableEq ι] (M : Matrix ι ι R) (a : ι → R)
    (h : ∀ i j, a i ∣ M i j) : (∏ i, a i) ∣ M.det := by
  classical
  choose N hN using h
  have hM : M = Matrix.of (fun i j => a i * N i j) := by
    ext i j
    exact hN i j
  have hdet : M.det = (∏ i, a i) * (Matrix.of N).det := by
    rw [hM]
    exact Matrix.det_mul_column a (Matrix.of N)
  rw [hdet]
  exact dvd_mul_right _ _

theorem row_prime_powers_dvd_det {R ι : Type*} [CommRing R]
    [Fintype ι] [DecidableEq ι] (M : Matrix ι ι R) (p : R) (h : ι → ℕ)
    (hrow : ∀ i j, p ^ h i ∣ M i j) : p ^ (∑ i, h i) ∣ M.det := by
  simpa only [Finset.prod_pow_eq_pow_sum] using
    product_row_factors_dvd_det M (fun i => p ^ h i) hrow

/-- A lower unitriangular row transformation preserves the determinant. -/
theorem det_unitriangular_mul {R ι : Type*} [CommRing R]
    [Fintype ι] [DecidableEq ι] [LinearOrder ι]
    (U M : Matrix ι ι R) (htri : U.IsLowerTriangular)
    (hdiag : ∀ i, U i i = 1) : (U * M).det = M.det := by
  rw [Matrix.det_mul, Matrix.det_of_isLowerTriangular U htri]
  simp [hdiag]

/-- The iterated Leibniz rule preserves divisibility by a fixed factor. -/
theorem dvd_iterate_derivative_mul {R : Type*} [CommRing R]
    (a z : R) (P Q : Polynomial R)
    (hP : ∀ j : ℕ, a ∣ (Polynomial.derivative^[j] P).eval z) (n : ℕ) :
    a ∣ (Polynomial.derivative^[n] (P * Q)).eval z := by
  rw [Polynomial.iterate_derivative_mul]
  simp only [Polynomial.eval_finsetSum, Polynomial.eval_mul,
    nsmul_eq_mul]
  apply Finset.dvd_sum
  intro j _
  exact dvd_mul_of_dvd_right (dvd_mul_of_dvd_left (hP (n - j)) _) _

/-- If all derivatives of P at z are divisible by a, then all derivatives of
P^h at z are divisible by a^h. This is the row divisibility argument used in
both Green and van Dijk, before specializing P to X^p - w. -/
theorem pow_dvd_iterate_derivative_pow {R : Type*} [CommRing R]
    (a z : R) (P : Polynomial R)
    (hP : ∀ j : ℕ, a ∣ (Polynomial.derivative^[j] P).eval z) (h n : ℕ) :
    a ^ h ∣ (Polynomial.derivative^[n] (P ^ h)).eval z := by
  induction h generalizing n with
  | zero => simp
  | succ h ih =>
    rw [pow_succ P h, Polynomial.iterate_derivative_mul]
    simp only [Polynomial.eval_finsetSum, Polynomial.eval_mul,
      nsmul_eq_mul]
    apply Finset.dvd_sum
    intro j _
    rw [pow_succ]
    exact dvd_mul_of_dvd_right (mul_dvd_mul (ih (n - j)) (hP j)) _

/-- Frobenius congruence at a grid point implies divisibility of every derivative
of X^p-w there. Positive derivatives introduce the factor p automatically. -/
theorem frobenius_polynomial_derivatives_dvd {R : Type*} [CommRing R]
    (p : ℕ) (z w : R) (hf : (p : R) ∣ z ^ p - w) (n : ℕ) :
    (p : R) ∣ (Polynomial.derivative^[n]
      ((Polynomial.X : Polynomial R) ^ p - Polynomial.C w)).eval z := by
  cases n with
  | zero => simpa using hf
  | succ n =>
    rw [Function.iterate_succ_apply, Polynomial.derivative_sub,
      Polynomial.derivative_X_pow, Polynomial.derivative_C, sub_zero,
      Polynomial.iterate_derivative_C_mul, Polynomial.eval_mul, Polynomial.eval_C]
    exact dvd_mul_right _ _

/-- The complete divisibility statement for a modified row polynomial. -/
theorem modified_row_derivatives_dvd {R : Type*} [CommRing R]
    (p : ℕ) (z w : R) (hf : (p : R) ∣ z ^ p - w)
    (Q : Polynomial R) (h n : ℕ) :
    (p : R) ^ h ∣ (Polynomial.derivative^[n]
      (((Polynomial.X : Polynomial R) ^ p - Polynomial.C w) ^ h * Q)).eval z := by
  apply dvd_iterate_derivative_mul
  intro j
  exact pow_dvd_iterate_derivative_pow (p : R) z _
    (frobenius_polynomial_derivatives_dvd p z w hf) h j

end MissingLinnik

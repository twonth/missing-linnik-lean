import MissingLinnik.SelbergAverage
import MissingLinnik.ExplicitSieveConstants

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

theorem roughWeightedClassSum_mod_one (b Y : ℕ) (x : ℝ) :
    roughWeightedClassSum 1 b Y x = roughWeightedSum Y x := by
  unfold roughWeightedClassSum roughWeightedSum
  congr 1
  ext n
  simp only [Finset.mem_filter,Nat.ModEq,Nat.mod_one,and_true]

/-- The fully instantiated comparison of Selberg's arithmetic kernel in a
reduced residue class and in all rough integers, with an absolute constant. -/
theorem selberg_rough_comparison (N q k c : ℕ) (hq : 2≤q) (hk : 1≤k)
    (hc : c.Coprime q) (hN : q^(170*k) ≤ N) :
    |roughSelbergClassSum N q c (q^(170*k))-
      roughSelbergClassSum N 1 0 (q^(170*k))/q.totient| ≤
      (10:ℝ)^40*Real.log ((q^(170*k):ℕ):ℝ)*Real.log N/q.totient := by
  let Y := q^(170*k)
  have hqY : q ≤ Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 1≤Y := (show 1≤q by omega).trans hqY
  have he : roughSelbergClassSum N q c Y-roughSelbergClassSum N 1 0 Y/q.totient =
      ∑ d ∈ (Icc 1 N).filter (IsRough Y), (moebius d:ℝ)/(d:ℝ)*
        (roughWeightedClassSum q (inverseResidue q c d) Y ((N:ℝ)/d)-roughWeightedSum Y ((N:ℝ)/d)/q.totient) := by
    rw [roughSelbergClassSum_convolution N q c Y (by omega) hqY,
      roughSelbergClassSum_convolution N 1 0 Y (by omega) hY]
    simp_rw [roughWeightedClassSum_mod_one]
    rw [Finset.sum_div,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro d hd
    ring
  change |roughSelbergClassSum N q c Y-roughSelbergClassSum N 1 0 Y/q.totient| ≤ _
  rw [he]
  have hb (d : ℕ) (hd : IsRough Y d) : (inverseResidue q c d).Coprime q :=
    inverseResidue_coprime q c d (by omega) hc (isRough_coprime q Y d (by omega) hqY hd)
  have hh := mobius_rough_comparison q k hq hk (inverseResidue q c) hb (N:ℝ) (by exact_mod_cast hN)
  rw [Nat.floor_natCast] at hh
  apply hh.trans
  have hlY : 0≤Real.log (Y:ℝ) := Real.log_nonneg (by exact_mod_cast hY)
  have hlN : 0≤Real.log (N:ℝ) := Real.log_nonneg (by exact_mod_cast hY.trans hN)
  have hm := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_right symmetryComparisonConstant_le hlY) hlN
  exact div_le_div_of_nonneg_right hm (Nat.cast_nonneg _)

end MissingLinnik

import MissingLinnik.MontgomeryVaughanTwoPower
import MissingLinnik.MontgomeryVaughanReciprocity
import MissingLinnik.MontgomeryVaughanProduct
import MissingLinnik.CharacterBridge
import Mathlib.Data.Nat.Factorization.Induction

namespace MissingLinnik

/-- An arithmetic representative on primes coprime to the modulus. Keeping
principal local factors allows CRT assembly without a conductor calculation. -/
def HasCoprimeQuadraticRepresentative {N : ℕ} (χ : DirichletCharacter ℝ N) : Prop :=
  ∃ d : ℤ, d.natAbs ≤ N ∧ ∀ (p : ℕ) (hp : p.Prime), p ≠ 2 → p.Coprime N →
    χ (p:ZMod N) = (@legendreSym p ⟨hp⟩ d : ℝ)

theorem principal_coprime_representative (N : ℕ) (hN : 1 ≤ N) :
    HasCoprimeQuadraticRepresentative (1 : DirichletCharacter ℝ N) := by
  refine ⟨1, by simpa, ?_⟩
  intro p hp _ hc
  letI : Fact p.Prime := ⟨hp⟩
  rw [MulChar.one_apply ((ZMod.isUnit_iff_coprime p N).mpr hc), legendreSym.at_one]
  norm_num

theorem coprime_representative_changeLevel {m N : ℕ} (hm : m ∣ N)
    (χ : DirichletCharacter ℝ m) (hχ : HasCoprimeQuadraticRepresentative χ) :
    HasCoprimeQuadraticRepresentative (DirichletCharacter.changeLevel hm χ) := by
  by_cases hN : N = 0
  · subst N
    obtain ⟨d, hd, hh⟩ := hχ
    refine ⟨0, by simp, ?_⟩
    intro p hp hp2 hc
    simp only [Nat.coprime_zero_right] at hc
    exact (hp.ne_one hc).elim
  obtain ⟨d, hd, hh⟩ := hχ
  refine ⟨d, hd.trans (Nat.le_of_dvd (Nat.pos_of_ne_zero hN) hm), ?_⟩
  intro p hp hp2 hc
  have hu := (ZMod.isUnit_iff_coprime p N).mpr hc
  have he := DirichletCharacter.changeLevel_eq_cast_of_dvd χ hm hu.unit
  rw [hu.unit_spec, ZMod.cast_natCast hm] at he
  rw [he]
  exact hh p hp hp2 (hc.of_dvd_right hm)

theorem coprime_representative_odd_prime_power (p k : ℕ) [Fact p.Prime]
    (hp : p ≠ 2) (hk : 0 < k) (χ : DirichletCharacter ℝ (p^k)) :
    HasCoprimeQuadraticRepresentative χ := by
  by_cases hχ : χ = 1
  · rw [hχ]; exact principal_coprime_representative _ (one_le_pow₀ (Fact.out : p.Prime).one_le)
  rw [real_character_prime_power_eq_legendre p k hp hk χ hχ]
  apply coprime_representative_changeLevel
  refine ⟨primeDiscriminant p, (primeDiscriminant_natAbs p).le, ?_⟩
  intro q hq hq2 _
  letI : Fact q.Prime := ⟨hq⟩
  exact real_character_prime_discriminant p q hp hq2 _ (realLegendreCharacter_nonprincipal p hp)

theorem coprime_representative_four (χ : DirichletCharacter ℝ 4) :
    HasCoprimeQuadraticRepresentative χ := by
  by_cases hχ : χ = 1
  · rw [hχ]; exact principal_coprime_representative _ (by norm_num)
  refine ⟨-1, by norm_num, ?_⟩
  intro p hp hp2 _
  letI : Fact p.Prime := ⟨hp⟩
  rw [real_character_four χ hχ, legendreSym.at_neg_one hp2]
  rfl

theorem coprime_representative_eight (χ : DirichletCharacter ℝ 8) :
    HasCoprimeQuadraticRepresentative χ := by
  rcases real_character_eight_cases χ with h | h | h | h
  · rw [h]; exact principal_coprime_representative _ (by norm_num)
  · rw [h]; exact coprime_representative_changeLevel _ _ (coprime_representative_four _)
  · refine ⟨2, by norm_num, ?_⟩
    intro p hp hp2 _
    letI : Fact p.Prime := ⟨hp⟩
    rw [h, legendreSym.at_two hp2]
    rfl
  · refine ⟨-2, by norm_num, ?_⟩
    intro p hp hp2 _
    letI : Fact p.Prime := ⟨hp⟩
    rw [h, legendreSym.at_neg_two hp2]
    rfl

theorem coprime_representative_two_power (k : ℕ) (χ : DirichletCharacter ℝ (2^k)) :
    HasCoprimeQuadraticRepresentative χ := by
  rcases k with _ | _ | _ | k
  · rw [DirichletCharacter.level_one' χ (by norm_num)]
    exact principal_coprime_representative _ (by norm_num)
  · have he : χ = 1 := by
      apply MulChar.ext
      intro u
      have hu : u = 1 := by
        apply Units.ext
        have hunit := u.isUnit
        generalize he : (u : ZMod (2^(0+1))) = x at *
        fin_cases x
        · exact ((by decide : ¬ IsUnit (0 : ZMod (2^(0+1)))) hunit).elim
        · rfl
      rw [hu]
      simp
    rw [he]
    exact principal_coprime_representative _ (by norm_num)
  · exact coprime_representative_four χ
  · have hf := real_character_two_power_factors_eight k χ
    rw [hf.eq_changeLevel]
    exact coprime_representative_changeLevel _ _ (coprime_representative_eight _)

/-- CRT multiplication of the integer representatives. -/
theorem coprime_representative_product (m n : ℕ) (hmn : m.Coprime n)
    (hm : ∀ χ : DirichletCharacter ℝ m, HasCoprimeQuadraticRepresentative χ)
    (hn : ∀ χ : DirichletCharacter ℝ n, HasCoprimeQuadraticRepresentative χ)
    (ψ : DirichletCharacter ℝ (m*n)) : HasCoprimeQuadraticRepresentative ψ := by
  obtain ⟨χ, θ, he⟩ := real_character_crt_decomposition m n hmn ψ
  obtain ⟨d, hd, hχ⟩ := hm χ
  obtain ⟨e, hd', hθ⟩ := hn θ
  refine ⟨d*e, ?_, ?_⟩
  · rw [Int.natAbs_mul]
    exact Nat.mul_le_mul hd hd'
  · intro p hp hp2 hc
    letI : Fact p.Prime := ⟨hp⟩
    have hh := he (p:ℤ)
    push_cast at hh
    rw [hh, hχ p hp hp2 (hc.of_dvd_right (dvd_mul_right m n)),
      hθ p hp hp2 (hc.of_dvd_right (dvd_mul_left n m)), legendreSym.mul, Int.cast_mul]

/-- The textbook local classification and reciprocity provide an integer
representative for every real character, including imprimitive characters. -/
theorem montgomeryVaughan_coprime_representative (N : ℕ) (hN : 1 ≤ N)
    (χ : DirichletCharacter ℝ N) : HasCoprimeQuadraticRepresentative χ := by
  induction N using Nat.recOnPosPrimePosCoprime with
  | zero => omega
  | one =>
    rw [DirichletCharacter.level_one χ]
    exact principal_coprime_representative _ (by norm_num)
  | prime_pow p k hp hk =>
    letI : Fact p.Prime := ⟨hp⟩
    by_cases hp2 : p = 2
    · subst p; exact coprime_representative_two_power k χ
    · exact coprime_representative_odd_prime_power p k hp2 hk χ
  | coprime m n hm hn hmn ih ih' =>
    exact coprime_representative_product m n hmn (ih (by omega)) (ih' (by omega)) χ

/-- The completed replacement for the Gauss-sum character bridge. -/
theorem montgomeryVaughan_representative (N : ℕ) (hN : 1 ≤ N)
    (χ : DirichletCharacter ℝ N) : HasWeakQuadraticRepresentative χ := by
  obtain ⟨d, hd, hh⟩ := montgomeryVaughan_coprime_representative N hN χ
  refine ⟨d, hd, ?_⟩
  intro p hp hp2 hneg
  have hu : IsUnit (p:ZMod N) := MulChar.apply_ne_zero_iff.mp (by rw [hneg]; norm_num)
  have he := hh p hp hp2 ((ZMod.isUnit_iff_coprime p N).mp hu)
  rw [hneg] at he
  exact_mod_cast he.symm

end MissingLinnik

import MissingLinnik.GridSizeEstimates

namespace MissingLinnik

/-- An explicit complex square root of an integer, with its exact size. -/
theorem exists_quadratic_root (d : ℤ) :
    ∃ a : ℂ, a^2 = d ∧ ‖a‖^2 = (d.natAbs : ℝ) := by
  have hex : ∃ a : ℂ, a^2 = d := by
    by_cases hd : (0:ℝ) ≤ d
    · refine ⟨(Real.sqrt (d:ℝ):ℂ), ?_⟩
      have hs := Real.sq_sqrt hd
      exact_mod_cast hs
    · refine ⟨(Real.sqrt (-(d:ℝ)):ℂ)*Complex.I, ?_⟩
      rw [mul_pow, Complex.I_sq]
      have hs := Real.sq_sqrt (show 0 ≤ -(d:ℝ) by linarith)
      have hc : (Real.sqrt (-(d:ℝ)):ℂ)^2 = -(d:ℂ) := by exact_mod_cast hs
      rw [hc]
      ring
  obtain ⟨a,ha⟩ := hex
  refine ⟨a,ha,?_⟩
  have hh := congrArg norm ha
  simpa using hh

end MissingLinnik

import MissingLinnik.AbstractMertens

namespace MissingLinnik

open Finset MeasureTheory

theorem log_square_inv_continuousOn (x : ℝ) :
    ContinuousOn (fun t : ℝ => t⁻¹*(Real.log t)^2) (Set.Icc 1 x) := by
  intro t ht
  have ht0 : t≠0 := by linarith [ht.1]
  exact (continuousAt_inv₀ ht0).continuousWithinAt.mul
    ((Real.continuousAt_log ht0).pow 2).continuousWithinAt

theorem integral_log_square_inv_one (x : ℝ) (hx : 1≤x) :
    (∫ t in Set.Ioc 1 x, t⁻¹*(Real.log t)^2) = (Real.log x)^3/3 := by
  have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (f := fun t : ℝ => (Real.log t)^3/3) (f' := fun t : ℝ => t⁻¹*(Real.log t)^2)
    (a := 1) (b := x) (by
      intro t ht
      rw [Set.uIcc_of_le hx] at ht
      have ht0 : t≠0 := by linarith [ht.1]
      convert ((Real.hasDerivAt_log ht0).pow 3).div_const 3 using 1 <;> ring)
    ((log_square_inv_continuousOn x).intervalIntegrable_of_Icc hx)
  rw [intervalIntegral.integral_of_le hx] at hh
  simpa using hh

theorem quadratic_mass_integral_error (c : ℕ → ℝ) (A D : ℝ)
    (hbound : ∀ t : ℝ, 1≤t → |coefficientMass c t-A*(Real.log t)^2|≤D*Real.log t)
    (x : ℝ) (hx : 1≤x) :
    |(∫ t in Set.Ioc 1 x, t⁻¹*coefficientMass c t)-A*(Real.log x)^3/3| ≤ D*(Real.log x)^2/2 := by
  have hi : IntegrableOn (fun t : ℝ => D*(t⁻¹*Real.log t)) (Set.Ioc 1 x) :=
    ((log_inv_continuousOn_Icc_one x).integrableOn_Icc.mono_set Set.Ioc_subset_Icc_self).const_mul D
  have hl : IntegrableOn (fun t : ℝ => A*(t⁻¹*(Real.log t)^2)) (Set.Ioc 1 x) :=
    ((log_square_inv_continuousOn x).integrableOn_Icc.mono_set Set.Ioc_subset_Icc_self).const_mul A
  have hm : IntegrableOn (fun t : ℝ => t⁻¹*coefficientMass c t) (Set.Ioc 1 x) :=
    (integrableOn_mul_sum_Icc c (m := 0) (by norm_num : (0:ℝ)≤1)
      (inv_integrableOn_Icc_one x)).mono_set Set.Ioc_subset_Icc_self
  have hlo := MeasureTheory.setIntegral_mono_on (hl.sub hi) hm measurableSet_Ioc
    (fun t ht => by
      have herr := (abs_le.mp (hbound t ht.1.le)).1
      have hh := mul_le_mul_of_nonneg_left herr (inv_nonneg.mpr (by linarith [ht.1] : 0≤t))
      dsimp
      nlinarith only [hh])
  have hhi := MeasureTheory.setIntegral_mono_on hm (hl.add hi) measurableSet_Ioc
    (fun t ht => by
      have herr := (abs_le.mp (hbound t ht.1.le)).2
      have hh := mul_le_mul_of_nonneg_left herr (inv_nonneg.mpr (by linarith [ht.1] : 0≤t))
      dsimp
      nlinarith only [hh])
  simp only [Pi.sub_apply,Pi.add_apply] at hlo hhi
  rw [MeasureTheory.integral_sub hl hi,MeasureTheory.integral_const_mul,
    MeasureTheory.integral_const_mul,integral_log_inv_one x hx,integral_log_square_inv_one x hx] at hlo
  rw [MeasureTheory.integral_add hl hi,MeasureTheory.integral_const_mul,
    MeasureTheory.integral_const_mul,integral_log_inv_one x hx,integral_log_square_inv_one x hx] at hhi
  apply abs_le.mpr
  constructor <;> linarith

theorem quadratic_mass_log_weight (c : ℕ → ℝ) (hc : c 0=0) (A D : ℝ) (hD : 0≤D)
    (hbound : ∀ t : ℝ, 1≤t → |coefficientMass c t-A*(Real.log t)^2|≤D*Real.log t)
    (x : ℝ) (hx : 1≤x) :
    |coefficientLogMoment c x-(2*A/3)*(Real.log x)^3| ≤ 2*D*(Real.log x)^2 := by
  have hm := mul_le_mul_of_nonneg_left (hbound x hx) (Real.log_nonneg hx)
  have hi := quadratic_mass_integral_error c A D hbound x hx
  rw [coefficientLogMoment_identity c hc]
  have he : Real.log x*coefficientMass c x-(∫ t in Set.Ioc 1 x, t⁻¹*coefficientMass c t)-(2*A/3)*(Real.log x)^3 =
      Real.log x*(coefficientMass c x-A*(Real.log x)^2)-
      ((∫ t in Set.Ioc 1 x, t⁻¹*coefficientMass c t)-A*(Real.log x)^3/3) := by ring
  rw [he]
  apply (abs_sub _ _).trans
  rw [abs_mul,abs_of_nonneg (Real.log_nonneg hx)]
  have hpos := mul_nonneg hD (sq_nonneg (Real.log x))
  nlinarith only [hm,hi,hpos]

end MissingLinnik

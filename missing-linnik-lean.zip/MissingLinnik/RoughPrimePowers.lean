import MissingLinnik.GeometricTail
import MissingLinnik.RoughBrunTitchmarsh

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

noncomputable def roughProperPrimePowerWeight (Y n : ℕ) : ℝ :=
  if IsRough Y n then properPrimePowerWeight n else 0

theorem roughProperPrimePowerWeight_nonneg (Y n : ℕ) : 0≤roughProperPrimePowerWeight Y n := by
  unfold roughProperPrimePowerWeight
  split_ifs <;> positivity [properPrimePowerWeight_nonneg n]

theorem roughProperPrimePowerWeight_le (Y n : ℕ) :
    roughProperPrimePowerWeight Y n≤properPrimePowerWeight n := by
  unfold roughProperPrimePowerWeight
  split_ifs
  · exact le_rfl
  · exact properPrimePowerWeight_nonneg n

theorem roughProperPrimePowerWeight_small (Y n : ℕ) (hn : n≤Y^2) :
    roughProperPrimePowerWeight Y n=0 := by
  by_cases hr : IsRough Y n
  · rw [roughProperPrimePowerWeight,if_pos hr]
    by_cases hp : n.Prime
    · simp [properPrimePowerWeight,hp]
    · rw [properPrimePowerWeight,if_neg hp]
      by_contra hΛ
      obtain ⟨p,k,hp',hk,hpk⟩ := vonMangoldt_ne_zero_iff.mp hΛ
      have hprime : p.Prime := Nat.prime_iff.mpr hp'
      have hk2 : 2≤k := by
        by_contra h
        have hk1 : k=1 := by omega
        rw [hk1,pow_one] at hpk
        exact hp (hpk ▸ hprime)
      have hdiv : p∣n := hpk ▸ dvd_pow_self p hk.ne'
      have hpY : Y<p := by
        by_contra h
        exact hr p (Nat.mem_primesLE.mpr ⟨le_of_not_gt h,hprime⟩) hdiv
      have hpow : p^2≤n := hpk ▸ Nat.pow_le_pow_right hprime.one_le hk2
      nlinarith
  · rw [roughProperPrimePowerWeight,if_neg hr]

theorem rough_proper_prime_power_mass (Y N : ℕ) (hY : 1≤Y) :
    (∑ n ∈ Ioc 0 N, roughProperPrimePowerWeight Y n/(n:ℝ))≤72/(Y:ℝ) := by
  have hh := weighted_tail_of_sqrt_growth (roughProperPrimePowerWeight Y) 18 (by norm_num)
    (roughProperPrimePowerWeight_nonneg Y) Y hY (roughProperPrimePowerWeight_small Y)
    (fun M => by
      apply (Finset.sum_le_sum (fun n _ => roughProperPrimePowerWeight_le Y n)).trans
      rw [sum_properPrimePowerWeight]
      exact psi_sub_theta_le_eighteen_sqrt M) N
  norm_num at hh ⊢
  exact hh

theorem rough_mangoldt_prime_split (Y n : ℕ) :
    roughRestriction Y vonMangoldt n =
      (if n.Prime ∧ Y<n then Real.log n else 0)+roughProperPrimePowerWeight Y n := by
  rw [roughRestriction_apply]
  unfold roughProperPrimePowerWeight properPrimePowerWeight
  have hpR (hp : n.Prime) : IsRough Y n ↔ Y<n := by
    constructor
    · intro hr
      by_contra h
      exact hr n (Nat.mem_primesLE.mpr ⟨le_of_not_gt h,hp⟩) (dvd_refl _)
    · intro hn p hpm hdiv
      have he : p=n := (hp.eq_one_or_self_of_dvd p hdiv).resolve_left (Nat.mem_primesLE.mp hpm).2.ne_one
      have := (Nat.mem_primesLE.mp hpm).1
      omega
  by_cases hp : n.Prime
  · rw [if_pos hp,vonMangoldt_apply_prime hp]
    by_cases hr : IsRough Y n
    · have hn := (hpR hp).mp hr
      rw [if_pos hr,if_pos hr]
      simp only [hp,hn,ite_true,true_and,add_zero]
    · have hn : ¬Y<n := fun h => hr ((hpR hp).mpr h)
      simp only [hr,hp,hn,ite_false,true_and,add_zero]
  · simp only [hp,false_and,ite_false,zero_add]

end MissingLinnik

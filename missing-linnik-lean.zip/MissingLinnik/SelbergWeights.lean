import MissingLinnik.UpperMobius

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped ArithmeticFunction.Moebius

noncomputable def sieveH (P R : ℕ) : ℝ :=
  ∑ r ∈ P.divisors, if r ≤ R then (1:ℝ)/r.totient else 0

noncomputable def sieveTarget (P R r : ℕ) : ℝ :=
  if r ≤ R then (μ r:ℝ)/((r.totient:ℝ)*sieveH P R) else 0

noncomputable def sieveWeight (P R : ℕ) : ℕ → ℝ :=
  upperMobiusWeight P (sieveTarget P R)

theorem sieveH_pos (P R : ℕ) (hP : P ≠ 0) (hR : 1 ≤ R) : 0 < sieveH P R := by
  have hh : (1:ℝ) ≤ sieveH P R := by
    have h1 : 1 ∈ P.divisors := Nat.mem_divisors.mpr ⟨one_dvd _,hP⟩
    have hs := Finset.single_le_sum (s := P.divisors)
      (f := fun r => if r ≤ R then (1:ℝ)/r.totient else 0)
      (fun r _ => by split_ifs <;> positivity) h1
    simpa only [sieveH, if_pos hR, Nat.totient_one, Nat.cast_one, div_one] using hs
  linarith

theorem sieveTarget_abs_sum (P R : ℕ) (hP : Squarefree P) (hR : 1 ≤ R) :
    (∑ r ∈ P.divisors, |sieveTarget P R r|) = 1 := by
  have hH := sieveH_pos P R hP.ne_zero hR
  calc
    _ = (∑ r ∈ P.divisors, if r ≤ R then (1:ℝ)/r.totient else 0)/sieveH P R := by
      simp only [div_eq_mul_inv, Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro r hr
      have hsf : Squarefree r := hP.squarefree_of_dvd (Nat.dvd_of_mem_divisors hr)
      have hm : |(μ r:ℝ)| = 1 := by exact_mod_cast ArithmeticFunction.abs_moebius_eq_one_of_squarefree hsf
      have hφ : (0:ℝ) ≤ r.totient := Nat.cast_nonneg _
      simp only [sieveTarget]
      split_ifs <;> simp [abs_div,abs_mul,hm,abs_of_nonneg hφ,abs_of_pos hH,div_mul_eq_div_div,div_eq_mul_inv,mul_comm]
    _ = 1 := div_self hH.ne'

theorem sieveTarget_moebius_sum (P R : ℕ) (hP : Squarefree P) (hR : 1 ≤ R) :
    (∑ r ∈ P.divisors, (μ r:ℝ)*sieveTarget P R r) = 1 := by
  have hH := sieveH_pos P R hP.ne_zero hR
  calc
    _ = (∑ r ∈ P.divisors, if r ≤ R then (1:ℝ)/r.totient else 0)/sieveH P R := by
      simp only [div_eq_mul_inv, Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro r hr
      have hsf : Squarefree r := hP.squarefree_of_dvd (Nat.dvd_of_mem_divisors hr)
      have hm : (μ r:ℝ)^2 = 1 := by exact_mod_cast ArithmeticFunction.moebius_sq_eq_one_of_squarefree hsf
      simp only [sieveTarget]
      split_ifs
      · rw [← mul_div_assoc, ← pow_two, hm, div_mul_eq_div_div]
        simp only [div_eq_mul_inv]
      · simp
    _ = 1 := div_self hH.ne'

theorem sieveTarget_quad_sum (P R : ℕ) (hP : Squarefree P) (hR : 1 ≤ R) :
    (∑ r ∈ P.divisors, (r.totient:ℝ)*(sieveTarget P R r)^2) = 1/sieveH P R := by
  have hH := sieveH_pos P R hP.ne_zero hR
  calc
    _ = (∑ r ∈ P.divisors, if r ≤ R then (1:ℝ)/r.totient else 0)/(sieveH P R)^2 := by
      simp only [div_eq_mul_inv, Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro r hr
      have hsf : Squarefree r := hP.squarefree_of_dvd (Nat.dvd_of_mem_divisors hr)
      have hm : (μ r:ℝ)^2 = 1 := by exact_mod_cast ArithmeticFunction.moebius_sq_eq_one_of_squarefree hsf
      have hφ : (r.totient:ℝ) ≠ 0 := by
        exact_mod_cast (Nat.totient_pos.mpr (Nat.pos_of_mem_divisors hr)).ne'
      simp only [sieveTarget]
      split_ifs
      · rw [div_pow,hm,mul_pow]
        field_simp
      · simp
    _ = 1/sieveH P R := by change sieveH P R / (sieveH P R)^2 = _; field_simp

theorem sieveWeight_one (P R : ℕ) (hP : Squarefree P) (hR : 1 ≤ R) :
    sieveWeight P R 1 = 1 := by
  rw [sieveWeight, upperMobiusWeight_one P hP.ne_zero, sieveTarget_moebius_sum P R hP hR]

theorem sieveWeight_abs_le (P R d : ℕ) (hP : Squarefree P) (hR : 1 ≤ R)
    (hd : d ∣ P) : |sieveWeight P R d| ≤ d := by
  have hh := upperMobiusWeight_abs_le P d hP.ne_zero hd (sieveTarget P R)
  rwa [sieveTarget_abs_sum P R hP hR,mul_one] at hh

theorem sieveWeight_support (P R d : ℕ) (hP : P ≠ 0) (hd : d ∣ P) (hRd : R < d) :
    sieveWeight P R d = 0 := by
  apply upperMobiusWeight_support P d R hP hd
  · intro r hr; simp [sieveTarget,not_le.mpr hr]
  · exact hRd

theorem sieveWeight_quad_sum (P R : ℕ) (hP : Squarefree P) (hR : 1 ≤ R) :
    (∑ d ∈ P.divisors, ∑ e ∈ P.divisors, sieveWeight P R d*sieveWeight P R e/(d.lcm e)) =
      1/sieveH P R := by
  rw [selberg_diagonalization P hP.ne_zero]
  have he : (∑ r ∈ P.divisors, (r.totient:ℝ)*
      (∑ d ∈ P.divisors, if r ∣ d then sieveWeight P R d/d else 0)^2) =
      ∑ r ∈ P.divisors, (r.totient:ℝ)*(sieveTarget P R r)^2 := by
    apply Finset.sum_congr rfl
    intro r hr
    rw [sieveWeight,upperMobiusWeight_transform P r hP.ne_zero (Nat.dvd_of_mem_divisors hr)]
  rw [he,sieveTarget_quad_sum P R hP hR]

/-- A deliberately crude bound suffices for a uniform rough-number sieve.
The manuscript's sharper coefficient bound improves R^4 below to R^2. -/
theorem sieveWeight_abs_sum_le (P R : ℕ) (hP : Squarefree P) (hR : 1 ≤ R) :
    (∑ d ∈ P.divisors, |sieveWeight P R d|) ≤ (R:ℝ)^2 := by
  let D := P.divisors.filter (fun d => d ≤ R)
  have he : (∑ d ∈ P.divisors, |sieveWeight P R d|) = ∑ d ∈ D, |sieveWeight P R d| := by
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro d hd hn
    have hgt : R < d := by
      simp only [D,Finset.mem_filter,hd,true_and,not_le] at hn
      exact hn
    rw [sieveWeight_support P R d hP.ne_zero (Nat.dvd_of_mem_divisors hd) hgt,abs_zero]
  have hsub : D ⊆ Finset.Icc 1 R := by
    intro d hd
    obtain ⟨hd,hle⟩ := Finset.mem_filter.mp hd
    exact Finset.mem_Icc.mpr ⟨Nat.pos_of_mem_divisors hd,hle⟩
  have hc : D.card ≤ R := by
    have hh := Finset.card_le_card hsub
    simpa using hh
  have hs : (∑ d ∈ D, |sieveWeight P R d|) ≤ (D.card:ℝ)*R := by
    calc
      _ ≤ ∑ _d ∈ D, (R:ℝ) := by
        apply Finset.sum_le_sum
        intro d hd
        obtain ⟨hd,hle⟩ := Finset.mem_filter.mp hd
        exact (sieveWeight_abs_le P R d hP hR (Nat.dvd_of_mem_divisors hd)).trans
          (by exact_mod_cast hle)
      _ = _ := by simp
  rw [he]
  have hcR : (D.card:ℝ) ≤ R := by exact_mod_cast hc
  nlinarith [mul_le_mul_of_nonneg_right hcR (Nat.cast_nonneg R : (0:ℝ) ≤ R)]

/-- The optimized Selberg main term for a progression, with a conservative
polynomial error from the coefficient bound above. -/
theorem selberg_progression_upper (N q b P R : ℕ) (hq : 0 < q)
    (hP : Squarefree P) (hcop : q.Coprime P) (hR : 1 ≤ R) :
    ((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => n.Coprime P)).card:ℝ) ≤
      (N:ℝ)/(q*sieveH P R) + (R:ℝ)^4 := by
  have hh := selberg_progression_square_bound N q b P hq
    (Nat.pos_of_ne_zero hP.ne_zero) hcop P.divisors
    (fun d hd => Nat.dvd_of_mem_divisors hd)
    (Nat.mem_divisors.mpr ⟨one_dvd _,hP.ne_zero⟩) (sieveWeight P R)
    (sieveWeight_one P R hP hR)
  rw [sieveWeight_quad_sum P R hP hR] at hh
  have hs := sieveWeight_abs_sum_le P R hP hR
  have hs0 : 0 ≤ ∑ d ∈ P.divisors, |sieveWeight P R d| :=
    Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  have he : (N:ℝ)/q*(1/sieveH P R) = (N:ℝ)/(q*sieveH P R) := by ring
  rw [he] at hh
  nlinarith [sq_nonneg ((R:ℝ)^2 - ∑ d ∈ P.divisors, |sieveWeight P R d|)]

end MissingLinnik

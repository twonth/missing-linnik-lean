import MissingLinnik.UnitWeightBounds

namespace MissingLinnik
open Finset ArithmeticFunction
open scoped Classical
set_option maxHeartbeats 1000000

theorem linnik_contradiction_at_cutoff (A : ℕ → ℕ) (hA : AntiConcentrationBounds A)
    (q k : ℕ) [NeZero q] (hq : 2≤q) (hk : 1≤k) (x : ℝ)
    (hx : ((q^(170*k):ℕ):ℝ)≤x) (hanti : (q:ℝ)^A 7≤x)
    (hlarge : (10:ℝ)^9≤Real.log x)
    (herror : (10:ℝ)^46*Real.log ((q^(170*k):ℕ):ℝ)≤Real.log x/1000000)
    (hBT : (10:ℝ)^42*Real.log ((q^(170*k):ℕ):ℝ)*
      (1+Real.log (Real.log x)-Real.log (Real.log ((q^(170*k):ℕ):ℝ)))≤Real.log x/1000000)
    (a : (ZMod q)ˣ)
    (hno : ∀ p : ℕ,p.Prime → (p:ℝ)≤x^3 → ¬Nat.ModEq q p (a:ZMod q).val) : False := by
  let Y := q^(170*k)
  let f := roughRestriction Y vonMangoldt
  let L := Real.log x
  let M := roughMangoldtMass Y x
  let W : (ZMod q)ˣ → ℝ := unitArithmeticMass f x
  let U : (ZMod q)ˣ → ℝ := unitArithmeticMass (logWeight f) x
  let V : (ZMod q)ˣ → (ZMod q)ˣ → ℝ := unitPairMass f x
  have hqY : q≤Y := (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2≤Y := hq.trans hqY
  have hx1 : 1≤x := (show (1:ℝ)≤Y by exact_mod_cast (show 1≤Y by omega)).trans hx
  have hL : 0<L := by dsimp [L]; linarith only [hlarge]
  have hyl := log_nat_ge_half Y hY
  have herr : Real.log (Y:ℝ)+157≤L/1000 := by
    change (10:ℝ)^46*Real.log (Y:ℝ)≤L/1000000 at herror
    nlinarith only [herror,hyl,hL]
  have hm := abs_le.mp (rough_mangoldt_mertens Y hY x hx1)
  have hf := roughRestriction_mangoldt_nonneg Y
  have hc := roughRestriction_support_coprime q Y (NeZero.pos q) hqY
  have hs : (10:ℝ)^42*Real.log (Y:ℝ)*L≤L^2/1000 := by
    have he : (10:ℝ)^42*Real.log (Y:ℝ)≤L/1000000 := by
      change (10:ℝ)^46*Real.log (Y:ℝ)≤L/1000000 at herror
      nlinarith only [herror,hyl]
    have hh := mul_le_mul_of_nonneg_right he hL.le
    nlinarith only [hh,sq_nonneg L]
  apply residue_contradiction_of_raw_bounds W U V a L M hL
  · change (999/1000:ℝ)*L≤roughMangoldtMass Y x
    linarith only [hm.1,herr]
  · change roughMangoldtMass Y x≤(1001/1000:ℝ)*L
    linarith only [hm.2,herr]
  · intro u; exact unitArithmeticMass_nonneg f hf x u
  · exact rough_unit_mass_total Y hqY x
  · intro u
    exact ⟨unitArithmeticMass_nonneg _ (logWeight_nonneg f hf) x u,unitArithmeticMass_log_le f hf x hx1 u⟩
  · intro u v
    exact ⟨unitPairMass_nonneg f hf x u v,unitPairMass_le f hc hf x (by linarith) u v⟩
  · intro u
    have hb := rough_brun_titchmarsh q k (u:ZMod q).val hq hk (ZMod.val_coe_unit_coprime u) x hx
    have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (by omega : 0<q)
    have hh := (le_div_iff₀ hφ).mp hb
    change W u*q.totient≤2*L+_ at hh
    nlinarith only [hh,hBT,hL]
  · have hh := rough_unit_cube_bound q k hq hk x hx a hno
    change _≤(9/2:ℝ)*(72+(10:ℝ)^46*Real.log (Y:ℝ))*L^2 at hh
    apply hh.trans
    have hcub : (9/2:ℝ)*(72+(10:ℝ)^46*Real.log (Y:ℝ))≤L/1000 := by
      change (10:ℝ)^46*Real.log (Y:ℝ)≤L/1000000 at herror
      change (10:ℝ)^9≤L at hlarge
      linarith only [herror,hlarge]
    have hb := mul_le_mul_of_nonneg_right hcub (sq_nonneg L)
    nlinarith only [hb]
  · have hh := rough_unit_two_lower q k hq hk x hx1
    change L^2-(10:ℝ)^42*Real.log (Y:ℝ)*L≤(∑ u,U u)+(∑ u,∑ v,V u v) at hh
    linarith only [hh,hs]
  · intro ψ hψ
    exact (rough_signed_two_bound q k hq hk x hx1 ψ hψ).trans hs
  · intro ψ hψ
    rw [show W=unitArithmeticMass (roughRestriction Y vonMangoldt) x from rfl,rough_negative_unit_mass Y hqY x ψ]
    apply (negative_rough_mass_bound A hA q Y hq hqY ψ hψ x hanti).trans
    have h72 : 72/(Y:ℝ)≤72 := div_le_self (by norm_num) (by exact_mod_cast (show 1≤Y by omega))
    change (10:ℝ)^9≤L at hlarge
    change (5/8:ℝ)*L+72/(Y:ℝ)≤(313/500:ℝ)*L
    linarith only [h72,hlarge]

end MissingLinnik



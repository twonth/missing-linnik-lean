import MissingLinnik.GeometricPartialSums

namespace MissingLinnik

open Finset ArithmeticFunction

noncomputable def properPrimePowerWeight (n : ℕ) : ℝ :=
  if n.Prime then 0 else vonMangoldt n

theorem properPrimePowerWeight_nonneg (n : ℕ) : 0 ≤ properPrimePowerWeight n := by
  unfold properPrimePowerWeight
  split_ifs <;> positivity [vonMangoldt_nonneg (n := n)]

theorem sum_properPrimePowerWeight (N : ℕ) :
    (∑ n ∈ Finset.Ioc 0 N, properPrimePowerWeight n) =
      Chebyshev.psi N-Chebyshev.theta N := by
  simp only [Chebyshev.psi,Chebyshev.theta,Nat.floor_natCast,Finset.sum_filter,← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hp : n.Prime
  · simp [properPrimePowerWeight,hp,vonMangoldt_apply_prime hp]
  · simp [properPrimePowerWeight,hp]

theorem psi_sub_theta_le_eighteen_sqrt (x : ℝ) :
    Chebyshev.psi x-Chebyshev.theta x ≤ 18*Real.sqrt x := by
  rcases le_total x 1 with hx | hx
  · rw [Chebyshev.theta_eq_zero_of_le_one hx,Chebyshev.psi_eq_zero_of_le_one hx,sub_self]
    positivity
  have hroot (n : ℕ) (hn : 2 ≤ n) :
      Chebyshev.psi (x^((1:ℝ)/n)) ≤ (Real.log 4+4)*Real.sqrt x := by
    grw [Chebyshev.psi_le_const_mul_self (by positivity),Real.sqrt_eq_rpow]
    gcongr
    norm_cast
  have hh := Chebyshev.psi_sub_theta_le_psi_add_psi_add_psi x
  have h2 := hroot 2 (by omega)
  have h3 := hroot 3 (by omega)
  have h5 := hroot 5 (by omega)
  have hl : Real.log (4:ℝ) ≤ 2 := by
    rw [show (4:ℝ)=2^2 by norm_num,Real.log_pow]
    norm_num
    linarith [Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)]
  have ht := mul_le_mul_of_nonneg_right hl (Real.sqrt_nonneg x)
  nlinarith only [hh,h2,h3,h5,ht]

theorem proper_prime_power_mass_le (N : ℕ) :
    (∑ n ∈ Finset.Ioc 0 N, properPrimePowerWeight n/(n:ℝ)) ≤ 72 := by
  apply (weighted_sum_of_sqrt_growth properPrimePowerWeight 18 (by norm_num)
    properPrimePowerWeight_nonneg (by simp [properPrimePowerWeight]) ?_ N).trans (by norm_num)
  intro M
  rw [sum_properPrimePowerWeight]
  exact psi_sub_theta_le_eighteen_sqrt M

theorem prime_weighted_mertens (N : ℕ) (hN : 1 ≤ N) :
    |(∑ p ∈ Nat.primesLE N, Real.log p/(p:ℝ))-Real.log N| ≤ 78 := by
  have hset : (Finset.Ioc 0 N).filter Nat.Prime = Nat.primesLE N := by
    ext p
    simp only [Finset.mem_filter,Finset.mem_Ioc,Nat.mem_primesLE]
    constructor
    · rintro ⟨⟨hp0,hpN⟩,hp⟩; exact ⟨hpN,hp⟩
    · rintro ⟨hpN,hp⟩; exact ⟨⟨hp.pos,hpN⟩,hp⟩
  have he : (∑ n ∈ Finset.Ioc 0 N, vonMangoldt n/(n:ℝ)) =
      (∑ p ∈ Nat.primesLE N, Real.log p/(p:ℝ))+
      ∑ n ∈ Finset.Ioc 0 N, properPrimePowerWeight n/(n:ℝ) := by
    rw [← hset,Finset.sum_filter,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro n hn
    by_cases hp : n.Prime
    · simp [properPrimePowerWeight,hp,vonMangoldt_apply_prime hp]
    · simp [properPrimePowerWeight,hp]
  have hh := abs_le.mp (mangoldt_weighted_mertens N hN)
  have hpp := proper_prime_power_mass_le N
  have hpp0 : 0 ≤ ∑ n ∈ Finset.Ioc 0 N, properPrimePowerWeight n/(n:ℝ) :=
    Finset.sum_nonneg (fun n hn => div_nonneg (properPrimePowerWeight_nonneg n) (Nat.cast_nonneg n))
  apply abs_le.mpr
  constructor <;> linarith

end MissingLinnik

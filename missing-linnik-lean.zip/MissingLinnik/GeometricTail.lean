import MissingLinnik.GeometricPartialSums

namespace MissingLinnik

open Finset

theorem weighted_tail_four_power (a : ℕ → ℝ) (C : ℝ) (hC : 0≤C) (R : ℕ) (hR : 1≤R)
    (ha : ∀ n, 0≤a n)
    (hsum : ∀ k : ℕ, (∑ n ∈ Ioc 0 (R^2*4^k), a n)≤C*(R:ℝ)*(2:ℝ)^k) (k : ℕ) :
    (∑ n ∈ Ioc (R^2) (R^2*4^k), a n/(n:ℝ))≤4*C/(R:ℝ)*(1-(2:ℝ)⁻¹^k) := by
  have hR0 : (0:ℝ)<R := by exact_mod_cast (show 0<R by omega)
  induction k with
  | zero => simp
  | succ k ih =>
    have hpow : R^2*4^k≤R^2*4^(k+1) := Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) (by omega))
    have hstart : R^2≤R^2*4^k := Nat.le_mul_of_pos_right _ (by positivity)
    have hsplit := Finset.sum_Ioc_consecutive (f := fun n : ℕ => a n/(n:ℝ)) hstart hpow
    have htail : (∑ n ∈ Ioc (R^2*4^k) (R^2*4^(k+1)), a n/(n:ℝ))≤
        (C*(R:ℝ)*(2:ℝ)^(k+1))/((R:ℝ)^2*(4:ℝ)^k) := by
      calc
        _ ≤ ∑ n ∈ Ioc (R^2*4^k) (R^2*4^(k+1)), a n/((R:ℝ)^2*(4:ℝ)^k) := by
          apply Finset.sum_le_sum
          intro n hn
          apply div_le_div_of_nonneg_left (ha n) (by positivity)
          exact_mod_cast (mem_Ioc.mp hn).1.le
        _ = (∑ n ∈ Ioc (R^2*4^k) (R^2*4^(k+1)), a n)/((R:ℝ)^2*(4:ℝ)^k) := by rw [Finset.sum_div]
        _ ≤ (∑ n ∈ Ioc 0 (R^2*4^(k+1)), a n)/((R:ℝ)^2*(4:ℝ)^k) := by
          apply div_le_div_of_nonneg_right _ (by positivity)
          apply Finset.sum_le_sum_of_subset_of_nonneg
          · intro n hn
            exact mem_Ioc.mpr ⟨lt_of_le_of_lt (Nat.zero_le _) (mem_Ioc.mp hn).1,(mem_Ioc.mp hn).2⟩
          · intro n hn hn'; exact ha n
        _ ≤ _ := div_le_div_of_nonneg_right (hsum (k+1)) (by positivity)
    have he : 4*C/(R:ℝ)*(1-(2:ℝ)⁻¹^k)+
        (C*(R:ℝ)*(2:ℝ)^(k+1))/((R:ℝ)^2*(4:ℝ)^k)=
        4*C/(R:ℝ)*(1-(2:ℝ)⁻¹^(k+1)) := by
      have h4 : (4:ℝ)^k=((2:ℝ)^k)^2 := by rw [pow_two,← mul_pow]; norm_num
      rw [h4]
      simp only [pow_succ,inv_pow]
      field_simp
      ring
    rw [← hsplit]
    exact (add_le_add ih htail).trans he.le

theorem weighted_tail_of_sqrt_growth (a : ℕ → ℝ) (C : ℝ) (hC : 0≤C)
    (ha : ∀ n, 0≤a n) (R : ℕ) (hR : 1≤R)
    (hsmall : ∀ n≤R^2, a n=0)
    (hsum : ∀ N : ℕ, (∑ n ∈ Ioc 0 N, a n)≤C*Real.sqrt N) (N : ℕ) :
    (∑ n ∈ Ioc 0 N, a n/(n:ℝ))≤4*C/(R:ℝ) := by
  have hs (k : ℕ) : (∑ n ∈ Ioc 0 (R^2*4^k), a n)≤C*(R:ℝ)*(2:ℝ)^k := by
    have hh := hsum (R^2*4^k)
    have he : Real.sqrt ((R^2*4^k:ℕ):ℝ)=(R:ℝ)*(2:ℝ)^k := by
      push_cast
      have h4 : (4:ℝ)^k=((2:ℝ)^k)^2 := by rw [pow_two,← mul_pow]; norm_num
      rw [h4,← mul_pow,Real.sqrt_sq_eq_abs,abs_of_nonneg (by positivity)]
    rw [he] at hh
    convert hh using 1 <;> ring
  have hN : N≤R^2*4^N := (Nat.lt_pow_self (by omega : 1<4)).le.trans
    (Nat.le_mul_of_pos_left _ (by positivity))
  have hh := weighted_tail_four_power a C hC R hR ha hs N
  have hzero : (∑ n ∈ Ioc 0 (R^2), a n/(n:ℝ))=0 := by
    apply Finset.sum_eq_zero
    intro n hn
    rw [hsmall n (mem_Ioc.mp hn).2,zero_div]
  have hsplit := Finset.sum_Ioc_consecutive (f := fun n : ℕ => a n/(n:ℝ))
    (Nat.zero_le (R^2)) (Nat.le_mul_of_pos_right (R^2) (by positivity : 0<4^N))
  rw [hzero,zero_add] at hsplit
  rw [hsplit] at hh
  have hsub : (∑ n ∈ Ioc 0 N, a n/(n:ℝ))≤∑ n ∈ Ioc 0 (R^2*4^N), a n/(n:ℝ) := by
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · intro n hn
      exact mem_Ioc.mpr ⟨(mem_Ioc.mp hn).1,(mem_Ioc.mp hn).2.trans hN⟩
    · intro n hn hn'; exact div_nonneg (ha n) (Nat.cast_nonneg _)
  have hp : 0≤(4*C/(R:ℝ))*(2:ℝ)⁻¹^N := by positivity
  nlinarith only [hh,hsub,hp]

end MissingLinnik

import MissingLinnik.RoughDiscrepancy

namespace MissingLinnik

open Finset

theorem logarithmic_scale_absorption (q k : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (F : ℝ) (hF : 0 ≤ F) (hFq : F ≤ q) :
    F*Real.log ((q^(170*k):ℕ):ℝ) ≤ (q:ℝ)^(85*k) := by
  have hq0 : (0:ℝ) < q := by exact_mod_cast (show 0<q by omega)
  have hlq : 0 ≤ Real.log (q:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤q by omega))
  have hlog : Real.log (q:ℝ) ≤ q := Real.log_le_self hq0.le
  have hkpow : k ≤ 2^k := (Nat.lt_pow_self (by omega : 1<2)).le
  have h170 : 170*k ≤ 2^(k+8) := by
    rw [pow_add]
    norm_num
    nlinarith
  have hpow : 170*k ≤ q^(k+8) := h170.trans (Nat.pow_le_pow_left hq _)
  have hpowR : (170:ℝ)*k ≤ (q:ℝ)^(k+8) := by exact_mod_cast hpow
  have hsmall : (q:ℝ)^(k+10) ≤ (q:ℝ)^(85*k) :=
    pow_le_pow_right₀ (by exact_mod_cast (show 1≤q by omega)) (by omega)
  have hmul := mul_le_mul_of_nonneg_right hpowR (sq_nonneg (q:ℝ))
  have he : (q:ℝ)^(k+8)*(q:ℝ)^2 = (q:ℝ)^(k+10) := by rw [← pow_add]
  rw [he] at hmul
  have hFlog := mul_le_mul hFq hlog hlq (Nat.cast_nonneg q)
  rw [Nat.cast_pow,Real.log_pow]
  push_cast
  have hscaled := mul_le_mul_of_nonneg_left hFlog (show 0 ≤ (170:ℝ)*k by positivity)
  nlinarith only [hscaled,hmul,hsmall]

/-- Uniform upper bound for q^(170k)-rough integers. The modulus m may
be q or 1, so this covers both the progression and unrestricted counts. -/
theorem rough_progression_upper_power (N q k m b : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hm : 0 < m) (hmq : m ≤ q) (hb : b.Coprime m) (hN : q^(170*k) ≤ N) :
    (roughProgressionCount N m b (q^(170*k)):ℝ) ≤
      (170*(1+16*Real.exp 15)+1)*(N:ℝ)/(m.totient*Real.log ((q^(170*k):ℕ):ℝ)) := by
  have hq1 : 1 ≤ q := by omega
  have hqk : q ≤ q^k := by simpa using Nat.pow_le_pow_right hq1 hk
  have hz : 2 ≤ q^k := hq.trans hqk
  have hzY : q^k ≤ q^(170*k) := Nat.pow_le_pow_right hq1 (by omega)
  have hsub : roughProgressionCount N m b (q^(170*k)) ≤ roughProgressionCount N m b (q^k) := by
    apply Finset.card_le_card
    intro n hn
    obtain ⟨hn,hrough⟩ := Finset.mem_filter.mp hn
    refine Finset.mem_filter.mpr ⟨hn,?_⟩
    intro p hp
    exact hrough p (Nat.mem_primesLE.mpr ⟨(Nat.mem_primesLE.mp hp).1.trans hzY,(Nat.mem_primesLE.mp hp).2⟩)
  have hs := (abs_le.mp (rough_numbers_sieve N m b (q^k) 17 hm hz (hmq.trans hqk) hb (by omega))).2
  change (roughProgressionCount N m b (q^k):ℝ)-_ ≤ _ at hs
  norm_num at hs
  have hφ : (0:ℝ) < m.totient := by exact_mod_cast Nat.totient_pos.mpr hm
  have hφq : (m.totient:ℝ) ≤ q := by exact_mod_cast (Nat.totient_le m).trans hmq
  have hlogq : 0 < Real.log (q:ℝ) := Real.log_pos (by exact_mod_cast (show 1<q by omega))
  have hlogz : 0 < Real.log ((q^k:ℕ):ℝ) := Real.log_pos (by exact_mod_cast (show 1<q^k by omega))
  have hlogY : 0 < Real.log ((q^(170*k):ℕ):ℝ) := Real.log_pos
    (by exact_mod_cast (show 1<q^(170*k) from lt_of_lt_of_le (by omega : 1<q^k) hzY))
  have hv := mul_le_mul_of_nonneg_left (sieveDensity_le_inv_log (q^k) hz)
    (show 0 ≤ (1+16*Real.exp 15)*((N:ℝ)/m.totient) by positivity)
  have hscale : Real.log ((q^(170*k):ℕ):ℝ) = 170*Real.log ((q^k:ℕ):ℝ) := by
    rw [Nat.cast_pow,Nat.cast_pow,Real.log_pow,Real.log_pow]
    push_cast
    ring
  have herr : (((q^k:ℕ):ℝ)^85) ≤ (N:ℝ)/(m.totient*Real.log ((q^(170*k):ℕ):ℝ)) := by
    apply (le_div_iff₀ (mul_pos hφ hlogY)).mpr
    have hbnd := logarithmic_scale_absorption q k hq hk m.totient hφ.le hφq
    have ht := mul_le_mul_of_nonneg_left hbnd (show 0 ≤ (q:ℝ)^(85*k) by positivity)
    have he : (q:ℝ)^(85*k)*(q:ℝ)^(85*k) = (q:ℝ)^(170*k) := by
      rw [← pow_add,show 85*k+85*k=170*k by omega]
    rw [he] at ht
    have hNR : (q:ℝ)^(170*k) ≤ N := by exact_mod_cast hN
    rw [Nat.cast_pow,← pow_mul,Nat.mul_comm k 85]
    nlinarith only [ht,hNR]
  have hv' : (1+16*Real.exp 15)*((N:ℝ)/m.totient)*(Real.log ((q^k:ℕ):ℝ))⁻¹ =
      (170*(1+16*Real.exp 15))*(N:ℝ)/(m.totient*Real.log ((q^(170*k):ℕ):ℝ)) := by
    rw [hscale]
    field_simp
  rw [hv'] at hv
  have hsubR : (roughProgressionCount N m b (q^(170*k)):ℝ) ≤ roughProgressionCount N m b (q^k) := by exact_mod_cast hsub
  have hv0 := sieveDensity_pos (Nat.primesLE (q^k)) (fun p hp => (Nat.mem_primesLE.mp hp).2)
  have he : (170*(1+16*Real.exp 15)+1)*(N:ℝ)/(m.totient*Real.log ((q^(170*k):ℕ):ℝ)) =
      (170*(1+16*Real.exp 15))*(N:ℝ)/(m.totient*Real.log ((q^(170*k):ℕ):ℝ))+
      (N:ℝ)/(m.totient*Real.log ((q^(170*k):ℕ):ℝ)) := by ring
  rw [he]
  push_cast at hs hv herr ⊢
  nlinarith only [hs,hv,herr,hsubR]

end MissingLinnik


import MissingLinnik.RoughUpperPower
import MissingLinnik.ExponentialSieveParameters

namespace MissingLinnik

noncomputable def roughUpperConstant : ℝ := 170*(1+16*Real.exp 15)+1
noncomputable def roughDiscrepancyConstant : ℝ :=
  (32*Real.exp 32+2)*Real.exp 1+2*roughUpperConstant*Real.exp 17

theorem roughProgressionCount_one (N z : ℕ) : roughProgressionCount N 1 0 z = roughCount N z := by
  simp only [roughProgressionCount,roughCount,Nat.ModEq,Nat.mod_one,Finset.filter_true]

/-- The uniform exponential discrepancy needed for the symmetry argument.
Restricting B to multiples of 170 is harmless when choosing a large exponent. -/
theorem uniform_rough_discrepancy (N q k b : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hb : b.Coprime q) (hN : q^(170*k) ≤ N) :
    |(roughProgressionCount N q b (q^(170*k)):ℝ)-(roughCount N (q^(170*k)):ℝ)/q.totient| ≤
      roughDiscrepancyConstant*((N:ℝ)/(q.totient*Real.log ((q^(170*k):ℕ):ℝ)))*
        Real.exp (-Real.log N/(10*Real.log ((q^(170*k):ℕ):ℝ))) := by
  let Y := q^(170*k)
  have hqY : q ≤ Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2 ≤ Y := hq.trans hqY
  have hN0 : (0:ℝ) < N := by exact_mod_cast (show 0<N by omega)
  have hlogY : 0 < Real.log (Y:ℝ) := Real.log_pos (by exact_mod_cast (show 1<Y by omega))
  have hφ : (0:ℝ) < q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have hC : 0 < roughUpperConstant := by unfold roughUpperConstant; positivity
  change |(roughProgressionCount N q b Y:ℝ)-(roughCount N Y:ℝ)/q.totient| ≤
    roughDiscrepancyConstant*((N:ℝ)/(q.totient*Real.log Y))*Real.exp (-Real.log N/(10*Real.log Y))
  by_cases hlarge : Y^170 ≤ N
  · have hs := rough_discrepancy_large N q b Y (by omega) hY hqY hb hlarge
    apply hs.trans
    have hcoef : (32*Real.exp 32+2)*Real.exp 1 ≤ roughDiscrepancyConstant := by
      unfold roughDiscrepancyConstant
      have ht : 0 ≤ 2*roughUpperConstant*Real.exp 17 := by positivity
      linarith
    exact mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right hcoef (by positivity)) (Real.exp_pos _).le
  · have hA := rough_progression_upper_power N q k q b hq hk (by omega) le_rfl hb hN
    have hAll := rough_progression_upper_power N q k 1 0 hq hk (by omega) (by omega) (by simp) hN
    rw [roughProgressionCount_one] at hAll
    simp only [Nat.totient_one,Nat.cast_one,one_mul] at hAll
    change (roughProgressionCount N q b Y:ℝ) ≤ roughUpperConstant*(N:ℝ)/(q.totient*Real.log Y) at hA
    change (roughCount N Y:ℝ) ≤ roughUpperConstant*(N:ℝ)/Real.log Y at hAll
    have hAll' := div_le_div_of_nonneg_right hAll hφ.le
    have he : (roughUpperConstant*(N:ℝ)/Real.log Y)/q.totient =
      roughUpperConstant*((N:ℝ)/(q.totient*Real.log Y)) := by ring
    rw [he] at hAll'
    have hAe : roughUpperConstant*(N:ℝ)/(q.totient*Real.log Y) =
      roughUpperConstant*((N:ℝ)/(q.totient*Real.log Y)) := by ring
    rw [hAe] at hA
    have habs : |(roughProgressionCount N q b Y:ℝ)-(roughCount N Y:ℝ)/q.totient| ≤
        2*roughUpperConstant*((N:ℝ)/(q.totient*Real.log Y)) := by
      have ha0 : (0:ℝ) ≤ roughProgressionCount N q b Y := Nat.cast_nonneg _
      have hb0 : (0:ℝ) ≤ (roughCount N Y:ℝ)/q.totient := by positivity
      apply abs_le.mpr
      constructor <;> nlinarith only [hA,hAll',ha0,hb0]
    have hlog := Real.log_le_log hN0
      (show (N:ℝ) ≤ (Y:ℝ)^170 by exact_mod_cast (Nat.le_of_lt (not_le.mp hlarge)))
    rw [Real.log_pow] at hlog
    norm_num at hlog
    have hr : Real.log (N:ℝ)/(10*Real.log Y) ≤ 17 := by
      apply (div_le_iff₀ (by positivity : 0<10*Real.log (Y:ℝ))).mpr
      linarith
    have hexp : 1 ≤ Real.exp 17*Real.exp (-Real.log N/(10*Real.log Y)) := by
      rw [← Real.exp_add]
      apply Real.one_le_exp
      simp only [neg_div]
      linarith
    have ht := mul_le_mul_of_nonneg_left hexp
      (show 0 ≤ 2*roughUpperConstant*((N:ℝ)/(q.totient*Real.log Y)) by positivity)
    have hcoef : 2*roughUpperConstant*Real.exp 17 ≤ roughDiscrepancyConstant := by
      unfold roughDiscrepancyConstant
      have ht : 0 ≤ (32*Real.exp 32+2)*Real.exp 1 := by positivity
      linarith
    have ht' := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right hcoef (show 0 ≤ (N:ℝ)/(q.totient*Real.log Y) by positivity))
      (Real.exp_pos (-Real.log N/(10*Real.log Y))).le
    nlinarith only [habs,ht,ht']

end MissingLinnik

import MissingLinnik.DeterminantEstimate

namespace MissingLinnik

/-- Chebyshev alone controls an omitted upper interval. This deliberately
coarse estimate avoids requiring Mertens in either anti-concentration route. -/
theorem prime_mass_tail_le (P : Finset ℕ) (X : ℕ) (Y : ℝ)
    (hY : 0 < Y) (hp : ∀ p ∈ P, p.Prime)
    (hlower : ∀ p ∈ P, Y ≤ p) (hupper : ∀ p ∈ P, p ≤ X) :
    (∑ p ∈ P, Real.log p / p) ≤ Real.log 4 * X / Y := by
  calc
    _ ≤ ∑ p ∈ P, Real.log p / Y := by
      apply Finset.sum_le_sum
      intro p h
      exact div_le_div_of_nonneg_left (Real.log_nonneg (by exact_mod_cast (hp p h).one_le))
        hY (hlower p h)
    _ = (∑ p ∈ P, Real.log p) / Y := by rw [Finset.sum_div]
    _ ≤ _ := div_le_div_of_nonneg_right (prime_log_sum_le P X hp hupper) hY.le

theorem prime_mass_small_le (P : Finset ℕ) (X : ℕ)
    (hp : ∀ p ∈ P, p.Prime) (hupper : ∀ p ∈ P, p ≤ X) :
    (∑ p ∈ P, Real.log p / p) ≤ Real.log 4 * X := by
  simpa using prime_mass_tail_le P X 1 (by norm_num) hp
    (fun p h => by exact_mod_cast (hp p h).one_le) hupper

theorem logarithmic_parameter_bound (k L Q b M : ℝ) (hk : 8 ≤ k)
    (hL : 0 ≤ L) (hQ : 0 ≤ Q)
    (hb : b ≤ L/2 + Q/2 + Real.log 8)
    (hM : M ≤ (1+5/k)*b + (5/k)*L + (3/k)*Real.log 4) :
    M ≤ (1/2+8/k)*L + Q + 8 := by
  have hk0 : 0 < k := by linarith
  have ht0 : 0 ≤ k⁻¹ := inv_nonneg.mpr hk0.le
  have ht : k⁻¹ ≤ 1/8 := by
    simpa using (one_div_le_one_div_of_le (by norm_num : (0:ℝ)<8) hk)
  have hl2 : Real.log (2:ℝ) ≤ 1 := by
    have hh := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    linarith
  have hl4 : Real.log (4:ℝ) ≤ 2 := by
    rw [show (4:ℝ)=2^2 by norm_num, Real.log_pow]
    norm_num
    linarith
  have hl8 : Real.log (8:ℝ) ≤ 3 := by
    rw [show (8:ℝ)=2^3 by norm_num, Real.log_pow]
    norm_num
    linarith
  have hb' := mul_le_mul_of_nonneg_left hb (show 0 ≤ 1+5/k by positivity)
  have he8 := mul_le_mul_of_nonneg_left hl8 (show 0 ≤ 1+5/k by positivity)
  have he4 := mul_le_mul_of_nonneg_left hl4 (show 0 ≤ 3/k by positivity)
  have hq := mul_nonneg (show 0 ≤ 1/2 - (5/2)*k⁻¹ by linarith) hQ
  have hl := mul_nonneg ht0 hL
  simp only [div_eq_mul_inv] at hM hb' he8 he4 ⊢
  nlinarith

end MissingLinnik

import MissingLinnik.EffectiveQuadraticBounds

namespace MissingLinnik

/-- A stronger arithmetic representative condition. The completed proofs use
the weaker condition below, supplied by the completed Montgomery--Vaughan
classification and reciprocity bridge. An independent Gauss-sum bridge is retained. -/
def HasQuadraticRepresentative {f : ℕ} (ψ : DirichletCharacter ℝ f) : Prop :=
  ∃ d : ℤ, (∀ n : ℤ, d ≠ n*n) ∧ d.natAbs ≤ f ∧
    ∀ (p : ℕ) (hp : p.Prime), p ≠ 2 → ψ (p:ZMod f) = -1 →
      @legendreSym p ⟨hp⟩ d = -1

/-- Nonsquareness need only be established when the prime sum is nonempty. -/
def HasWeakQuadraticRepresentative {f : ℕ} (ψ : DirichletCharacter ℝ f) : Prop :=
  ∃ d : ℤ, d.natAbs ≤ f ∧
    ∀ (p : ℕ) (hp : p.Prime), p ≠ 2 → ψ (p:ZMod f) = -1 →
      @legendreSym p ⟨hp⟩ d = -1

def bridgeExponent (A : ℕ → ℕ) (j : ℕ) : ℕ := A (2*j+1)+2*(j+1)

theorem bridgeExponent_computable (A : ℕ → ℕ) (hA : Computable A) :
    Computable (bridgeExponent A) := by
  have hn : Primrec (fun j : ℕ => 2*j+1) := Primrec.nat_add.comp
    (Primrec.nat_mul.comp (Primrec.const 2) Primrec.id) (Primrec.const 1)
  have ht : Primrec (fun j : ℕ => 2*(j+1)) := Primrec.nat_mul.comp (Primrec.const 2)
    (Primrec.nat_add.comp Primrec.id (Primrec.const 1))
  exact Primrec.nat_add.to_comp.comp (hA.comp hn.to_comp) ht.to_comp

/-- All remaining analytic bookkeeping in passing from quadratic inert-prime
bounds to the character statement, including the prime 2. The character
classification hypothesis is explicit and is not discharged by this theorem. -/
theorem antiConcentration_of_weak_quadratic_representatives
    (A : ℕ → ℕ) (hA : QuadraticPrimeBounds A)
    (hrep : ∀ (f : ℕ), 1 ≤ f → ∀ (ψ : DirichletCharacter ℝ f),
      ψ.IsPrimitive → ψ ≠ 1 → HasWeakQuadraticRepresentative ψ) :
    AntiConcentrationBounds (bridgeExponent A) := by
  classical
  intro j f hf ψ hprim hnon x hx
  have hf2 : 2 ≤ f := by
    have hfne : f ≠ 1 := fun he => hnon (DirichletCharacter.level_one' ψ he)
    omega
  have hfr : (2:ℝ) ≤ f := by exact_mod_cast hf2
  have hf1 : (1:ℝ) ≤ f := by linarith
  have hx1 : 1 ≤ x := (one_le_pow₀ hf1).trans hx
  have hxA : (f:ℝ)^A (2*j+1) ≤ x :=
    (pow_le_pow_right₀ hf1 (show A (2*j+1) ≤ bridgeExponent A j by unfold bridgeExponent; omega)).trans hx
  obtain ⟨d,hdq,hchar⟩ := hrep f hf ψ hprim hnon
  let T := (Finset.range (Nat.floor x+1)).filter
    (fun p => Nat.Prime p ∧ ψ (p:ZMod f) = -1)
  let P := T.erase 2
  have hprime : ∀ p ∈ P, p.Prime := by
    intro p hp
    exact (Finset.mem_filter.mp (Finset.mem_erase.mp hp).2).2.1
  have hupper : ∀ p ∈ P, (p:ℝ) ≤ x := by
    intro p hp
    have hh := Finset.mem_range.mp (Finset.mem_filter.mp (Finset.mem_erase.mp hp).2).1
    exact (show (p:ℝ) ≤ ⌊x⌋₊ by exact_mod_cast (show p ≤ ⌊x⌋₊ by omega)).trans
      (Nat.floor_le (by linarith))
  have hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1 := by
    intro p hp
    exact hchar p (hprime p hp) (Finset.mem_erase.mp hp).1
      (Finset.mem_filter.mp (Finset.mem_erase.mp hp).2).2.2
  have hmass : (∑ p ∈ P, Real.log p/p) ≤
      (1/2+1/(((2*j+1:ℕ):ℝ)+1))*Real.log x := by
    by_cases hP : P.Nonempty
    · obtain ⟨p,hp⟩ := hP
      letI : Fact p.Prime := ⟨hprime p hp⟩
      letI : Fact (¬IsSquare (d:ZMod p)) := ⟨(legendreSym.eq_neg_one_iff p).mp (hinert p hp)⟩
      exact quadratic_bounds_of_natAbs A hA (2*j+1) f x hfr hxA d
        (VanDijk.nonsquare_integer_of_inert p d) (by exact_mod_cast hdq) P hprime hupper hinert
    · rw [Finset.not_nonempty_iff_eq_empty.mp hP,Finset.sum_empty]
      have := Real.log_nonneg hx1
      positivity
  have hlog2 : Real.log (2:ℝ) ≤ 1 := by
    have hh := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    linarith
  have hsplit : negativePrimeMass ψ x ≤ (∑ p ∈ P, Real.log p/p)+1/2 := by
    change (∑ p ∈ T, Real.log p/p) ≤ _
    by_cases h2 : 2 ∈ T
    · have he := Finset.sum_erase_add T (fun p : ℕ => Real.log p/p) h2
      dsimp only [P]
      norm_num at he
      linarith
    · simp only [P,Finset.erase_eq_of_notMem h2]
      linarith
  have hlogf : 1/2 ≤ Real.log (f:ℝ) := by
    have hh := Real.one_sub_inv_le_log_of_pos (by norm_num : (0:ℝ)<2)
    have hm := Real.log_le_log (by norm_num : (0:ℝ)<2) hfr
    norm_num at hh
    linarith
  have hlogx := Real.log_le_log (pow_pos (by linarith : (0:ℝ)<f) _) hx
  rw [Real.log_pow] at hlogx
  have he : (2*(j+1):ℝ) ≤ bridgeExponent A j := by
    exact_mod_cast (show 2*(j+1) ≤ bridgeExponent A j by unfold bridgeExponent; omega)
  have hprod := mul_le_mul_of_nonneg_right he (show 0 ≤ Real.log (f:ℝ) by linarith)
  have ht : 0 < (j:ℝ)+1 := by positivity
  have hl : (j:ℝ)+1 ≤ Real.log x := by nlinarith
  push_cast at hmass
  have herr : (1/2+1/(2*(j:ℝ)+1+1))*Real.log x+1/2 ≤
      (1/2+1/((j:ℝ)+1))*Real.log x := by
    apply (mul_le_mul_iff_right₀ ht).mp
    field_simp
    nlinarith only [hl]
  linarith

theorem antiConcentration_of_quadratic_representatives
    (A : ℕ → ℕ) (hA : QuadraticPrimeBounds A)
    (hrep : ∀ (f : ℕ), 1 ≤ f → ∀ (ψ : DirichletCharacter ℝ f),
      ψ.IsPrimitive → ψ ≠ 1 → HasQuadraticRepresentative ψ) :
    AntiConcentrationBounds (bridgeExponent A) := by
  apply antiConcentration_of_weak_quadratic_representatives A hA
  intro f hf ψ hprim hnon
  obtain ⟨d,_hd,hdq,hchar⟩ := hrep f hf ψ hprim hnon
  exact ⟨d,hdq,hchar⟩

end MissingLinnik

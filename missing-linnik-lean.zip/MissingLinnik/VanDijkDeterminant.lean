import MissingLinnik.VanDijkMinor
import MissingLinnik.DeterminantHeights
import MissingLinnik.QuadraticDeterminantBound

namespace MissingLinnik.VanDijk

theorem nonsquare_integer_of_inert (p : ℕ) (d : ℤ)
    [Fact (¬ IsSquare (d : ZMod p))] : ∀ n : ℤ, d ≠ n * n := by
  intro n hn
  apply (Fact.out : ¬ IsSquare (d : ZMod p))
  refine ⟨(n : ZMod p), ?_⟩
  simpa only [Int.cast_mul] using congrArg (fun t : ℤ => (t : ZMod p)) hn

theorem integerGrid_embedding_bound (M : ℕ) (d : ℤ) (a : ℂ) (ha : a ^ 2 = d)
    (i : Fin M × Fin M) :
    ‖quadraticComplexEmbedding d a ha (integerGrid M d i)‖ ≤ (M : ℝ) * (1 + ‖a‖) := by
  apply quadraticComplexEmbedding_bound d a ha _ M ‖a‖ (by positivity)
  · change |(i.1.val : ℝ)| ≤ (M : ℝ)
    rw [abs_of_nonneg (Nat.cast_nonneg _)]
    exact_mod_cast Nat.le_of_lt i.1.isLt
  · change |(i.2.val : ℝ)| ≤ (M : ℝ)
    rw [abs_of_nonneg (Nat.cast_nonneg _)]
    exact_mod_cast Nat.le_of_lt i.2.isLt
  · exact le_rfl

/-- The finite determinant at the heart of van Dijk's argument, including
nonvanishing, every usable inert-prime divisibility, and the archimedean bound.
No statement about zeros of L-functions is assumed. -/
theorem exists_positive_determinant_norm
    (p₀ M R S : ℕ) (d : ℤ) [Fact p₀.Prime] [Fact (¬ IsSquare (d : ZMod p₀))]
    (hp₂ : p₀ ≠ 2) (hd : legendreSym p₀ d = -1)
    (hM : M ≤ p₀) (hcard : p₀ ≤ M * M) (hR : R ≤ p₀)
    (hRpos : 1 ≤ R) (hS : 0 < S) (hSp : S < p₀)
    (a : ℂ) (ha : a ^ 2 = d) (B : ℝ) (hB : 1 ≤ B)
    (hMB : (M : ℝ) * (1 + ‖a‖) ≤ B) :
    ∃ D : ℕ, 0 < D ∧
      (∀ (p m T : ℕ) (hp : p.Prime), let _ : Fact p.Prime := ⟨hp⟩;
        p ≠ 2 → legendreSym p d = -1 →
        R ≤ p * m → T + m ≤ S →
        p ^ (2 * (T * ∑ r ∈ Finset.range R, r / p)) ∣ D) ∧
      Real.log (D : ℝ) ≤ 2 * Real.log ((R * S).factorial : ℝ) +
        2 * ∑ i : Fin R × Fin S, ((S : ℝ) * Real.log R +
          ((i.1.val + i.2.val : ℕ) : ℝ) * Real.log B) := by
  classical
  obtain ⟨f, hf⟩ := exists_integer_minor p₀ M R S d hp₂ hd hM hcard hR hS hSp
  let z : (Fin R × Fin S) → Zsqrtd d := fun c => integerGrid M d (f c).1
  let j : (Fin R × Fin S) → ℕ := fun c => (f c).2.val
  let Δ := (Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c) i.1.val i.2.val)).det
  have hΔ : Δ ≠ 0 := by
    intro hh
    apply hf
    change quadraticReduction p₀ d Δ = 0
    rw [hh, map_zero]
  have hD : 0 < Δ.norm.natAbs :=
    quadratic_norm_natAbs_pos (nonsquare_integer_of_inert p₀ d) Δ hΔ
  refine ⟨Δ.norm.natAbs, hD, ?_, ?_⟩
  · intro p m T hp hpFact hp2 hdp hRp hT
    letI : Fact p.Prime := ⟨hp⟩
    have hv := vanDijk_norm_dvd p m R S T d hp2 hdp hRp hT z j
    have habs := Int.natAbs_dvd_natAbs.mpr hv
    simpa only [Int.natAbs_pow, Int.natAbs_natCast] using habs
  · apply log_norm_jet_det_le R S d a ha z j B hRpos hB _ _ _ hD
    · intro c; exact Nat.le_of_lt (f c).2.isLt
    · intro c
      exact (integerGrid_embedding_bound M d a ha (f c).1).trans hMB
    · intro c
      have hh := integerGrid_embedding_bound M d (-a) (by simpa using ha) (f c).1
      simp only [norm_neg] at hh
      exact hh.trans hMB

end MissingLinnik.VanDijk



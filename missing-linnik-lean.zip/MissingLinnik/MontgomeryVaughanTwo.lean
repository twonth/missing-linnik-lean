import MissingLinnik.MontgomeryVaughanLocal
import Mathlib.Tactic.FinCases

namespace MissingLinnik

set_option backward.isDefEq.respectTransparency false

-- Closed finite-ring facts used to normalize the character table.
@[simp] private theorem eight_ne_0_1 : (0 : ZMod 8) ≠ 1 := by decide
@[simp] private theorem eight_ne_0_2 : (0 : ZMod 8) ≠ 2 := by decide
@[simp] private theorem eight_ne_0_3 : (0 : ZMod 8) ≠ 3 := by decide
@[simp] private theorem eight_ne_0_4 : (0 : ZMod 8) ≠ 4 := by decide
@[simp] private theorem eight_ne_0_5 : (0 : ZMod 8) ≠ 5 := by decide
@[simp] private theorem eight_ne_0_6 : (0 : ZMod 8) ≠ 6 := by decide
@[simp] private theorem eight_ne_0_7 : (0 : ZMod 8) ≠ 7 := by decide
@[simp] private theorem eight_ne_1_0 : (1 : ZMod 8) ≠ 0 := by decide
@[simp] private theorem eight_ne_1_2 : (1 : ZMod 8) ≠ 2 := by decide
@[simp] private theorem eight_ne_1_3 : (1 : ZMod 8) ≠ 3 := by decide
@[simp] private theorem eight_ne_1_4 : (1 : ZMod 8) ≠ 4 := by decide
@[simp] private theorem eight_ne_1_5 : (1 : ZMod 8) ≠ 5 := by decide
@[simp] private theorem eight_ne_1_6 : (1 : ZMod 8) ≠ 6 := by decide
@[simp] private theorem eight_ne_1_7 : (1 : ZMod 8) ≠ 7 := by decide
@[simp] private theorem eight_ne_2_0 : (2 : ZMod 8) ≠ 0 := by decide
@[simp] private theorem eight_ne_2_1 : (2 : ZMod 8) ≠ 1 := by decide
@[simp] private theorem eight_ne_2_3 : (2 : ZMod 8) ≠ 3 := by decide
@[simp] private theorem eight_ne_2_4 : (2 : ZMod 8) ≠ 4 := by decide
@[simp] private theorem eight_ne_2_5 : (2 : ZMod 8) ≠ 5 := by decide
@[simp] private theorem eight_ne_2_6 : (2 : ZMod 8) ≠ 6 := by decide
@[simp] private theorem eight_ne_2_7 : (2 : ZMod 8) ≠ 7 := by decide
@[simp] private theorem eight_ne_3_0 : (3 : ZMod 8) ≠ 0 := by decide
@[simp] private theorem eight_ne_3_1 : (3 : ZMod 8) ≠ 1 := by decide
@[simp] private theorem eight_ne_3_2 : (3 : ZMod 8) ≠ 2 := by decide
@[simp] private theorem eight_ne_3_4 : (3 : ZMod 8) ≠ 4 := by decide
@[simp] private theorem eight_ne_3_5 : (3 : ZMod 8) ≠ 5 := by decide
@[simp] private theorem eight_ne_3_6 : (3 : ZMod 8) ≠ 6 := by decide
@[simp] private theorem eight_ne_3_7 : (3 : ZMod 8) ≠ 7 := by decide
@[simp] private theorem eight_ne_4_0 : (4 : ZMod 8) ≠ 0 := by decide
@[simp] private theorem eight_ne_4_1 : (4 : ZMod 8) ≠ 1 := by decide
@[simp] private theorem eight_ne_4_2 : (4 : ZMod 8) ≠ 2 := by decide
@[simp] private theorem eight_ne_4_3 : (4 : ZMod 8) ≠ 3 := by decide
@[simp] private theorem eight_ne_4_5 : (4 : ZMod 8) ≠ 5 := by decide
@[simp] private theorem eight_ne_4_6 : (4 : ZMod 8) ≠ 6 := by decide
@[simp] private theorem eight_ne_4_7 : (4 : ZMod 8) ≠ 7 := by decide
@[simp] private theorem eight_ne_5_0 : (5 : ZMod 8) ≠ 0 := by decide
@[simp] private theorem eight_ne_5_1 : (5 : ZMod 8) ≠ 1 := by decide
@[simp] private theorem eight_ne_5_2 : (5 : ZMod 8) ≠ 2 := by decide
@[simp] private theorem eight_ne_5_3 : (5 : ZMod 8) ≠ 3 := by decide
@[simp] private theorem eight_ne_5_4 : (5 : ZMod 8) ≠ 4 := by decide
@[simp] private theorem eight_ne_5_6 : (5 : ZMod 8) ≠ 6 := by decide
@[simp] private theorem eight_ne_5_7 : (5 : ZMod 8) ≠ 7 := by decide
@[simp] private theorem eight_ne_6_0 : (6 : ZMod 8) ≠ 0 := by decide
@[simp] private theorem eight_ne_6_1 : (6 : ZMod 8) ≠ 1 := by decide
@[simp] private theorem eight_ne_6_2 : (6 : ZMod 8) ≠ 2 := by decide
@[simp] private theorem eight_ne_6_3 : (6 : ZMod 8) ≠ 3 := by decide
@[simp] private theorem eight_ne_6_4 : (6 : ZMod 8) ≠ 4 := by decide
@[simp] private theorem eight_ne_6_5 : (6 : ZMod 8) ≠ 5 := by decide
@[simp] private theorem eight_ne_6_7 : (6 : ZMod 8) ≠ 7 := by decide
@[simp] private theorem eight_ne_7_0 : (7 : ZMod 8) ≠ 0 := by decide
@[simp] private theorem eight_ne_7_1 : (7 : ZMod 8) ≠ 1 := by decide
@[simp] private theorem eight_ne_7_2 : (7 : ZMod 8) ≠ 2 := by decide
@[simp] private theorem eight_ne_7_3 : (7 : ZMod 8) ≠ 3 := by decide
@[simp] private theorem eight_ne_7_4 : (7 : ZMod 8) ≠ 4 := by decide
@[simp] private theorem eight_ne_7_5 : (7 : ZMod 8) ≠ 5 := by decide
@[simp] private theorem eight_ne_7_6 : (7 : ZMod 8) ≠ 6 := by decide
@[simp] private theorem eight_unit_0 : ¬ IsUnit (0 : ZMod 8) := by decide
@[simp] private theorem eight_cast_0 : (ZMod.cast (0 : ZMod 8) : ZMod 4) = 0 := by decide
@[simp] private theorem eight_one_0 : (1 : DirichletCharacter ℝ 8) (0 : ZMod 8) = 0 := by
  exact MulChar.map_nonunit _ eight_unit_0
@[simp] private theorem eight_unit_1 : IsUnit (1 : ZMod 8) := by decide
@[simp] private theorem eight_cast_1 : (ZMod.cast (1 : ZMod 8) : ZMod 4) = 1 := by decide
@[simp] private theorem eight_one_1 : (1 : DirichletCharacter ℝ 8) (1 : ZMod 8) = 1 := by
  exact MulChar.one_apply eight_unit_1
@[simp] private theorem eight_unit_2 : ¬ IsUnit (2 : ZMod 8) := by decide
@[simp] private theorem eight_cast_2 : (ZMod.cast (2 : ZMod 8) : ZMod 4) = 2 := by decide
@[simp] private theorem eight_one_2 : (1 : DirichletCharacter ℝ 8) (2 : ZMod 8) = 0 := by
  exact MulChar.map_nonunit _ eight_unit_2
@[simp] private theorem eight_unit_3 : IsUnit (3 : ZMod 8) := by decide
@[simp] private theorem eight_cast_3 : (ZMod.cast (3 : ZMod 8) : ZMod 4) = 3 := by decide
@[simp] private theorem eight_one_3 : (1 : DirichletCharacter ℝ 8) (3 : ZMod 8) = 1 := by
  exact MulChar.one_apply eight_unit_3
@[simp] private theorem eight_unit_4 : ¬ IsUnit (4 : ZMod 8) := by decide
@[simp] private theorem eight_cast_4 : (ZMod.cast (4 : ZMod 8) : ZMod 4) = 0 := by decide
@[simp] private theorem eight_one_4 : (1 : DirichletCharacter ℝ 8) (4 : ZMod 8) = 0 := by
  exact MulChar.map_nonunit _ eight_unit_4
@[simp] private theorem eight_unit_5 : IsUnit (5 : ZMod 8) := by decide
@[simp] private theorem eight_cast_5 : (ZMod.cast (5 : ZMod 8) : ZMod 4) = 1 := by decide
@[simp] private theorem eight_one_5 : (1 : DirichletCharacter ℝ 8) (5 : ZMod 8) = 1 := by
  exact MulChar.one_apply eight_unit_5
@[simp] private theorem eight_unit_6 : ¬ IsUnit (6 : ZMod 8) := by decide
@[simp] private theorem eight_cast_6 : (ZMod.cast (6 : ZMod 8) : ZMod 4) = 2 := by decide
@[simp] private theorem eight_one_6 : (1 : DirichletCharacter ℝ 8) (6 : ZMod 8) = 0 := by
  exact MulChar.map_nonunit _ eight_unit_6
@[simp] private theorem eight_unit_7 : IsUnit (7 : ZMod 8) := by decide
@[simp] private theorem eight_cast_7 : (ZMod.cast (7 : ZMod 8) : ZMod 4) = 3 := by decide
@[simp] private theorem eight_one_7 : (1 : DirichletCharacter ℝ 8) (7 : ZMod 8) = 1 := by
  exact MulChar.one_apply eight_unit_7


noncomputable def realFourCharacter : DirichletCharacter ℝ 4 :=
  ZMod.χ₄.ringHomComp (Int.castRingHom ℝ)

noncomputable def realEightCharacter : DirichletCharacter ℝ 8 :=
  ZMod.χ₈.ringHomComp (Int.castRingHom ℝ)

noncomputable def realEightCharacter' : DirichletCharacter ℝ 8 :=
  ZMod.χ₈'.ringHomComp (Int.castRingHom ℝ)

theorem real_character_four (ψ : DirichletCharacter ℝ 4) (hψ : ψ ≠ 1) :
    ψ = realFourCharacter := by
  letI := ZMod.isCyclic_units_four
  apply real_character_unique_of_cyclic ψ _ hψ
  intro he
  have hh := congrArg (fun χ : DirichletCharacter ℝ 4 => χ (3 : ZMod 4)) he
  norm_num [realFourCharacter, MulChar.ringHomComp_apply, ZMod.χ₄, MulChar.one_apply (by decide : IsUnit (3 : ZMod 4))] at hh

/-- The elementary four-value table for real characters modulo 8. -/
theorem real_character_eight_table (ψ : DirichletCharacter ℝ 8) :
    ∀ x : ZMod 8, ψ x =
      if x = 1 then 1 else if x = 3 then ψ 3 else
      if x = 5 then ψ 5 else if x = 7 then ψ 3 * ψ 5 else 0 := by
  have h7 : ψ (7 : ZMod 8) = ψ 3 * ψ 5 := by
    rw [← map_mul]
    rfl
  intro x
  fin_cases x <;> norm_num [h7, MulChar.map_nonunit ψ (by decide : ¬ IsUnit (0 : ZMod 8)),
    MulChar.map_nonunit ψ (by decide : ¬ IsUnit (2 : ZMod 8)),
    MulChar.map_nonunit ψ (by decide : ¬ IsUnit (4 : ZMod 8)),
    MulChar.map_nonunit ψ (by decide : ¬ IsUnit (6 : ZMod 8))]

theorem real_character_eight_cases (ψ : DirichletCharacter ℝ 8) :
    ψ = 1 ∨ ψ = DirichletCharacter.changeLevel (by decide : 4 ∣ 8) realFourCharacter ∨
    ψ = realEightCharacter ∨ ψ = realEightCharacter' := by
  have h3 : ψ (3 : ZMod 8) = 1 ∨ ψ 3 = -1 := by
    rcases real_character_quadratic ψ (3 : ZMod 8) with hz | hp | hn
    · exact ((MulChar.apply_ne_zero_iff.mpr (by decide : IsUnit (3 : ZMod 8))) hz).elim
    · exact Or.inl hp
    · exact Or.inr hn
  have h5 : ψ (5 : ZMod 8) = 1 ∨ ψ 5 = -1 := by
    rcases real_character_quadratic ψ (5 : ZMod 8) with hz | hp | hn
    · exact ((MulChar.apply_ne_zero_iff.mpr (by decide : IsUnit (5 : ZMod 8))) hz).elim
    · exact Or.inl hp
    · exact Or.inr hn
  rcases h3 with h3 | h3 <;> rcases h5 with h5 | h5
  · left
    apply DFunLike.ext
    intro x
    rw [real_character_eight_table]
    fin_cases x <;> norm_num [h3,h5]
  · right; right; right
    apply DFunLike.ext
    intro x
    rw [real_character_eight_table]
    fin_cases x <;> norm_num [h3,h5,realEightCharacter',MulChar.ringHomComp_apply,ZMod.χ₈']
  · right; left
    apply MulChar.ext
    intro u
    rw [DirichletCharacter.changeLevel_eq_cast_of_dvd]
    have hu := u.isUnit
    generalize he : (u : ZMod 8) = x at *
    rw [real_character_eight_table]
    fin_cases x <;> norm_num [h3,h5,realFourCharacter,MulChar.ringHomComp_apply,ZMod.χ₄] at *
  · right; right; left
    apply DFunLike.ext
    intro x
    rw [real_character_eight_table]
    fin_cases x <;> norm_num [h3,h5,realEightCharacter,MulChar.ringHomComp_apply,ZMod.χ₈]

/-- The two primitive real characters at conductor 8. -/
theorem primitive_real_character_eight (ψ : DirichletCharacter ℝ 8)
    (hψ : ψ ≠ 1) (hprim : ψ.IsPrimitive) :
    ψ = realEightCharacter ∨ ψ = realEightCharacter' := by
  rcases real_character_eight_cases ψ with hp | hfour | h8 | h8'
  · exact (hψ hp).elim
  · have hf : ψ.FactorsThrough 4 := ⟨by decide, realFourCharacter, hfour⟩
    have hle : ψ.conductor ≤ 4 := Nat.sInf_le hf
    change ψ.conductor = 8 at hprim
    omega
  · exact Or.inl h8
  · exact Or.inr h8'

end MissingLinnik

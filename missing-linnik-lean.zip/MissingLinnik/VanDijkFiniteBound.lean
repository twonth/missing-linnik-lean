import MissingLinnik.VanDijkDeterminant
import MissingLinnik.WeightedFloorBound

namespace MissingLinnik.VanDijk

/-- A finite prime-sum inequality obtained from van Dijk's determinant. This
is the starting point for the remaining effective choice of parameters. -/
theorem finite_inert_prime_bound
    (p₀ M R S m T : ℕ) (d : ℤ) [Fact p₀.Prime] [Fact (¬ IsSquare (d : ZMod p₀))]
    (hp₂ : p₀ ≠ 2) (hd : legendreSym p₀ d = -1)
    (hM : M ≤ p₀) (hcard : p₀ ≤ M * M) (hR : R ≤ p₀)
    (hRpos : 1 ≤ R) (hS : 0 < S) (hSp : S < p₀)
    (a : ℂ) (ha : a ^ 2 = d) (B : ℝ) (hB : 1 ≤ B)
    (hMB : (M : ℝ) * (1 + ‖a‖) ≤ B)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime)
    (hpodd : ∀ p ∈ P, p ≠ 2)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1)
    (hRp : ∀ p ∈ P, R ≤ p * m) (hT : T + m ≤ S) :
    (T : ℝ) * R * (R - 1) * (∑ p ∈ P, Real.log p / p) ≤
      2 * Real.log ((R * S).factorial : ℝ) +
      2 * ∑ i : Fin R × Fin S, ((S : ℝ) * Real.log R +
        ((i.1.val + i.2.val : ℕ) : ℝ) * Real.log B) +
      2 * T * R * (∑ p ∈ P, Real.log p) := by
  obtain ⟨D, hD, hdiv, hupper⟩ := exists_positive_determinant_norm p₀ M R S d
    hp₂ hd hM hcard hR hRpos hS hSp a ha B hB hMB
  have hvaluation := sum_valuation_log_le P
    (fun p => 2 * (T * ∑ r ∈ Finset.range R, r / p)) D hD hprime
    (fun p hp => hdiv p m T (hprime p hp) (hpodd p hp) (hinert p hp) (hRp p hp) hT)
  have hlower := weighted_floor_sum_lower P R T (fun p hp => (hprime p hp).pos)
  linarith

end MissingLinnik.VanDijk

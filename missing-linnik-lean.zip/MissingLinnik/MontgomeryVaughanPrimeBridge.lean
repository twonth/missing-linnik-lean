import MissingLinnik.MontgomeryVaughanReciprocity
import MissingLinnik.CharacterBridge

namespace MissingLinnik

/-- The requested replacement bridge is complete for odd prime conductors.
This uses the cyclic-character classification and quadratic reciprocity. -/
theorem montgomeryVaughan_prime_representative (p : ℕ) [Fact p.Prime]
    (hp : p ≠ 2) (ψ : DirichletCharacter ℝ p) (hψ : ψ ≠ 1) :
    HasWeakQuadraticRepresentative ψ := by
  refine ⟨primeDiscriminant p, (primeDiscriminant_natAbs p).le, ?_⟩
  intro q hq hq2 hneg
  letI : Fact q.Prime := ⟨hq⟩
  have he := real_character_prime_discriminant p q hp hq2 ψ hψ
  have hh : (legendreSym q (primeDiscriminant p) : ℝ) = -1 := he.symm.trans hneg
  exact_mod_cast hh

end MissingLinnik

import MissingLinnik.GreenGrid

namespace MissingLinnik.Green

/-- Green's minor is obtained in characteristic zero, independently of the
finite-field independence argument used in the van Dijk route. -/
theorem exists_integer_minor (N J R S : ℕ) (d : ℤ)
    (hd : ∀ n : ℤ, d ≠ n * n) (a : ℂ) (ha : a ^ 2 = d)
    (hJ : 0 < J) (hNJ : 2 * N ≤ J)
    (hsize : 2 * R * S + J * (R + S) < (N * N) * J) :
    ∃ f : (Fin R × Fin S) → ((Fin N × Fin N) × Fin J),
      (Matrix.of (fun i j => monomialJet (VanDijk.integerGrid N d (f j).1)
        (star (VanDijk.integerGrid N d (f j).1)) (f j).2.val i.1.val i.2.val)).det ≠ 0 := by
  classical
  obtain ⟨f, hf⟩ := exists_nonzero_minor _
    (grid_rows_linearIndependent N J R S d hd a ha hJ hNJ hsize)
  refine ⟨f, ?_⟩
  intro hzero
  apply hf
  have hh := congrArg (quadraticComplexEmbedding d a ha) hzero
  rw [RingHom.map_det, map_zero] at hh
  exact hh

/-- Green's finite determinant construction: positive integer norm, simultaneous
inert-prime divisibility, and an explicit archimedean bound. -/
theorem exists_positive_determinant_norm (N J R S : ℕ) (d : ℤ)
    (hd : ∀ n : ℤ, d ≠ n * n) (a : ℂ) (ha : a ^ 2 = d)
    (hJ : 0 < J) (hNJ : 2 * N ≤ J) (hJS : J ≤ S) (hR : 1 ≤ R)
    (hsize : 2 * R * S + J * (R + S) < (N * N) * J)
    (B : ℝ) (hB : 1 ≤ B) (hNB : (N : ℝ) * (1 + ‖a‖) ≤ B) :
    ∃ D : ℕ, 0 < D ∧
      (∀ (p : ℕ) (hp : p.Prime), let _ : Fact p.Prime := ⟨hp⟩;
        p ≠ 2 → legendreSym p d = -1 →
        p ^ (2 * ∑ i : Fin R × Fin S, greenHeight p S (i.1.val, i.2.val)) ∣ D) ∧
      Real.log (D : ℝ) ≤ 2 * Real.log ((R * S).factorial : ℝ) +
        2 * ∑ i : Fin R × Fin S, ((S : ℝ) * Real.log R +
          ((i.1.val + i.2.val : ℕ) : ℝ) * Real.log B) := by
  classical
  obtain ⟨f, hf⟩ := exists_integer_minor N J R S d hd a ha hJ hNJ hsize
  let z : (Fin R × Fin S) → Zsqrtd d := fun c => VanDijk.integerGrid N d (f c).1
  let j : (Fin R × Fin S) → ℕ := fun c => (f c).2.val
  let Δ := (Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c) i.1.val i.2.val)).det
  have hΔ : Δ ≠ 0 := hf
  have hD : 0 < Δ.norm.natAbs := quadratic_norm_natAbs_pos hd Δ hΔ
  refine ⟨Δ.norm.natAbs, hD, ?_, ?_⟩
  · intro p hp hpFact hp2 hdp
    letI : Fact p.Prime := ⟨hp⟩
    have hv := green_norm_dvd p R S d hp2 hdp z j
    have habs := Int.natAbs_dvd_natAbs.mpr hv
    simpa only [Int.natAbs_pow, Int.natAbs_natCast] using habs
  · apply log_norm_jet_det_le R S d a ha z j B hR hB _ _ _ hD
    · intro c; exact (Nat.le_of_lt (f c).2.isLt).trans hJS
    · intro c
      exact (VanDijk.integerGrid_embedding_bound N d a ha (f c).1).trans hNB
    · intro c
      have hh := VanDijk.integerGrid_embedding_bound N d (-a) (by simpa using ha) (f c).1
      simp only [norm_neg] at hh
      exact hh.trans hNB

end MissingLinnik.Green

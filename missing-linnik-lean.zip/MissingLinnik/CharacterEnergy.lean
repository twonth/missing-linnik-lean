import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Push

/-!
A quantitative version of the energy argument in Section 3 of Pollack's paper.
This is a supporting lemma, not a proof of Linnik's theorem.
-/

namespace MissingLinnik

open scoped BigOperators

/-- Cubic mass >= 1 and quadratic mass <= 1.1 force a coefficient > 0.9. -/
theorem exists_large_coefficient {ι : Type*} (s : Finset ι) (w : ι → ℝ)
    (h₂ : ∑ i ∈ s, w i ^ 2 ≤ 11 / 10)
    (h₃ : 1 ≤ ∑ i ∈ s, w i ^ 3) :
    ∃ i ∈ s, 9 / 10 < w i := by
  by_contra! h
  have hterm : ∀ i ∈ s, w i ^ 3 ≤ (9 / 10) * w i ^ 2 := by
    intro i hi
    have hh := mul_le_mul_of_nonneg_right (h i hi) (sq_nonneg (w i))
    nlinarith
  have hs := Finset.sum_le_sum hterm
  rw [← Finset.mul_sum] at hs
  linarith

/-- If coefficients come in equal-weight pairs, a large one must be fixed.
For character coefficients, the pairing is complex conjugation and w is norm.
-/
theorem exists_large_fixed_coefficient {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (w : ι → ℝ) (τ : ι → ι)
    (hmem : ∀ i ∈ s, τ i ∈ s)
    (hweight : ∀ i ∈ s, w (τ i) = w i)
    (h₂ : ∑ i ∈ s, w i ^ 2 ≤ 11 / 10)
    (h₃ : 1 ≤ ∑ i ∈ s, w i ^ 3) :
    ∃ i ∈ s, 9 / 10 < w i ∧ τ i = i := by
  obtain ⟨i, hi, hlarge⟩ := exists_large_coefficient s w h₂ h₃
  refine ⟨i, hi, hlarge, ?_⟩
  by_contra hne
  have hsubset : ({i, τ i} : Finset ι) ⊆ s := by
    intro j hj
    simp only [Finset.mem_insert, Finset.mem_singleton] at hj
    rcases hj with rfl | rfl
    · exact hi
    · exact hmem i hi
  have hpair : w i ^ 2 + w (τ i) ^ 2 ≤ ∑ j ∈ s, w j ^ 2 := by
    have hh := Finset.sum_le_sum_of_subset_of_nonneg hsubset
      (fun j _ _ => sq_nonneg (w j))
    simpa [Ne.symm hne] using hh
  rw [hweight i hi] at hpair
  nlinarith [sq_nonneg (w i - 9 / 10)]

end MissingLinnik

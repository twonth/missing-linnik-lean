import MissingLinnik.RealCharacterLift
import Mathlib.NumberTheory.LegendreSymbol.QuadraticReciprocity
import Mathlib.RingTheory.ZMod.UnitsCyclic

namespace MissingLinnik

open Classical

/-- The primitive-root step in Montgomery--Vaughan, section 9.3:
a cyclic unit group admits at most one nonprincipal real character. -/
theorem real_character_unique_of_cyclic {N : ℕ} [NeZero N]
    [IsCyclic (ZMod N)ˣ] (χ ψ : DirichletCharacter ℝ N)
    (hχ : χ ≠ 1) (hψ : ψ ≠ 1) : χ = ψ := by
  obtain ⟨g, hg⟩ := IsCyclic.exists_generator (α := (ZMod N)ˣ)
  have neg (θ : DirichletCharacter ℝ N) (hθ : θ ≠ 1) : θ (g : ZMod N) = -1 := by
    rcases real_character_quadratic θ (g : ZMod N) with hz | ho | hn
    · exact ((MulChar.apply_ne_zero_iff.mpr g.isUnit) hz).elim
    · apply False.elim
      apply hθ
      apply (MulChar.eq_iff hg θ 1).mpr
      simpa using ho
    · exact hn
  exact (MulChar.eq_iff hg χ ψ).mpr ((neg χ hχ).trans (neg ψ hψ).symm)

/-- The Legendre character, regarded as a real Dirichlet character. -/
noncomputable def realLegendreCharacter (p : ℕ) [Fact p.Prime] :
    DirichletCharacter ℝ p :=
  (quadraticChar (ZMod p)).ringHomComp (Int.castRingHom ℝ)

theorem realLegendreCharacter_nonprincipal (p : ℕ) [Fact p.Prime] (hp : p ≠ 2) :
    realLegendreCharacter p ≠ 1 := by
  obtain ⟨u, hu⟩ := quadraticChar_exists_neg_one' (by simpa only [ZMod.ringChar_zmod_n] using hp : ringChar (ZMod p) ≠ 2)
  intro he
  have hh := congrArg (fun χ : DirichletCharacter ℝ p => χ (u : ZMod p)) he
  change ((quadraticChar (ZMod p) (u : ZMod p) : ℤ) : ℝ) = (1 : DirichletCharacter ℝ p) u at hh
  rw [hu] at hh
  norm_num at hh

/-- Montgomery--Vaughan's classification at an odd prime modulus. -/
theorem real_character_prime_eq_legendre (p : ℕ) [Fact p.Prime] (hp : p ≠ 2)
    (ψ : DirichletCharacter ℝ p) (hψ : ψ ≠ 1) :
    ψ = realLegendreCharacter p := by
  letI := ZMod.isCyclic_units_prime (Fact.out : p.Prime)
  exact real_character_unique_of_cyclic ψ _ hψ (realLegendreCharacter_nonprincipal p hp)

/-- At an odd prime power every nonprincipal real character is induced from
the Legendre character at the prime. This is the exclusion of higher odd
prime powers in both Davenport and Montgomery--Vaughan. -/
theorem real_character_prime_power_eq_legendre (p k : ℕ) [Fact p.Prime]
    (hp : p ≠ 2) (hk : 1 ≤ k) (ψ : DirichletCharacter ℝ (p^k)) (hψ : ψ ≠ 1) :
    ψ = DirichletCharacter.changeLevel (dvd_pow_self p (by omega : k ≠ 0))
      (realLegendreCharacter p) := by
  letI : NeZero (p^k) := ⟨pow_ne_zero k (Fact.out : p.Prime).ne_zero⟩
  letI := ZMod.isCyclic_units_of_prime_pow p (Fact.out : p.Prime) hp k
  apply real_character_unique_of_cyclic ψ _ hψ
  simpa using realLegendreCharacter_nonprincipal p hp

theorem primitive_real_odd_prime_power_exponent (p k : ℕ) [Fact p.Prime]
    (hp : p ≠ 2) (hk : 1 ≤ k) (ψ : DirichletCharacter ℝ (p^k))
    (hψ : ψ ≠ 1) (hprim : ψ.IsPrimitive) : k = 1 := by
  have he := real_character_prime_power_eq_legendre p k hp hk ψ hψ
  have hf : ψ.FactorsThrough p := ⟨_, realLegendreCharacter p, he⟩
  have hle : ψ.conductor ≤ p := Nat.sInf_le hf
  change ψ.conductor = p^k at hprim
  rw [hprim] at hle
  have hp1 : 1 < p := (Fact.out : p.Prime).one_lt
  have hk' : k ≤ 1 := by
    by_contra hn
    have hpow : p^1 < p^k := (pow_lt_pow_right₀ hp1 (by omega))
    rw [pow_one] at hpow
    exact not_lt_of_ge hle hpow
  omega

end MissingLinnik

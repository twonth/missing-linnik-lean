import MissingLinnik.MontgomeryVaughanLocal

namespace MissingLinnik

/-- The signed odd prime discriminant used in both textbooks. -/
def primeDiscriminant (p : ℕ) : ℤ := (-1)^(p/2) * p

theorem primeDiscriminant_natAbs (p : ℕ) : (primeDiscriminant p).natAbs = p := by
  simp [primeDiscriminant, Int.natAbs_mul, Int.natAbs_pow]

/-- Quadratic reciprocity in the form needed to identify the basic characters
with discriminant symbols. This proof uses reciprocity, not a new Gauss sum. -/
theorem primeDiscriminant_reciprocity (p q : ℕ) [Fact p.Prime] [Fact q.Prime]
    (hp : p ≠ 2) (hq : q ≠ 2) :
    legendreSym q (primeDiscriminant p) = legendreSym p q := by
  have hodd := (Nat.Prime.mod_two_eq_one_iff_ne_two (Fact.out : q.Prime)).mpr hq
  have hpow : legendreSym q ((-1:ℤ)^(p/2)) = (legendreSym q (-1))^(p/2) :=
    map_pow (legendreSym.hom q) (-1) (p/2)
  rw [primeDiscriminant, legendreSym.mul, hpow, legendreSym.at_neg_one hq,
    ZMod.χ₄_eq_neg_one_pow hodd, ← pow_mul, Nat.mul_comm (q/2) (p/2),
    legendreSym.quadratic_reciprocity' hp hq, ← mul_assoc, ← pow_two,
    ← pow_mul, Nat.mul_comm _ 2, pow_mul]
  norm_num

theorem real_character_prime_discriminant (p q : ℕ) [Fact p.Prime] [Fact q.Prime]
    (hp : p ≠ 2) (hq : q ≠ 2) (ψ : DirichletCharacter ℝ p) (hψ : ψ ≠ 1) :
    ψ (q : ZMod p) = (legendreSym q (primeDiscriminant p) : ℝ) := by
  rw [real_character_prime_eq_legendre p hp ψ hψ, primeDiscriminant_reciprocity p q hp hq]
  simp [realLegendreCharacter, legendreSym]

end MissingLinnik

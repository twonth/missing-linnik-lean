import MissingLinnik.LogDecayIntegrals

namespace MissingLinnik

open Finset MeasureTheory

noncomputable def logSquareOver (t : ℝ) : ℝ := (Real.log t)^2/t
noncomputable def logSquareOverDeriv (t : ℝ) : ℝ := (2*Real.log t-(Real.log t)^2)/t^2

theorem logSquareOver_hasDerivAt (t : ℝ) (ht : t ≠ 0) :
    HasDerivAt logSquareOver (logSquareOverDeriv t) t := by
  have hh := ((Real.hasDerivAt_log ht).pow 2).div (hasDerivAt_id t) ht
  convert hh using 1
  · rfl
  · unfold logSquareOverDeriv
    norm_num
    field_simp <;> ring

theorem logSquareOverDeriv_continuousOn (x : ℝ) :
    ContinuousOn logSquareOverDeriv (Set.Icc 1 x) := by
  intro t ht
  have ht0 : t ≠ 0 := by linarith [ht.1]
  unfold logSquareOverDeriv
  fun_prop (disch := simp [ht0])

theorem logSquareOverDeriv_abs_bound (t : ℝ) (ht : 1 ≤ t) :
    |logSquareOverDeriv t| ≤ (2*(Real.log t)^2+1)/t^2 := by
  have hl := Real.log_nonneg ht
  have hn : |2*Real.log t-(Real.log t)^2| ≤ 2*(Real.log t)^2+1 := by
    apply abs_le.mpr
    constructor <;> nlinarith [sq_nonneg (Real.log t-1),sq_nonneg (Real.log t)]
  unfold logSquareOverDeriv
  rw [abs_div,abs_of_nonneg (sq_nonneg t)]
  exact div_le_div_of_nonneg_right hn (sq_nonneg t)

theorem logSquareOver_abel (c : ℕ → ℝ) (hc : c 0 = 0) (x : ℝ) :
    (∑ n ∈ Finset.Icc 0 (Nat.floor x), logSquareOver n*c n) =
      logSquareOver x*(∑ n ∈ Finset.Icc 0 (Nat.floor x), c n)-
      ∫ t in Set.Ioc 1 x, logSquareOverDeriv t*(∑ n ∈ Finset.Icc 0 (Nat.floor t), c n) := by
  have hd (t : ℝ) (ht : t ∈ Set.Icc 1 x) : deriv logSquareOver t = logSquareOverDeriv t :=
    (logSquareOver_hasDerivAt t (by linarith [ht.1])).deriv
  have hi : IntegrableOn (deriv logSquareOver) (Set.Icc 1 x) := by
    apply (logSquareOverDeriv_continuousOn x).integrableOn_Icc.congr_fun
      (fun t ht => (hd t ht).symm) measurableSet_Icc
  have hh := sum_mul_eq_sub_integral_mul₀ c hc x
    (fun t ht => (logSquareOver_hasDerivAt t (by linarith [ht.1])).differentiableAt) hi
  have he : (∫ t in Set.Ioc 1 x, deriv logSquareOver t*(∑ n ∈ Finset.Icc 0 (Nat.floor t), c n)) =
      ∫ t in Set.Ioc 1 x, logSquareOverDeriv t*(∑ n ∈ Finset.Icc 0 (Nat.floor t), c n) := by
    apply MeasureTheory.setIntegral_congr_fun measurableSet_Ioc
    intro t ht
    dsimp only
    rw [hd t (Set.Ioc_subset_Icc_self ht)]
  rwa [he] at hh

/-- Uniform boundedness of the logarithmically weighted discrepancy from
an exponentially decaying relative counting discrepancy. -/
theorem weighted_discrepancy_bound (c : ℕ → ℝ) (hc : c 0 = 0)
    (K β : ℝ) (hK : 0 ≤ K) (hβ : 0 < β) (hβ1 : β ≤ 1)
    (hcount : ∀ t : ℝ, 1 ≤ t → |∑ n ∈ Finset.Icc 0 (Nat.floor t), c n| ≤ K*t*logDecay β t)
    (x : ℝ) (hx : 1 ≤ x) :
    |∑ n ∈ Finset.Icc 0 (Nat.floor x), logSquareOver n*c n| ≤ 9*K/β^3 := by
  let C := fun t : ℝ => ∑ n ∈ Finset.Icc 0 (Nat.floor t), c n
  let G := fun t : ℝ => K*(2*((Real.log t)^2*logDecay β t/t)+logDecay β t/t)
  have hmajor (t : ℝ) (ht : 1 ≤ t) : |logSquareOverDeriv t*C t| ≤ G t := by
    have ht0 : 0 < t := by linarith
    have hb := mul_le_mul (logSquareOverDeriv_abs_bound t ht) (hcount t ht)
      (abs_nonneg (C t)) (by positivity : 0 ≤ (2*(Real.log t)^2+1)/t^2)
    rw [abs_mul]
    apply hb.trans_eq
    dsimp [G]
    field_simp
  have hi2 : IntegrableOn (fun t : ℝ => (Real.log t)^2*logDecay β t/t) (Set.Ioc 1 x) := by
    have hcont : ContinuousOn (fun t : ℝ => (Real.log t)^2*logDecay β t/t) (Set.Icc 1 x) := by
      intro t ht
      have ht0 : t ≠ 0 := by linarith [ht.1]
      unfold logDecay
      fun_prop
    exact hcont.integrableOn_Icc.mono_set Set.Ioc_subset_Icc_self
  have hi0 : IntegrableOn (fun t : ℝ => logDecay β t/t) (Set.Ioc 1 x) := by
    have hcont : ContinuousOn (fun t : ℝ => logDecay β t/t) (Set.Icc 1 x) := by
      intro t ht
      have ht0 : t ≠ 0 := by linarith [ht.1]
      unfold logDecay
      fun_prop
    exact hcont.integrableOn_Icc.mono_set Set.Ioc_subset_Icc_self
  have hG : IntegrableOn G (Set.Ioc 1 x) := ((hi2.const_mul 2).add hi0).const_mul K
  have hfun : IntegrableOn (fun t : ℝ => logSquareOverDeriv t*C t) (Set.Ioc 1 x) := by
    exact (integrableOn_mul_sum_Icc c (m := 0) (by norm_num : (0:ℝ)≤1)
      (logSquareOverDeriv_continuousOn x).integrableOn_Icc).mono_set Set.Ioc_subset_Icc_self
  have habs : |∫ t in Set.Ioc 1 x, logSquareOverDeriv t*C t| ≤ ∫ t in Set.Ioc 1 x, G t := by
    apply MeasureTheory.abs_integral_le_integral_abs.trans
    exact MeasureTheory.setIntegral_mono_on hfun.abs hG measurableSet_Ioc (fun t ht => hmajor t ht.1.le)
  have hGint : (∫ t in Set.Ioc 1 x, G t) ≤ K*(4/β^3+1/β) := by
    dsimp [G]
    rw [MeasureTheory.integral_const_mul,MeasureTheory.integral_add (hi2.const_mul 2) hi0,
      MeasureTheory.integral_const_mul]
    apply mul_le_mul_of_nonneg_left _ hK
    have h2 := logDecay_integral_two β x hβ hx
    have h0 := logDecay_integral_zero β x hβ hx
    ring_nf at h2 h0 ⊢
    linarith
  have hboundary : |logSquareOver x*C x| ≤ 4*K/β^2 := by
    have hf : 0 ≤ logSquareOver x := by unfold logSquareOver; positivity
    rw [abs_mul,abs_of_nonneg hf]
    have ht := mul_le_mul_of_nonneg_left (hcount x hx) hf
    have he : logSquareOver x*(K*x*logDecay β x) = K*((Real.log x)^2*logDecay β x) := by
      unfold logSquareOver
      field_simp
    rw [he] at ht
    have hb := mul_le_mul_of_nonneg_left (logDecay_boundary_two β x hβ hx) hK
    dsimp only [C]
    exact ht.trans (by convert hb using 1 <;> ring)
  have htotal : 4*K/β^2+K*(4/β^3+1/β) ≤ 9*K/β^3 := by
    apply (mul_le_mul_iff_right₀ (show 0<β^3 by positivity)).mp
    field_simp
    have hb2 : β^2 ≤ 1 := by nlinarith
    have ht := mul_nonneg hK (show 0 ≤ 5-4*β-β^2 by nlinarith)
    nlinarith only [ht]
  rw [logSquareOver_abel c hc]
  exact (abs_sub _ _).trans ((add_le_add hboundary (habs.trans hGint)).trans htotal)

end MissingLinnik

import MissingLinnik.Statements
import Mathlib.Tactic.FieldSimp

namespace MissingLinnik

/-- A deliberately generous computable exponent shared by both quadratic
anti-concentration proofs. -/
def quadraticExponent (j : ℕ) : ℕ :=
  (2 + 512 * ((16*(j+1))*(16*(j+1)))) * (j+1)

theorem quadraticExponent_computable : Computable quadraticExponent := by
  have ht : Primrec (fun j : ℕ => j+1) := Primrec.nat_add.comp Primrec.id (Primrec.const 1)
  have hk : Primrec (fun j : ℕ => 16*(j+1)) := Primrec.nat_mul.comp (Primrec.const 16) ht
  exact (Primrec.nat_mul.comp
    (Primrec.nat_add.comp (Primrec.const 2)
      (Primrec.nat_mul.comp (Primrec.const 512) (Primrec.nat_mul.comp hk hk))) ht).to_comp

theorem quadraticExponent_pos (j : ℕ) : 0 < quadraticExponent j := by
  unfold quadraticExponent
  positivity

theorem effective_error_absorption (j : ℕ) (q x : ℝ) (hq : 2 ≤ q)
    (hx : q ^ quadraticExponent j ≤ x) :
    (1/2+8/((16*(j+1):ℕ):ℝ))*Real.log x + Real.log q +
      128*(((16*(j+1):ℕ):ℝ)^2) ≤
      (1/2+1/((j:ℝ)+1))*Real.log x := by
  have hq0 : 0 < q := by linarith
  have hq1 : 1 ≤ q := by linarith
  have hlogq : 1/2 ≤ Real.log q := by
    have hlog2 := Real.one_sub_inv_le_log_of_pos (by norm_num : (0:ℝ)<2)
    have hmono := Real.log_le_log (by norm_num : (0:ℝ)<2) hq
    norm_num at hlog2
    linarith
  have hlogx := Real.log_le_log (pow_pos hq0 _) hx
  rw [Real.log_pow] at hlogx
  have ht : 0 < (j:ℝ)+1 := by positivity
  have hc : 128*(16*((j:ℝ)+1))^2 ≤ 256*(16*((j:ℝ)+1))^2*Real.log q := by
    nlinarith [mul_nonneg (sq_nonneg (16*((j:ℝ)+1))) (show 0 ≤ 2*Real.log q-1 by linarith)]
  have hc' := mul_le_mul_of_nonneg_left hc (show 0 ≤ 2*((j:ℝ)+1) by positivity)
  unfold quadraticExponent at hlogx
  push_cast at hlogx ⊢
  have herr : 2*((j:ℝ)+1)*(Real.log q+128*(16*((j:ℝ)+1))^2) ≤ Real.log x := by
    nlinarith only [hlogx,hc']
  apply (mul_le_mul_iff_right₀ ht).mp
  field_simp
  nlinarith only [herr]

end MissingLinnik

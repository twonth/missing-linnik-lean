import MissingLinnik.GreenCappedMultiplicity

namespace MissingLinnik.Green

open Classical

/-- Green's interpolation lemma, in its equivalent polynomial formulation.
The geometric zero-count assumption is deliberately explicit. -/
theorem polynomial_eq_zero_of_jets {K ι : Type*} [Field K] [CharZero K] [Fintype ι]
    (z w : ι → K) (hw : Function.Injective w) (J R S : ℕ) (hJ : 0 < J)
    (hzero : ∀ f : Polynomial (Polynomial K), f ≠ 0 →
      (Finset.univ.filter (fun i => (f.map (Polynomial.evalRingHom (w i))).eval (z i) = 0)).card ≤
        J * (f.natDegree + yDegree f))
    (hsize : 2 * R * S + J * (R + S) < Fintype.card ι * J)
    (f : Polynomial (Polynomial K)) (hR : f.natDegree ≤ R) (hS : yDegree f ≤ S)
    (hjets : ∀ i, ∀ j < J, (Polynomial.derivative^[j]
      (f.map (Polynomial.evalRingHom (w i)))).eval (z i) = 0) : f = 0 := by
  by_contra hf
  have hbound := capped_multiplicity_sum_bound z w hw J hzero f hf
  have horder (i : ι) : cappedOrder J (z i) (f.map (Polynomial.evalRingHom (w i))) = J := by
    by_cases hi : f.map (Polynomial.evalRingHom (w i)) = 0
    · simp [cappedOrder, hi]
    have hfac : ((J-1).factorial : K) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero (J-1)
    have hm := Polynomial.lt_rootMultiplicity_of_isRoot_iterate_derivative_of_mem_nonZeroDivisors
      hi (fun j (hj : j ≤ J-1) => hjets i j (by omega))
      (mem_nonZeroDivisors_iff_ne_zero.mpr hfac)
    rw [cappedOrder, ite_eq_right hi, min_eq_left (by omega)]
  simp only [horder, Finset.sum_const, Finset.card_univ, smul_eq_mul] at hbound
  have hprod : f.natDegree * yDegree f ≤ R * S := Nat.mul_le_mul hR hS
  have hsum : f.natDegree + yDegree f ≤ R + S := Nat.add_le_add hR hS
  have hsum' := Nat.mul_le_mul_left J hsum
  nlinarith

end MissingLinnik.Green


import MissingLinnik.RoughArithmetic

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

theorem arithmeticClassSum_convolution (f g : ArithmeticFunction ℝ) (q c : ℕ) (hq : 0<q)
    (hf : ∀ d, f d≠0 → d.Coprime q) (x : ℝ) :
    arithmeticClassSum (f*g) q c x =
      ∑ d ∈ Icc 1 (Nat.floor x), f d/(d:ℝ)*arithmeticClassSum g q (inverseResidue q c d) (x/d) := by
  let F : ℕ → ℕ → ℝ := fun d m => if Nat.ModEq q (d*m) c then f d*g m/((d*m:ℕ):ℝ) else 0
  have he : arithmeticClassSum (f*g) q c x =
      ∑ n ∈ Icc 1 (Nat.floor x), ∑ a ∈ n.divisorsAntidiagonal, F a.1 a.2 := by
    unfold arithmeticClassSum
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro n hn
    rw [ArithmeticFunction.mul_apply,Finset.sum_div]
    by_cases hnq : Nat.ModEq q n c
    · rw [if_pos hnq]
      apply Finset.sum_congr rfl
      intro a ha
      dsimp [F]
      rw [(Nat.mem_divisorsAntidiagonal.mp ha).1,if_pos hnq]
    · rw [if_neg hnq]
      symm
      apply Finset.sum_eq_zero
      intro a ha
      dsimp [F]
      rw [(Nat.mem_divisorsAntidiagonal.mp ha).1,if_neg hnq]
  rw [he,sum_divisor_pairs,sum_hyperbolaPairs]
  apply Finset.sum_congr rfl
  intro d hd
  unfold arithmeticClassSum
  rw [Nat.floor_div_natCast,Finset.sum_filter,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro m hm
  by_cases hfd : f d=0
  · dsimp [F]
    simp [hfd]
  · dsimp [F]
    simp only [inverseResidue_congruence q c d m hq (hf d hfd),Nat.cast_mul]
    split_ifs <;> ring

noncomputable def arithmeticClassCoefficient (f : ArithmeticFunction ℝ) (q c n : ℕ) : ℝ :=
  if Nat.ModEq q n c then f n/(n:ℝ) else 0

theorem arithmeticClassCoefficient_zero (f : ArithmeticFunction ℝ) (q c : ℕ) :
    arithmeticClassCoefficient f q c 0=0 := by simp [arithmeticClassCoefficient]

theorem coefficientMass_class (f : ArithmeticFunction ℝ) (q c : ℕ) (x : ℝ) :
    coefficientMass (arithmeticClassCoefficient f q c) x=arithmeticClassSum f q c x := by
  unfold coefficientMass arithmeticClassSum
  rw [sum_Icc_zero_eq_one (arithmeticClassCoefficient_zero f q c),Finset.sum_filter]
  rfl

theorem coefficientLogMoment_class (f : ArithmeticFunction ℝ) (q c : ℕ) (x : ℝ) :
    coefficientLogMoment (arithmeticClassCoefficient f q c) x=arithmeticClassSum (logWeight f) q c x := by
  unfold coefficientLogMoment arithmeticClassSum
  rw [sum_Icc_zero_eq_one (f := fun n : ℕ => Real.log n*arithmeticClassCoefficient f q c n) (by simp),Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro n hn
  unfold arithmeticClassCoefficient
  rw [logWeight_apply]
  split_ifs <;> ring

end MissingLinnik

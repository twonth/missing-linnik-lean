import MissingLinnik.SelbergSquare
import Mathlib.Data.Int.CardIntervalMod

namespace MissingLinnik

/-- An interval of N consecutive nonnegative integers has N/q members of
each residue class, up to an absolute error at most one. -/
theorem progression_count_error (N q b : ℕ) (hq : 0 < q) :
    |(((Finset.range N).filter (fun n => Nat.ModEq q n b)).card:ℝ) - (N:ℝ)/q| ≤ 1 := by
  rw [← Nat.count_eq_card_filter_range, Nat.count_modEq_card N hq b]
  have hqR : (0:ℝ) < q := by exact_mod_cast hq
  have hmod : (N % q:ℝ) < q := by exact_mod_cast Nat.mod_lt N hq
  have hmod0 : (0:ℝ) ≤ N % q := Nat.cast_nonneg _
  have he : (N:ℝ) = (N/q:ℕ)*q + (N%q:ℕ) := by
    exact_mod_cast (show N = N/q*q+N%q by simpa [Nat.mul_comm] using (Nat.div_add_mod N q).symm)
  have hdiv : (N:ℝ)/q*q = N := div_mul_cancel₀ _ hqR.ne'
  split_ifs <;> push_cast <;> apply abs_le.mpr <;> constructor <;>
    nlinarith only [he,hmod,hmod0,hdiv,hqR]

/-- CRT identifies the multiples of d in a progression with a single
progression modulo q*d. -/
theorem progression_multiples_filter (N q b d : ℕ) (hc : q.Coprime d) :
    (((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter (fun n => d ∣ n)) =
      (Finset.range N).filter (fun n => Nat.ModEq (q*d) n (Nat.chineseRemainder hc b 0)) := by
  ext n
  simp only [Finset.mem_filter]
  constructor
  · rintro ⟨⟨hN,hq⟩,hd⟩
    exact ⟨hN,Nat.chineseRemainder_modEq_unique hc hq (Nat.modEq_zero_iff_dvd.mpr hd)⟩
  · rintro ⟨hN,h⟩
    have hq := h.of_dvd (dvd_mul_right q d)
    have hd := h.of_dvd (dvd_mul_left d q)
    exact ⟨⟨hN,hq.trans (Nat.chineseRemainder hc b 0).property.1⟩,
      Nat.modEq_zero_iff_dvd.mp (hd.trans (Nat.chineseRemainder hc b 0).property.2)⟩

theorem progression_multiples_count_error (N q b d : ℕ) (hq : 0 < q)
    (hd : 0 < d) (hc : q.Coprime d) :
    |((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => d ∣ n)).card:ℝ) - (N:ℝ)/(q*d)| ≤ 1 := by
  rw [progression_multiples_filter N q b d hc]
  simpa only [Nat.cast_mul] using progression_count_error N (q*d)
    (Nat.chineseRemainder hc b 0) (Nat.mul_pos hq hd)

/-- Selberg's square specialized to actual arithmetic progressions. -/
theorem selberg_progression_square_bound (N q b P : ℕ) (hq : 0 < q) (hP : 0 < P)
    (hcop : q.Coprime P) (D : Finset ℕ) (hD : ∀ d ∈ D, d ∣ P) (h1 : 1 ∈ D)
    (ρ : ℕ → ℝ) (hρ : ρ 1 = 1) :
    ((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => n.Coprime P)).card:ℝ) ≤
      ((N:ℝ)/q)*(∑ d ∈ D, ∑ e ∈ D, ρ d*ρ e/(d.lcm e)) + (∑ d ∈ D, |ρ d|)^2 := by
  apply selberg_square_bound _ D P hD h1 ρ hρ
  intro d hd e he
  have hl : d.lcm e ∣ P := Nat.lcm_dvd (hD d hd) (hD e he)
  have hl0 : 0 < d.lcm e := Nat.pos_of_dvd_of_pos hl hP
  have hh := progression_multiples_count_error N q b (d.lcm e) hq hl0
    (hcop.of_dvd_right hl)
  simpa only [div_div] using hh

end MissingLinnik

import MissingLinnik.TriangleDeterminant
import MissingLinnik.WeightedFloorBound

namespace MissingLinnik.Triangle

theorem row_floor_sum_lower {ι : Type*} [Fintype ι] (r : ι → ℕ)
    (p : ℕ) (hp : 0 < p) :
    (∑ i, (r i:ℝ)) / p - Fintype.card ι ≤ ∑ i, ((r i/p:ℕ):ℝ) := by
  have hpR : (0:ℝ) < p := by exact_mod_cast hp
  have ht (i : ι) : (r i:ℝ) ≤ (p:ℝ)*((r i/p:ℕ):ℝ)+p := by
    have hm := Nat.mod_lt (r i) hp
    have he := Nat.mod_add_div (r i) p
    exact_mod_cast (show r i ≤ p*(r i/p)+p by omega)
  have hs := Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => ht i)
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_const,
    Finset.card_univ, nsmul_eq_mul] at hs
  apply (sub_le_iff_le_add).mpr
  apply (div_le_iff₀ hpR).mpr
  nlinarith only [hs]

theorem weighted_floor_lower {ι : Type*} [Fintype ι] (r : ι → ℕ)
    (P : Finset ℕ) (hp : ∀ p ∈ P, 0 < p) :
    2*(∑ i, (r i:ℝ))*(∑ p ∈ P, Real.log p/p) -
      2*(Fintype.card ι:ℝ)*(∑ p ∈ P, Real.log p) ≤
      ∑ p ∈ P, ((2 * ∑ i, r i/p:ℕ):ℝ)*Real.log p := by
  have ht (p : ℕ) (hmem : p ∈ P) :
      2*(∑ i, (r i:ℝ))*(Real.log p/p) - 2*(Fintype.card ι:ℝ)*Real.log p ≤
      ((2 * ∑ i, r i/p:ℕ):ℝ)*Real.log p := by
    have hh := mul_le_mul_of_nonneg_right (row_floor_sum_lower r p (hp p hmem))
      (show 0 ≤ 2*Real.log p by positivity)
    push_cast at ⊢
    convert hh using 1 <;> ring
  have hs := Finset.sum_le_sum (fun p hmem => ht p hmem)
  simpa only [Finset.sum_sub_distrib, ← Finset.mul_sum] using hs

/-- Quantitative prime-sum inequality from the triangular determinant, before
choosing the slope and the cutoff. All rows enter the valuation sum. -/
theorem finite_inert_prime_bound
    (L Y S M : ℕ) (d : ℤ) [Fact L.Prime] [Fact (¬ IsSquare (d : ZMod L))]
    (hL2 : L ≠ 2) (hd : legendreSym L d = -1)
    (hM : M ≤ L) (hcard : L ≤ M*M) (hS : 0 < S) (hSL : S < L)
    (hcover : L ≤ Y*S)
    (a : ℂ) (ha : a^2=d) (B : ℝ) (hB : 1 ≤ B)
    (hMB : (M:ℝ)*(1+‖a‖) ≤ B)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime)
    (hpodd : ∀ p ∈ P, p ≠ 2)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1)
    (hY : ∀ p ∈ P, Y ≤ p) :
    (∑ i : Row L Y S, (i.val.1.val:ℝ))*(∑ p ∈ P, Real.log p/p) ≤
      Real.log ((Fintype.card (Row L Y S)).factorial:ℝ) +
      (∑ i : Row L Y S,
        ((S:ℝ)*Real.log L + ((i.val.1.val+i.val.2.val:ℕ):ℝ)*Real.log B)) +
      (Fintype.card (Row L Y S):ℝ)*(∑ p ∈ P, Real.log p) := by
  obtain ⟨D,hD,hdiv,hupper⟩ := exists_positive_determinant_norm L Y S M d
    hL2 hd hM hcard hS hSL hcover a ha B hB hMB
  have hval := sum_valuation_log_le P
    (fun p => 2*∑ i : Row L Y S, i.val.1.val/p) D hD hprime
    (fun p hp => hdiv p (hprime p hp) (hpodd p hp) (hinert p hp) (hY p hp))
  have hlower := weighted_floor_lower (fun i : Row L Y S => i.val.1.val)
    P (fun p hp => (hprime p hp).pos)
  linarith

end MissingLinnik.Triangle

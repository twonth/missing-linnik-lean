import MissingLinnik.SieveEulerProduct
import MissingLinnik.PrimeLogMass

namespace MissingLinnik

open Finset

theorem weighted_totient_product_ratio (P : ℕ) (hP : Squarefree P) (α : ℝ) :
    (∑ r ∈ P.divisors, (r:ℝ)^α/r.totient) =
      fullSieveH P * ∏ p ∈ P.primeFactors, (1+((p:ℝ)^α-1)/p) := by
  rw [weighted_totient_divisor_product P hP α,fullSieveH_product P hP,← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro p hp
  have hpR : (1:ℝ) < p := by exact_mod_cast (Nat.prime_of_mem_primeFactors hp).one_lt
  have hp0 : (p:ℝ) ≠ 0 := by linarith
  have hp1 : (p:ℝ)-1 ≠ 0 := by linarith
  field_simp
  ring

theorem weighted_totient_sum_le_exp (P : ℕ) (hP : Squarefree P) (α : ℝ) (hα : 0 ≤ α) :
    (∑ r ∈ P.divisors, (r:ℝ)^α/r.totient) ≤
      fullSieveH P * Real.exp (∑ p ∈ P.primeFactors, ((p:ℝ)^α-1)/p) := by
  rw [weighted_totient_product_ratio P hP α,Real.exp_sum]
  apply mul_le_mul_of_nonneg_left _ (fullSieveH_pos P hP.ne_zero).le
  apply Finset.prod_le_prod₀
  · intro p hp
    have hp1 : (1:ℝ) ≤ p := by exact_mod_cast (Nat.prime_of_mem_primeFactors hp).one_le
    have hm := Real.one_le_rpow hp1 hα
    have : 0 ≤ ((p:ℝ)^α-1)/p := div_nonneg (by linarith) (Nat.cast_nonneg p)
    linarith
  · intro p hp
    simpa [add_comm] using Real.add_one_le_exp (((p:ℝ)^α-1)/p)

theorem prime_rpow_sub_one_le (p z : ℕ) (hp : 2 ≤ p) (hpz : p ≤ z) :
    (p:ℝ)^((Real.log z)⁻¹)-1 ≤ 2*Real.log p/Real.log z := by
  have hp0 : (0:ℝ) < p := by exact_mod_cast (show 0<p by omega)
  have hz1 : (1:ℝ) < z := by exact_mod_cast (show 1<z by omega)
  have hlz : 0 < Real.log (z:ℝ) := Real.log_pos hz1
  have hlp : 0 ≤ Real.log (p:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤p by omega))
  have hle : Real.log (p:ℝ) ≤ Real.log z := Real.log_le_log hp0 (by exact_mod_cast hpz)
  have hu0 : 0 ≤ Real.log (p:ℝ)/Real.log z := div_nonneg hlp hlz.le
  have hu1 : Real.log (p:ℝ)/Real.log z ≤ 1 := (div_le_one hlz).mpr hle
  have hh := Real.abs_exp_sub_one_le (x := Real.log (p:ℝ)/Real.log z)
    (by rwa [abs_of_nonneg hu0])
  have he := (le_abs_self (Real.exp (Real.log (p:ℝ)/Real.log z)-1)).trans hh
  rw [abs_of_nonneg hu0] at he
  rw [Real.rpow_def_of_pos hp0]
  simpa [div_eq_mul_inv,mul_assoc] using he

/-- A uniform constant for the auxiliary Euler product. -/
theorem rankin_euler_product_bound (P z : ℕ) (hP : Squarefree P) (hz : 2 ≤ z)
    (hpz : ∀ p ∈ P.primeFactors, p ≤ z) :
    (∑ r ∈ P.divisors, (r:ℝ)^((Real.log z)⁻¹)/r.totient) ≤
      fullSieveH P * Real.exp 16 := by
  have hlz : 0 < Real.log (z:ℝ) := Real.log_pos (by exact_mod_cast (show 1<z by omega))
  have hh := weighted_totient_sum_le_exp P hP ((Real.log z)⁻¹) (by positivity)
  have hs : (∑ p ∈ P.primeFactors, ((p:ℝ)^((Real.log z)⁻¹)-1)/p) ≤ 16 := by
    calc
      _ ≤ ∑ p ∈ P.primeFactors, (2/Real.log z)*(Real.log p/p) := by
        apply Finset.sum_le_sum
        intro p hp
        have ht := div_le_div_of_nonneg_right
          (prime_rpow_sub_one_le p z (Nat.prime_of_mem_primeFactors hp).two_le (hpz p hp))
          (Nat.cast_nonneg p : (0:ℝ) ≤ p)
        convert ht using 1 <;> ring
      _ = (2/Real.log z)*(∑ p ∈ P.primeFactors, Real.log p/p) := by rw [Finset.mul_sum]
      _ ≤ (2/Real.log z)*(8*Real.log z) :=
        mul_le_mul_of_nonneg_left
          (prime_log_mass_le_eight_log P.primeFactors z hz
            (fun p hp => Nat.prime_of_mem_primeFactors hp) hpz) (by positivity)
      _ = 16 := by field_simp; norm_num
  exact hh.trans (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hs) (fullSieveH_pos P hP.ne_zero).le)

/-- Exponential accuracy of the truncated divisor sum, with explicit constants. -/
theorem sieveH_tail_power (P z h : ℕ) (hP : Squarefree P) (hz : 2 ≤ z)
    (hpz : ∀ p ∈ P.primeFactors, p ≤ z) :
    fullSieveH P - sieveH P (z^h) ≤ fullSieveH P * Real.exp (16-(h:ℝ)) := by
  have hz0 : (0:ℝ) < z := by exact_mod_cast (show 0<z by omega)
  have hlz : 0 < Real.log (z:ℝ) := Real.log_pos (by exact_mod_cast (show 1<z by omega))
  have hh := sieveH_tail_rankin P (z^h) (one_le_pow₀ (by omega : 1≤z))
    ((Real.log z)⁻¹) (by positivity)
  have hb := rankin_euler_product_bound P z hP hz hpz
  have ht := mul_le_mul_of_nonneg_left hb
    (Real.rpow_nonneg (Nat.cast_nonneg (z^h)) (-((Real.log z)⁻¹)))
  have he : ((z^h:ℕ):ℝ)^(-((Real.log z)⁻¹)) = Real.exp (-(h:ℝ)) := by
    rw [Nat.cast_pow,Real.rpow_def_of_pos (pow_pos hz0 _),Real.log_pow]
    congr 1
    field_simp
  rw [he] at ht hh
  have he' : Real.exp (-(h:ℝ))*(fullSieveH P*Real.exp 16) =
      fullSieveH P*Real.exp (16-(h:ℝ)) := by
    rw [← mul_assoc,mul_comm (Real.exp (-(h:ℝ))),mul_assoc,← Real.exp_add]
    congr 2
    ring
  exact hh.trans (he' ▸ ht)

theorem inverse_truncation_bound (H H₀ δ : ℝ) (hH : 0 < H) (hH₀ : 0 < H₀)
    (hδ0 : 0 ≤ δ) (hδ : δ ≤ 1/2) (htail : H₀-H ≤ H₀*δ) :
    1/H ≤ (1+2*δ)/H₀ := by
  apply (div_le_div_iff₀ hH hH₀).mpr
  have ht := mul_le_mul_of_nonneg_left (show H₀*(1-δ) ≤ H by nlinarith)
    (show 0 ≤ 1+2*δ by linarith)
  have he := mul_nonneg hδ0 (show 0 ≤ 1-2*δ by linarith)
  have he' := mul_nonneg hH₀.le he
  nlinarith only [ht,he']

theorem exp_sixteen_sub_le_half (h : ℕ) (hh : 17 ≤ h) :
    Real.exp (16-(h:ℝ)) ≤ 1/2 := by
  have hhR : (17:ℝ) ≤ h := by exact_mod_cast hh
  have hm : Real.exp (16-(h:ℝ)) ≤ Real.exp (-1) := Real.exp_le_exp.mpr (by linarith)
  have he := Real.add_one_le_exp (1:ℝ)
  have he0 := Real.exp_pos (1:ℝ)
  have hi : Real.exp (-1) ≤ 1/2 := by
    rw [Real.exp_neg]
    simpa only [one_div] using one_div_le_one_div_of_le (by norm_num : (0:ℝ)<2)
      (show (2:ℝ) ≤ Real.exp 1 by linarith)
  exact hm.trans hi

theorem sieveH_inverse_power (P z h : ℕ) (hP : Squarefree P) (hz : 2 ≤ z)
    (hh : 17 ≤ h) (hpz : ∀ p ∈ P.primeFactors, p ≤ z) :
    1/sieveH P (z^h) ≤ (1+2*Real.exp (16-(h:ℝ)))/fullSieveH P := by
  exact inverse_truncation_bound _ _ _
    (sieveH_pos P (z^h) hP.ne_zero (one_le_pow₀ (by omega : 1≤z)))
    (fullSieveH_pos P hP.ne_zero) (Real.exp_pos _).le (exp_sixteen_sub_le_half h hh)
    (sieveH_tail_power P z h hP hz hpz)

/-- Uniform sieve upper bound, with explicit exponential error and a
conservative level error z^(4h). -/
theorem rough_progression_upper (N q b P z h : ℕ) (hq : 0 < q)
    (hP : Squarefree P) (hcop : q.Coprime P) (hz : 2 ≤ z) (hh : 17 ≤ h)
    (hpz : ∀ p ∈ P.primeFactors, p ≤ z) :
    ((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => n.Coprime P)).card:ℝ) ≤
      ((N:ℝ)/q)*(1+2*Real.exp (16-(h:ℝ)))/fullSieveH P + (z:ℝ)^(4*h) := by
  have hs := selberg_progression_upper N q b P (z^h) hq hP hcop
    (one_le_pow₀ (by omega : 1≤z))
  have hi := mul_le_mul_of_nonneg_left (sieveH_inverse_power P z h hP hz hh hpz)
    (show (0:ℝ) ≤ (N:ℝ)/q by positivity)
  have he : (N:ℝ)/(q*sieveH P (z^h)) = ((N:ℝ)/q)*(1/sieveH P (z^h)) := by ring
  rw [he] at hs
  have he' : (((z^h:ℕ):ℝ)^4) = (z:ℝ)^(4*h) := by
    rw [Nat.cast_pow,← pow_mul,Nat.mul_comm]
  rw [he'] at hs
  have ht : ((N:ℝ)/q)*((1+2*Real.exp (16-(h:ℝ)))/fullSieveH P) =
      ((N:ℝ)/q)*(1+2*Real.exp (16-(h:ℝ)))/fullSieveH P := by ring
  rw [ht] at hi
  linarith

end MissingLinnik

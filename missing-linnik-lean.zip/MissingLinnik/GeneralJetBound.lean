import MissingLinnik.QuadraticDeterminantBound

namespace MissingLinnik.GeneralJet

theorem norm_mapped_jet_det_le {ι : Type*} [Fintype ι] [DecidableEq ι]
    (r s : ι → ℕ) (R S : ℕ) (d : ℤ)
    (f : Zsqrtd d →+* ℂ) (z : ι → Zsqrtd d)
    (j : ι → ℕ) (B : ℝ) (hR : 1 ≤ R) (hr : ∀ i, r i ≤ R) (hB : 1 ≤ B)
    (hz : ∀ c, ‖f (z c)‖ ≤ B) (hw : ∀ c, ‖f (star (z c))‖ ≤ B)
    (hj : ∀ c, j c ≤ S) :
    ‖f ((Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c) (r i) (s i))).det)‖ ≤
      (Fintype.card ι).factorial * ∏ i : ι, (R : ℝ) ^ S * B ^ (r i + s i) := by
  rw [RingHom.map_det]
  apply norm_det_le_factorial_mul_row_bounds
  · intro i; positivity
  · intro i c
    change ‖f (monomialJet (z c) (star (z c)) (j c) (r i) (s i))‖ ≤ _
    rw [map_monomialJet]
    exact norm_derivative_monomial_le R S (r i) (s i) (j c) _ _ B hR
      (hr i) (hj c) hB (hz c) (hw c)

/-- The archimedean determinant estimate with its constants still explicit.
The two embeddings are bounded separately, so this applies to positive and
negative quadratic parameters alike. -/
theorem log_norm_jet_det_le {ι : Type*} [Fintype ι] [DecidableEq ι]
    (r s : ι → ℕ) (R S : ℕ) (d : ℤ) (a : ℂ) (ha : a ^ 2 = d)
    (z : ι → Zsqrtd d) (j : ι → ℕ)
    (B : ℝ) (hR : 1 ≤ R) (hr : ∀ i, r i ≤ R) (hB : 1 ≤ B) (hj : ∀ c, j c ≤ S)
    (hz : ∀ c, ‖quadraticComplexEmbedding d a ha (z c)‖ ≤ B)
    (hw : ∀ c, ‖quadraticComplexEmbedding d (-a) (by simpa using ha) (z c)‖ ≤ B)
    (hD : 0 < ((Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c)
      (r i) (s i))).det).norm.natAbs) :
    Real.log (((Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c)
      (r i) (s i))).det).norm.natAbs : ℝ) ≤
      2 * Real.log ((Fintype.card ι).factorial : ℝ) +
      2 * ∑ i : ι, ((S : ℝ) * Real.log R +
        ((r i + s i : ℕ) : ℝ) * Real.log B) := by
  let Δ := (Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c) (r i) (s i))).det
  let U : ℝ := (Fintype.card ι).factorial * ∏ i : ι, (R : ℝ) ^ S * B ^ (r i + s i)
  have hRp : (0 : ℝ) < R := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hR)
  have hBp : 0 < B := lt_of_lt_of_le zero_lt_one hB
  have hU : 0 < U := by
    apply mul_pos
    · exact_mod_cast Nat.factorial_pos (Fintype.card ι)
    · exact Finset.prod_pos (fun i _ => mul_pos (pow_pos hRp _) (pow_pos hBp _))
  have hplus : ‖quadraticComplexEmbedding d a ha Δ‖ ≤ U := by
    apply norm_mapped_jet_det_le r s R S d _ z j B hR hr hB hz _ hj
    intro c
    simpa only [quadraticComplexEmbedding_star] using hw c
  have hminus : ‖quadraticComplexEmbedding d (-a) (by simpa using ha) Δ‖ ≤ U := by
    apply norm_mapped_jet_det_le r s R S d _ z j B hR hr hB hw _ hj
    intro c
    simpa only [quadraticComplexEmbedding_star, neg_neg] using hz c
  have hDU : (Δ.norm.natAbs : ℝ) ≤ U ^ 2 := by
    rw [quadratic_norm_natAbs_eq d a ha Δ]
    exact (mul_le_mul hplus hminus (norm_nonneg _) hU.le).trans_eq (pow_two U).symm
  have hl : Real.log (Δ.norm.natAbs : ℝ) ≤ 2 * Real.log U := by
    have hh := Real.log_le_log (by exact_mod_cast hD) hDU
    simpa [Real.log_pow] using hh
  have hlogU : Real.log U = Real.log ((Fintype.card ι).factorial : ℝ) +
      ∑ i : ι, ((S : ℝ) * Real.log R +
        ((r i + s i : ℕ) : ℝ) * Real.log B) := by
    dsimp only [U]
    rw [Real.log_mul (by positivity) (by positivity), Real.log_prod]
    · congr 1
      apply Finset.sum_congr rfl
      intro i _
      rw [Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_pow]
    · intro i _; positivity
  rw [hlogU, mul_add] at hl
  exact hl

end MissingLinnik.GeneralJet


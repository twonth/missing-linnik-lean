import MissingLinnik.PrimeLogMoment

namespace MissingLinnik

open MeasureTheory

noncomputable def logDecay (β t : ℝ) : ℝ := Real.exp (-β*Real.log t)

theorem logDecay_pos (β t : ℝ) : 0 < logDecay β t := Real.exp_pos _

theorem logDecay_continuousOn (β x : ℝ) : ContinuousOn (logDecay β) (Set.Icc 1 x) := by
  intro t ht
  have ht0 : t ≠ 0 := by linarith [ht.1]
  unfold logDecay
  fun_prop

theorem logDecay_zero_primitive_deriv (β t : ℝ) (hβ : β ≠ 0) (ht : t ≠ 0) :
    HasDerivAt (fun s : ℝ => -logDecay β s/β) (logDecay β t/t) t := by
  have hh := (((Real.hasDerivAt_log ht).const_mul (-β)).exp).neg.div_const β
  convert hh using 1
  · rfl
  · unfold logDecay
    field_simp <;> ring

theorem logDecay_two_primitive_deriv (β t : ℝ) (hβ : β ≠ 0) (ht : t ≠ 0) :
    HasDerivAt (fun s : ℝ => -logDecay β s*((Real.log s)^2/β+2*Real.log s/β^2+2/β^3))
      ((Real.log t)^2*logDecay β t/t) t := by
  have hl := Real.hasDerivAt_log ht
  have he := ((hl.const_mul (-β)).exp).neg
  have hp := ((hl.pow 2).div_const β).add ((hl.const_mul 2).div_const (β^2))
  have hh := he.mul (hp.add_const (2/β^3))
  convert hh using 1
  · rfl
  · unfold logDecay
    simp only [Pi.neg_apply,Pi.mul_apply,Pi.add_apply,Pi.pow_apply]
    norm_num
    field_simp <;> ring

theorem logDecay_integral_zero (β x : ℝ) (hβ : 0 < β) (hx : 1 ≤ x) :
    (∫ t in Set.Ioc 1 x, logDecay β t/t) ≤ 1/β := by
  have hc : ContinuousOn (fun t : ℝ => logDecay β t/t) (Set.Icc 1 x) := by
    apply (logDecay_continuousOn β x).div continuousOn_id
    intro t ht
    change t ≠ 0
    linarith [ht.1]
  have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (a := 1) (b := x) (fun t ht => logDecay_zero_primitive_deriv β t hβ.ne' (by
      rw [Set.uIcc_of_le hx] at ht; linarith [ht.1]))
    (hc.intervalIntegrable_of_Icc hx)
  rw [intervalIntegral.integral_of_le hx] at hh
  simp only [logDecay,Real.log_one,mul_zero,Real.exp_zero,neg_div,sub_neg_eq_add] at hh
  have hp : 0 ≤ logDecay β x/β := div_nonneg (logDecay_pos β x).le hβ.le
  change 0 ≤ Real.exp (-β*Real.log x)/β at hp
  unfold logDecay
  linarith

theorem logDecay_integral_two (β x : ℝ) (hβ : 0 < β) (hx : 1 ≤ x) :
    (∫ t in Set.Ioc 1 x, (Real.log t)^2*logDecay β t/t) ≤ 2/β^3 := by
  have hc : ContinuousOn (fun t : ℝ => (Real.log t)^2*logDecay β t/t) (Set.Icc 1 x) := by
    intro t ht
    have ht0 : t ≠ 0 := by linarith [ht.1]
    unfold logDecay
    fun_prop
  have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (a := 1) (b := x) (fun t ht => logDecay_two_primitive_deriv β t hβ.ne' (by
      rw [Set.uIcc_of_le hx] at ht; linarith [ht.1]))
    (hc.intervalIntegrable_of_Icc hx)
  rw [intervalIntegral.integral_of_le hx] at hh
  have h1 : logDecay β 1 = 1 := by simp [logDecay]
  rw [h1,Real.log_one] at hh
  norm_num at hh
  have hnon : 0 ≤ logDecay β x*((Real.log x)^2/β+2*Real.log x/β^2+2/β^3) := by
    have hl := Real.log_nonneg hx
    positivity [logDecay_pos β x]
  nlinarith only [hh,hnon]

theorem logDecay_boundary_two (β x : ℝ) (hβ : 0 < β) (hx : 1 ≤ x) :
    (Real.log x)^2*logDecay β x ≤ 4/β^2 := by
  let u := β*Real.log x
  have hu : 0 ≤ u := mul_nonneg hβ.le (Real.log_nonneg hx)
  have he : u/2 ≤ Real.exp (u/2) := by linarith [Real.add_one_le_exp (u/2)]
  have hs := (sq_le_sq₀ (show 0≤u/2 by positivity) (Real.exp_pos (u/2)).le).mpr he
  have hexp : Real.exp (u/2)^2 = Real.exp u := by rw [pow_two,← Real.exp_add]; congr 1; ring
  rw [hexp] at hs
  have ht := mul_le_mul_of_nonneg_right hs (Real.exp_pos (-u)).le
  have hcancel : Real.exp u*Real.exp (-u) = 1 := by rw [← Real.exp_add]; simp
  rw [hcancel] at ht
  apply (le_div_iff₀ (sq_pos_of_pos hβ)).mpr
  dsimp [logDecay,u] at ht ⊢
  have hneg : -(β*Real.log x) = -β*Real.log x := by ring
  rw [hneg] at ht
  nlinarith only [ht]

end MissingLinnik

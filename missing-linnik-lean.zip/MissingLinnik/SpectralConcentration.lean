import MissingLinnik.FiniteFourier
import MissingLinnik.CharacterEnergy

namespace MissingLinnik

open Classical

/-- A quantitative form of the large-real-character step. The coefficients
are normalized to have principal coefficient one. -/
theorem spectral_concentration {C : Type*} [Fintype C]
    (b v : C → ℂ) (c₀ : C) (τ : C → C)
    (hb₀ : b c₀ = 1) (hv₀ : v c₀ = 1)
    (hv : ∀ c, ‖v c‖ ≤ 1)
    (hτ : ∀ c, τ (τ c) = c) (hτ₀ : τ c₀ = c₀)
    (hconj : ∀ c, b (τ c) = star (b c))
    (henergy : ∑ c, ‖b c‖^2 ≤ 201/100)
    (hcube : ‖∑ c, v c * (b c)^3‖ ≤ 1/100) :
    ∃ c, c ≠ c₀ ∧ 19/20 < ‖b c‖ ∧ τ c = c := by
  let s := Finset.univ.erase c₀
  have hs₀ : c₀ ∈ (Finset.univ : Finset C) := Finset.mem_univ _
  have h₂ : ∑ c ∈ s, ‖b c‖^2 ≤ 101/100 := by
    have hh := Finset.sum_erase_add (s := Finset.univ) (fun c => ‖b c‖^2) hs₀
    simp only [hb₀, norm_one, one_pow] at hh
    dsimp only [s]
    linarith
  have h₃ : 99/100 ≤ ∑ c ∈ s, ‖b c‖^3 := by
    have he := Finset.sum_erase_add (s := Finset.univ) (fun c => v c * (b c)^3) hs₀
    simp only [hb₀, hv₀, one_pow, mul_one] at he
    have hnorm : ‖∑ c ∈ s, v c * (b c)^3‖ ≤ ∑ c ∈ s, ‖b c‖^3 := by
      apply (norm_sum_le _ _).trans
      apply Finset.sum_le_sum
      intro c _
      rw [norm_mul, norm_pow]
      exact mul_le_of_le_one_left (by positivity) (hv c)
    have htri := norm_sub_le (∑ c, v c * (b c)^3) (∑ c ∈ s, v c * (b c)^3)
    have hone : (∑ c, v c * (b c)^3) - (∑ c ∈ s, v c * (b c)^3) = 1 := by
      change (∑ c, v c * (b c)^3) - (∑ c ∈ Finset.univ.erase c₀, v c * (b c)^3) = 1
      rw [← he]
      ring
    rw [hone, norm_one] at htri
    linarith
  have hex : ∃ c ∈ s, 19/20 < ‖b c‖ := by
    by_contra! hh
    have hterm : ∀ c ∈ s, ‖b c‖^3 ≤ (19/20)*‖b c‖^2 := by
      intro c hc
      nlinarith [mul_le_mul_of_nonneg_right (hh c hc) (sq_nonneg ‖b c‖)]
    have hsum := Finset.sum_le_sum hterm
    rw [← Finset.mul_sum] at hsum
    linarith
  obtain ⟨c, hc, hlarge⟩ := hex
  have hne : c ≠ c₀ := (Finset.mem_erase.mp hc).1
  refine ⟨c, hne, hlarge, ?_⟩
  by_contra hnotfixed
  have hτne : τ c ≠ c₀ := by
    intro hh
    have := congrArg τ hh
    rw [hτ, hτ₀] at this
    exact hne this
  have hsub : ({c, τ c} : Finset C) ⊆ s := by
    intro i hi
    simp only [Finset.mem_insert, Finset.mem_singleton] at hi
    rcases hi with rfl | rfl
    · exact hc
    · exact Finset.mem_erase.mpr ⟨hτne, Finset.mem_univ _⟩
  have hp := Finset.sum_le_sum_of_subset_of_nonneg (f := fun c => ‖b c‖^2) hsub
    (fun i _ _ => sq_nonneg ‖b i‖)
  simp only [Finset.sum_pair (Ne.symm hnotfixed), hconj, norm_star] at hp
  nlinarith [sq_nonneg (‖b c‖ - 19/20)]

end MissingLinnik

import MissingLinnik.JetDeterminant
import MissingLinnik.VanDijkMinor

namespace MissingLinnik.Triangle

/-- The triangular monomial region from Section 3 of the uploaded note. -/
def Row (L Y S : ℕ) := {i : Fin L × Fin S // i.1.val + Y*i.2.val < L}

instance (L Y S : ℕ) : Fintype (Row L Y S) := inferInstanceAs (Fintype {i : Fin L × Fin S // _})
instance (L Y S : ℕ) : DecidableEq (Row L Y S) := inferInstanceAs (DecidableEq {i : Fin L × Fin S // _})

theorem step_closed (L Y p r s : ℕ) (hp : Y ≤ p) (hpr : p ≤ r)
    (hrow : r+Y*s < L) : (r-p)+Y*(s+1) < L := by
  have he : r-p+p = r := Nat.sub_add_cancel hpr
  nlinarith

theorem rowDifference_eq_sum {K : Type*} [CommRing K]
    (L Y S p h r s : ℕ) (B : ℕ → ℕ → K)
    (hcover : L ≤ Y*S) (hp : Y ≤ p) (hpr : p*h ≤ r)
    (hrow : r+Y*s < L) :
    rowDifference p B h r s =
      ∑ i : Row L Y S, rowDifferenceCoeff p h r s i.val.1.val i.val.2.val *
        B i.val.1.val i.val.2.val := by
  classical
  induction h generalizing r s with
  | zero =>
    have hr : r < L := by omega
    have hs : s < S := by nlinarith
    let i : Row L Y S := ⟨(⟨r,hr⟩,⟨s,hs⟩),hrow⟩
    simp only [rowDifference, rowDifferenceCoeff]
    rw [Finset.sum_eq_single i]
    · simp [i]
    · intro j _ hj
      have hn : ¬(r=j.val.1.val ∧ s=j.val.2.val) := by
        rintro ⟨h1,h2⟩
        apply hj
        apply Subtype.ext
        exact Prod.ext (Fin.ext h1.symm) (Fin.ext h2.symm)
      simp [hn]
    · simp
  | succ h ih =>
    have hpr' : p*h ≤ r := by nlinarith
    have hpR : p ≤ r := by nlinarith
    have hpr'' : p*h ≤ r-p := by rw [Nat.mul_succ] at hpr; omega
    change rowDifference p B h r s - rowDifference p B h (r-p) (s+1) = _
    rw [ih r s hpr' hrow, ih (r-p) (s+1) hpr''
      (step_closed L Y p r s hp hpR hrow), ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    simp only [rowDifferenceCoeff, rowDifference]
    ring

/-- Unlike the rectangular argument, every row can be transformed. -/
theorem det_rowDifference {K : Type*} [CommRing K]
    (L Y S p : ℕ) (B : ℕ → ℕ → Row L Y S → K)
    (hcover : L ≤ Y*S) (hp : Y ≤ p) (hp0 : 0 < p) :
    (Matrix.of (fun i c : Row L Y S => rowDifference p (fun r s => B r s c)
      (i.val.1.val / p) i.val.1.val i.val.2.val)).det =
    (Matrix.of (fun i c : Row L Y S => B i.val.1.val i.val.2.val c)).det := by
  classical
  let U : Matrix (Row L Y S) (Row L Y S) K := fun i j =>
    rowDifferenceCoeff p (i.val.1.val/p) i.val.1.val i.val.2.val j.val.1.val j.val.2.val
  have hr (i : Row L Y S) : p*(i.val.1.val/p) ≤ i.val.1.val := Nat.mul_div_le _ _
  have hU : U.det = 1 := by
    apply det_eq_one_of_degree_lower U (fun i => i.val.1.val)
    · intro i
      simp [U, rowDifferenceCoeff_at_or_above p _ _ _ _ _ hp0 (hr i) le_rfl]
    · intro i j hij hdeg
      change rowDifferenceCoeff p _ _ _ _ _ = 0
      rw [rowDifferenceCoeff_at_or_above p _ _ _ _ _ hp0 (hr i) hdeg]
      split_ifs with he
      · exact (hij (Subtype.ext (Prod.ext (Fin.ext he.1) (Fin.ext he.2)))).elim
      · rfl
  have heq : Matrix.of (fun i c : Row L Y S => rowDifference p (fun r s => B r s c)
      (i.val.1.val/p) i.val.1.val i.val.2.val) =
      U * Matrix.of (fun i c : Row L Y S => B i.val.1.val i.val.2.val c) := by
    apply Matrix.ext
    intro i c
    exact rowDifference_eq_sum L Y S p _ _ _ (fun r s => B r s c)
      hcover hp (hr i) i.property
  rw [heq, Matrix.det_mul, hU, one_mul]

theorem prime_power_dvd_jet_det {K : Type*} [CommRing K]
    (L Y S p : ℕ) (z w : Row L Y S → K) (j : Row L Y S → ℕ)
    (hcover : L ≤ Y*S) (hp : Y ≤ p) (hp0 : 0 < p)
    (hf : ∀ c, (p:K) ∣ z c ^ p - w c) :
    (p:K) ^ (∑ i : Row L Y S, i.val.1.val/p) ∣
      (Matrix.of (fun i c : Row L Y S =>
        monomialJet (z c) (w c) (j c) i.val.1.val i.val.2.val)).det := by
  rw [← det_rowDifference L Y S p
    (fun r s c => monomialJet (z c) (w c) (j c) r s) hcover hp hp0]
  apply row_prime_powers_dvd_det
  intro i c
  exact rowDifference_monomialJet_dvd p _ _ _ _ _ _ (Nat.mul_div_le _ _) (hf c)

/-- The same finite-field root count proves independence on the triangular
region by restricting the independent rectangle containing it. -/
theorem exists_integer_minor (L Y S M : ℕ) (d : ℤ) [Fact L.Prime]
    [Fact (¬ IsSquare (d : ZMod L))] (hL2 : L ≠ 2) (hd : legendreSym L d = -1)
    (hM : M ≤ L) (hcard : L ≤ M*M) (hS : 0 < S) (hSL : S < L) :
    ∃ f : Row L Y S → ((Fin M × Fin M) × Fin S),
      quadraticReduction L d
        (Matrix.of (fun i j : Row L Y S =>
          VanDijk.rowVector L S (VanDijk.integerGrid M d) i.val (f j))).det ≠ 0 := by
  classical
  have hLI := (VanDijk.grid_rows_linearIndependent L M L S d hL2 hd hM hcard
    le_rfl hS hSL).comp (fun i : Row L Y S => i.val) Subtype.val_injective
  obtain ⟨f,hf⟩ := exists_nonzero_minor
    (fun i : Row L Y S => VanDijk.rowVector L S (VanDijk.gridPoint L M d) i.val) hLI
  refine ⟨f,?_⟩
  rw [RingHom.map_det]
  convert hf using 1
  congr 1
  apply Matrix.ext
  intro i j
  exact VanDijk.reduction_row L M L S d i.val (f j)

end MissingLinnik.Triangle

import MissingLinnik.LinnikKernel
import MissingLinnik.RealCharacterExtraction

namespace MissingLinnik

open Classical

/-- The final contradiction for actual Dirichlet characters. The hypotheses
are normalized versions of the analytic estimates still needed for Linnik.
In particular this theorem does not assert that prime weights satisfy them. -/
theorem residue_linnik_contradiction {q : ℕ} [NeZero q]
    (w u : (ZMod q)ˣ → ℝ) (v : (ZMod q)ˣ → (ZMod q)ˣ → ℝ)
    (a : (ZMod q)ˣ)
    (hw : ∀ i, 0 ≤ w i) (hmass : ∑ i, w i = 1)
    (hu : ∀ i, 0 ≤ u i ∧ u i ≤ w i)
    (hv : ∀ i j, 0 ≤ v i j ∧ v i j ≤ w i * w j)
    (hmax : ∀ i, q.totient * w i ≤ 201/100)
    (hcube : ‖∑ χ : DirichletCharacter ℂ q,
      star (χ (a : ZMod q)) * (residueCoefficient w χ)^3‖ ≤ 1/100)
    (htotal : 9/10 ≤ (∑ i, u i) + (∑ i, ∑ j, v i j))
    (hsigned : ∀ ψ : DirichletCharacter ℝ q, ψ ≠ 1 →
      ((∑ i, u i * ψ (i : ZMod q)) +
       (∑ i, ∑ j, v i j * (ψ (i : ZMod q) * ψ (j : ZMod q)))) ≤ 1/10)
    (hanti : ∀ ψ : DirichletCharacter ℝ q, ψ ≠ 1 →
      (∑ i ∈ Finset.univ.filter (fun i : (ZMod q)ˣ => ψ (i : ZMod q) = -1), w i) ≤ 3/4) :
    False := by
  apply finite_linnik_contradiction (fun χ i => χ (i : ZMod q)) w u v
    (fun χ => star (χ (a : ZMod q))) (1 : DirichletCharacter ℂ q) star
    hw hmass hu hv
  · simpa only [residueCoefficient, hmass, Complex.ofReal_one] using residueCoefficient_principal w
  · simp
  · intro χ
    rw [norm_star]
    exact (Complex.norm_eq_one_of_mem_rootsOfUnity (χ.apply_mem_rootsOfUnity a)).le
  · exact star_star
  · exact star_one _
  · intro χ i
    exact MulChar.star_apply χ (i : ZMod q)
  · simpa only [residueCoefficient, hmass, mul_one] using residue_energy_bound w (201/100) hw hmax
  · exact hcube
  · exact htotal
  · intro χ hχ hfixed
    let ψ := realCharacterOfStarFixed χ hfixed
    have hψ : ψ ≠ 1 := realCharacterOfStarFixed_nonprincipal χ hfixed hχ
    refine ⟨fun i => ψ (i : ZMod q), ?_, ?_, hsigned ψ hψ, hanti ψ hψ⟩
    · intro i
      rcases real_character_quadratic ψ (i : ZMod q) with hz | hp | hn
      · exact ((MulChar.apply_ne_zero_iff.mpr i.isUnit) hz).elim
      · exact Or.inl hp
      · exact Or.inr hn
    · intro i
      exact (realCharacterOfStarFixed_cast χ hfixed (i : ZMod q)).symm

end MissingLinnik

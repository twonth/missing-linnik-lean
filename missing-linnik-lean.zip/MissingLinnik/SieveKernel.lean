import MissingLinnik.RankinSieve

namespace MissingLinnik

open Finset

theorem inverse_prime_factor_le_exp (p : ℕ) (hp : 2 ≤ p) :
    (1-1/(p:ℝ))⁻¹ ≤ Real.exp (2/(p:ℝ)) := by
  have hpR : (2:ℝ) ≤ p := by exact_mod_cast hp
  have hp0 : (0:ℝ) < p := by linarith
  have hp1 : (0:ℝ) < p-1 := by linarith
  have hi : 1/((p:ℝ)-1) ≤ 2/p := by
    apply (div_le_div_iff₀ hp1 hp0).mpr
    nlinarith
  have he : (1-1/(p:ℝ))⁻¹ = 1+1/((p:ℝ)-1) := by field_simp; ring
  rw [he]
  calc
    _ ≤ 1+2/(p:ℝ) := by linarith only [hi]
    _ ≤ _ := by linarith [Real.add_one_le_exp (2/(p:ℝ))]

/-- A deliberately coarse Euler-product ratio bound; its exponential form
is sufficient when combined with the faster Rankin decay. -/
theorem prime_interval_product_bound (P : Finset ℕ) (p z : ℕ) (hp : 2 ≤ p)
    (hz : p ≤ z) (hprime : ∀ l ∈ P, l.Prime)
    (hlower : ∀ l ∈ P, p ≤ l) (hupper : ∀ l ∈ P, l ≤ z) :
    (∏ l ∈ P, (1-1/(l:ℝ))⁻¹) ≤ Real.exp (16*Real.log z/Real.log p) := by
  have hlp : 0 < Real.log (p:ℝ) := Real.log_pos (by exact_mod_cast (show 1<p by omega))
  have hmass := prime_log_mass_le_eight_log P z (hp.trans hz) hprime hupper
  have hs : (∑ l ∈ P, 2/(l:ℝ)) ≤ (2/Real.log p)*(∑ l ∈ P, Real.log l/l) := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro l hl
    have hl0 : (0:ℝ) < l := by exact_mod_cast (hprime l hl).pos
    have hlog : Real.log (p:ℝ) ≤ Real.log l :=
      Real.log_le_log (by exact_mod_cast (show 0<p by omega)) (by exact_mod_cast hlower l hl)
    have hh : (2:ℝ) ≤ (2/Real.log p)*Real.log l := by
      apply (mul_le_mul_iff_right₀ hlp).mp
      field_simp
      linarith
    have ht := div_le_div_of_nonneg_right hh hl0.le
    convert ht using 1 <;> ring
  have hb : (∑ l ∈ P, 2/(l:ℝ)) ≤ 16*Real.log z/Real.log p := by
    have ht := mul_le_mul_of_nonneg_left hmass (show 0 ≤ 2/Real.log (p:ℝ) by positivity)
    calc
      _ ≤ (2/Real.log p)*(∑ l ∈ P, Real.log l/l) := hs
      _ ≤ (2/Real.log p)*(8*Real.log z) := ht
      _ = _ := by ring
  calc
    _ ≤ ∏ l ∈ P, Real.exp (2/(l:ℝ)) := by
      apply Finset.prod_le_prod₀
      · intro l hl
        have hh : (1:ℝ) < l := by exact_mod_cast (hprime l hl).one_lt
        have hi : 1/(l:ℝ) < 1 := (div_lt_one (by linarith)).mpr (by linarith)
        exact inv_nonneg.mpr (by linarith)
      · intro l hl; exact inverse_prime_factor_le_exp l (hprime l hl).two_le
    _ = Real.exp (∑ l ∈ P, 2/(l:ℝ)) := by rw [Real.exp_sum]
    _ ≤ _ := Real.exp_le_exp.mpr hb

theorem exp_decay_kernel (a u : ℝ) (ha : 1 ≤ a) (hu : 1 ≤ u) :
    u*Real.exp (-a*u) ≤ Real.exp (-a) := by
  have he : u ≤ Real.exp (a*(u-1)) := by
    have ht := Real.add_one_le_exp (a*(u-1))
    have hm := mul_nonneg (show 0 ≤ a-1 by linarith) (show 0 ≤ u-1 by linarith)
    nlinarith
  have ht := mul_le_mul_of_nonneg_right he (Real.exp_pos (-a*u)).le
  rw [← Real.exp_add] at ht
  convert ht using 1 <;> congr 1 <;> ring

theorem prime_rankin_kernel_sum (P : Finset ℕ) (z : ℕ) (hz : 2 ≤ z)
    (hprime : ∀ p ∈ P, p.Prime) (hupper : ∀ p ∈ P, p ≤ z)
    (a : ℝ) (ha : 1 ≤ a) :
    (∑ p ∈ P, (1/(p:ℝ))*Real.exp (-a*(Real.log z/Real.log p))) ≤
      8*Real.exp (-a) := by
  have hlz : 0 < Real.log (z:ℝ) := Real.log_pos (by exact_mod_cast (show 1<z by omega))
  have hs : (∑ p ∈ P, (1/(p:ℝ))*Real.exp (-a*(Real.log z/Real.log p))) ≤
      (Real.exp (-a)/Real.log z)*(∑ p ∈ P, Real.log p/p) := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro p hp
    have hp0 : (0:ℝ) < p := by exact_mod_cast (hprime p hp).pos
    have hlp : 0 < Real.log (p:ℝ) := Real.log_pos (by exact_mod_cast (hprime p hp).one_lt)
    have hlog : Real.log (p:ℝ) ≤ Real.log z := Real.log_le_log hp0 (by exact_mod_cast hupper p hp)
    have hu : 1 ≤ Real.log (z:ℝ)/Real.log p := (le_div_iff₀ hlp).mpr (by simpa)
    have ht := exp_decay_kernel a (Real.log z/Real.log p) ha hu
    apply (mul_le_mul_iff_right₀ (show 0 < (p:ℝ)*Real.log z by positivity)).mp
    have ht' := mul_le_mul_of_nonneg_right ht hlp.le
    field_simp at ht' ⊢
    nlinarith only [ht']
  have hm := mul_le_mul_of_nonneg_left (prime_log_mass_le_eight_log P z hz hprime hupper)
    (show 0 ≤ Real.exp (-a)/Real.log z by positivity)
  calc
    _ ≤ _ := hs
    _ ≤ (Real.exp (-a)/Real.log z)*(8*Real.log z) := hm
    _ = _ := by field_simp

end MissingLinnik


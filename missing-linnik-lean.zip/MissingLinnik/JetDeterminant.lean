import MissingLinnik.RowDifference

namespace MissingLinnik

noncomputable def monomialJet {K : Type*} [CommRing K]
    (z w : K) (j r s : ℕ) : K :=
  (Polynomial.derivative^[j] ((Polynomial.X : Polynomial K) ^ r)).eval z * w ^ s

theorem map_monomialJet {K L : Type*} [CommRing K] [CommRing L]
    (f : K →+* L) (z w : K) (j r s : ℕ) :
    f (monomialJet z w j r s) = monomialJet (f z) (f w) j r s := by
  unfold monomialJet
  rw [map_mul, map_pow]
  congr 1
  rw [← Polynomial.eval_map_apply, ← Polynomial.iterate_derivative_map]
  simp

theorem rowDifference_monomialJet {K : Type*} [CommRing K]
    (p h r s j : ℕ) (z w : K) :
    rowDifference p (monomialJet z w j) h r s =
      (Polynomial.derivative^[j]
        (rowDifference p (fun r s => (Polynomial.X : Polynomial K) ^ r * Polynomial.C (w ^ s))
          h r s)).eval z := by
  induction h generalizing r s with
  | zero =>
    simp only [rowDifference, monomialJet]
    rw [mul_comm (Polynomial.X ^ r), Polynomial.iterate_derivative_C_mul]
    simp [mul_comm]
  | succ h ih =>
    simp only [rowDifference, Polynomial.iterate_derivative_sub, Polynomial.eval_sub, ih]

theorem rowDifference_monomialJet_dvd {K : Type*} [CommRing K]
    (p h r s j : ℕ) (z w : K) (hr : p * h ≤ r) (hf : (p : K) ∣ z ^ p - w) :
    (p : K) ^ h ∣ rowDifference p (monomialJet z w j) h r s := by
  rw [rowDifference_monomialJet, rowDifference_polynomial p h r s w hr, mul_assoc]
  exact modified_row_derivatives_dvd p z w hf _ h j

/-- Both determinant arguments use this exact arithmetic statement. The
chosen row exponents may vary; only the rectangular support conditions matter. -/
theorem prime_power_dvd_jet_determinant {K : Type*} [CommRing K]
    (p R S : ℕ) (z w : (Fin R × Fin S) → K) (j : (Fin R × Fin S) → ℕ)
    (h : (Fin R × Fin S) → ℕ) (hp : 0 < p)
    (hr : ∀ i, p * h i ≤ i.1.val) (hs : ∀ i, i.2.val + h i < S)
    (hf : ∀ c, (p : K) ∣ z c ^ p - w c) :
    (p : K) ^ (∑ i, h i) ∣
      (Matrix.of (fun i c => monomialJet (z c) (w c) (j c) i.1.val i.2.val)).det := by
  let B := fun r s c => monomialJet (z c) (w c) (j c) r s
  rw [← det_rowDifference p R S B h hp hr hs]
  apply row_prime_powers_dvd_det
  intro i c
  exact rowDifference_monomialJet_dvd p (h i) i.1.val i.2.val (j c)
    (z c) (w c) (hr i) (hf c)

end MissingLinnik

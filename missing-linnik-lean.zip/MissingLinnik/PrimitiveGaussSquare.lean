import Mathlib.NumberTheory.DirichletCharacter.GaussSum
import Mathlib.Tactic.Ring

namespace MissingLinnik

/-- Fourier inversion at 1, over a general finite commutative ring. -/
theorem gauss_fourier_at_one {R K : Type*} [CommRing R] [Fintype R]
    [CommRing K] [IsDomain K] (χ : MulChar R K) (e : AddChar R K)
    (he : e.IsPrimitive) :
    (∑ t : R, gaussSum χ (e.mulShift t)*e (-t)) = (Fintype.card R:K) := by
  classical
  calc
    _ = ∑ t : R, ∑ u : R, χ u * e (t*u) * e (-t) := by
      simp only [gaussSum, AddChar.mulShift_apply, Finset.sum_mul]
    _ = ∑ u : R, χ u * ∑ t : R, e (t*(u-1)) := by
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro u _
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro t _
      rw [mul_assoc, ← e.map_add_eq_mul]
      congr 2
      ring
    _ = (Fintype.card R:K) := by
      simp_rw [AddChar.sum_mulShift _ he, sub_eq_zero]
      simp

/-- The quadratic Gauss-square identity for primitive Dirichlet characters
of arbitrary modulus, rather than only characters of prime modulus. -/
theorem primitive_gauss_square {N : ℕ} [NeZero N]
    {K : Type*} [CommRing K] [IsDomain K]
    (χ : DirichletCharacter K N) (hχ : χ.IsPrimitive) (hquad : χ.IsQuadratic)
    (e : AddChar (ZMod N) K) (he : e.IsPrimitive) :
    gaussSum χ e ^ 2 = χ (-1)*(N:K) := by
  classical
  have hfourier := gauss_fourier_at_one χ e he
  have hshift (t : ZMod N) : gaussSum χ (e.mulShift t) = χ t*gaussSum χ e := by
    simpa only [hquad.inv] using gaussSum_mulShift_of_isPrimitive e hχ t
  have hneg : (∑ t : ZMod N, χ t*e (-t)) = χ (-1)*gaussSum χ e := by
    have hh := hshift (-1)
    simpa only [gaussSum, AddChar.mulShift_apply, neg_one_mul] using hh
  have hprod : χ (-1)*(gaussSum χ e)^2 = (N:K) := by
    simp_rw [hshift] at hfourier
    have hs : (∑ t : ZMod N, χ t*gaussSum χ e*e (-t)) =
        gaussSum χ e * (∑ t : ZMod N, χ t*e (-t)) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro t _
      ring
    rw [hs,hneg] at hfourier
    simpa [ZMod.card, pow_two, mul_comm, mul_left_comm, mul_assoc] using hfourier
  have hsign : χ (-1)*χ (-1)=1 := by rw [← map_mul]; simp
  have hh := congrArg (fun z : K => χ (-1)*z) hprod
  simpa only [← mul_assoc,hsign,one_mul] using hh

end MissingLinnik

import MissingLinnik.VanDijkGrid
import Mathlib.LinearAlgebra.LinearIndependent.Defs

namespace MissingLinnik.VanDijk

open scoped BigOperators QuadraticAlgebra

theorem iterate_derivative_mul_of_right_derivative_zero {K : Type*} [CommRing K]
    (P Q : Polynomial K) (hQ : Q.derivative = 0) (j : ℕ) :
    Polynomial.derivative^[j] (P * Q) = (Polynomial.derivative^[j] P) * Q := by
  induction j with
  | zero => rfl
  | succ j ih =>
    rw [Function.iterate_succ_apply', ih, Polynomial.derivative_mul, hQ, mul_zero,
      add_zero, Function.iterate_succ_apply']

theorem iterate_derivative_encoded_eval {K : Type*} [Field K]
    (p : ℕ) [CharP K p] (R S : ℕ) (c : Fin R × Fin S → K)
    (a w : K) (ha : a ^ p = w) (j : ℕ) :
    (Polynomial.derivative^[j] (encodedPolynomial p R S c)).eval a =
      ∑ i, c i * ((Polynomial.derivative^[j]
        ((Polynomial.X : Polynomial K) ^ i.1.val)).eval a * w ^ i.2.val) := by
  classical
  rw [encodedPolynomial, Polynomial.iterate_derivative_sum, Polynomial.eval_finsetSum]
  apply Finset.sum_congr rfl
  intro i _
  rw [← Polynomial.C_mul_X_pow_eq_monomial, Polynomial.iterate_derivative_C_mul,
    Polynomial.eval_mul, Polynomial.eval_C]
  congr 1
  have hz : Polynomial.derivative ((Polynomial.X : Polynomial K) ^ (p * i.2.val)) = 0 := by
    simp [Polynomial.derivative_X_pow, Nat.cast_mul, CharP.cast_eq_zero]
  rw [pow_add, iterate_derivative_mul_of_right_derivative_zero _ _ hz,
    Polynomial.eval_mul, Polynomial.eval_pow, Polynomial.eval_X, pow_mul, ha]

noncomputable def rowVector {K α : Type*} [CommRing K] [Star K]
    (R S : ℕ) (point : α → K) (i : Fin R × Fin S) (col : α × Fin S) : K :=
  (Polynomial.derivative^[col.2.val]
    ((Polynomial.X : Polynomial K) ^ i.1.val)).eval (point col.1) *
      (star (point col.1)) ^ i.2.val

/-- Full row independence modulo the inert prime, following van Dijk's
Frobenius/root-counting argument. The actual rectangular matrix entries are
the partial derivatives of z^r w^s at the grid points. -/
theorem grid_rows_linearIndependent (p M R S : ℕ) (d : ℤ) [Fact p.Prime]
    [Fact (¬ IsSquare (d : ZMod p))] (hp2 : p ≠ 2) (hd : legendreSym p d = -1)
    (hM : M ≤ p) (hcard : p ≤ M * M) (hR : R ≤ p)
    (hS : 0 < S) (hSp : S < p) :
    LinearIndependent (QuadraticAlgebra (ZMod p) (d : ZMod p) 0)
      (rowVector R S (gridPoint p M d)) := by
  classical
  let K := QuadraticAlgebra (ZMod p) (d : ZMod p) 0
  let : CharP K p := charP_of_injective_algebraMap
    QuadraticAlgebra.algebraMap_injective p
  rw [Fintype.linearIndependent_iff]
  intro c hc
  apply grid_coefficients_zero p M R S d hM hcard hR hS hSp c
  intro a j hj
  rw [iterate_derivative_encoded_eval p R S c _ _
    (quadratic_frobenius_eq_star p hp2 d hd _) j]
  have hh := congrFun hc (a, ⟨j, hj⟩)
  simpa only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul, rowVector, Pi.zero_apply]
    using hh

end MissingLinnik.VanDijk

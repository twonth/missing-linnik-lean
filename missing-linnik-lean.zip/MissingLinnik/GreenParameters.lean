import MissingLinnik.GridSizeEstimates

namespace MissingLinnik.Green

theorem grid_parameter_conditions (k m : ℕ) (hk : 8 ≤ k) (hm : 64 ≤ m) :
    2*(2*((k^2*m).sqrt+1)) ≤ k*m ∧
      2*(k^2*m)*(k*m) + (k*m)*(k^2*m+k*m) <
        ((2*((k^2*m).sqrt+1))*(2*((k^2*m).sqrt+1)))*(k*m) := by
  have hsq := Nat.sqrt_le' (k^2*m)
  have hsucc := Nat.lt_succ_sqrt' (k^2*m)
  have hmSq : 64*m ≤ m^2 := by nlinarith
  have hscaled := Nat.mul_le_mul_left (k^2) hmSq
  have h8 : 8*(k^2*m).sqrt ≤ k*m := by
    apply (mul_self_le_mul_self_iff (Nat.zero_le _) (Nat.zero_le _)).mpr
    nlinarith
  have hs1 : 1 ≤ (k^2*m).sqrt := by
    apply Nat.le_sqrt'.mpr
    nlinarith
  have hS : 0 < k*m := by positivity
  have hSR : k*m ≤ k^2*m := by nlinarith
  constructor
  · omega
  · have hbase : 3*(k^2*m)+k*m <
        (2*((k^2*m).sqrt+1))*(2*((k^2*m).sqrt+1)) := by
      simp only [Nat.succ_eq_add_one] at hsucc
      nlinarith
    have hh := Nat.mul_lt_mul_of_pos_right hbase hS
    nlinarith

theorem doubled_grid_archimedean_bound (R : ℕ) (hR : 2 ≤ R) (q : ℝ) (hq : 1 ≤ q)
    (a : ℂ) (ha : ‖a‖^2 ≤ q) :
    1 ≤ 8*Real.sqrt R*Real.sqrt q ∧
      (((2*(R.sqrt+1) : ℕ) : ℝ) * (1+‖a‖) ≤ 8*Real.sqrt R*Real.sqrt q) ∧
      Real.log (8*Real.sqrt R*Real.sqrt q) =
        Real.log R/2 + Real.log q/2 + Real.log 8 := by
  obtain ⟨hB,hM,_⟩ := grid_archimedean_bound R hR q hq a ha
  refine ⟨by nlinarith, ?_, ?_⟩
  · push_cast at hM ⊢
    nlinarith
  · have hp : (0:ℝ) < R := by exact_mod_cast (show 0 < R by omega)
    have hq0 : 0 < q := by linarith
    rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by norm_num) (by positivity),
      Real.log_sqrt hp.le, Real.log_sqrt hq0.le]
    ring

end MissingLinnik.Green

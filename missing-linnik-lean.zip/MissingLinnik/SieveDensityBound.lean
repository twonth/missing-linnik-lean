import MissingLinnik.RoughSieve
import Mathlib.NumberTheory.EulerProduct.Basic
import Mathlib.NumberTheory.Harmonic.Bounds

namespace MissingLinnik

open Finset

theorem harmonic_le_inverse_sieveDensity (z : ℕ) :
    (harmonic z:ℝ) ≤ (sieveDensity (Nat.primesLE z))⁻¹ := by
  classical
  let f : ℕ →* ℝ := {
    toFun := fun n => (n:ℝ)⁻¹
    map_one' := by norm_num
    map_mul' := by intro a b; simp only [Nat.cast_mul,mul_inv] }
  have hf {p : ℕ} (hp : p.Prime) : ‖f p‖ < 1 := by
    change ‖(p:ℝ)⁻¹‖ < 1
    rw [Real.norm_of_nonneg (by positivity)]
    exact (inv_lt_one₀ (by exact_mod_cast hp.pos)).mpr (by exact_mod_cast hp.one_lt)
  have hs := EulerProduct.summable_and_hasSum_factoredNumbers_prod_filter_prime_geometric
    (f := f) hf (Nat.primesLE z)
  let e : {n : ℕ // n ∈ Finset.Icc 1 z} ↪ Nat.factoredNumbers (Nat.primesLE z) := {
    toFun := fun n => ⟨n.val,Nat.mem_factoredNumbers_of_primeFactors_subset
      (by have := (Finset.mem_Icc.mp n.property).1; omega) (by
        intro p hp
        exact Nat.mem_primesLE.mpr
          ⟨(Nat.le_of_dvd (by have := (Finset.mem_Icc.mp n.property).1; omega)
            (Nat.dvd_of_mem_primeFactors hp)).trans (Finset.mem_Icc.mp n.property).2,
           Nat.prime_of_mem_primeFactors hp⟩)⟩
    inj' := by
      intro a b hab
      have heq : a.val = b.val := congrArg (fun n : Nat.factoredNumbers (Nat.primesLE z) => n.val) hab
      exact Subtype.ext heq }
  let S := (Finset.Icc 1 z).attach.map e
  have hb := Summable.sum_le_tsum S (fun n hn => show (0:ℝ) ≤ f n by dsimp [f]; positivity) hs.2.summable
  rw [hs.2.tsum_eq] at hb
  have he : (∑ n ∈ S, f n) = (harmonic z:ℝ) := by
    rw [show S = (Finset.Icc 1 z).attach.map e by rfl,Finset.sum_map]
    change (∑ n ∈ (Finset.Icc 1 z).attach, (n.val:ℝ)⁻¹) = (harmonic z:ℝ)
    rw [Finset.sum_attach (Finset.Icc 1 z) (fun n : ℕ => (n:ℝ)⁻¹)]
    simp only [harmonic_eq_sum_Icc,Rat.cast_sum,Rat.cast_inv,Rat.cast_natCast]
  have hp : (Nat.primesLE z).filter Nat.Prime = Nat.primesLE z :=
    Finset.filter_true_of_mem (fun p hp => (Nat.mem_primesLE.mp hp).2)
  rw [he,hp] at hb
  simpa only [f,MonoidHom.coe_mk,OneHom.coe_mk,sieveDensity,one_div,Finset.prod_inv_distrib] using hb

/-- The upper Mertens product bound needed for rough-number counts follows
already from the finite Euler product and the harmonic sum. -/
theorem sieveDensity_le_inv_log (z : ℕ) (hz : 2 ≤ z) :
    sieveDensity (Nat.primesLE z) ≤ (Real.log (z:ℝ))⁻¹ := by
  have hlz : 0 < Real.log (z:ℝ) := Real.log_pos (by exact_mod_cast (show 1<z by omega))
  have hv : 0 < sieveDensity (Nat.primesLE z) :=
    sieveDensity_pos _ (fun p hp => (Nat.mem_primesLE.mp hp).2)
  have hh : Real.log (z:ℝ) ≤ (sieveDensity (Nat.primesLE z))⁻¹ := by
    apply (log_le_harmonic_floor (z:ℝ) (by positivity)).trans
    simpa only [Nat.floor_natCast] using harmonic_le_inverse_sieveDensity z
  have ht := mul_le_mul_of_nonneg_right hh hv.le
  rw [inv_mul_cancel₀ hv.ne'] at ht
  rw [← one_div]
  apply (le_div_iff₀ hlz).mpr
  nlinarith only [ht]

end MissingLinnik


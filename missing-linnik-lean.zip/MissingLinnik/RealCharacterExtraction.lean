import MissingLinnik.DirichletFourier
import MissingLinnik.RealCharacterLift

namespace MissingLinnik

theorem star_fixed_character_im {q : ℕ} (χ : DirichletCharacter ℂ q)
    (hχ : star χ = χ) (x : ZMod q) : (χ x).im = 0 := by
  have hh := congrArg (fun c : DirichletCharacter ℂ q => (c x).im) hχ
  simp only [MulChar.star_apply,RCLike.star_def,Complex.conj_im] at hh
  linarith

/-- The actual real character obtained from the conjugation-fixed coefficient
selected by the manuscript's energy argument. -/
noncomputable def realCharacterOfStarFixed {q : ℕ}
    (χ : DirichletCharacter ℂ q) (hχ : star χ = χ) : DirichletCharacter ℝ q where
  toFun := fun x => (χ x).re
  map_one' := by simp
  map_mul' := by
    intro x y
    simp only [map_mul,Complex.mul_re,star_fixed_character_im χ hχ,mul_zero,sub_zero]
  map_nonunit' := by
    intro x hx
    simp [MulChar.map_nonunit χ hx]

theorem realCharacterOfStarFixed_cast {q : ℕ}
    (χ : DirichletCharacter ℂ q) (hχ : star χ = χ) (x : ZMod q) :
    (realCharacterOfStarFixed χ hχ x:ℂ) = χ x := by
  apply Complex.ext
  · rfl
  · exact (star_fixed_character_im χ hχ x).symm

theorem realCharacterOfStarFixed_nonprincipal {q : ℕ}
    (χ : DirichletCharacter ℂ q) (hχ : star χ = χ) (hn : χ ≠ 1) :
    realCharacterOfStarFixed χ hχ ≠ 1 := by
  intro he
  apply hn
  ext1 u
  rw [← realCharacterOfStarFixed_cast χ hχ u,he]
  simp

end MissingLinnik

import MissingLinnik.VanDijkRows
import MissingLinnik.NonzeroMinor

namespace MissingLinnik.VanDijk

open scoped QuadraticAlgebra

def integerGrid (M : ℕ) (d : ℤ) (a : Fin M × Fin M) : Zsqrtd d :=
  ⟨a.1.val, a.2.val⟩

theorem reduction_row (p M R S : ℕ) (d : ℤ)
    (i : Fin R × Fin S) (c : (Fin M × Fin M) × Fin S) :
    quadraticReduction p d (rowVector R S (integerGrid M d) i c) =
      rowVector R S (gridPoint p M d) i c := by
  unfold rowVector
  rw [map_mul, map_pow, quadraticReduction_star]
  congr 1
  · rw [← Polynomial.eval_map_apply, ← Polynomial.iterate_derivative_map]
    simp [integerGrid, gridPoint, quadraticReduction]
  · simp [integerGrid, gridPoint, quadraticReduction]

/-- The square minor exists already over the quadratic integers, and its
reduction modulo the chosen inert prime is nonzero. -/
theorem exists_integer_minor (p M R S : ℕ) (d : ℤ) [Fact p.Prime]
    [Fact (¬ IsSquare (d : ZMod p))] (hp2 : p ≠ 2) (hd : legendreSym p d = -1)
    (hM : M ≤ p) (hcard : p ≤ M * M) (hR : R ≤ p)
    (hS : 0 < S) (hSp : S < p) :
    ∃ f : (Fin R × Fin S) → ((Fin M × Fin M) × Fin S),
      quadraticReduction p d
        (Matrix.det (Matrix.of (fun i j => rowVector R S (integerGrid M d) i (f j)))) ≠ 0 := by
  classical
  obtain ⟨f, hf⟩ := exists_nonzero_minor
    (rowVector R S (gridPoint p M d))
    (grid_rows_linearIndependent p M R S d hp2 hd hM hcard hR hS hSp)
  refine ⟨f, ?_⟩
  rw [RingHom.map_det]
  convert hf using 1
  congr 1
  apply Matrix.ext
  intro i j
  exact reduction_row p M R S d i (f j)

end MissingLinnik.VanDijk



import MissingLinnik.PrimeLogMass
import Mathlib.Analysis.SpecialFunctions.Log.Sum

namespace MissingLinnik

open Finset ArithmeticFunction

theorem sum_divisor_sums (N : ℕ) (f : ℕ → ℝ) :
    (∑ n ∈ Finset.Ioc 0 N, ∑ d ∈ n.divisors, f d) =
      ∑ d ∈ Finset.Ioc 0 N, f d*(N/d:ℕ) := by
  have hdiv (n : ℕ) (hn : n ∈ Finset.Ioc 0 N) :
      n.divisors = (Finset.Ioc 0 N).filter (fun d => d ∣ n) := by
    obtain ⟨hn0,hnN⟩ := Finset.mem_Ioc.mp hn
    ext d
    constructor
    · intro hd
      exact Finset.mem_filter.mpr ⟨Finset.mem_Ioc.mpr
        ⟨Nat.pos_of_mem_divisors hd,(Nat.le_of_dvd hn0 (Nat.dvd_of_mem_divisors hd)).trans hnN⟩,
        Nat.dvd_of_mem_divisors hd⟩
    · intro hd
      exact Nat.mem_divisors.mpr ⟨(Finset.mem_filter.mp hd).2,hn0.ne'⟩
  calc
    _ = ∑ n ∈ Finset.Ioc 0 N, ∑ d ∈ Finset.Ioc 0 N, if d ∣ n then f d else 0 := by
      apply Finset.sum_congr rfl
      intro n hn
      rw [hdiv n hn,Finset.sum_filter]
    _ = ∑ d ∈ Finset.Ioc 0 N, ∑ n ∈ Finset.Ioc 0 N, if d ∣ n then f d else 0 := Finset.sum_comm
    _ = _ := by
      apply Finset.sum_congr rfl
      intro d hd
      rw [← Finset.sum_filter,Finset.sum_const,Nat.Ioc_filter_dvd_card_eq_div,nsmul_eq_mul]
      ring

theorem log_factorial_eq_mangoldt_floor (N : ℕ) :
    Real.log (N.factorial:ℝ) =
      ∑ d ∈ Finset.Ioc 0 N, vonMangoldt d*(N/d:ℕ) := by
  rw [← Real.sum_log_eq_log_factorial]
  simp_rw [← vonMangoldt_sum]
  exact sum_divisor_sums N vonMangoldt

theorem nat_div_cast_error (N d : ℕ) (hd : 0 < d) :
    0 ≤ (N:ℝ)/d-(N/d:ℕ) ∧ (N:ℝ)/d-(N/d:ℕ) ≤ 1 := by
  have hdR : (0:ℝ) < d := by exact_mod_cast hd
  have hm : ((N%d:ℕ):ℝ) < d := by exact_mod_cast Nat.mod_lt N hd
  have hm0 : (0:ℝ) ≤ ((N%d:ℕ):ℝ) := Nat.cast_nonneg _
  have he : (N:ℝ) = (N/d:ℕ)*d+(N%d:ℕ) := by
    exact_mod_cast (show N = N/d*d+N%d by simpa [Nat.mul_comm] using (Nat.div_add_mod N d).symm)
  have hdiv := div_mul_cancel₀ (N:ℝ) hdR.ne'
  constructor <;> nlinarith only [he,hm,hm0,hdiv,hdR]

theorem mangoldt_sum_le_six (N : ℕ) :
    (∑ d ∈ Finset.Ioc 0 N, vonMangoldt d) ≤ 6*(N:ℝ) := by
  have hh := Chebyshev.psi_le_const_mul_self (x := (N:ℝ)) (by positivity)
  simp only [Chebyshev.psi,Nat.floor_natCast] at hh
  have hl : Real.log (4:ℝ) ≤ 2 := by
    rw [show (4:ℝ)=2^2 by norm_num,Real.log_pow]
    norm_num
    linarith [Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)]
  nlinarith [mul_le_mul_of_nonneg_right hl (Nat.cast_nonneg N : (0:ℝ) ≤ N)]

/-- The elementary weighted von Mangoldt estimate, with explicit absolute
error. It follows from the divisor identity, factorial bounds, and Chebyshev. -/
theorem mangoldt_weighted_mertens (N : ℕ) (hN : 1 ≤ N) :
    |(∑ d ∈ Finset.Ioc 0 N, vonMangoldt d/(d:ℝ))-Real.log N| ≤ 6 := by
  have hN0 : (0:ℝ) < N := by exact_mod_cast (show 0<N by omega)
  have he : (N:ℝ)*(∑ d ∈ Finset.Ioc 0 N, vonMangoldt d/(d:ℝ))-
      Real.log (N.factorial:ℝ) =
      ∑ d ∈ Finset.Ioc 0 N, vonMangoldt d*((N:ℝ)/d-(N/d:ℕ)) := by
    rw [log_factorial_eq_mangoldt_floor,Finset.mul_sum,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro d hd
    ring
  have hs0 : 0 ≤ ∑ d ∈ Finset.Ioc 0 N, vonMangoldt d*((N:ℝ)/d-(N/d:ℕ)) := by
    apply Finset.sum_nonneg
    intro d hd
    exact mul_nonneg vonMangoldt_nonneg (nat_div_cast_error N d (Finset.mem_Ioc.mp hd).1).1
  have hs1 : (∑ d ∈ Finset.Ioc 0 N, vonMangoldt d*((N:ℝ)/d-(N/d:ℕ))) ≤ 6*(N:ℝ) := by
    apply (Finset.sum_le_sum (fun d hd => ?_)).trans (mangoldt_sum_le_six N)
    have ht := mul_le_mul_of_nonneg_left (nat_div_cast_error N d (Finset.mem_Ioc.mp hd).1).2
      (vonMangoldt_nonneg (n := d))
    simpa using ht
  have hlo := Real.le_sum_log_nat N
  rw [Real.sum_log_eq_log_factorial] at hlo
  have hhi := log_factorial_le N
  apply abs_le.mpr
  constructor <;> nlinarith only [he,hs0,hs1,hlo,hhi,hN0]

end MissingLinnik


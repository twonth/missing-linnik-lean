import MissingLinnik.UnitConvolution

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

theorem unitArithmeticMass_eq_sum {q : ℕ} [NeZero q] (f : ArithmeticFunction ℝ)
    (hf : ∀ n,f n≠0 → n.Coprime q) (x : ℝ) (u : (ZMod q)ˣ) :
    unitArithmeticMass f x u=∑ n ∈ Icc 1 (Nat.floor x), if unitResidue q n=u then f n/(n:ℝ) else 0 := by
  unfold unitArithmeticMass arithmeticClassSum
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hfn : f n=0
  · simp [hfn]
  · simp only [modEq_unitResidue q n (hf n hfn)]

noncomputable def unitPairMass {q : ℕ} (f : ArithmeticFunction ℝ) (x : ℝ)
    (u v : (ZMod q)ˣ) : ℝ :=
  ∑ d ∈ Icc 1 (Nat.floor x), if unitResidue q d=u then f d/(d:ℝ)*unitArithmeticMass f (x/d) v else 0

theorem unitPairMass_nonneg {q : ℕ} (f : ArithmeticFunction ℝ) (hf : ∀ n,0≤f n)
    (x : ℝ) (u v : (ZMod q)ˣ) : 0≤unitPairMass f x u v := by
  apply Finset.sum_nonneg
  intro d hd
  split_ifs
  · exact mul_nonneg (div_nonneg (hf d) (Nat.cast_nonneg _)) (unitArithmeticMass_nonneg f hf _ _)
  · exact le_rfl

theorem unitPairMass_le {q : ℕ} [NeZero q] (f : ArithmeticFunction ℝ)
    (hf : ∀ n,f n≠0 → n.Coprime q) (hfn : ∀ n,0≤f n)
    (x : ℝ) (hx : 0≤x) (u v : (ZMod q)ˣ) :
    unitPairMass f x u v≤unitArithmeticMass f x u*unitArithmeticMass f x v := by
  rw [unitArithmeticMass_eq_sum f hf x u,Finset.sum_mul]
  apply Finset.sum_le_sum
  intro d hd
  have hd1 : (1:ℝ)≤d := by exact_mod_cast (mem_Icc.mp hd).1
  by_cases hdu : unitResidue q d=u
  · simp only [hdu,ite_true]
    exact mul_le_mul_of_nonneg_left (unitArithmeticMass_mono f hfn (x/d) x (div_le_self hx hd1) v)
      (div_nonneg (hfn d) (Nat.cast_nonneg _))
  · simp only [hdu,ite_false,zero_mul,le_refl]

theorem unitPairMass_convolution {q : ℕ} [NeZero q] (f : ArithmeticFunction ℝ)
    (hf : ∀ n,f n≠0 → n.Coprime q) (x : ℝ) (a : (ZMod q)ˣ) :
    unitArithmeticMass (f*f) x a=∑ u,unitPairMass f x u (u⁻¹*a) := by
  rw [unitArithmeticMass_convolution f f hf]
  unfold unitPairMass
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro d hd
  simp

theorem pair_mass_reindex {G : Type*} [Group G] [Fintype G]
    (V : G → G → ℝ) (H : G → ℝ) :
    (∑ a,(∑ u,V u (u⁻¹*a))*H a)=∑ u,∑ v,V u v*H (u*v) := by
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro u hu
  have hh := Equiv.sum_comp (Equiv.mulLeft u) (fun a => V u (u⁻¹*a)*H a)
  simpa only [Equiv.coe_mulLeft,inv_mul_cancel_left] using hh.symm

theorem unitPairMass_weighted_sum {q : ℕ} [NeZero q] (f : ArithmeticFunction ℝ)
    (hf : ∀ n,f n≠0 → n.Coprime q) (x : ℝ) (H : (ZMod q)ˣ → ℝ) :
    (∑ a,unitArithmeticMass (f*f) x a*H a)=∑ u,∑ v,unitPairMass f x u v*H (u*v) := by
  simp_rw [unitPairMass_convolution f hf]
  exact pair_mass_reindex (unitPairMass f x) H

theorem unitPairMass_total {q : ℕ} [NeZero q] (f : ArithmeticFunction ℝ)
    (hf : ∀ n,f n≠0 → n.Coprime q) (x : ℝ) :
    (∑ a : (ZMod q)ˣ,unitArithmeticMass (f*f) x a)=∑ u : (ZMod q)ˣ,∑ v,unitPairMass f x u v := by
  simpa only [mul_one] using unitPairMass_weighted_sum f hf x (fun _ : (ZMod q)ˣ => 1)

theorem real_character_sum_units {q : ℕ} [NeZero q] (ψ : DirichletCharacter ℝ q) (hψ : ψ≠1) :
    (∑ u : (ZMod q)ˣ, ψ (u:ZMod q))=0 := by
  obtain ⟨b,hb⟩ := MulChar.ne_one_iff.mp hψ
  apply eq_zero_of_mul_eq_self_left hb
  have hh := Equiv.sum_comp (Equiv.mulLeft b) (fun u : (ZMod q)ˣ => ψ (u:ZMod q))
  simpa only [Equiv.coe_mulLeft,Units.val_mul,map_mul,Finset.mul_sum] using hh

end MissingLinnik


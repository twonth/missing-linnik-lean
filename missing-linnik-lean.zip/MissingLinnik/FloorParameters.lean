import MissingLinnik.ParameterBounds

namespace MissingLinnik

theorem floor_parameter_bounds (k p : ℕ) (hk : 8 ≤ k) (hp : k^2 ≤ p) :
    1 ≤ p/k^2 ∧ k^2*(p/k^2) ≤ p ∧ k*(p/k^2) < p ∧
      p < 2*(k^2*(p/k^2)) ∧ (k-1)*(p/k^2)+(p/k^2) ≤ k*(p/k^2) := by
  have hk0 : 0 < k := by omega
  have hk2 : 0 < k^2 := pow_pos hk0 2
  have hm : 1 ≤ p/k^2 := (Nat.one_le_div_iff hk2).mpr hp
  have hR : k^2*(p/k^2) ≤ p := Nat.mul_div_le p (k^2)
  have hS : k*(p/k^2) < k^2*(p/k^2) := by
    apply Nat.mul_lt_mul_of_pos_right _ (by omega)
    nlinarith
  have hrem := Nat.mod_lt p hk2
  have hdecomp := Nat.mod_add_div p (k^2)
  have hlarge : p < 2*(k^2*(p/k^2)) := by nlinarith
  have hT : (k-1)*(p/k^2)+(p/k^2) = k*(p/k^2) := by
    rw [← Nat.succ_mul, Nat.succ_eq_add_one, Nat.sub_add_cancel (by omega)]
  exact ⟨hm,hR,hS.trans_le hR,hlarge,hT.le⟩

end MissingLinnik

import MissingLinnik.FloorSum

namespace MissingLinnik

theorem sum_fin_real_id (R : ℕ) :
    (∑ r : Fin R, (r.val : ℝ)) = (R : ℝ) * (R - 1) / 2 := by
  rw [Fin.sum_univ_eq_sum_range (fun r => (r : ℝ)) R, sum_range_real_id]

theorem twice_rectangle_degree_sum (R S : ℕ) :
    2 * (∑ i : Fin R × Fin S, ((i.1.val + i.2.val : ℕ) : ℝ)) =
      (R : ℝ) * S * (R + S - 2) := by
  rw [Fintype.sum_prod_type]
  simp only [Nat.cast_add, Finset.sum_add_distrib, Finset.sum_const,
    Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  rw [← Finset.mul_sum, sum_fin_real_id, sum_fin_real_id]
  ring

theorem rectangular_log_bound (R S : ℕ) (B : ℝ) (hB : 1 ≤ B) :
    2 * (∑ i : Fin R × Fin S, ((S : ℝ) * Real.log R +
      ((i.1.val + i.2.val : ℕ) : ℝ) * Real.log B)) ≤
      2 * S * (R * S) * Real.log R + (R * S) * (R + S) * Real.log B := by
  rw [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_prod,
    Fintype.card_fin, Fintype.card_fin, nsmul_eq_mul, Nat.cast_mul,
    ← Finset.sum_mul, mul_add]
  have hs := twice_rectangle_degree_sum R S
  have hlog : 0 ≤ Real.log B := Real.log_nonneg hB
  nlinarith [mul_nonneg (show (0 : ℝ) ≤ R * S by positivity) hlog]

end MissingLinnik


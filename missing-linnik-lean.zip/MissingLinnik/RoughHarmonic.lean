import MissingLinnik.RoughWeightedParameters
import MissingLinnik.HarmonicCounting

namespace MissingLinnik

open scoped Classical

noncomputable def roughAboveOne (Y n : ℕ) : ℝ := if IsRough Y n ∧ n ≠ 1 then 1 else 0

theorem roughAboveOne_small (Y n : ℕ) (hY : 2 ≤ Y) (hn : n ≤ Y) : roughAboveOne Y n = 0 := by
  unfold roughAboveOne
  have hn' := isRough_small_iff Y n hY hn
  simp only [hn',and_not_self,ite_false]

theorem roughAboveOne_count (q k : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k) (t : ℝ) (ht : 1 ≤ t) :
    (∑ n ∈ Finset.Icc 0 (Nat.floor t), roughAboveOne (q^(170*k)) n) ≤
      (2*roughUpperConstant/Real.log ((q^(170*k):ℕ):ℝ))*t := by
  let Y := q^(170*k)
  have hqY : q ≤ Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2 ≤ Y := hq.trans hqY
  have hlY : 0 < Real.log (Y:ℝ) := Real.log_pos (by exact_mod_cast (show 1<Y by omega))
  have hC : 0 ≤ roughUpperConstant := by unfold roughUpperConstant; positivity
  by_cases htY : t < Y
  · have hs : (∑ n ∈ Finset.Icc 0 (Nat.floor t), roughAboveOne Y n) = 0 := by
      apply Finset.sum_eq_zero
      intro n hn
      apply roughAboveOne_small Y n hY
      have hnt : (n:ℝ) ≤ t := (show (n:ℝ) ≤ Nat.floor t by exact_mod_cast (Finset.mem_Icc.mp hn).2).trans
        (Nat.floor_le (by linarith))
      exact_mod_cast (hnt.trans htY.le)
    change (∑ n ∈ Finset.Icc 0 (Nat.floor t), roughAboveOne Y n) ≤ _
    rw [hs]
    change 0 ≤ (2*roughUpperConstant/Real.log (Y:ℝ))*t
    positivity
  · let N := Nat.floor t+1
    have htN : t ≤ (N:ℝ) := by simpa [N] using (Nat.lt_floor_add_one t).le
    have hNY : Y ≤ N := by exact_mod_cast (le_of_not_gt htY).trans htN
    have hNt : (N:ℝ) ≤ 2*t := by
      dsimp [N]
      push_cast
      have hf := Nat.floor_le (by linarith : 0≤t)
      linarith
    have hs := rough_progression_upper_power N q k 1 0 hq hk (by omega) (by omega) (by simp) hNY
    rw [roughProgressionCount_one] at hs
    simp only [Nat.totient_one,Nat.cast_one,one_mul] at hs
    change (roughCount N Y:ℝ) ≤ roughUpperConstant*(N:ℝ)/Real.log Y at hs
    have hsum : (∑ n ∈ Finset.Icc 0 (Nat.floor t), roughAboveOne Y n) ≤ (roughCount N Y:ℝ) := by
      rw [← Nat.range_succ_eq_Icc_zero]
      change (∑ n ∈ Finset.range N, roughAboveOne Y n) ≤ _
      have he : (roughCount N Y:ℝ) = ∑ n ∈ Finset.range N, if IsRough Y n then (1:ℝ) else 0 := by
        rw [← Finset.sum_filter]
        simp only [roughCount,Finset.sum_const,nsmul_eq_mul,mul_one]
      rw [he]
      apply Finset.sum_le_sum
      intro n hn
      unfold roughAboveOne
      split_ifs <;> norm_num at * <;> tauto
    have hm := mul_le_mul_of_nonneg_left hNt (show 0≤roughUpperConstant/Real.log (Y:ℝ) by positivity)
    change (∑ n ∈ Finset.Icc 0 (Nat.floor t), roughAboveOne Y n) ≤ (2*roughUpperConstant/Real.log (Y:ℝ))*t
    calc
      _ ≤ roughUpperConstant*(N:ℝ)/Real.log Y := hsum.trans hs
      _ ≤ _ := by convert hm using 1 <;> ring

theorem rough_harmonic_bound (q k : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k) (x : ℝ)
    (hx : ((q^(170*k):ℕ):ℝ) ≤ x) :
    (∑ n ∈ (Finset.Icc 1 (Nat.floor x)).filter (IsRough (q^(170*k))), (n:ℝ)⁻¹) ≤
      (1+6*roughUpperConstant)*Real.log x/Real.log ((q^(170*k):ℕ):ℝ) := by
  let Y := q^(170*k)
  have hqY : q ≤ Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2 ≤ Y := hq.trans hqY
  have hY1 : (1:ℝ) ≤ Y := by exact_mod_cast (show 1≤Y by omega)
  have hx1 : 1 ≤ x := hY1.trans hx
  have hlY := log_nat_ge_half Y hY
  have hlY0 : 0 < Real.log (Y:ℝ) := by linarith
  have hlx := Real.log_le_log (by linarith : (0:ℝ)<Y) hx
  have hC : 0 ≤ roughUpperConstant := by unfold roughUpperConstant; positivity
  have hh := harmonic_counting_bound (roughAboveOne Y)
    (roughAboveOne_small Y 0 hY (Nat.zero_le _)) (2*roughUpperConstant/Real.log (Y:ℝ))
    (fun t ht => roughAboveOne_count q k hq hk t ht) x hx1
  have he : (∑ n ∈ (Finset.Icc 1 (Nat.floor x)).filter (IsRough Y), (n:ℝ)⁻¹) =
      1+∑ n ∈ Finset.Icc 0 (Nat.floor x), (n:ℝ)⁻¹*roughAboveOne Y n := by
    rw [Finset.sum_filter]
    have hfloor : 1 ≤ Nat.floor x := Nat.le_floor (by simpa using hx1)
    rw [← Finset.add_sum_erase (Finset.Icc 1 (Nat.floor x))
      (fun n : ℕ => if IsRough Y n then (n:ℝ)⁻¹ else 0)
      (Finset.mem_Icc.mpr ⟨le_rfl,hfloor⟩),← Finset.sdiff_singleton_eq_erase]
    simp only [Nat.cast_one,inv_one]
    rw [if_pos (isRough_one Y)]
    congr 1
    apply Finset.sum_subset_zero_on_sdiff
    · intro n hn
      exact Finset.mem_Icc.mpr ⟨Nat.zero_le _, (Finset.mem_Icc.mp (Finset.mem_sdiff.mp hn).1).2⟩
    · intro n hn'
      obtain ⟨hn,hnot⟩ := Finset.mem_sdiff.mp hn'
      have hn' : n=0 ∨ n=1 := by
        simp only [Finset.mem_sdiff,Finset.mem_Icc,Finset.mem_singleton] at hnot hn
        omega
      rcases hn' with rfl | rfl <;> simp [roughAboveOne]
    · intro n hn
      have hn1 : n≠1 := by simpa using (Finset.mem_sdiff.mp hn).2
      simp [roughAboveOne,hn1]
  change (∑ n ∈ (Finset.Icc 1 (Nat.floor x)).filter (IsRough Y), (n:ℝ)⁻¹) ≤ _
  rw [he]
  apply (add_le_add_right hh 1).trans
  change 1+(2*roughUpperConstant/Real.log (Y:ℝ))*(1+Real.log x) ≤
    (1+6*roughUpperConstant)*Real.log x/Real.log (Y:ℝ)
  apply (le_div_iff₀ hlY0).mpr
  field_simp
  have hm := mul_nonneg hC (show 0≤2*Real.log x-1 by linarith)
  nlinarith only [hm,hlx]

end MissingLinnik

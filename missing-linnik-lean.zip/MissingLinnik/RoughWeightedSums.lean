import MissingLinnik.RoughWeightedParameters

namespace MissingLinnik

open scoped Classical

noncomputable def roughWeightedClassSum (q b Y : ℕ) (x : ℝ) : ℝ :=
  ∑ n ∈ (Finset.Icc 0 (Nat.floor x)).filter (fun n => IsRough Y n ∧ Nat.ModEq q n b), logSquareOver n

noncomputable def roughWeightedSum (Y : ℕ) (x : ℝ) : ℝ :=
  ∑ n ∈ (Finset.Icc 0 (Nat.floor x)).filter (IsRough Y), logSquareOver n

theorem roughWeightedSum_comparison (q k b : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hb : b.Coprime q) (x : ℝ) (hx : 1 ≤ x) :
    |roughWeightedClassSum q b (q^(170*k)) x-roughWeightedSum (q^(170*k)) x/q.totient| ≤
      9000*(2*roughDiscrepancyConstant+1)*(Real.log ((q^(170*k):ℕ):ℝ))^2/q.totient := by
  have he : roughWeightedClassSum q b (q^(170*k)) x-roughWeightedSum (q^(170*k)) x/q.totient =
      ∑ n ∈ Finset.Icc 0 (Nat.floor x), logSquareOver n*roughResidueCoefficient q b (q^(170*k)) n := by
    unfold roughWeightedClassSum roughWeightedSum
    rw [Finset.sum_filter,Finset.sum_filter,Finset.sum_div,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro n hn
    unfold roughResidueCoefficient
    split_ifs <;> ring
  rw [he]
  exact weighted_rough_discrepancy q k b hq hk hb x hx

end MissingLinnik

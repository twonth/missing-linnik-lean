import MissingLinnik.TriangleRows
import MissingLinnik.GeneralJetBound
import MissingLinnik.VanDijkDeterminant

namespace MissingLinnik.Triangle

/-- The uploaded triangular variant: a nonzero determinant whose entire
triangular set of rows contributes at every inert prime at least Y. -/
theorem exists_positive_determinant_norm
    (L Y S M : ℕ) (d : ℤ) [Fact L.Prime] [Fact (¬ IsSquare (d : ZMod L))]
    (hL2 : L ≠ 2) (hd : legendreSym L d = -1)
    (hM : M ≤ L) (hcard : L ≤ M*M) (hS : 0 < S) (hSL : S < L)
    (hcover : L ≤ Y*S)
    (a : ℂ) (ha : a^2=d) (B : ℝ) (hB : 1 ≤ B)
    (hMB : (M:ℝ)*(1+‖a‖) ≤ B) :
    ∃ D : ℕ, 0 < D ∧
      (∀ (p : ℕ) (hp : p.Prime), let _ : Fact p.Prime := ⟨hp⟩;
        p ≠ 2 → legendreSym p d = -1 → Y ≤ p →
        p ^ (2 * ∑ i : Row L Y S, i.val.1.val/p) ∣ D) ∧
      Real.log (D:ℝ) ≤ 2*Real.log ((Fintype.card (Row L Y S)).factorial:ℝ) +
        2 * ∑ i : Row L Y S,
          ((S:ℝ)*Real.log L + ((i.val.1.val+i.val.2.val:ℕ):ℝ)*Real.log B) := by
  classical
  obtain ⟨f,hf⟩ := exists_integer_minor L Y S M d hL2 hd hM hcard hS hSL
  let z : Row L Y S → Zsqrtd d := fun c => VanDijk.integerGrid M d (f c).1
  let j : Row L Y S → ℕ := fun c => (f c).2.val
  let Δ := (Matrix.of (fun i c : Row L Y S =>
    monomialJet (z c) (star (z c)) (j c) i.val.1.val i.val.2.val)).det
  have hΔ : Δ ≠ 0 := by
    intro hh
    apply hf
    change quadraticReduction L d Δ = 0
    rw [hh,map_zero]
  have hD : 0 < Δ.norm.natAbs :=
    quadratic_norm_natAbs_pos (VanDijk.nonsquare_integer_of_inert L d) Δ hΔ
  refine ⟨Δ.norm.natAbs,hD,?_,?_⟩
  · intro p hp hpFact hp2 hdp hY
    letI : Fact p.Prime := ⟨hp⟩
    have hv : (p:ℤ) ^ (2 * ∑ i : Row L Y S, i.val.1.val/p) ∣ Δ.norm := by
      apply prime_power_dvd_quadratic_norm
      apply prime_power_dvd_jet_det L Y S p z (fun c => star (z c)) j hcover hY hp.pos
      intro c
      exact inert_frobenius_congruence p hp2 d hdp (z c)
    have habs := Int.natAbs_dvd_natAbs.mpr hv
    simpa only [Int.natAbs_pow, Int.natAbs_natCast] using habs
  · apply GeneralJet.log_norm_jet_det_le
      (fun i : Row L Y S => i.val.1.val) (fun i => i.val.2.val)
      L S d a ha z j B (Fact.out : L.Prime).one_le
      (fun i => Nat.le_of_lt i.val.1.isLt) hB _ _ _ hD
    · intro c; exact Nat.le_of_lt (f c).2.isLt
    · intro c
      exact (VanDijk.integerGrid_embedding_bound M d a ha (f c).1).trans hMB
    · intro c
      have hh := VanDijk.integerGrid_embedding_bound M d (-a) (by simpa using ha) (f c).1
      simp only [norm_neg] at hh
      exact hh.trans hMB

end MissingLinnik.Triangle

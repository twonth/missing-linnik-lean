import MissingLinnik.VanDijkFiniteBound
import MissingLinnik.ParameterizedPrimeBound
import MissingLinnik.PrimeTailBounds
import MissingLinnik.GridSizeEstimates
import MissingLinnik.FloorParameters

namespace MissingLinnik.VanDijk

/-- The adapted van Dijk argument bounds an arbitrary set of inert primes
in its middle window, with fully explicit error terms. -/
theorem window_prime_bound (k p₀ : ℕ) (hk : 8 ≤ k) (hp₀ : k^2 ≤ p₀)
    [Fact p₀.Prime] (d : ℤ) (hd : legendreSym p₀ d = -1)
    (a : ℂ) (ha : a^2=d) (q : ℝ) (hq : 1 ≤ q) (haq : ‖a‖^2 ≤ q)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime)
    (hlower : ∀ p ∈ P, k^2 ≤ p) (hupper : ∀ p ∈ P, p ≤ k*(p₀/k^2))
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) :
    (∑ p ∈ P, Real.log p / p) ≤
      (1/2+8/(k:ℝ))*Real.log p₀ + Real.log q + 8 := by
  let m := p₀/k^2
  have hmdef : m = p₀/k^2 := rfl
  obtain ⟨hm,hR,hS,hpR,hT⟩ := floor_parameter_bounds k p₀ hk hp₀
  have hp2 : 2 ≤ p₀ := by nlinarith
  have hpodd : p₀ ≠ 2 := by nlinarith
  letI : Fact (¬ IsSquare (d : ZMod p₀)) := ⟨(legendreSym.eq_neg_one_iff p₀).mp hd⟩
  let B := 4*Real.sqrt p₀*Real.sqrt q
  obtain ⟨hB,hMB,hlogB⟩ := grid_archimedean_bound p₀ hp2 q hq a haq
  obtain ⟨hcard,hM,_⟩ := sqrt_grid_bounds p₀ hp2
  have hRpos : 1 ≤ k^2*m := by dsimp only [m]; nlinarith
  have hSpos : 0 < k*m := by dsimp only [m]; positivity
  have hfinite := finite_inert_prime_bound p₀ (p₀.sqrt+1) (k^2*m) (k*m) m ((k-1)*m) d
    hpodd hd hM hcard hR hRpos hSpos hS a ha B hB hMB P hprime
    (fun p hp => by have := hlower p hp; nlinarith)
    hinert (fun p hp => Nat.mul_le_mul_right m (hlower p hp)) hT
  have hparam := parameterized_prime_bound k m hk hm B hB P hprime hupper (by
    simpa only [Nat.cast_mul, Nat.cast_pow] using hfinite)
  have hlogR : Real.log ((k:ℝ)^2*m) ≤ Real.log p₀ := by
    apply Real.log_le_log (by positivity)
    exact_mod_cast hR
  apply logarithmic_parameter_bound (k:ℝ) (Real.log p₀) (Real.log q) (Real.log B)
    (∑ p ∈ P, Real.log p / p) (by exact_mod_cast hk)
    (Real.log_nonneg (by exact_mod_cast (show 1 ≤ p₀ by omega))) (Real.log_nonneg hq) hlogB
  have hh := mul_le_mul_of_nonneg_left hlogR (show (0:ℝ) ≤ 5/k by positivity)
  linarith

end MissingLinnik.VanDijk

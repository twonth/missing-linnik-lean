import MissingLinnik.JetDeterminant
import MissingLinnik.QuadraticEmbedding
import MissingLinnik.DerivativeBound
import Mathlib.Analysis.SpecialFunctions.Log.Basic

namespace MissingLinnik

theorem quadraticComplexEmbedding_star (d : ℤ) (a : ℂ) (ha : a ^ 2 = d) (x : Zsqrtd d) :
    quadraticComplexEmbedding d a ha (star x) =
      quadraticComplexEmbedding d (-a) (by simpa using ha) x := by
  simp [quadraticComplexEmbedding]

theorem norm_mapped_jet_det_le (R S : ℕ) (d : ℤ)
    (f : Zsqrtd d →+* ℂ) (z : (Fin R × Fin S) → Zsqrtd d)
    (j : (Fin R × Fin S) → ℕ) (B : ℝ) (hR : 1 ≤ R) (hB : 1 ≤ B)
    (hz : ∀ c, ‖f (z c)‖ ≤ B) (hw : ∀ c, ‖f (star (z c))‖ ≤ B)
    (hj : ∀ c, j c ≤ S) :
    ‖f ((Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c) i.1.val i.2.val)).det)‖ ≤
      (R * S).factorial * ∏ i : Fin R × Fin S, (R : ℝ) ^ S * B ^ (i.1.val + i.2.val) := by
  rw [RingHom.map_det]
  have hc : Fintype.card (Fin R × Fin S) = R * S := by simp
  rw [← hc]
  apply norm_det_le_factorial_mul_row_bounds
  · intro i; positivity
  · intro i c
    change ‖f (monomialJet (z c) (star (z c)) (j c) i.1.val i.2.val)‖ ≤ _
    rw [map_monomialJet]
    exact norm_derivative_monomial_le R S i.1.val i.2.val (j c) _ _ B hR
      (Nat.le_of_lt i.1.isLt) (hj c) hB (hz c) (hw c)

/-- The archimedean determinant estimate with its constants still explicit.
The two embeddings are bounded separately, so this applies to positive and
negative quadratic parameters alike. -/
theorem log_norm_jet_det_le (R S : ℕ) (d : ℤ) (a : ℂ) (ha : a ^ 2 = d)
    (z : (Fin R × Fin S) → Zsqrtd d) (j : (Fin R × Fin S) → ℕ)
    (B : ℝ) (hR : 1 ≤ R) (hB : 1 ≤ B) (hj : ∀ c, j c ≤ S)
    (hz : ∀ c, ‖quadraticComplexEmbedding d a ha (z c)‖ ≤ B)
    (hw : ∀ c, ‖quadraticComplexEmbedding d (-a) (by simpa using ha) (z c)‖ ≤ B)
    (hD : 0 < ((Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c)
      i.1.val i.2.val)).det).norm.natAbs) :
    Real.log (((Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c)
      i.1.val i.2.val)).det).norm.natAbs : ℝ) ≤
      2 * Real.log ((R * S).factorial : ℝ) +
      2 * ∑ i : Fin R × Fin S, ((S : ℝ) * Real.log R +
        ((i.1.val + i.2.val : ℕ) : ℝ) * Real.log B) := by
  let Δ := (Matrix.of (fun i c => monomialJet (z c) (star (z c)) (j c) i.1.val i.2.val)).det
  let U : ℝ := (R * S).factorial * ∏ i : Fin R × Fin S, (R : ℝ) ^ S * B ^ (i.1.val + i.2.val)
  have hRp : (0 : ℝ) < R := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hR)
  have hBp : 0 < B := lt_of_lt_of_le zero_lt_one hB
  have hU : 0 < U := by
    apply mul_pos
    · exact_mod_cast Nat.factorial_pos (R*S)
    · exact Finset.prod_pos (fun i _ => mul_pos (pow_pos hRp _) (pow_pos hBp _))
  have hplus : ‖quadraticComplexEmbedding d a ha Δ‖ ≤ U := by
    apply norm_mapped_jet_det_le R S d _ z j B hR hB hz _ hj
    intro c
    simpa only [quadraticComplexEmbedding_star] using hw c
  have hminus : ‖quadraticComplexEmbedding d (-a) (by simpa using ha) Δ‖ ≤ U := by
    apply norm_mapped_jet_det_le R S d _ z j B hR hB hw _ hj
    intro c
    simpa only [quadraticComplexEmbedding_star, neg_neg] using hz c
  have hDU : (Δ.norm.natAbs : ℝ) ≤ U ^ 2 := by
    rw [quadratic_norm_natAbs_eq d a ha Δ]
    exact (mul_le_mul hplus hminus (norm_nonneg _) hU.le).trans_eq (pow_two U).symm
  have hl : Real.log (Δ.norm.natAbs : ℝ) ≤ 2 * Real.log U := by
    have hh := Real.log_le_log (by exact_mod_cast hD) hDU
    simpa [Real.log_pow] using hh
  have hlogU : Real.log U = Real.log ((R * S).factorial : ℝ) +
      ∑ i : Fin R × Fin S, ((S : ℝ) * Real.log R +
        ((i.1.val + i.2.val : ℕ) : ℝ) * Real.log B) := by
    dsimp only [U]
    rw [Real.log_mul (by positivity) (by positivity), Real.log_prod]
    · congr 1
      apply Finset.sum_congr rfl
      intro i _
      rw [Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_pow]
    · intro i _; positivity
  rw [hlogU, mul_add] at hl
  exact hl

end MissingLinnik


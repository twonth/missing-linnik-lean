import MissingLinnik.RealCharacterLift

namespace MissingLinnik

variable {R S : Type*} [CommRing R] [CommRing S]

/-- A character on a product ring restricted to the first factor. -/
noncomputable def characterFirstFactor (χ : MulChar (R × S) ℝ) : MulChar R ℝ where
  toFun r := χ (r,1)
  map_one' := χ.map_one
  map_mul' r t := by simpa using χ.map_mul (r,1) (t,1)
  map_nonunit' r hr := by
    apply χ.map_nonunit
    intro hu
    exact hr (hu.map (RingHom.fst R S))

/-- A character on a product ring restricted to the second factor. -/
noncomputable def characterSecondFactor (χ : MulChar (R × S) ℝ) : MulChar S ℝ where
  toFun s := χ (1,s)
  map_one' := χ.map_one
  map_mul' s t := by simpa using χ.map_mul (1,s) (1,t)
  map_nonunit' s hs := by
    apply χ.map_nonunit
    intro hu
    exact hs (hu.map (RingHom.snd R S))

/-- The multiplicative decomposition underlying the CRT step in the textbooks. -/
theorem character_product_decomposition (χ : MulChar (R × S) ℝ) (r : R) (s : S) :
    χ (r,s) = characterFirstFactor χ r * characterSecondFactor χ s := by
  change χ (r,s) = χ (r,1) * χ (1,s)
  simpa using χ.map_mul (r,1) (1,s)

/-- Transport of a character along a ring equivalence. -/
noncomputable def characterTransport (e : R ≃+* S) (χ : MulChar R ℝ) : MulChar S ℝ where
  toFun s := χ (e.symm s)
  map_one' := by simp
  map_mul' s t := by simp
  map_nonunit' s hs := by
    apply χ.map_nonunit
    intro hu
    apply hs
    simpa using hu.map e.toMonoidHom

/-- Every real character at a product of coprime moduli decomposes into
real characters at those moduli, as used by Montgomery--Vaughan and Davenport. -/
theorem real_character_crt_decomposition (m n : ℕ) (hmn : m.Coprime n)
    (ψ : DirichletCharacter ℝ (m*n)) :
    ∃ χ : DirichletCharacter ℝ m, ∃ θ : DirichletCharacter ℝ n,
      ∀ a : ℤ, ψ (a : ZMod (m*n)) = χ (a : ZMod m) * θ (a : ZMod n) := by
  let e := ZMod.chineseRemainder hmn
  let η := characterTransport e ψ
  refine ⟨characterFirstFactor η, characterSecondFactor η, ?_⟩
  intro a
  have ht : η ((a : ZMod m),(a : ZMod n)) = ψ (a : ZMod (m*n)) := by
    change ψ (e.symm (a : ZMod m × ZMod n)) = ψ (a : ZMod (m*n))
    rw [map_intCast]
  rw [← ht]
  exact character_product_decomposition η _ _

end MissingLinnik

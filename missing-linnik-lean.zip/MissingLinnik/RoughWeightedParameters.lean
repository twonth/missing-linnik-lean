import MissingLinnik.RoughCoefficients

namespace MissingLinnik

theorem logDecay_antitone (β t u : ℝ) (hβ : 0 ≤ β) (ht : 0 < t) (htu : t ≤ u) :
    logDecay β u ≤ logDecay β t := by
  apply Real.exp_le_exp.mpr
  exact mul_le_mul_of_nonpos_left (Real.log_le_log ht htu) (neg_nonpos.mpr hβ)

/-- The contribution at 1 is absorbed uniformly at the chosen roughness scale. -/
theorem rough_unit_absorption (q k : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (t : ℝ) (ht : ((q^(170*k):ℕ):ℝ) ≤ t) :
    (q.totient:ℝ)*Real.log ((q^(170*k):ℕ):ℝ) ≤
      t*logDecay (1/(10*Real.log ((q^(170*k):ℕ):ℝ))) t := by
  let Y := q^(170*k)
  have hq0 : (0:ℝ) < q := by exact_mod_cast (show 0<q by omega)
  have hqY : q ≤ Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2 ≤ Y := hq.trans hqY
  have hY0 : (0:ℝ) < Y := by exact_mod_cast (show 0<Y by omega)
  have ht0 : 0 < t := hY0.trans_le ht
  have hlY := log_nat_ge_half Y hY
  have hlY0 : 0 < Real.log (Y:ℝ) := by linarith
  have hlt := Real.log_le_log hY0 ht
  have hlt0 : 0 ≤ Real.log t := by linarith
  have hβ : 1/(10*Real.log (Y:ℝ)) ≤ 1/2 := by
    apply (div_le_iff₀ (by positivity : 0<10*Real.log (Y:ℝ))).mpr
    linarith
  have ha := logarithmic_scale_absorption q k hq hk (q.totient:ℝ)
    (Nat.cast_nonneg _) (by exact_mod_cast Nat.totient_le q)
  have hp : (q:ℝ)^(85*k) = Real.exp (Real.log (Y:ℝ)/2) := by
    have he : Real.log (Y:ℝ)/2 = Real.log ((q:ℝ)^(85*k)) := by
      dsimp [Y]
      rw [Nat.cast_pow,Real.log_pow,Real.log_pow]
      push_cast
      ring
    rw [he,Real.exp_log (pow_pos hq0 _)]
  have he : t*logDecay (1/(10*Real.log (Y:ℝ))) t =
      Real.exp ((1-1/(10*Real.log (Y:ℝ)))*Real.log t) := by
    unfold logDecay
    rw [← Real.exp_log ht0,← Real.exp_add]
    congr 1
    rw [Real.log_exp]
    ring
  change (q.totient:ℝ)*Real.log (Y:ℝ) ≤ _ at ha ⊢
  rw [he]
  apply ha.trans
  rw [hp]
  apply Real.exp_le_exp.mpr
  have hm := mul_le_mul_of_nonneg_right hβ hlt0
  nlinarith only [hm,hlt]

theorem rough_weighted_count_bound (q k b : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hb : b.Coprime q) (t : ℝ) (ht : 1 ≤ t) :
    |∑ n ∈ Finset.Icc 0 (Nat.floor t), roughResidueCoefficientAboveOne q b (q^(170*k)) n| ≤
      ((2*roughDiscrepancyConstant+1)/(q.totient*Real.log ((q^(170*k):ℕ):ℝ)))*t*
        logDecay (1/(10*Real.log ((q^(170*k):ℕ):ℝ))) t := by
  let Y := q^(170*k)
  have hqY : q ≤ Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2 ≤ Y := hq.trans hqY
  have hlY : 0 < Real.log (Y:ℝ) := Real.log_pos (by exact_mod_cast (show 1<Y by omega))
  have hφ : (0:ℝ) < q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have hC : 0 ≤ roughDiscrepancyConstant := by
    unfold roughDiscrepancyConstant roughUpperConstant
    positivity
  change |∑ n ∈ Finset.Icc 0 (Nat.floor t), roughResidueCoefficientAboveOne q b Y n| ≤
    ((2*roughDiscrepancyConstant+1)/(q.totient*Real.log Y))*t*logDecay (1/(10*Real.log Y)) t
  by_cases htY : t < Y
  · have hs : (∑ n ∈ Finset.Icc 0 (Nat.floor t), roughResidueCoefficientAboveOne q b Y n) = 0 := by
      apply Finset.sum_eq_zero
      intro n hn
      apply roughResidueCoefficientAboveOne_small q b Y n hY
      have hnt : (n:ℝ) ≤ t := (show (n:ℝ) ≤ Nat.floor t by exact_mod_cast (Finset.mem_Icc.mp hn).2).trans
        (Nat.floor_le (by linarith))
      exact_mod_cast (hnt.trans htY.le)
    rw [hs,abs_zero]
    have hd := (logDecay_pos (1/(10*Real.log (Y:ℝ))) t).le
    positivity
  · have hYt : (Y:ℝ) ≤ t := le_of_not_gt htY
    let N := Nat.floor t+1
    have htN : t ≤ (N:ℝ) := by simpa [N] using (Nat.lt_floor_add_one t).le
    have hNY : Y ≤ N := by exact_mod_cast hYt.trans htN
    have hNt : (N:ℝ) ≤ 2*t := by
      dsimp [N]
      push_cast
      have hf := Nat.floor_le (by linarith : 0≤t)
      linarith
    have hd := uniform_rough_discrepancy N q k b hq hk hb hNY
    have hexp : Real.exp (-Real.log N/(10*Real.log (Y:ℝ))) = logDecay (1/(10*Real.log Y)) N := by
      unfold logDecay
      congr 1
      ring
    change |(roughProgressionCount N q b Y:ℝ)-(roughCount N Y:ℝ)/q.totient| ≤
      roughDiscrepancyConstant*((N:ℝ)/(q.totient*Real.log Y))*Real.exp (-Real.log N/(10*Real.log Y)) at hd
    rw [hexp] at hd
    have hm := logDecay_antitone (1/(10*Real.log (Y:ℝ))) t N (by positivity) (by linarith) htN
    have hprod := mul_le_mul hNt hm (logDecay_pos _ _).le (by linarith : 0≤2*t)
    have hscaled := mul_le_mul_of_nonneg_left hprod
      (show 0 ≤ roughDiscrepancyConstant/(q.totient*Real.log (Y:ℝ)) by positivity)
    have hunit := rough_unit_absorption q k hq hk t hYt
    have hunit' : 1 ≤ t*logDecay (1/(10*Real.log (Y:ℝ))) t/(q.totient*Real.log Y) := by
      apply (le_div_iff₀ (by positivity : 0< (q.totient:ℝ)*Real.log Y)).mpr
      simpa only [one_mul] using hunit
    rw [sum_roughResidueCoefficientAboveOne q b Y t ht]
    have habs := (abs_sub ((roughProgressionCount N q b Y:ℝ)-(roughCount N Y:ℝ)/q.totient)
      (roughResidueCoefficient q b Y 1)).trans (add_le_add hd (roughResidueCoefficient_one_abs q b Y (by omega)))
    dsimp only [N] at habs hscaled
    ring_nf at habs hscaled hunit' ⊢
    linarith

/-- Explicit version of the manuscript's weighted rough-number comparison. -/
theorem weighted_rough_discrepancy (q k b : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hb : b.Coprime q) (x : ℝ) (hx : 1 ≤ x) :
    |∑ n ∈ Finset.Icc 0 (Nat.floor x),
      logSquareOver n*roughResidueCoefficient q b (q^(170*k)) n| ≤
      9000*(2*roughDiscrepancyConstant+1)*(Real.log ((q^(170*k):ℕ):ℝ))^2/q.totient := by
  let Y := q^(170*k)
  have hqY : q ≤ Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2 ≤ Y := hq.trans hqY
  have hlY := log_nat_ge_half Y hY
  have hlY0 : 0 < Real.log (Y:ℝ) := by linarith
  have hφ : (0:ℝ) < q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have hC : 0 ≤ roughDiscrepancyConstant := by
    unfold roughDiscrepancyConstant roughUpperConstant
    positivity
  have hc : roughResidueCoefficientAboveOne q b Y 0 = 0 :=
    roughResidueCoefficientAboveOne_small q b Y 0 hY (Nat.zero_le _)
  have hβ : 0 < 1/(10*Real.log (Y:ℝ)) := by positivity
  have hβ1 : 1/(10*Real.log (Y:ℝ)) ≤ 1 := by
    apply (div_le_one (by positivity : 0<10*Real.log (Y:ℝ))).mpr
    linarith
  have hh := weighted_discrepancy_bound (roughResidueCoefficientAboveOne q b Y) hc
    ((2*roughDiscrepancyConstant+1)/(q.totient*Real.log (Y:ℝ)))
    (1/(10*Real.log (Y:ℝ))) (by positivity) hβ hβ1
    (fun t ht => rough_weighted_count_bound q k b hq hk hb t ht) x hx
  rw [weighted_rough_coefficient_eq] at hh
  apply hh.trans_eq
  change 9*((2*roughDiscrepancyConstant+1)/(q.totient*Real.log (Y:ℝ)))/
    (1/(10*Real.log (Y:ℝ)))^3 = _
  dsimp only [Y]
  field_simp
  <;> ring

end MissingLinnik


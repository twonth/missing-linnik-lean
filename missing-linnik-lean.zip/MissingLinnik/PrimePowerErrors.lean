import MissingLinnik.RoughPrimePowers
import MissingLinnik.InducedAntiConcentration

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

theorem single_log_square_of_no_primes (q c Y : ℕ) (hY : 1≤Y) (x : ℝ) (hx : 1≤x)
    (hno : ∀ p : ℕ, p.Prime → (p:ℝ)≤x → ¬Nat.ModEq q p c) :
    arithmeticClassSum (logWeight (logWeight (roughRestriction Y vonMangoldt))) q c x ≤
      72*(Real.log x)^2/(Y:ℝ) := by
  have hsingle : arithmeticClassSum (logWeight (logWeight (roughRestriction Y vonMangoldt))) q c x ≤
      (Real.log x)^2*∑ n ∈ Ioc 0 (Nat.floor x), roughProperPrimePowerWeight Y n/(n:ℝ) := by
    unfold arithmeticClassSum
    rw [Finset.mul_sum]
    have hset : Icc 1 (Nat.floor x)=Ioc 0 (Nat.floor x) := by ext n; simp only [mem_Icc,mem_Ioc]; omega
    rw [hset]
    apply (Finset.sum_le_sum (fun n hn => ?_)).trans
      (Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun n hn _ => by positivity [roughProperPrimePowerWeight_nonneg Y n]))
    obtain ⟨hn,hnq⟩ := Finset.mem_filter.mp hn
    have hn0 : (0:ℝ)<n := by exact_mod_cast (mem_Ioc.mp hn).1
    have hnx : (n:ℝ)≤x := (show (n:ℝ)≤Nat.floor x by exact_mod_cast (mem_Ioc.mp hn).2).trans
      (Nat.floor_le (by linarith))
    have hnp : ¬n.Prime := fun hp => hno n hp hnx hnq
    have he : roughRestriction Y vonMangoldt n=roughProperPrimePowerWeight Y n := by
      rw [rough_mangoldt_prime_split]
      simp only [hnp,false_and,ite_false,zero_add]
    simp only [logWeight_apply,he]
    have hln : 0≤Real.log (n:ℝ) := Real.log_nonneg (by exact_mod_cast (mem_Ioc.mp hn).1)
    have hl := Real.log_le_log hn0 hnx
    have hsq : (Real.log (n:ℝ))^2≤(Real.log x)^2 := by nlinarith
    have hm := mul_le_mul_of_nonneg_right hsq
      (div_nonneg (roughProperPrimePowerWeight_nonneg Y n) hn0.le)
    convert hm using 1 <;> ring
  have hh := mul_le_mul_of_nonneg_left (rough_proper_prime_power_mass Y (Nat.floor x) hY) (sq_nonneg (Real.log x))
  apply hsingle.trans
  convert hh using 1 <;> ring

noncomputable def negativeRoughMass {q : ℕ} (χ : DirichletCharacter ℝ q) (Y : ℕ) (x : ℝ) : ℝ :=
  ∑ n ∈ (Icc 1 (Nat.floor x)).filter (fun n : ℕ => χ (n:ZMod q)=-1), roughRestriction Y vonMangoldt n/(n:ℝ)

theorem negative_rough_mass_bound (A : ℕ → ℕ) (hA : AntiConcentrationBounds A)
    (q Y : ℕ) (hq : 2≤q) (hqY : q≤Y) (χ : DirichletCharacter ℝ q) (hχ : χ≠1)
    (x : ℝ) (hx : (q:ℝ)^A 7≤x) :
    negativeRoughMass χ Y x≤(5/8:ℝ)*Real.log x+72/(Y:ℝ) := by
  let P := ((Icc 1 (Nat.floor x)).filter (fun n => n.Prime ∧ Y<n ∧ χ (n:ZMod q)=-1))
  have hx0 : 0≤x := (pow_nonneg (Nat.cast_nonneg q) _).trans hx
  have hp := induced_negative_prime_bound A hA 7 q hq χ hχ x hx P
    (fun p hp => (Finset.mem_filter.mp hp).2.1)
    (fun p hp => hqY.trans_lt (Finset.mem_filter.mp hp).2.2.1)
    (fun p hp => (show (p:ℝ)≤Nat.floor x by exact_mod_cast (mem_Icc.mp (Finset.mem_filter.mp hp).1).2).trans (Nat.floor_le hx0))
    (fun p hp => (Finset.mem_filter.mp hp).2.2.2)
  norm_num at hp
  have hsplit : negativeRoughMass χ Y x =
      (∑ p ∈ P, Real.log p/(p:ℝ))+
      ∑ n ∈ (Icc 1 (Nat.floor x)).filter (fun n : ℕ => χ (n:ZMod q)=-1), roughProperPrimePowerWeight Y n/(n:ℝ) := by
    unfold negativeRoughMass
    rw [Finset.sum_filter,Finset.sum_filter]
    rw [Finset.sum_filter,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro n hn
    rw [rough_mangoldt_prime_split]
    split_ifs <;> first | (solve | ring) | tauto
  have hproper : (∑ n ∈ (Icc 1 (Nat.floor x)).filter (fun n : ℕ => χ (n:ZMod q)=-1), roughProperPrimePowerWeight Y n/(n:ℝ))≤72/(Y:ℝ) := by
    apply (Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
      (fun n hn _ => div_nonneg (roughProperPrimePowerWeight_nonneg Y n) (Nat.cast_nonneg _))).trans
    have hset : Icc 1 (Nat.floor x)=Ioc 0 (Nat.floor x) := by ext n; simp only [mem_Icc,mem_Ioc]; omega
    rw [hset]
    exact rough_proper_prime_power_mass Y (Nat.floor x) (by omega)
  rw [hsplit]
  linarith

end MissingLinnik


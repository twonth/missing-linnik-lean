import MissingLinnik.FloorSum
import MissingLinnik.PrimeValuationBound

namespace MissingLinnik

theorem weighted_floor_sum_lower (P : Finset ℕ) (R T : ℕ)
    (hp : ∀ p ∈ P, 0 < p) :
    (T : ℝ) * R * (R - 1) * (∑ p ∈ P, Real.log p / p) -
      2 * T * R * (∑ p ∈ P, Real.log p) ≤
      ∑ p ∈ P, ((2 * (T * ∑ r ∈ Finset.range R, r / p) : ℕ) : ℝ) * Real.log p := by
  have hterm (p : ℕ) (hmem : p ∈ P) :
      (T : ℝ) * R * (R - 1) * (Real.log p / p) - 2 * T * R * Real.log p ≤
      ((2 * (T * ∑ r ∈ Finset.range R, r / p) : ℕ) : ℝ) * Real.log p := by
    have h := mul_le_mul_of_nonneg_right (floor_sum_lower R p (hp p hmem))
      (show 0 ≤ (2 : ℝ) * T * Real.log p by positivity)
    have he : ((R : ℝ) * (R - 1) / (2 * p) - R) * (2 * T * Real.log p) =
        (T : ℝ) * R * (R - 1) * (Real.log p / p) - 2 * T * R * Real.log p := by ring
    rw [he] at h
    convert h using 1 <;> push_cast <;> ring
  have hs := Finset.sum_le_sum (fun p hmem => hterm p hmem)
  simpa only [Finset.sum_sub_distrib, ← Finset.mul_sum] using hs

end MissingLinnik

import MissingLinnik.FiniteSieveUpper

namespace MissingLinnik

open Finset

theorem sieveDensity_prefix (P : Finset ℕ) (hp : ∀ p ∈ P, p.Prime) (p : ℕ) :
    sieveDensity (P.filter (fun l => l < p)) =
      sieveDensity P * ∏ l ∈ P with ¬l < p, (1-1/(l:ℝ))⁻¹ := by
  have he := Finset.prod_filter_mul_prod_filter_not P (fun l => l < p) (fun l : ℕ => (1:ℝ)-1/l)
  have hn : (∏ l ∈ P with ¬l < p, (1-1/(l:ℝ))) ≠ 0 := by
    exact (sieveDensity_pos _ (fun l hl => hp l (Finset.mem_filter.mp hl).1)).ne'
  change _ = (∏ l ∈ P, (1-1/(l:ℝ))) * _
  rw [← he,Finset.prod_inv_distrib,mul_assoc,mul_inv_cancel₀ hn,mul_one]
  rfl

theorem sieveDensity_prefix_le (P : Finset ℕ) (z p : ℕ) (hp : ∀ l ∈ P, l.Prime)
    (hpz : ∀ l ∈ P, l ≤ z) (hpp : 2 ≤ p) (hple : p ≤ z) :
    sieveDensity (P.filter (fun l => l < p)) ≤
      sieveDensity P*Real.exp (16*Real.log z/Real.log p) := by
  rw [sieveDensity_prefix P hp p]
  apply mul_le_mul_of_nonneg_left _ (sieveDensity_pos P hp).le
  exact prime_interval_product_bound _ p z hpp hple
    (fun l hl => hp l (Finset.mem_filter.mp hl).1)
    (fun l hl => Nat.le_of_not_gt (Finset.mem_filter.mp hl).2)
    (fun l hl => hpz l (Finset.mem_filter.mp hl).1)

/-- Summing the errors in the lower sieve does not lose a factor log z.
A coarse exponential Euler-product bound is enough for this purpose. -/
theorem sieve_lower_error_sum (P : Finset ℕ) (z : ℕ) (hz : 2 ≤ z)
    (hp : ∀ p ∈ P, p.Prime) (hpz : ∀ p ∈ P, p ≤ z)
    (h : ℝ) (hh : 17 ≤ h) :
    (∑ p ∈ P, (sieveDensity (P.filter (fun l => l < p))/(p:ℝ))*
      Real.exp (16-h*(Real.log z/Real.log p))) ≤
      8*sieveDensity P*Real.exp (32-h) := by
  have hs : (∑ p ∈ P, (sieveDensity (P.filter (fun l => l < p))/(p:ℝ))*
      Real.exp (16-h*(Real.log z/Real.log p))) ≤
      sieveDensity P*Real.exp 16 *
        (∑ p ∈ P, (1/(p:ℝ))*Real.exp (-(h-16)*(Real.log z/Real.log p))) := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro p hpm
    have hb := sieveDensity_prefix_le P z p hp hpz (hp p hpm).two_le (hpz p hpm)
    have ht := mul_le_mul_of_nonneg_right
      (div_le_div_of_nonneg_right hb (Nat.cast_nonneg p : (0:ℝ) ≤ p))
      (Real.exp_pos (16-h*(Real.log z/Real.log p))).le
    convert ht using 1
    have he : Real.exp (16*Real.log (z:ℝ)/Real.log p)*
        Real.exp (16-h*(Real.log z/Real.log p)) =
        Real.exp 16*Real.exp (-(h-16)*(Real.log z/Real.log p)) := by
      rw [← Real.exp_add,← Real.exp_add]
      congr 1
      ring
    calc
      _ = (sieveDensity P/(p:ℝ)) * (Real.exp 16*Real.exp (-(h-16)*(Real.log z/Real.log p))) := by ring
      _ = _ := by rw [← he]; ring
  have hk := prime_rankin_kernel_sum P z hz hp hpz (h-16) (by linarith)
  have ht := mul_le_mul_of_nonneg_left hk (show 0 ≤ sieveDensity P*Real.exp 16 by positivity [sieveDensity_pos P hp])
  have he : sieveDensity P*Real.exp 16*(8*Real.exp (-(h-16))) =
      8*sieveDensity P*Real.exp (32-h) := by
    calc
      _ = 8*sieveDensity P*(Real.exp 16*Real.exp (-(h-16))) := by ring
      _ = _ := by rw [← Real.exp_add]; congr 2 <;> ring
  exact hs.trans (he ▸ ht)

end MissingLinnik


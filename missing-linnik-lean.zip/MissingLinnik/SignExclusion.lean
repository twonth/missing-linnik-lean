import MissingLinnik.FiniteFourier

namespace MissingLinnik

open Classical

/-- The elementary sign argument behind the manuscript's use of the two-prime
symmetry formula. Single and pair weights are dominated by the prime weights. -/
theorem signed_symmetry_difference_bound {I : Type*} [Fintype I]
    (w u : I → ℝ) (v : I → I → ℝ) (a : I → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hmass : ∑ i, w i = 1)
    (hu : ∀ i, 0 ≤ u i ∧ u i ≤ w i)
    (hv : ∀ i j, 0 ≤ v i j ∧ v i j ≤ w i * w j)
    (ha : ∀ i, a i = 1 ∨ a i = -1) :
    (∑ i, u i) + (∑ i, ∑ j, v i j) -
      ((∑ i, u i * a i) + (∑ i, ∑ j, v i j * (a i * a j))) ≤
      3 * (1 - ∑ i, w i * a i) := by
  have hsingle (i : I) : u i - u i * a i ≤ w i - w i * a i := by
    rcases ha i with h | h <;> rw [h] <;> nlinarith [(hu i).2]
  have hpair (i j : I) :
      v i j - v i j * (a i * a j) ≤
        (w i - w i * a i) * w j + w i * (w j - w j * a j) := by
    rcases ha i with hi | hi <;> rcases ha j with hj | hj <;>
      rw [hi, hj] <;> nlinarith [(hv i j).1, (hv i j).2, mul_nonneg (hw i) (hw j)]
  have hs := Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => hsingle i)
  have hp := Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) =>
    Finset.sum_le_sum (fun j (_ : j ∈ Finset.univ) => hpair i j))
  simp only [Finset.sum_sub_distrib, Finset.sum_add_distrib, ← Finset.mul_sum,
    ← Finset.sum_mul, hmass, mul_one] at hs hp
  linarith

theorem negative_mass_identity {I : Type*} [Fintype I]
    (w a : I → ℝ) (ha : ∀ i, a i = 1 ∨ a i = -1) :
    2 * (∑ i ∈ Finset.univ.filter (fun i => a i = -1), w i) =
      (∑ i, w i) - (∑ i, w i * a i) := by
  rw [Finset.sum_filter, Finset.mul_sum, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i _
  rcases ha i with hi | hi <;> norm_num [hi] <;> ring

/-- Direct negative-mass estimate used in the 25 October manuscript.
A negative pair has at least one negative factor. -/
theorem negative_symmetry_mass_bound {I : Type*} [Fintype I]
    (w u : I → ℝ) (v : I → I → ℝ) (a : I → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hmass : ∑ i, w i = 1)
    (hu : ∀ i, 0 ≤ u i ∧ u i ≤ w i)
    (hv : ∀ i j, 0 ≤ v i j ∧ v i j ≤ w i * w j)
    (ha : ∀ i, a i = 1 ∨ a i = -1) :
    (∑ i ∈ Finset.univ.filter (fun i => a i = -1), u i) +
      (∑ i, ∑ j ∈ Finset.univ.filter (fun j => a i * a j = -1), v i j) ≤
      3 * (∑ i ∈ Finset.univ.filter (fun i => a i = -1), w i) := by
  classical
  let m : I → ℝ := fun i => if a i = -1 then w i else 0
  have hs : (∑ i, if a i = -1 then u i else 0) ≤ ∑ i, m i := by
    apply Finset.sum_le_sum
    intro i _
    split_ifs <;> simp_all [m, (hu i).2]
  have hp (i j : I) :
      (if a i * a j = -1 then v i j else 0) ≤ m i * w j + w i * m j := by
    rcases ha i with hi | hi <;> rcases ha j with hj | hj <;>
      norm_num [m, hi, hj] <;> nlinarith [(hv i j).2, mul_nonneg (hw i) (hw j)]
  have hps := Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) =>
    Finset.sum_le_sum (fun j (_ : j ∈ Finset.univ) => hp i j))
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.sum_mul,
    hmass, mul_one, one_mul] at hps
  simp only [Finset.sum_filter]
  change _ ≤ 3 * ∑ i, m i
  linarith

/-- Twice the negative mass is the unsigned sum minus the signed sum. -/
theorem negative_symmetry_mass_identity {I : Type*} [Fintype I]
    (u : I → ℝ) (v : I → I → ℝ) (a : I → ℝ)
    (ha : ∀ i, a i = 1 ∨ a i = -1) :
    2 * ((∑ i ∈ Finset.univ.filter (fun i => a i = -1), u i) +
      (∑ i, ∑ j ∈ Finset.univ.filter (fun j => a i * a j = -1), v i j)) =
      (∑ i, u i) + (∑ i, ∑ j, v i j) -
      ((∑ i, u i * a i) + (∑ i, ∑ j, v i j * (a i * a j))) := by
  classical
  have hs := negative_mass_identity u a ha
  have hp (i : I) := negative_mass_identity (v i) (fun j => a i * a j) (by
    intro j
    rcases ha i with hi | hi <;> rcases ha j with hj | hj <;> simp [hi, hj])
  have hps := congrArg (fun f : I → ℝ => ∑ i, f i) (funext hp)
  simp only [Finset.sum_sub_distrib, ← Finset.mul_sum] at hps
  linarith

theorem positive_sign_excluded {I : Type*} [Fintype I]
    (w u : I → ℝ) (v : I → I → ℝ) (a : I → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hmass : ∑ i, w i = 1)
    (hu : ∀ i, 0 ≤ u i ∧ u i ≤ w i)
    (hv : ∀ i j, 0 ≤ v i j ∧ v i j ≤ w i * w j)
    (ha : ∀ i, a i = 1 ∨ a i = -1)
    (htotal : 9/10 ≤ (∑ i, u i) + (∑ i, ∑ j, v i j))
    (hsigned : (∑ i, u i * a i) + (∑ i, ∑ j, v i j * (a i * a j)) ≤ 1/10) :
    (∑ i, w i * a i) ≤ 3/4 := by
  have hbound := negative_symmetry_mass_bound w u v a hw hmass hu hv ha
  have hsym := negative_symmetry_mass_identity u v a ha
  have hmassneg := negative_mass_identity w a ha
  rw [hmass] at hmassneg
  linarith

theorem negative_mass_of_large_abs_bias {I : Type*} [Fintype I]
    (w a : I → ℝ) (ha : ∀ i, a i = 1 ∨ a i = -1)
    (hmass : ∑ i, w i = 1)
    (hpositive : (∑ i, w i * a i) ≤ 3/4)
    (hlarge : 19/20 < |∑ i, w i * a i|) :
    39/40 < ∑ i ∈ Finset.univ.filter (fun i => a i = -1), w i := by
  have hid := negative_mass_identity w a ha
  rw [hmass] at hid
  rcases lt_abs.mp hlarge with h | h <;> linarith

end MissingLinnik

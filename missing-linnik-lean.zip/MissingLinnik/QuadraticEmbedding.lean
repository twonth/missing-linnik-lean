import MissingLinnik.QuadraticNorm
import Mathlib.Analysis.Complex.Basic

namespace MissingLinnik

noncomputable def quadraticComplexEmbedding (d : ℤ) (a : ℂ) (ha : a ^ 2 = d) :
    Zsqrtd d →+* ℂ where
  toFun x := (x.re : ℂ) + (x.im : ℂ) * a
  map_zero' := by simp
  map_one' := by simp
  map_add' x y := by simp; ring
  map_mul' x y := by
    simp only [Zsqrtd.re_mul, Zsqrtd.im_mul, Int.cast_add, Int.cast_mul]
    calc
      _ = (x.re : ℂ) * y.re + x.im * y.im * (d : ℂ) +
        ((x.re : ℂ) * y.im + x.im * y.re) * a := by ring
      _ = _ := by rw [← ha]; ring

theorem quadratic_norm_complex_product (d : ℤ) (a : ℂ) (ha : a ^ 2 = d)
    (x : Zsqrtd d) :
    (x.norm : ℂ) = quadraticComplexEmbedding d a ha x *
      quadraticComplexEmbedding d (-a) (by simpa using ha) x := by
  simp only [quadraticComplexEmbedding, RingHom.coe_mk, MonoidHom.coe_mk, OneHom.coe_mk,
    Zsqrtd.norm_def, Int.cast_sub, Int.cast_mul]
  rw [← ha]
  ring

theorem quadratic_norm_natAbs_eq (d : ℤ) (a : ℂ) (ha : a ^ 2 = d)
    (x : Zsqrtd d) :
    (x.norm.natAbs : ℝ) = ‖quadraticComplexEmbedding d a ha x‖ *
      ‖quadraticComplexEmbedding d (-a) (by simpa using ha) x‖ := by
  have hh := congrArg norm (quadratic_norm_complex_product d a ha x)
  simpa using hh

theorem quadraticComplexEmbedding_bound (d : ℤ) (a : ℂ) (ha : a ^ 2 = d)
    (x : Zsqrtd d) (M A : ℝ) (hM : 0 ≤ M)
    (hre : |(x.re : ℝ)| ≤ M) (him : |(x.im : ℝ)| ≤ M) (haA : ‖a‖ ≤ A) :
    ‖quadraticComplexEmbedding d a ha x‖ ≤ M * (1 + A) := by
  change ‖(x.re : ℂ) + (x.im : ℂ) * a‖ ≤ _
  calc
    _ ≤ ‖(x.re : ℂ)‖ + ‖(x.im : ℂ) * a‖ := norm_add_le _ _
    _ = |(x.re : ℝ)| + |(x.im : ℝ)| * ‖a‖ := by simp
    _ ≤ M + M * A := add_le_add hre (mul_le_mul him haA (norm_nonneg _) hM)
    _ = _ := by ring

end MissingLinnik

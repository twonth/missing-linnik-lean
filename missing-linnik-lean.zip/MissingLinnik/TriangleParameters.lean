import MissingLinnik.TriangleEstimate

namespace MissingLinnik.Triangle

theorem slope_parameters (Y L : ℕ) (hY : 1024 ≤ Y) (hL : 8*Y ≤ L) :
    8 ≤ L/Y+1 ∧ L/Y+1 < L ∧ L ≤ Y*(L/Y+1) ∧ Y*(L/Y+1) ≤ 2*L := by
  have hY0 : 0 < Y := by omega
  have hdiv : 8 ≤ L/Y := (Nat.le_div_iff_mul_le hY0).mpr (by nlinarith)
  have hlow := Nat.mul_div_le L Y
  have he := Nat.mod_add_div L Y
  have hm := Nat.mod_lt L hY0
  constructor
  · omega
  constructor
  · nlinarith
  constructor
  · nlinarith
  · nlinarith

theorem scalar_bound (Y L S b l Q M : ℝ)
    (hY : 1024 ≤ Y) (hL : 8*Y ≤ L) (hS : 0 ≤ S) (hYS : Y*S ≤ 2*L)
    (hl : 0 ≤ l) (hQ : 0 ≤ Q) (hb : b ≤ l/2+Q/2+3)
    (hM : M ≤ (1+512*S/L)*b + (512*(S+2)/L)*l+1024) :
    M ≤ (1/2+2048/Y)*l + Q + 1030 := by
  have hY0 : 0 < Y := by linarith
  have hL0 : 0 < L := by linarith
  have hu : 512*S/L ≤ 1 := (div_le_iff₀ hL0).mpr (by nlinarith)
  have hc : 768*S/L + 1024/L ≤ 2048/Y := by
    apply (le_div_iff₀ hY0).mpr
    have he : (768*S/L + 1024/L)*Y = (768*S*Y+1024*Y)/L := by ring
    rw [he]
    apply (div_le_iff₀ hL0).mpr
    nlinarith
  have hbm := mul_le_mul_of_nonneg_left hb (show 0 ≤ 1+512*S/L by positivity)
  have hlm := mul_le_mul_of_nonneg_right hc hl
  have hqm := mul_le_mul_of_nonneg_right hu hQ
  have hu3 := mul_le_mul_of_nonneg_right hu (by norm_num : (0:ℝ) ≤ 3)
  have he : (1+512*S/L)*(l/2+Q/2+3)+(512*(S+2)/L)*l+1024 =
      l/2+(768*S/L+1024/L)*l+Q/2+(512*S/L)*Q/2+3+3*(512*S/L)+1024 := by ring
  nlinarith only [hM,hbm,hlm,hqm,hu3,he]

end MissingLinnik.Triangle

import MissingLinnik.PrimeTailBounds
import Mathlib.Data.Nat.Log

namespace MissingLinnik

theorem prime_log_mass_pow_two (k : ℕ) (P : Finset ℕ)
    (hp : ∀ p ∈ P, p.Prime) (hupper : ∀ p ∈ P, p ≤ 2^k) :
    (∑ p ∈ P, Real.log p/p) ≤ 2*Real.log 4*(k:ℝ) := by
  classical
  induction k generalizing P with
  | zero =>
    have hP : P = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro p hpP
      have hh := hupper p hpP
      have h2 := (hp p hpP).two_le
      norm_num at hh
      omega
    simp [hP]
  | succ k ih =>
    let A := P.filter (fun p => p ≤ 2^k)
    let B := P.filter (fun p => ¬ p ≤ 2^k)
    have hA := ih A (fun p h => hp p (Finset.mem_filter.mp h).1)
      (fun p h => (Finset.mem_filter.mp h).2)
    have hB := prime_mass_tail_le B (2^(k+1)) ((2:ℝ)^k) (by positivity)
      (fun p h => hp p (Finset.mem_filter.mp h).1)
      (fun p h => by exact_mod_cast (Nat.le_of_lt (not_le.mp (Finset.mem_filter.mp h).2)))
      (fun p h => hupper p (Finset.mem_filter.mp h).1)
    have hpow : (2:ℝ)^k ≠ 0 := by positivity
    have hB' : (∑ p ∈ B, Real.log p/p) ≤ 2*Real.log 4 := by
      convert hB using 1
      push_cast
      rw [pow_succ]
      field_simp
    have hs : (∑ p ∈ A, Real.log p/p)+(∑ p ∈ B, Real.log p/p) =
        ∑ p ∈ P, Real.log p/p := by
      exact Finset.sum_filter_add_sum_filter_not _ _ _
    push_cast
    linarith

/-- A logarithmic bound from Chebyshev alone, sufficient for Rankin's
trick. This is not the sharper Mertens asymptotic used later in Linnik. -/
theorem prime_log_mass_le_eight_log (P : Finset ℕ) (X : ℕ) (hX : 2 ≤ X)
    (hp : ∀ p ∈ P, p.Prime) (hupper : ∀ p ∈ P, p ≤ X) :
    (∑ p ∈ P, Real.log p/p) ≤ 8*Real.log X := by
  have hX0 : X ≠ 0 := by omega
  have hbound : X < 2^(Nat.log 2 X+1) := Nat.lt_pow_of_log_lt (by norm_num) (by omega)
  have hh := prime_log_mass_pow_two (Nat.log 2 X+1) P hp
    (fun p h => (hupper p h).trans hbound.le)
  have hpow : (2:ℝ)^(Nat.log 2 X) ≤ X := by exact_mod_cast Nat.pow_log_le_self 2 hX0
  have hl := Real.log_le_log (by positivity : (0:ℝ)<2^(Nat.log 2 X)) hpow
  rw [Real.log_pow] at hl
  have hl2 : Real.log (2:ℝ) ≤ Real.log X :=
    Real.log_le_log (by norm_num) (by exact_mod_cast hX)
  have hl4 : Real.log (4:ℝ) = 2*Real.log 2 := by
    rw [show (4:ℝ)=2^2 by norm_num,Real.log_pow]; norm_num
  rw [hl4] at hh
  push_cast at hh
  nlinarith only [hh,hl,hl2]

end MissingLinnik

import MissingLinnik.TriangleRows
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import MissingLinnik.FloorSum

namespace MissingLinnik.Triangle

theorem card_le_rectangle (L Y S : ℕ) : Fintype.card (Row L Y S) ≤ L*S := by
  simpa using Fintype.card_le_of_injective
    (fun i : Row L Y S => i.val) Subtype.val_injective

theorem degree_sum_lower (L Y S a b : ℕ) (hb : b ≤ S)
    (hinside : 2*a+Y*b ≤ L) :
    a*a*b ≤ ∑ i : Row L Y S, i.val.1.val := by
  classical
  let f : (Fin a × Fin b) → Row L Y S := fun i =>
    ⟨(⟨a+i.1.val,by have := i.1.isLt; omega⟩,
      ⟨i.2.val,lt_of_lt_of_le i.2.isLt hb⟩),by
      change a+i.1.val+Y*i.2.val < L
      have h1 := i.1.isLt
      have h2 := Nat.mul_le_mul_left Y (Nat.le_of_lt i.2.isLt)
      omega⟩
  have hf : Function.Injective f := by
    intro i j he
    have h1 := congrArg (fun v : Row L Y S => v.val.1.val) he
    have h2 := congrArg (fun v : Row L Y S => v.val.2.val) he
    apply Prod.ext
    · apply Fin.ext
      dsimp [f] at h1
      omega
    · exact Fin.ext h2
  have hs : (∑ i : Fin a × Fin b, a) ≤ ∑ i : Row L Y S, i.val.1.val := by
    apply Finset.sum_le_sum_of_injOn f
    · exact hf.injOn
    · intro i _; simp
    · intro i _; change a ≤ a+i.1.val; omega
    · intro i _ _; exact Nat.zero_le _
  simpa [mul_comm,mul_left_comm,mul_assoc] using hs

theorem degree_sum_dominates_card (L Y S : ℕ) (hL : 8 ≤ L) (hS : 8 ≤ S)
    (hYS : Y*S ≤ 2*L) :
    (L:ℝ)*(Fintype.card (Row L Y S):ℝ) ≤
      512 * ∑ i : Row L Y S, (i.val.1.val:ℝ) := by
  have ha : L ≤ 8*(L/4) := by omega
  have hb : S ≤ 8*(S/4) := by omega
  have ha4 : 4*(L/4) ≤ L := Nat.mul_div_le _ _
  have hb4 : 4*(S/4) ≤ S := Nat.mul_div_le _ _
  have hinside : 2*(L/4)+Y*(S/4) ≤ L := by nlinarith
  have he := degree_sum_lower L Y S (L/4) (S/4) (Nat.div_le_self _ _) hinside
  have hc := card_le_rectangle L Y S
  have hprod : L*L*S ≤ (8*(L/4))*(8*(L/4))*(8*(S/4)) :=
    Nat.mul_le_mul (Nat.mul_le_mul ha ha) hb
  have hn : L*Fintype.card (Row L Y S) ≤ 512*∑ i : Row L Y S, i.val.1.val := by
    nlinarith
  exact_mod_cast hn

theorem second_degree_sum_le (L Y S : ℕ) :
    (∑ i : Row L Y S, (i.val.2.val:ℝ)) ≤ S*(Fintype.card (Row L Y S):ℝ) := by
  have hs := Finset.sum_le_sum (s := Finset.univ)
    (fun (i : Row L Y S) _ => (show (i.val.2.val:ℝ) ≤ S by exact_mod_cast Nat.le_of_lt i.val.2.isLt))
  simpa [mul_comm] using hs

end MissingLinnik.Triangle

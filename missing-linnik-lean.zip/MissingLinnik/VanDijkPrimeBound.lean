import MissingLinnik.VanDijkWindowBound
import MissingLinnik.PrimeWindowDecomposition

namespace MissingLinnik.VanDijk

open Classical

theorem prime_set_bound_at_inert_prime (k p₀ : ℕ) (hk : 8 ≤ k)
    [Fact p₀.Prime] (d : ℤ) (hd : legendreSym p₀ d = -1)
    (a : ℂ) (ha : a^2=d) (q : ℝ) (hq : 1 ≤ q) (haq : ‖a‖^2 ≤ q)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime) (hupper : ∀ p ∈ P, p ≤ p₀)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) :
    (∑ p ∈ P, Real.log p / p) ≤
      (1/2+8/(k:ℝ))*Real.log p₀ + Real.log q + 4*(k:ℝ)^2 := by
  have hl4 : Real.log (4:ℝ) ≤ 2 := by
    have hl2 := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    rw [show (4:ℝ)=2^2 by norm_num, Real.log_pow]
    norm_num
    linarith
  have hlogp : 0 ≤ Real.log (p₀:ℝ) := Real.log_nonneg
    (by exact_mod_cast (Fact.out : p₀.Prime).one_le)
  have hlogq : 0 ≤ Real.log q := Real.log_nonneg hq
  by_cases hkp : k^2 ≤ p₀
  · let S := k*(p₀/k^2)
    have hmid := window_prime_bound k p₀ hk hkp d hd a ha q hq haq
      (P.filter (fun p => k^2 ≤ p ∧ p ≤ S))
      (fun p hp => hprime p (Finset.mem_filter.mp hp).1)
      (fun p hp => (Finset.mem_filter.mp hp).2.1)
      (fun p hp => (Finset.mem_filter.mp hp).2.2)
      (fun p hp => hinert p (Finset.mem_filter.mp hp).1)
    obtain ⟨hm,_,_,hpR,_⟩ := floor_parameter_bounds k p₀ hk hkp
    have hS : 0 < S := by dsimp only [S]; positivity
    have hpS : p₀ ≤ 2*k*S := by dsimp only [S]; nlinarith
    have hext := prime_window_extension P k S p₀ hS hprime hupper hpS _ hmid
    have hh := mul_le_mul_of_nonneg_right hl4
      (show (0:ℝ) ≤ (k:ℝ)^2+2*k by positivity)
    have hkr : (8:ℝ) ≤ k := by exact_mod_cast hk
    nlinarith [sq_nonneg ((k:ℝ)-8)]
  · have hsmall := prime_mass_small_le P (k^2) hprime (fun p hp => by
      have := hupper p hp
      omega)
    push_cast at hsmall
    have hh := mul_le_mul_of_nonneg_right hl4 (sq_nonneg (k:ℝ))
    have hmain : 0 ≤ (1/2+8/(k:ℝ))*Real.log p₀ := by positivity
    nlinarith

/-- Explicit quadratic anti-concentration obtained by adapting van Dijk's
argument to the largest inert prime in a finite set. -/
theorem prime_set_bound (k X : ℕ) (hk : 8 ≤ k) (hX : 1 ≤ X)
    (d : ℤ) (a : ℂ) (ha : a^2=d) (q : ℝ) (hq : 1 ≤ q) (haq : ‖a‖^2 ≤ q)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime) (hupper : ∀ p ∈ P, p ≤ X)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) :
    (∑ p ∈ P, Real.log p / p) ≤
      (1/2+8/(k:ℝ))*Real.log X + Real.log q + 4*(k:ℝ)^2 := by
  by_cases hP : P.Nonempty
  · let p₀ := P.max' hP
    have hpP : p₀ ∈ P := Finset.max'_mem P hP
    letI : Fact p₀.Prime := ⟨hprime p₀ hpP⟩
    have hh := prime_set_bound_at_inert_prime k p₀ hk d (hinert p₀ hpP) a ha q hq haq P
      hprime (fun p hp => Finset.le_max' P p hp) hinert
    have hlog := Real.log_le_log
      (show (0:ℝ) < p₀ by exact_mod_cast (hprime p₀ hpP).pos)
      (show (p₀:ℝ) ≤ X by exact_mod_cast hupper p₀ hpP)
    have hmul := mul_le_mul_of_nonneg_left hlog (show (0:ℝ) ≤ 1/2+8/(k:ℝ) by positivity)
    linarith
  · have he : P = ∅ := Finset.not_nonempty_iff_eq_empty.mp hP
    rw [he, Finset.sum_empty]
    have hlogX := Real.log_nonneg (show (1:ℝ) ≤ X by exact_mod_cast hX)
    have hlogq := Real.log_nonneg hq
    positivity

end MissingLinnik.VanDijk

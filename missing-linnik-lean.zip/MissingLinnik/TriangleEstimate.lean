import MissingLinnik.TriangleFiniteBound
import MissingLinnik.TriangleGeometry
import MissingLinnik.DeterminantEstimate

namespace MissingLinnik.Triangle

theorem normalized_bound (L Y S : ℕ) (B M θ : ℝ)
    (hL : 8 ≤ L) (hS : 8 ≤ S) (hSL : S ≤ L) (hYS : Y*S ≤ 2*L)
    (hB : 1 ≤ B) (hθ : θ ≤ 2*L)
    (hbound : (∑ i : Row L Y S, (i.val.1.val:ℝ))*M ≤
      Real.log ((Fintype.card (Row L Y S)).factorial:ℝ) +
      (∑ i : Row L Y S,
        ((S:ℝ)*Real.log L + ((i.val.1.val+i.val.2.val:ℕ):ℝ)*Real.log B)) +
      (Fintype.card (Row L Y S):ℝ)*θ) :
    M ≤ (1+512*(S:ℝ)/L)*Real.log B +
      (512*((S:ℝ)+2)/L)*Real.log L + 1024 := by
  classical
  let N := Fintype.card (Row L Y S)
  let E : ℝ := ∑ i : Row L Y S, (i.val.1.val:ℝ)
  have hL0 : (0:ℝ) < L := by exact_mod_cast (show 0<L by omega)
  have hN0 : 0 < N := by
    apply Fintype.card_pos_iff.mpr
    exact ⟨⟨(⟨0,by omega⟩,⟨0,by omega⟩),by simpa using (show 0<L by omega)⟩⟩
  have hNr : (0:ℝ) < N := by exact_mod_cast hN0
  have hc : (N:ℝ) ≤ (L:ℝ)^2 := by
    have hh := card_le_rectangle L Y S
    exact_mod_cast (show N ≤ L^2 by dsimp [N]; nlinarith)
  have hE := degree_sum_dominates_card L Y S hL hS hYS
  change (L:ℝ)*N ≤ 512*E at hE
  have hE0 : 0 < E := by nlinarith [mul_pos hL0 hNr]
  have hlogL : 0 ≤ Real.log (L:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤L by omega))
  have hlogB : 0 ≤ Real.log B := Real.log_nonneg hB
  have hlogN : Real.log (N:ℝ) ≤ 2*Real.log L := by
    have hh := Real.log_le_log hNr hc
    simpa only [Real.log_pow, Nat.cast_ofNat] using hh
  have hfac := (log_factorial_le N).trans
    (mul_le_mul_of_nonneg_left hlogN hNr.le)
  have hs := second_degree_sum_le L Y S
  have hsum : (∑ i : Row L Y S,
      ((S:ℝ)*Real.log L + ((i.val.1.val+i.val.2.val:ℕ):ℝ)*Real.log B)) ≤
      S*N*Real.log L + (E+S*N)*Real.log B := by
    push_cast
    simp only [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ,
      nsmul_eq_mul, add_mul, ← Finset.sum_mul]
    dsimp only [E,N] at *
    nlinarith [mul_le_mul_of_nonneg_right hs hlogB]
  have hθ' := mul_le_mul_of_nonneg_left hθ hNr.le
  have hh : E*M ≤ E*Real.log B + N*((S+2)*Real.log L + S*Real.log B + 2*L) := by
    dsimp only [N,E] at *
    nlinarith only [hbound,hfac,hsum,hθ']
  have hcoef : 0 ≤ ((S:ℝ)+2)*Real.log L + S*Real.log B + 2*L := by positivity
  have hscaled := mul_le_mul_of_nonneg_right hE hcoef
  have hscaled' := mul_le_mul_of_nonneg_left hh hL0.le
  apply (mul_le_mul_iff_right₀ hE0).mp
  apply (mul_le_mul_iff_right₀ hL0).mp
  have he : ((1+512*(S:ℝ)/L)*Real.log B +
      (512*((S:ℝ)+2)/L)*Real.log L + 1024)*E*L =
      E*((L+512*S)*Real.log B + 512*(S+2)*Real.log L + 1024*L) := by
    field_simp
    <;> ring
  nlinarith only [hscaled,hscaled',he]

end MissingLinnik.Triangle

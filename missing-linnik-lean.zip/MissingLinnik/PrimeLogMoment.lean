import MissingLinnik.PrimeMassReal

namespace MissingLinnik

open Finset MeasureTheory

noncomputable def primeLogMoment (x : ℝ) : ℝ :=
  ∑ p ∈ Nat.primesLE (Nat.floor x), (Real.log p)^2/(p:ℝ)

theorem sum_log_primeCoefficient (x : ℝ) :
    (∑ n ∈ Finset.Icc 0 (Nat.floor x), Real.log n*primeCoefficient n) = primeLogMoment x := by
  rw [primeLogMoment,Nat.primesLE_eq_filter_Icc_zero,Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hp : n.Prime
  · simp [primeCoefficient,hp]; ring
  · simp [primeCoefficient,hp]

theorem inv_integrableOn_Icc_one (x : ℝ) :
    IntegrableOn (fun t : ℝ => t⁻¹) (Set.Icc 1 x) := by
  apply ContinuousOn.integrableOn_Icc
  apply continuousOn_id.inv₀
  intro t ht
  change t ≠ 0
  linarith [ht.1]

theorem prime_log_moment_identity (x : ℝ) :
    primeLogMoment x = Real.log x*primeMass x-
      ∫ t in Set.Ioc 1 x, t⁻¹*primeMass t := by
  have hh := sum_mul_eq_sub_integral_mul₀ primeCoefficient (by simp [primeCoefficient]) x
    (f := Real.log)
    (fun t ht => Real.differentiableAt_log (by linarith [ht.1]))
    (by simpa only [Real.deriv_log'] using inv_integrableOn_Icc_one x)
  simpa only [sum_log_primeCoefficient,sum_primeCoefficient,Real.deriv_log] using hh

theorem log_inv_continuousOn_Icc_one (x : ℝ) :
    ContinuousOn (fun t : ℝ => t⁻¹*Real.log t) (Set.Icc 1 x) := by
  intro t ht
  have ht0 : t ≠ 0 := by linarith [ht.1]
  exact (continuousAt_inv₀ ht0).continuousWithinAt.mul
    (Real.continuousAt_log ht0).continuousWithinAt

theorem integral_log_inv_one (x : ℝ) (hx : 1 ≤ x) :
    (∫ t in Set.Ioc 1 x, t⁻¹*Real.log t) = (Real.log x)^2/2 := by
  have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (f := fun t : ℝ => (Real.log t)^2/2) (f' := fun t : ℝ => t⁻¹*Real.log t)
    (a := 1) (b := x) (by
      intro t ht
      rw [Set.uIcc_of_le hx] at ht
      have ht0 : t ≠ 0 := by linarith [ht.1]
      have hd := ((Real.hasDerivAt_log ht0).pow 2).div_const 2
      convert hd using 1 <;> ring)
    ((log_inv_continuousOn_Icc_one x).intervalIntegrable_of_Icc hx)
  rw [intervalIntegral.integral_of_le hx] at hh
  simpa using hh

theorem primeMass_inv_integrableOn (x : ℝ) :
    IntegrableOn (fun t : ℝ => t⁻¹*primeMass t) (Set.Icc 1 x) := by
  have hh := integrableOn_mul_sum_Icc primeCoefficient (m := 0)
    (by norm_num : (0:ℝ) ≤ 1) (inv_integrableOn_Icc_one x)
  simpa only [sum_primeCoefficient] using hh

theorem integral_primeMass_error (x : ℝ) (hx : 1 ≤ x) :
    |(∫ t in Set.Ioc 1 x, t⁻¹*primeMass t)-(Real.log x)^2/2| ≤ 79*Real.log x := by
  have hi := (inv_integrableOn_Icc_one x).mono_set Set.Ioc_subset_Icc_self
  have hl : IntegrableOn (fun t : ℝ => t⁻¹*Real.log t) (Set.Ioc 1 x) :=
    (log_inv_continuousOn_Icc_one x).integrableOn_Icc.mono_set Set.Ioc_subset_Icc_self
  have hm := (primeMass_inv_integrableOn x).mono_set Set.Ioc_subset_Icc_self
  have hconst := hi.const_mul 79
  have hlo := MeasureTheory.setIntegral_mono_on (hl.sub hconst) hm measurableSet_Ioc
    (fun t ht => by
      have herr := (abs_le.mp (prime_mass_mertens t ht.1.le)).1
      have ht0 : (0:ℝ) ≤ t⁻¹ := inv_nonneg.mpr (by linarith [ht.1])
      have hh := mul_le_mul_of_nonneg_left herr ht0
      dsimp
      nlinarith only [hh])
  have hhi := MeasureTheory.setIntegral_mono_on hm (hl.add hconst) measurableSet_Ioc
    (fun t ht => by
      have herr := (abs_le.mp (prime_mass_mertens t ht.1.le)).2
      have ht0 : (0:ℝ) ≤ t⁻¹ := inv_nonneg.mpr (by linarith [ht.1])
      have hh := mul_le_mul_of_nonneg_left herr ht0
      dsimp
      nlinarith only [hh])
  have he : (∫ t in Set.Ioc 1 x, (t:ℝ)⁻¹) = Real.log x := by
    have hh := integral_inv_of_pos (by norm_num : (0:ℝ)<1) (show 0<x by linarith)
    rw [intervalIntegral.integral_of_le hx] at hh
    simpa using hh
  simp only [Pi.sub_apply,Pi.add_apply] at hlo hhi
  rw [MeasureTheory.integral_sub hl hconst,MeasureTheory.integral_const_mul,
    integral_log_inv_one x hx,he] at hlo
  rw [MeasureTheory.integral_add hl hconst,MeasureTheory.integral_const_mul,
    integral_log_inv_one x hx,he] at hhi
  exact abs_le.mpr ⟨by linarith,by linarith⟩

theorem prime_log_moment_estimate (x : ℝ) (hx : 1 ≤ x) :
    |primeLogMoment x-(Real.log x)^2/2| ≤ 158*Real.log x := by
  have hmass := abs_le.mp (prime_mass_mertens x hx)
  have hint := abs_le.mp (integral_primeMass_error x hx)
  have hlog : 0 ≤ Real.log x := Real.log_nonneg hx
  have hlo := mul_le_mul_of_nonneg_left hmass.1 hlog
  have hhi := mul_le_mul_of_nonneg_left hmass.2 hlog
  rw [prime_log_moment_identity]
  apply abs_le.mpr
  constructor <;> nlinarith only [hint.1,hint.2,hlo,hhi]

end MissingLinnik

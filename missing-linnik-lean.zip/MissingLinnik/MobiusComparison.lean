import MissingLinnik.RoughWeightedSums
import MissingLinnik.RoughHarmonic
import MissingLinnik.SelbergIdentity

namespace MissingLinnik

open scoped Classical

noncomputable def symmetryComparisonConstant : ℝ :=
  9000*(2*roughDiscrepancyConstant+1)*(1+6*roughUpperConstant)

/-- Weighted convolution comparison. The residue representative b(d) is supplied
by inversion modulo q when this estimate is applied to Selberg's identity. -/
theorem mobius_rough_comparison (q k : ℕ) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (b : ℕ → ℕ) (hb : ∀ d, IsRough (q^(170*k)) d → (b d).Coprime q)
    (x : ℝ) (hx : ((q^(170*k):ℕ):ℝ) ≤ x) :
    |∑ d ∈ (Finset.Icc 1 (Nat.floor x)).filter (IsRough (q^(170*k))),
      (ArithmeticFunction.moebius d:ℝ)/(d:ℝ)*
      (roughWeightedClassSum q (b d) (q^(170*k)) (x/d)-roughWeightedSum (q^(170*k)) (x/d)/q.totient)| ≤
      symmetryComparisonConstant*Real.log ((q^(170*k):ℕ):ℝ)*Real.log x/q.totient := by
  let Y := q^(170*k)
  let E := 9000*(2*roughDiscrepancyConstant+1)*(Real.log (Y:ℝ))^2/q.totient
  have hφ : (0:ℝ) < q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have hqY : q ≤ Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hlY : 0 < Real.log (Y:ℝ) := Real.log_pos (by exact_mod_cast (show 1<Y by omega))
  have hC : 0 ≤ roughDiscrepancyConstant := by
    unfold roughDiscrepancyConstant roughUpperConstant
    positivity
  have hE : 0 ≤ E := by dsimp [E]; positivity
  calc
    _ ≤ ∑ d ∈ (Finset.Icc 1 (Nat.floor x)).filter (IsRough Y),
      |(ArithmeticFunction.moebius d:ℝ)/(d:ℝ)*
      (roughWeightedClassSum q (b d) Y (x/d)-roughWeightedSum Y (x/d)/q.totient)| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ d ∈ (Finset.Icc 1 (Nat.floor x)).filter (IsRough Y), E*(d:ℝ)⁻¹ := by
      apply Finset.sum_le_sum
      intro d hd
      obtain ⟨hd,hrough⟩ := Finset.mem_filter.mp hd
      obtain ⟨hd1,hdx⟩ := Finset.mem_Icc.mp hd
      have hd0 : (0:ℝ)<d := by exact_mod_cast (show 0<d by omega)
      have hx0 : 0≤x := (Nat.cast_nonneg Y).trans hx
      have hdxR : (d:ℝ) ≤ x := (show (d:ℝ)≤Nat.floor x by exact_mod_cast hdx).trans (Nat.floor_le hx0)
      have hxdiv : 1≤x/(d:ℝ) := (le_div_iff₀ hd0).mpr (by simpa using hdxR)
      have herror := roughWeightedSum_comparison q k (b d) hq hk (hb d hrough) (x/d) hxdiv
      have hμ : |(ArithmeticFunction.moebius d:ℝ)| ≤ 1 := by
        exact_mod_cast (ArithmeticFunction.abs_moebius_le_one (n := d))
      have hw : |(ArithmeticFunction.moebius d:ℝ)/(d:ℝ)| ≤ (d:ℝ)⁻¹ := by
        rw [abs_div,abs_of_pos hd0]
        simpa only [one_div] using div_le_div_of_nonneg_right hμ hd0.le
      rw [abs_mul]
      have hm := mul_le_mul hw herror (abs_nonneg _) (inv_nonneg.mpr hd0.le)
      change _ ≤ (d:ℝ)⁻¹*E at hm
      exact hm.trans_eq (mul_comm _ _)
    _ = E*∑ d ∈ (Finset.Icc 1 (Nat.floor x)).filter (IsRough Y), (d:ℝ)⁻¹ := by rw [Finset.mul_sum]
    _ ≤ E*((1+6*roughUpperConstant)*Real.log x/Real.log (Y:ℝ)) :=
      mul_le_mul_of_nonneg_left (rough_harmonic_bound q k hq hk x hx) hE
    _ = _ := by
      dsimp [E,symmetryComparisonConstant]
      change 9000*(2*roughDiscrepancyConstant+1)*(Real.log (Y:ℝ))^2/q.totient*
        ((1+6*roughUpperConstant)*Real.log x/Real.log (Y:ℝ)) = _
      field_simp
      <;> ring

end MissingLinnik

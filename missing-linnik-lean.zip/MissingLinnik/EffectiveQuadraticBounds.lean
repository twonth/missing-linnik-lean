import MissingLinnik.GreenPrimeBound
import MissingLinnik.VanDijkPrimeBound
import MissingLinnik.EffectiveExponent
import MissingLinnik.QuadraticRoot

namespace MissingLinnik

/-- The common, effective quadratic-prime conclusion. The bridge from primitive
real Dirichlet characters to quadratic discriminants is not assumed here. -/
def QuadraticPrimeBounds (A : ℕ → ℕ) : Prop :=
  ∀ (j : ℕ) (q x : ℝ), 2 ≤ q → q ^ A j ≤ x →
  ∀ (d : ℤ), (∀ n : ℤ, d ≠ n*n) →
  ∀ (a : ℂ), a^2 = d → ‖a‖^2 ≤ q →
  ∀ (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime),
    (∀ p ∈ P, (p : ℝ) ≤ x) →
    (∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) →
    (∑ p ∈ P, Real.log p / p) ≤ (1/2+1/((j:ℝ)+1))*Real.log x

private theorem transfer_real_cutoff (j : ℕ) (q x : ℝ) (hq : 2 ≤ q)
    (hx : q ^ quadraticExponent j ≤ x) (P : Finset ℕ)
    (hbound : ∀ X : ℕ, 1 ≤ X → (∀ p ∈ P, p ≤ X) →
      (∑ p ∈ P, Real.log p / p) ≤
      (1/2+8/((16*(j+1):ℕ):ℝ))*Real.log X + Real.log q +
        128*(((16*(j+1):ℕ):ℝ)^2))
    (hupper : ∀ p ∈ P, (p : ℝ) ≤ x) :
    (∑ p ∈ P, Real.log p / p) ≤ (1/2+1/((j:ℝ)+1))*Real.log x := by
  have hx1 : 1 ≤ x := le_trans (one_le_pow₀ (by linarith : (1:ℝ) ≤ q)) hx
  have hf1 : 1 ≤ ⌊x⌋₊ := Nat.le_floor (by simpa using hx1)
  have hh := hbound ⌊x⌋₊ hf1 (fun p hp => Nat.le_floor (hupper p hp))
  have hlog : Real.log (⌊x⌋₊:ℝ) ≤ Real.log x :=
    Real.log_le_log (by exact_mod_cast (show 0 < ⌊x⌋₊ by omega))
      (Nat.floor_le (by linarith))
  have hmul := mul_le_mul_of_nonneg_left hlog
    (show (0:ℝ) ≤ 1/2+8/((16*(j+1):ℕ):ℝ) by positivity)
  exact le_trans (by linarith : _ ≤
    (1/2+8/((16*(j+1):ℕ):ℝ))*Real.log x + Real.log q +
      128*(((16*(j+1):ℕ):ℝ)^2)) (effective_error_absorption j q x hq hx)

/-- Green's interpolation argument gives a computable uniform exponent. -/
theorem green_quadratic_bounds : QuadraticPrimeBounds quadraticExponent := by
  intro j q x hq hx d hd a ha haq P hprime hupper hinert
  apply transfer_real_cutoff j q x hq hx P _ hupper
  intro X hX hPX
  exact Green.prime_set_bound (16*(j+1)) X (by omega) hX d hd a ha q
    (by linarith) haq P hprime hPX hinert

/-- Van Dijk's finite-field argument gives the same computable exponent. -/
theorem vanDijk_quadratic_bounds : QuadraticPrimeBounds quadraticExponent := by
  intro j q x hq hx d _hd a ha haq P hprime hupper hinert
  apply transfer_real_cutoff j q x hq hx P _ hupper
  intro X hX hPX
  have hh := VanDijk.prime_set_bound (16*(j+1)) X (by omega) hX d a ha q
    (by linarith) haq P hprime hPX hinert
  nlinarith [sq_nonneg (((16*(j+1):ℕ):ℝ))]

/-- Remove the auxiliary embedding from the common conclusion. -/
theorem quadratic_bounds_of_natAbs (A : ℕ → ℕ) (hA : QuadraticPrimeBounds A)
    (j : ℕ) (q x : ℝ) (hq : 2 ≤ q) (hx : q ^ A j ≤ x)
    (d : ℤ) (hd : ∀ n : ℤ, d ≠ n*n) (hdq : (d.natAbs:ℝ) ≤ q)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime)
    (hupper : ∀ p ∈ P, (p:ℝ) ≤ x)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) :
    (∑ p ∈ P, Real.log p / p) ≤ (1/2+1/((j:ℝ)+1))*Real.log x := by
  obtain ⟨a,ha,hasize⟩ := exists_quadratic_root d
  exact hA j q x hq hx d hd a ha (hasize.trans_le hdq) P hprime hupper hinert

/-- The ordinary positive-real-epsilon formulation, valid at every sufficiently
large real cutoff and for every finite set of inert primes below that cutoff. -/
theorem quadratic_bounds_real_epsilon (A : ℕ → ℕ) (hA : QuadraticPrimeBounds A)
    (ε : ℝ) (hε : 0 < ε) :
    ∃ B : ℕ, ∀ (q x : ℝ), 2 ≤ q → q ^ B ≤ x →
    ∀ (d : ℤ), (∀ n : ℤ, d ≠ n*n) → (d.natAbs:ℝ) ≤ q →
    ∀ (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime),
      (∀ p ∈ P, (p:ℝ) ≤ x) →
      (∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) →
      (∑ p ∈ P, Real.log p / p) ≤ (1/2+ε)*Real.log x := by
  obtain ⟨j,hj⟩ := exists_nat_one_div_lt hε
  refine ⟨A j, ?_⟩
  intro q x hq hx d hd hdq P hprime hupper hinert
  have hh := quadratic_bounds_of_natAbs A hA j q x hq hx d hd hdq P hprime hupper hinert
  have hx1 : 1 ≤ x := le_trans (one_le_pow₀ (by linarith : (1:ℝ) ≤ q)) hx
  exact hh.trans (mul_le_mul_of_nonneg_right (by linarith) (Real.log_nonneg hx1))

end MissingLinnik

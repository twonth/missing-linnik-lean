import MissingLinnik.DeterminantBound
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Tactic.Positivity

namespace MissingLinnik

theorem norm_derivative_monomial_le (R S r s j : ℕ) (z w : ℂ) (B : ℝ)
    (hR : 1 ≤ R) (hr : r ≤ R) (hj : j ≤ S)
    (hB : 1 ≤ B) (hz : ‖z‖ ≤ B) (hw : ‖w‖ ≤ B) :
    ‖(Polynomial.derivative^[j] ((Polynomial.X : Polynomial ℂ) ^ r)).eval z * w ^ s‖
      ≤ (R : ℝ) ^ S * B ^ (r + s) := by
  rw [Polynomial.iterate_derivative_X_pow_eq_C_mul]
  simp only [Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_pow,
    Polynomial.eval_X, norm_mul, norm_pow, Complex.norm_natCast]
  have hc : (r.descFactorial j : ℝ) ≤ (R : ℝ) ^ S := by
    have hn : r.descFactorial j ≤ R ^ S :=
      (Nat.descFactorial_le_pow r j).trans
        ((Nat.pow_le_pow_left hr j).trans (Nat.pow_le_pow_right hR hj))
    exact_mod_cast hn
  have hz' : ‖z‖ ^ (r - j) ≤ B ^ r :=
    (pow_le_pow_left₀ (norm_nonneg _) hz _).trans
      (pow_le_pow_right₀ hB (Nat.sub_le r j))
  have hw' : ‖w‖ ^ s ≤ B ^ s := pow_le_pow_left₀ (norm_nonneg _) hw _
  rw [pow_add]
  exact (mul_le_mul (mul_le_mul hc hz' (by positivity) (by positivity)) hw'
    (by positivity) (by positivity)).trans_eq (mul_assoc _ _ _)

end MissingLinnik

import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic.Linarith

namespace MissingLinnik

/-- Common final absorption step for the two determinant arguments.
This lemma does not supply the determinant bounds or their effective constants.
-/
theorem absorb_determinant_errors {M T δ ε C : ℝ}
    (hT : 0 ≤ T) (hε : 0 < ε) (hε1 : ε ≤ 1)
    (hδ0 : 0 ≤ δ) (hδ : δ ≤ ε / 8)
    (hC : C ≤ ε / 4 * T)
    (hbound : (1 - δ) * M ≤ (1 / 2 + δ) * T + C) :
    M ≤ (1 / 2 + ε) * T := by
  have hd1 : 0 < 1 - δ := by linarith
  have hdε : δ * ε ≤ δ := mul_le_of_le_one_right hδ0 hε1
  have hcoeff : (1 / 2 + δ + ε / 4) ≤ (1 - δ) * (1 / 2 + ε) := by
    nlinarith
  have hmul := mul_le_mul_of_nonneg_right hcoeff hT
  have hfinal : (1 - δ) * M ≤ (1 - δ) * ((1 / 2 + ε) * T) := by
    nlinarith
  exact le_of_mul_le_mul_left hfinal hd1

end MissingLinnik

import Mathlib.NumberTheory.ArithmeticFunction.VonMangoldt
import Mathlib.Tactic.Ring

namespace MissingLinnik

open ArithmeticFunction
open scoped ArithmeticFunction ArithmeticFunction.zeta ArithmeticFunction.Moebius

noncomputable def logWeight (f : ArithmeticFunction ℝ) : ArithmeticFunction ℝ :=
  ⟨fun n => Real.log n * f n, by simp⟩

@[simp] theorem logWeight_apply (f : ArithmeticFunction ℝ) (n : ℕ) :
    logWeight f n = Real.log n * f n := rfl

theorem logWeight_mul (f g : ArithmeticFunction ℝ) :
    logWeight (f * g) = logWeight f * g + f * logWeight g := by
  ext n
  simp only [logWeight_apply, ArithmeticFunction.mul_apply,
    ArithmeticFunction.add_apply, Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro d hd
  obtain ⟨hprod, hn⟩ := Nat.mem_divisorsAntidiagonal.mp hd
  have hd1 : d.1 ≠ 0 := by intro h; simp [h] at hprod; exact hn hprod.symm
  have hd2 : d.2 ≠ 0 := by intro h; simp [h] at hprod; exact hn hprod.symm
  rw [← hprod, Nat.cast_mul, Real.log_mul (by exact_mod_cast hd1) (by exact_mod_cast hd2)]
  ring

theorem logWeight_zeta : logWeight (ζ : ArithmeticFunction ℝ) = ArithmeticFunction.log := by
  ext n
  by_cases hn : n = 0
  · subst n; simp
  · simp [logWeight, ArithmeticFunction.natCoe_apply, ArithmeticFunction.zeta_apply_ne hn, hn]

/-- Selberg's exact two-prime identity in Dirichlet-convolution form. -/
theorem selberg_identity :
    (μ : ArithmeticFunction ℝ) * logWeight ArithmeticFunction.log =
      logWeight Λ + Λ * Λ := by
  have h := logWeight_mul (ζ : ArithmeticFunction ℝ) Λ
  rw [ArithmeticFunction.zeta_mul_vonMangoldt, logWeight_zeta] at h
  rw [h, mul_add, ← mul_assoc,
    ArithmeticFunction.moebius_mul_log_eq_vonMangoldt,
    ← mul_assoc, ArithmeticFunction.coe_moebius_mul_coe_zeta, one_mul, add_comm]

end MissingLinnik



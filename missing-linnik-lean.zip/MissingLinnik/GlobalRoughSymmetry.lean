import MissingLinnik.RoughMangoldtMass
import MissingLinnik.AbstractMertens

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

theorem roughMangoldtCoefficient_mul (Y d m : ℕ) :
    roughMangoldtCoefficient Y d*roughMangoldtCoefficient Y m =
      if IsRough Y (d*m) then vonMangoldt d*vonMangoldt m/((d*m:ℕ):ℝ) else 0 := by
  unfold roughMangoldtCoefficient
  simp only [isRough_mul,Nat.cast_mul]
  split_ifs <;> try ring
  all_goals tauto

theorem selbergKernel_rough_expansion (Y n : ℕ) :
    (if IsRough Y n then selbergKernel n/(n:ℝ) else 0) =
      Real.log n*roughMangoldtCoefficient Y n+
        ∑ a ∈ n.divisorsAntidiagonal, roughMangoldtCoefficient Y a.1*roughMangoldtCoefficient Y a.2 := by
  have hs : (∑ a ∈ n.divisorsAntidiagonal, roughMangoldtCoefficient Y a.1*roughMangoldtCoefficient Y a.2) =
      if IsRough Y n then (∑ a ∈ n.divisorsAntidiagonal, vonMangoldt a.1*vonMangoldt a.2)/(n:ℝ) else 0 := by
    by_cases hr : IsRough Y n
    · rw [if_pos hr,Finset.sum_div]
      apply Finset.sum_congr rfl
      intro a ha
      rw [roughMangoldtCoefficient_mul,(Nat.mem_divisorsAntidiagonal.mp ha).1,if_pos hr]
    · rw [if_neg hr]
      apply Finset.sum_eq_zero
      intro a ha
      rw [roughMangoldtCoefficient_mul,(Nat.mem_divisorsAntidiagonal.mp ha).1,if_neg hr]
  rw [hs]
  unfold selbergKernel roughMangoldtCoefficient
  simp only [ArithmeticFunction.add_apply,logWeight_apply,ArithmeticFunction.mul_apply]
  split_ifs <;> ring

theorem global_rough_selberg_identity (N Y : ℕ) :
    roughSelbergClassSum N 1 0 Y =
      coefficientLogMoment (roughMangoldtCoefficient Y) N+coefficientPairMass (roughMangoldtCoefficient Y) N := by
  have he : roughSelbergClassSum N 1 0 Y =
      (∑ n ∈ Icc 1 N, Real.log n*roughMangoldtCoefficient Y n)+
        ∑ n ∈ Icc 1 N, ∑ a ∈ n.divisorsAntidiagonal, roughMangoldtCoefficient Y a.1*roughMangoldtCoefficient Y a.2 := by
    unfold roughSelbergClassSum
    rw [Finset.sum_filter,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro n hn
    simp only [Nat.ModEq,Nat.mod_one,and_true]
    exact selbergKernel_rough_expansion Y n
  rw [he,sum_divisor_pairs N (fun d m => roughMangoldtCoefficient Y d*roughMangoldtCoefficient Y m),
    sum_hyperbolaPairs N (fun d m => roughMangoldtCoefficient Y d*roughMangoldtCoefficient Y m)]
  unfold coefficientLogMoment coefficientPairMass coefficientMass
  rw [Nat.floor_natCast,sum_Icc_zero_eq_one (f := fun n : ℕ => Real.log n*roughMangoldtCoefficient Y n) (by simp)]
  congr 1
  apply Finset.sum_congr rfl
  intro d hd
  rw [Nat.floor_div_natCast,Nat.floor_natCast,sum_Icc_zero_eq_one (roughMangoldtCoefficient_zero Y),Finset.mul_sum]

theorem global_rough_selberg_estimate (N Y : ℕ) (hY : 2≤Y) (hN : Y≤N) :
    |roughSelbergClassSum N 1 0 Y-(Real.log N)^2| ≤ 100000*Real.log Y*Real.log N := by
  have hh := coefficient_two_symmetry (roughMangoldtCoefficient Y) (roughMangoldtCoefficient_zero Y)
    (roughMangoldtCoefficient_nonneg Y) (Real.log Y+157)
    (by have := log_nat_ge_half Y hY; linarith)
    (fun t ht => rough_mangoldt_mertens Y hY t ht) N
    (by exact_mod_cast (show 1≤N by omega))
  rw [← global_rough_selberg_identity] at hh
  apply hh.trans
  have hlY := log_nat_ge_half Y hY
  have hlN := Real.log_le_log (by exact_mod_cast (show 0<Y by omega) : (0:ℝ)<Y)
    (show (Y:ℝ)≤N by exact_mod_cast hN)
  have hK : Real.log (Y:ℝ)+157 ≤ 315*Real.log Y := by linarith
  have hK0 : 0≤Real.log (Y:ℝ)+157 := by linarith
  have hs := mul_le_mul hK hK hK0 (by linarith : 0≤315*Real.log (Y:ℝ))
  have hprod := mul_le_mul_of_nonneg_left hlN (by linarith : 0≤Real.log (Y:ℝ))
  have hlin := mul_le_mul_of_nonneg_right hK (by linarith : 0≤Real.log (N:ℝ))
  nlinarith only [hs,hprod,hlin]

theorem rough_selberg_two (N q k c : ℕ) (hq : 2≤q) (hk : 1≤k)
    (hc : c.Coprime q) (hN : q^(170*k)≤N) :
    |roughSelbergClassSum N q c (q^(170*k))-(Real.log N)^2/q.totient| ≤
      (10:ℝ)^41*Real.log ((q^(170*k):ℕ):ℝ)*Real.log N/q.totient := by
  let Y := q^(170*k)
  have hqY : q≤Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2≤Y := hq.trans hqY
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have hcompare := selberg_rough_comparison N q k c hq hk hc hN
  have hglobal := div_le_div_of_nonneg_right (global_rough_selberg_estimate N Y hY hN) hφ.le
  have he : roughSelbergClassSum N q c Y-(Real.log N)^2/q.totient =
      (roughSelbergClassSum N q c Y-roughSelbergClassSum N 1 0 Y/q.totient)+
      (roughSelbergClassSum N 1 0 Y-(Real.log N)^2)/q.totient := by ring
  change |roughSelbergClassSum N q c Y-(Real.log N)^2/q.totient| ≤ _
  rw [he]
  apply (abs_add_le _ _).trans
  rw [abs_div,abs_of_pos hφ]
  apply (add_le_add hcompare hglobal).trans
  have hp : 0≤Real.log (Y:ℝ)*Real.log N/q.totient := by
    apply div_nonneg (mul_nonneg (Real.log_nonneg (by exact_mod_cast (show 1≤Y by omega)))
      (Real.log_nonneg (by exact_mod_cast (show 1≤N by omega)))) hφ.le
  have hh := mul_le_mul_of_nonneg_right (show (10:ℝ)^40+100000≤(10:ℝ)^41 by norm_num) hp
  convert hh using 1 <;> ring

end MissingLinnik


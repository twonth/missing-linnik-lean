import Mathlib.NumberTheory.DirichletCharacter.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Computability.Partrec
import Mathlib.Algebra.Order.Archimedean.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity

/-!
Independent specifications for the requested proof developments.
These definitions contain no proof holes and no additional axioms.

The effective assertion is encoded by a computable function on natural error
indices: index k means error 1/(k+1). This is stronger than merely quantifying
existentially over an exponent for every positive real epsilon.
-/

namespace MissingLinnik

noncomputable section

/-- The sum is over primes p <= x with character value -1. -/
def negativePrimeMass {f : ℕ} (ψ : DirichletCharacter ℝ f) (x : ℝ) : ℝ :=
  ∑ p ∈ (Finset.range (Nat.floor x + 1)).filter
    (fun p => Nat.Prime p ∧ ψ (p : ZMod f) = -1), Real.log p / p

/-- A candidate effective exponent function satisfies the specified estimates. -/
def AntiConcentrationBounds (A : ℕ → ℕ) : Prop :=
  ∀ (k f : ℕ), 1 ≤ f → ∀ (ψ : DirichletCharacter ℝ f),
    ψ.IsPrimitive → ψ ≠ 1 → ∀ x : ℝ,
    (f : ℝ) ^ A k ≤ x →
      negativePrimeMass ψ x ≤ (1 / 2 + 1 / ((k : ℝ) + 1)) * Real.log x

/-- Proposition 2, retaining the effectivity requirement. -/
def EffectiveAntiConcentration : Prop :=
  ∃ A : ℕ → ℕ, Computable A ∧ AntiConcentrationBounds A

/-- The paper's real-epsilon formulation, without separately encoding effectivity. -/
def AntiConcentration : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ A : ℕ, ∀ f : ℕ, 1 ≤ f →
    ∀ ψ : DirichletCharacter ℝ f, ψ.IsPrimitive → ψ ≠ 1 →
      ∀ x : ℝ, (f : ℝ) ^ A ≤ x →
        negativePrimeMass ψ x ≤ (1 / 2 + ε) * Real.log x

/-- Theorem 1, with all integer representatives of reduced residue classes. -/
def Linnik : Prop :=
  ∃ L : ℕ, ∀ q : ℕ, 2 ≤ q → ∀ a : ℤ, IsCoprime a (q : ℤ) →
    ∃ p : ℕ, Nat.Prime p ∧ p ≤ q ^ L ∧ Int.ModEq q (p : ℤ) a

/-- The effective specification implies the ordinary epsilon formulation. -/
theorem effectiveAntiConcentration_implies_antiConcentration
    (h : EffectiveAntiConcentration) : AntiConcentration := by
  obtain ⟨A, _, hA⟩ := h
  intro ε hε
  obtain ⟨k, hk⟩ := exists_nat_one_div_lt hε
  refine ⟨A k, ?_⟩
  intro f hf ψ hp hn x hx
  have hf' : (1 : ℝ) ≤ f := by exact_mod_cast hf
  have hx1 : (1 : ℝ) ≤ x := (one_le_pow₀ hf').trans hx
  exact (hA k f hf ψ hp hn x hx).trans
    (mul_le_mul_of_nonneg_right (by linarith) (Real.log_nonneg hx1))

end
end MissingLinnik

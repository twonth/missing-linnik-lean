import MissingLinnik.LogarithmicUpperBound

namespace MissingLinnik

open Finset ArithmeticFunction

theorem arithmeticClassSum_nonneg (f : ArithmeticFunction ℝ) (hf : ∀ n, 0≤f n)
    (q c : ℕ) (x : ℝ) : 0≤arithmeticClassSum f q c x := by
  unfold arithmeticClassSum
  exact Finset.sum_nonneg (fun n _ => div_nonneg (hf n) (Nat.cast_nonneg _))

theorem arithmetic_mul_nonneg (f g : ArithmeticFunction ℝ) (hf : ∀ n, 0≤f n) (hg : ∀ n, 0≤g n)
    (n : ℕ) : 0≤(f*g) n := by
  rw [ArithmeticFunction.mul_apply]
  exact Finset.sum_nonneg (fun a _ => mul_nonneg (hf a.1) (hg a.2))

theorem roughRestriction_mangoldt_nonneg (Y n : ℕ) : 0≤roughRestriction Y vonMangoldt n := by
  rw [roughRestriction_apply]
  split_ifs <;> positivity [vonMangoldt_nonneg (n := n)]

theorem roughRestriction_mangoldt_small (Y n : ℕ) (hY : 2≤Y) (hn : n≤Y) :
    roughRestriction Y vonMangoldt n=0 := by
  rw [roughRestriction_apply]
  by_cases hr : IsRough Y n
  · rw [if_pos hr,(isRough_small_iff Y n hY hn).mp hr]
    simp
  · rw [if_neg hr]

theorem rough_single_log_le_Q (q c Y : ℕ) (x : ℝ) :
    arithmeticClassSum (logWeight (roughRestriction Y vonMangoldt)) q c x≤roughQ q c Y x := by
  rw [roughQ_eq_arithmeticClassSum,twoKernel,arithmeticClassSum_add]
  have hh := arithmeticClassSum_nonneg _ (arithmetic_mul_nonneg _ _
    (roughRestriction_mangoldt_nonneg Y) (roughRestriction_mangoldt_nonneg Y)) q c x
  linarith

theorem rough_brun_titchmarsh (q k c : ℕ) (hq : 2≤q) (hk : 1≤k) (hc : c.Coprime q)
    (x : ℝ) (hx : ((q^(170*k):ℕ):ℝ)≤x) :
    arithmeticClassSum (roughRestriction (q^(170*k)) vonMangoldt) q c x ≤
      (2*Real.log x+(10:ℝ)^42*Real.log ((q^(170*k):ℕ):ℝ)*
        (1+Real.log (Real.log x)-Real.log (Real.log ((q^(170*k):ℕ):ℝ))))/q.totient := by
  let Y := q^(170*k)
  let f := roughRestriction Y vonMangoldt
  have hY : 2≤Y := by
    apply hq.trans
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have hsmall (n : ℕ) (hn : n≤Y) : arithmeticClassCoefficient f q c n=0 := by
    unfold arithmeticClassCoefficient
    have he := roughRestriction_mangoldt_small Y n hY hn
    change (if Nat.ModEq q n c then roughRestriction Y vonMangoldt n/(n:ℝ) else 0)=0
    rw [he]
    simp
  have hbound (t : ℝ) (ht : (Y:ℝ)≤t) :
      coefficientLogMoment (arithmeticClassCoefficient f q c) t≤
      (1/(q.totient:ℝ))*(Real.log t)^2+((10:ℝ)^42*Real.log Y/q.totient)*Real.log t := by
    rw [coefficientLogMoment_class]
    have ht1 : 1≤t := (show (1:ℝ)≤Y by exact_mod_cast (show 1≤Y by omega)).trans ht
    have hh := (abs_le.mp (rough_two_real q k c hq hk hc t ht1)).2
    have hs := rough_single_log_le_Q q c Y t
    change arithmeticClassSum (logWeight f) q c t≤_ at hs
    change roughQ q c Y t-(Real.log t)^2/q.totient≤(10:ℝ)^42*Real.log Y*Real.log t/q.totient at hh
    ring_nf at hh ⊢
    linarith only [hh,hs]
  have hh := logarithmic_upper_bound (arithmeticClassCoefficient f q c) Y hY hsmall
    (1/(q.totient:ℝ)) ((10:ℝ)^42*Real.log Y/q.totient) (by positivity) hbound x hx
  rw [coefficientMass_class] at hh
  apply hh.trans_eq
  ring

end MissingLinnik

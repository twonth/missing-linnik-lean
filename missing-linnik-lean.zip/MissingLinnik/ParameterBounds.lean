import MissingLinnik.DeterminantEstimate

namespace MissingLinnik

/-- Uniform numerical bounds for R=k^2*m, S=k*m, T=(k-1)*m.
The constants are deliberately loose, to keep effectivity explicit. -/
theorem parameter_ratios (k m : ℝ) (hk : 8 ≤ k) (hm : 1 ≤ m) :
    (k*m) / ((k-1)*m) ≤ 1 + 2/k ∧
    (k^2*m + k*m) / (k^2*m-1) ≤ 1 + 2/k ∧
    2*(k*m)/(k^2*m-1) ≤ 3/k ∧
    4/(k^2*m-1) ≤ 1/k := by
  have hk0 : 0 < k := by linarith
  have hm0 : 0 < m := by linarith
  have hkm1 : 0 < k-1 := by linarith
  have hk1 : 0 < (k-1)*m := mul_pos hkm1 hm0
  have hr : k^2 ≤ k^2*m := le_mul_of_one_le_right (sq_nonneg k) hm
  have hr1 : 0 < k^2*m-1 := by nlinarith [sq_nonneg (k-8)]
  have hk2 : k + 2 ≤ k^2*m := by nlinarith [sq_nonneg (k-8)]
  constructor
  · apply (div_le_iff₀ hk1).mpr
    apply (mul_le_mul_iff_right₀ hk0).mp
    field_simp
    nlinarith [mul_nonneg (show 0 ≤ k-2 by linarith) (le_of_lt hm0)]
  constructor
  · apply (div_le_iff₀ hr1).mpr
    apply (mul_le_mul_iff_right₀ hk0).mp
    field_simp
    nlinarith
  constructor
  · apply (div_le_iff₀ hr1).mpr
    apply (mul_le_mul_iff_right₀ hk0).mp
    field_simp
    nlinarith [sq_nonneg (k-8)]
  · apply (div_le_iff₀ hr1).mpr
    apply (mul_le_mul_iff_right₀ hk0).mp
    field_simp
    nlinarith [sq_nonneg (k-8)]

theorem parameter_bound_simplified (k m b l L c M : ℝ)
    (hk : 8 ≤ k) (hm : 1 ≤ m) (hb : 0 ≤ b) (hl : 0 ≤ l) (hc : 0 ≤ c)
    (hL : L ≤ 2*l)
    (hbound : M ≤ (k*m)/((k-1)*m) *
      ((k^2*m+k*m)/(k^2*m-1)*b + 2*(k*m)/(k^2*m-1)*l + 2*L/(k^2*m-1)) +
      2*(k*m)/(k^2*m-1)*c) :
    M ≤ (1+5/k)*b + (5/k)*l + (3/k)*c := by
  obtain ⟨h₁,h₂,h₃,h₄⟩ := parameter_ratios k m hk hm
  have hk0 : 0 < k := by linarith
  have hkm1 : 0 < k-1 := by linarith
  have hm0 : 0 < m := by linarith
  have hr : k^2 ≤ k^2*m := le_mul_of_one_le_right (sq_nonneg k) hm
  have hr1 : 0 < k^2*m-1 := by nlinarith [sq_nonneg (k-8)]
  have hterm : 2*L/(k^2*m-1) ≤ (1/k)*l := by
    calc
      _ ≤ (4/(k^2*m-1))*l := by apply (div_le_iff₀ hr1).mpr; field_simp; nlinarith
      _ ≤ _ := mul_le_mul_of_nonneg_right h₄ hl
  have hinside : (k^2*m+k*m)/(k^2*m-1)*b + 2*(k*m)/(k^2*m-1)*l + 2*L/(k^2*m-1) ≤
      (1+2/k)*b + (4/k)*l := by
    have hh₂ := mul_le_mul_of_nonneg_right h₂ hb
    have hh₃ := mul_le_mul_of_nonneg_right h₃ hl
    simp only [div_eq_mul_inv] at hterm hh₂ hh₃ ⊢
    nlinarith
  have houter := (mul_le_mul_of_nonneg_left hinside
    (by positivity : 0 ≤ (k*m)/((k-1)*m))).trans
      (mul_le_mul_of_nonneg_right h₁ (by positivity : 0 ≤ (1+2/k)*b + (4/k)*l))
  have hlast := mul_le_mul_of_nonneg_right h₃ hc
  have hcoef₁ : (1+2/k)*(1+2/k) ≤ 1+5/k := by
    apply (mul_le_mul_iff_right₀ (show 0 < k^2 by positivity)).mp
    field_simp
    nlinarith
  have hcoef₂ : (1+2/k)*(4/k) ≤ 5/k := by
    apply (mul_le_mul_iff_right₀ (show 0 < k^2 by positivity)).mp
    field_simp
    nlinarith
  have hh₁ := mul_le_mul_of_nonneg_right hcoef₁ hb
  have hh₂ := mul_le_mul_of_nonneg_right hcoef₂ hl
  simp only [div_eq_mul_inv] at hbound houter hlast hh₁ hh₂ ⊢
  nlinarith

end MissingLinnik

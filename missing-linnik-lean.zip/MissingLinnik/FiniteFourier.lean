import Mathlib.Analysis.Complex.Basic
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith

namespace MissingLinnik

open Classical
open scoped ComplexConjugate

noncomputable def finiteCoefficient {G C : Type*} [Fintype G]
    (χ : C → G → ℂ) (w : G → ℝ) (c : C) : ℂ :=
  ∑ g, (w g : ℂ) * χ c g

/-- Parseval from the character orthogonality relation, with the normalization
used in Section 3 of the manuscript. -/
theorem finite_parseval {G C : Type*} [Fintype G] [Fintype C]
    (χ : C → G → ℂ) (w : G → ℝ) (n : ℝ)
    (horth : ∀ g h, ∑ c, star (χ c g) * χ c h = if g = h then (n : ℂ) else 0) :
    (∑ c, ‖finiteCoefficient χ w c‖ ^ 2) = n * ∑ g, (w g)^2 := by
  have hc : (∑ c, star (finiteCoefficient χ w c) * finiteCoefficient χ w c) =
      (n : ℂ) * ∑ g, (w g : ℂ)^2 := by
    calc
      _ = ∑ g, ∑ h, (w g : ℂ) * w h * (∑ c, star (χ c h) * χ c g) := by
        simp only [finiteCoefficient, RCLike.star_def, map_sum, map_mul, Complex.conj_ofReal,
          Finset.sum_mul, Finset.mul_sum]
        rw [Finset.sum_comm]
        apply Finset.sum_congr rfl
        intro g _
        rw [Finset.sum_comm]
        apply Finset.sum_congr rfl
        intro h _
        apply Finset.sum_congr rfl
        intro c _
        ring
      _ = _ := by
        simp_rw [horth]
        simp [Finset.mul_sum, pow_two, mul_assoc, mul_comm, mul_left_comm]
  simp only [RCLike.star_def, Complex.conj_mul'] at hc
  exact_mod_cast hc

/-- The weak Brun--Titchmarsh bound gives the square-energy bound. -/
theorem finite_energy_bound {G C : Type*} [Fintype G] [Fintype C]
    (χ : C → G → ℂ) (w : G → ℝ) (n K : ℝ)
    (hn : 0 ≤ n) (hw : ∀ g, 0 ≤ w g)
    (hmax : ∀ g, n * w g ≤ K)
    (horth : ∀ g h, ∑ c, star (χ c g) * χ c h = if g = h then (n : ℂ) else 0) :
    (∑ c, ‖finiteCoefficient χ w c‖ ^ 2) ≤ K * ∑ g, w g := by
  rw [finite_parseval χ w n horth, Finset.mul_sum, Finset.mul_sum]
  apply Finset.sum_le_sum
  intro g _
  have hh := mul_le_mul_of_nonneg_right (hmax g) (hw g)
  nlinarith

/-- Cubic orthogonality, before restricting to a residue class. -/
theorem finite_cubic_identity {G C : Type*} [Fintype G] [Fintype C]
    (χ : C → G → ℂ) (w : G → ℝ) (v : C → ℂ) :
    (∑ c, v c * (finiteCoefficient χ w c)^3) =
      ∑ g, ∑ h, ∑ k, ((w g : ℂ) * w h * w k) *
        (∑ c, v c * (χ c g * χ c h * χ c k)) := by
  simp only [finiteCoefficient, pow_succ, pow_zero, one_mul,
    Finset.sum_mul, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro g _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro h _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k _
  apply Finset.sum_congr rfl
  intro c _
  ring

theorem finiteCoefficient_star {G C : Type*} [Fintype G]
    (χ : C → G → ℂ) (w : G → ℝ) (τ : C → C)
    (hτ : ∀ c g, χ (τ c) g = star (χ c g)) (c : C) :
    finiteCoefficient χ w (τ c) = star (finiteCoefficient χ w c) := by
  simp only [finiteCoefficient, hτ, RCLike.star_def, map_sum, map_mul, Complex.conj_ofReal]

end MissingLinnik

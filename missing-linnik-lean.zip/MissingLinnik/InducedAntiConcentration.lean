import MissingLinnik.PropositionTwo

namespace MissingLinnik

theorem primitiveCharacter_at_large_prime {q : ℕ} [NeZero q]
    (χ : DirichletCharacter ℝ q) (p : ℕ) (hp : p.Prime) (hpq : q < p) :
    χ.primitiveCharacter (p:ZMod χ.conductor) = χ (p:ZMod q) := by
  have hcop : p.Coprime q := (hp.coprime_iff_not_dvd).mpr
    (fun h => (Nat.le_of_dvd (NeZero.pos q) h).not_gt hpq)
  have hu := (ZMod.isUnit_iff_coprime p q).mpr hcop
  have he := DirichletCharacter.changeLevel_eq_cast_of_dvd χ.primitiveCharacter
    χ.conductor_dvd_level hu.unit
  rw [χ.changeLevel_primitiveCharacter,hu.unit_spec,
    ZMod.cast_natCast χ.conductor_dvd_level] at he
  exact he.symm

/-- Proposition 2 applied to an induced real character, in the precise large-
prime range needed by the last paragraph of the manuscript. -/
theorem induced_negative_prime_bound
    (A : ℕ → ℕ) (hA : AntiConcentrationBounds A)
    (j q : ℕ) (hq : 2 ≤ q) (χ : DirichletCharacter ℝ q) (hχ : χ ≠ 1)
    (x : ℝ) (hx : (q:ℝ)^A j ≤ x)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime)
    (hlower : ∀ p ∈ P, q < p) (hupper : ∀ p ∈ P, (p:ℝ) ≤ x)
    (hneg : ∀ p ∈ P, χ (p:ZMod q) = -1) :
    (∑ p ∈ P, Real.log p/p) ≤ (1/2+1/((j:ℝ)+1))*Real.log x := by
  classical
  letI : NeZero q := ⟨by omega⟩
  have hf : 1 ≤ χ.conductor := Nat.one_le_iff_ne_zero.mpr χ.conductor_ne_zero
  have hfq : χ.conductor ≤ q := Nat.le_of_dvd (NeZero.pos q) χ.conductor_dvd_level
  have hprimne : χ.primitiveCharacter ≠ 1 := by
    intro he
    have hh := χ.changeLevel_primitiveCharacter
    rw [he,map_one] at hh
    exact hχ hh.symm
  have hxf : (χ.conductor:ℝ)^A j ≤ x :=
    (pow_le_pow_left₀ (Nat.cast_nonneg _) (by exact_mod_cast hfq) _).trans hx
  have hh := hA j χ.conductor hf χ.primitiveCharacter χ.primitiveCharacter_isPrimitive hprimne x hxf
  apply le_trans _ hh
  unfold negativePrimeMass
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro p hp
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_range.mpr (by have := Nat.le_floor (hupper p hp); omega),hprime p hp,?_⟩
    rw [primitiveCharacter_at_large_prime χ p (hprime p hp) (hlower p hp)]
    exact hneg p hp
  · intro p hp _
    exact div_nonneg (Real.log_nonneg (by
      exact_mod_cast (Finset.mem_filter.mp hp).2.1.one_le)) (Nat.cast_nonneg _)

theorem induced_three_quarters_bound
    (A : ℕ → ℕ) (hA : AntiConcentrationBounds A)
    (q : ℕ) (hq : 2 ≤ q) (χ : DirichletCharacter ℝ q) (hχ : χ ≠ 1)
    (x : ℝ) (hx : (q:ℝ)^A 3 ≤ x)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime)
    (hlower : ∀ p ∈ P, q < p) (hupper : ∀ p ∈ P, (p:ℝ) ≤ x)
    (hneg : ∀ p ∈ P, χ (p:ZMod q) = -1) :
    (∑ p ∈ P, Real.log p/p) ≤ (3/4)*Real.log x := by
  have hh := induced_negative_prime_bound A hA 3 q hq χ hχ x hx P hprime hlower hupper hneg
  norm_num at hh ⊢
  exact hh

end MissingLinnik

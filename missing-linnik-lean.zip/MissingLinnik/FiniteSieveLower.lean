import MissingLinnik.SieveLowerError

namespace MissingLinnik

open Finset

theorem first_divisor_progression_upper (N q b R z p : ℕ) (P : Finset ℕ)
    (hq : 0 < q) (hR : 1 ≤ R) (hz : 2 ≤ z) (hp : ∀ p ∈ P, p.Prime)
    (hcop : ∀ p ∈ P, q.Coprime p) (hpz : ∀ p ∈ P, p ≤ z) (hpm : p ∈ P)
    (hlevel : 17 ≤ Real.log (R:ℝ)/Real.log p) :
    ((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => p ∣ n ∧ ∀ l ∈ P, l < p → ¬l ∣ n)).card:ℝ) ≤
      ((N:ℝ)/(q*p))*sieveDensity (P.filter (fun l => l < p))*
        (1+2*Real.exp (16-Real.log R/Real.log p))+(R:ℝ)^4 := by
  let S := P.filter (fun l => l < p)
  have hqpc : ∀ l ∈ S, (q*p).Coprime l := by
    intro l hl
    obtain ⟨hlP,hlp⟩ := Finset.mem_filter.mp hl
    exact (hcop l hlP).mul_left ((Nat.coprime_primes (hp p hpm) (hp l hlP)).mpr (by omega))
  have he : (((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
      (fun n => p ∣ n ∧ ∀ l ∈ P, l < p → ¬l ∣ n)) =
      ((((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter (fun n => p ∣ n)).filter
        (fun n => ∀ l ∈ S, ¬ l ∣ n)) := by
    ext n
    simp only [Finset.mem_filter,S]
    aesop
  rw [he,progression_multiples_filter N q b p (hcop p hpm)]
  simpa only [Nat.cast_mul] using finite_sieve_upper N (q*p)
    (Nat.chineseRemainder (hcop p hpm) b 0) R p S (Nat.mul_pos hq (hp p hpm).pos)
    hR (hp p hpm).two_le (fun l hl => hp l (Finset.mem_filter.mp hl).1) hqpc
    (fun l hl => (Finset.mem_filter.mp hl).2.le) hlevel

/-- The lower half of the finite sieve, after supplying the upper bounds
for the classes removed at their first prime. -/
theorem finite_sieve_lower_of_counts (A P : Finset ℕ) (z R : ℕ) (hz : 2 ≤ z)
    (hp : ∀ p ∈ P, p.Prime) (hpz : ∀ p ∈ P, p ≤ z)
    (t h : ℝ) (ht : 0 ≤ t) (hh : 17 ≤ h) (hcount : t-1 ≤ (A.card:ℝ))
    (hfirst : ∀ p ∈ P,
      ((A.filter (fun n => p ∣ n ∧ ∀ l ∈ P, l < p → ¬l ∣ n)).card:ℝ) ≤
        t*(sieveDensity (P.filter (fun l => l < p))/(p:ℝ))*
          (1+2*Real.exp (16-h*(Real.log z/Real.log p)))+(R:ℝ)^4) :
    t*sieveDensity P*(1-16*Real.exp (32-h))-(P.card:ℝ)*(R:ℝ)^4-1 ≤
      ((A.filter (fun n => ∀ p ∈ P, ¬p ∣ n)).card:ℝ) := by
  have hid : ((A.filter (fun n => ∀ p ∈ P, ¬p ∣ n)).card:ℝ) +
      ∑ p ∈ P, ((A.filter (fun n => p ∣ n ∧ ∀ l ∈ P, l < p → ¬l ∣ n)).card:ℝ) =
      A.card := by exact_mod_cast buchstab_partition A P
  have hs := Finset.sum_le_sum hfirst
  have he : (∑ p ∈ P, (t*(sieveDensity (P.filter (fun l => l < p))/(p:ℝ))*
      (1+2*Real.exp (16-h*(Real.log z/Real.log p)))+(R:ℝ)^4)) =
      t*(∑ p ∈ P, sieveDensity (P.filter (fun l => l < p))/(p:ℝ)) +
      2*t*(∑ p ∈ P, (sieveDensity (P.filter (fun l => l < p))/(p:ℝ))*
        Real.exp (16-h*(Real.log z/Real.log p)))+(P.card:ℝ)*(R:ℝ)^4 := by
    rw [Finset.sum_add_distrib]
    simp only [Finset.sum_const,nsmul_eq_mul]
    congr 1
    rw [Finset.mul_sum,Finset.mul_sum,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro p hpm
    ring
  rw [he] at hs
  have hd := buchstab_density P
  have herr := mul_le_mul_of_nonneg_left (sieve_lower_error_sum P z hz hp hpz h hh)
    (show 0 ≤ 2*t by positivity)
  nlinarith only [hid,hs,hd,herr,hcount]

end MissingLinnik

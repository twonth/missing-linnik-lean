import Mathlib.Algebra.Polynomial.FieldDivision
import Mathlib.Algebra.Polynomial.Roots
import Lean.Elab.Tactic.Omega
import Mathlib.Tactic.Ring

/-!
Polynomial ingredients of van Dijk's nonvanishing argument, page 2.
The passage from a row dependence to a polynomial and the finite-field grid
construction are not yet formalized here.
-/

namespace MissingLinnik.VanDijk

open scoped BigOperators

/-- The exponents r + p*s are distinct when 0 <= r < R <= p. -/
theorem exponent_injective {p R S : ℕ} (hp : 0 < p) (hR : R ≤ p) :
    Function.Injective (fun i : Fin R × Fin S => i.1.val + p * i.2.val) := by
  intro i j h
  change i.1.val + p * i.2.val = j.1.val + p * j.2.val at h
  have hi : i.1.val < p := i.1.isLt.trans_le hR
  have hj : j.1.val < p := j.1.isLt.trans_le hR
  have hr : i.1.val = j.1.val := by
    have hh := congrArg (fun n => n % p) h
    simpa [Nat.add_mod, Nat.mod_eq_of_lt hi, Nat.mod_eq_of_lt hj] using hh
  have hs : i.2.val = j.2.val := by
    rw [hr] at h
    exact Nat.eq_of_mul_eq_mul_left hp (Nat.add_left_cancel h)
  exact Prod.ext (Fin.ext hr) (Fin.ext hs)

/-- Every exponent in the row-dependence polynomial is below p*S. -/
theorem exponent_lt {p R S : ℕ} (hR : R ≤ p) (i : Fin R × Fin S) :
    i.1.val + p * i.2.val < p * S := by
  calc
    i.1.val + p * i.2.val < p + p * i.2.val :=
      Nat.add_lt_add_right (i.1.isLt.trans_le hR) _
    _ = p * (i.2.val + 1) := by ring
    _ ≤ p * S := Nat.mul_le_mul_left _ (Nat.succ_le_of_lt i.2.isLt)

/-- Counting roots with multiplicity yields the degree obstruction. -/
theorem multiplicity_card_le_degree {K : Type*} [Field K]
    (G : Polynomial K) (t : Finset K) {S : ℕ} (hS : 0 < S)
    (hm : ∀ a ∈ t, S ≤ G.rootMultiplicity a) :
    t.card * S ≤ G.natDegree := by
  classical
  have ht : t ⊆ G.roots.toFinset := by
    intro a ha
    rw [Multiset.mem_toFinset, ← Multiset.count_pos, Polynomial.count_roots]
    exact hS.trans_le (hm a ha)
  calc
    t.card * S = ∑ a ∈ t, S := by simp
    _ ≤ ∑ a ∈ t, G.roots.count a := by
      apply Finset.sum_le_sum
      intro a ha
      simpa only [Polynomial.count_roots] using hm a ha
    _ ≤ ∑ a ∈ G.roots.toFinset, G.roots.count a :=
      Finset.sum_le_sum_of_subset ht
    _ = G.roots.card := Multiset.toFinset_sum_count_eq _
    _ ≤ G.natDegree := Polynomial.card_roots' _

/-- Vanishing of the first S derivatives at sufficiently many points forces G=0.
The factorial hypothesis is the exact positive-characteristic restriction needed
in the paper; it must not be replaced by an assumption of characteristic zero.
-/
theorem eq_zero_of_derivatives_vanish {K : Type*} [Field K]
    (G : Polynomial K) (t : Finset K) {S : ℕ} (hS : 0 < S)
    (hfac : ((S - 1).factorial : K) ≠ 0)
    (hv : ∀ a ∈ t, ∀ j < S, (Polynomial.derivative^[j] G).eval a = 0)
    (hdeg : G.natDegree < t.card * S) : G = 0 := by
  by_contra hG
  have hm : ∀ a ∈ t, S ≤ G.rootMultiplicity a := by
    intro a ha
    have hh := Polynomial.lt_rootMultiplicity_of_isRoot_iterate_derivative_of_mem_nonZeroDivisors
      hG (fun j hj => hv a ha j (by omega))
      (mem_nonZeroDivisors_iff_ne_zero.mpr hfac)
    omega
  exact (not_lt_of_ge (multiplicity_card_le_degree G t hS hm)) hdeg

/-- Encoding of a rectangular coefficient array by Frobenius exponents. -/
noncomputable def encodedPolynomial {K : Type*} [Field K] (p R S : ℕ)
    (c : Fin R × Fin S → K) : Polynomial K :=
  ∑ i, Polynomial.monomial (i.1.val + p * i.2.val) (c i)

theorem coeff_encodedPolynomial {K : Type*} [Field K] {p R S : ℕ}
    (hp : 0 < p) (hR : R ≤ p) (c : Fin R × Fin S → K) (i : Fin R × Fin S) :
    (encodedPolynomial p R S c).coeff (i.1.val + p * i.2.val) = c i := by
  classical
  simp only [encodedPolynomial, Polynomial.finsetSum_coeff]
  rw [Finset.sum_eq_single i]
  · simp
  · intro j _ hji
    have he : j.1.val + p * j.2.val ≠ i.1.val + p * i.2.val := by
      intro he
      exact hji (exponent_injective hp hR he)
    simp [Polynomial.coeff_monomial, he]
  · simp

theorem encodedPolynomial_natDegree_lt {K : Type*} [Field K] {p R S : ℕ}
    (hp : 0 < p) (hS : 0 < S) (hR : R ≤ p) (c : Fin R × Fin S → K) :
    (encodedPolynomial p R S c).natDegree < p * S := by
  have hpos : 0 < p * S := Nat.mul_pos hp hS
  apply lt_of_le_of_lt (Polynomial.natDegree_sum_le_of_forall_le _ _ ?_)
    (Nat.sub_lt hpos (by decide : 0 < 1))
  intro i _
  exact (Polynomial.natDegree_monomial_le _).trans (Nat.le_sub_one_of_lt (exponent_lt hR i))

/-- The root-counting argument forces every coefficient of a row dependence to
vanish. This is the univariate polynomial part of van Dijk's full-rank proof. -/
theorem coefficients_zero_of_encoded_derivatives_vanish {K : Type*} [Field K]
    {p R S : ℕ} (hp : 0 < p) (hS : 0 < S) (hR : R ≤ p)
    (c : Fin R × Fin S → K) (t : Finset K) (ht : p ≤ t.card)
    (hfac : ((S - 1).factorial : K) ≠ 0)
    (hv : ∀ a ∈ t, ∀ j < S,
      (Polynomial.derivative^[j] (encodedPolynomial p R S c)).eval a = 0) :
    ∀ i, c i = 0 := by
  have hdeg : (encodedPolynomial p R S c).natDegree < t.card * S :=
    (encodedPolynomial_natDegree_lt hp hS hR c).trans_le (Nat.mul_le_mul_right S ht)
  have hz := eq_zero_of_derivatives_vanish (encodedPolynomial p R S c) t hS hfac hv hdeg
  intro i
  have hh := congrArg (fun G : Polynomial K => G.coeff (i.1.val + p * i.2.val)) hz
  simpa only [coeff_encodedPolynomial hp hR, Polynomial.coeff_zero] using hh

end MissingLinnik.VanDijk

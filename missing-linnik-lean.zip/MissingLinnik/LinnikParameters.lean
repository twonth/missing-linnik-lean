import MissingLinnik.ExplicitSieveConstants
import MissingLinnik.Statements

namespace MissingLinnik

set_option maxRecDepth 10000
set_option maxHeartbeats 2000000

/-- Input a is an anti-concentration exponent. No real-number rounding is used. -/
def linnikScale (a : ℕ) : ℕ := 10^60*(a+1)
def linnikB (a : ℕ) : ℕ := (170*linnikScale a)*(170*linnikScale a)
def linnikSieveIndex (a : ℕ) : ℕ := 170*(linnikScale a)^2
def linnikCandidateExponent (a : ℕ) : ℕ := 3*(linnikB a*linnikB a)

theorem linnikB_eq_sieve_index (a : ℕ) : linnikB a=170*linnikSieveIndex a := by
  unfold linnikB linnikSieveIndex
  ring

theorem linnikSieveIndex_pos (a : ℕ) : 1≤linnikSieveIndex a := by
  apply Nat.succ_le_iff.mpr
  unfold linnikSieveIndex linnikScale
  positivity

theorem linnikB_large (a : ℕ) : 10^60≤linnikB a ∧ a≤linnikB a := by
  have hs : 10^60≤linnikScale a := by unfold linnikScale; nlinarith
  have hsa : a≤linnikScale a := by unfold linnikScale; nlinarith
  unfold linnikB
  constructor <;> nlinarith

theorem linnikB_covers_anti_exponent (a : ℕ) : a≤(linnikB a)^2 := by
  have h := linnikB_large a
  nlinarith

theorem linnikCandidateExponent_computable : Computable linnikCandidateExponent := by
  have ht : Primrec (fun a : ℕ => a+1) := Primrec.nat_add.comp Primrec.id (Primrec.const 1)
  have hs : Primrec linnikScale := Primrec.nat_mul.comp (Primrec.const (10^60)) ht
  have hp : Primrec (fun a : ℕ => 170*linnikScale a) := Primrec.nat_mul.comp (Primrec.const 170) hs
  have hB : Primrec linnikB := Primrec.nat_mul.comp hp hp
  exact (Primrec.nat_mul.comp (Primrec.const 3) (Primrec.nat_mul.comp hB hB)).to_comp

/-- A single explicit choice controls the logarithmic loss in Brun--Titchmarsh
as well as the smaller errors in the symmetry formulas. This is a parameter
lemma, not a claim that the remaining Linnik application has been completed. -/
theorem linnik_logarithmic_error (a : ℕ) :
    (10:ℝ)^46*(1+Real.log (linnikB a:ℝ))/(linnikB a:ℝ) ≤ 1/1000000 := by
  let P : ℝ := 170*(linnikScale a:ℝ)
  have hs : (10:ℝ)^60≤linnikScale a := by
    exact_mod_cast (show 10^60≤linnikScale a by unfold linnikScale; nlinarith)
  have hP : 170*(10:ℝ)^60≤P := by dsimp [P]; linarith
  have hP0 : 0<P := by linarith
  have hB : (linnikB a:ℝ)=P^2 := by simp only [linnikB,Nat.cast_mul,Nat.cast_ofNat,P,pow_two]
  rw [hB,Real.log_pow]
  norm_num only [Nat.cast_ofNat]
  apply (div_le_iff₀ (sq_pos_of_pos hP0)).mpr
  have hl := Real.log_le_sub_one_of_pos hP0
  have hm := mul_le_mul_of_nonneg_left hl (show 0≤2*(10:ℝ)^46 by positivity)
  have hprod := mul_nonneg hP0.le (show 0≤P-2*(10:ℝ)^52 by linarith)
  nlinarith only [hm,hprod]

theorem linnik_constant_error (a : ℕ) : (10:ℝ)^46/(linnikB a:ℝ) ≤ 1/1000000 := by
  have hB := linnikB_large a
  have hB1 : (1:ℝ)≤linnikB a := by exact_mod_cast (show 1≤linnikB a by omega)
  have hl := Real.log_nonneg hB1
  have hm := div_le_div_of_nonneg_right
    (show (10:ℝ)^46≤(10:ℝ)^46*(1+Real.log (linnikB a:ℝ)) by nlinarith only [hl])
    (Nat.cast_nonneg (linnikB a))
  exact hm.trans (linnik_logarithmic_error a)

end MissingLinnik

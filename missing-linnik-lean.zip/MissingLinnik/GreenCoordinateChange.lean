import MissingLinnik.LinearSubstitutionDegree
import MissingLinnik.CartesianZeroCount
import Mathlib.Tactic.LinearCombination

namespace MissingLinnik.Green

open Polynomial

noncomputable def coordinateChange {K : Type*} [Field K] (a : K) :
    Polynomial (Polynomial K) →ₐ[K] Polynomial (Polynomial K) :=
  Polynomial.aevalAeval
    (Polynomial.X - Polynomial.C (Polynomial.C a) * Polynomial.C Polynomial.X)
    (Polynomial.X + Polynomial.C (Polynomial.C a) * Polynomial.C Polynomial.X)

noncomputable def inverseCoordinateChange {K : Type*} [Field K] (a : K) :
    Polynomial (Polynomial K) →ₐ[K] Polynomial (Polynomial K) :=
  Polynomial.aevalAeval
    (Polynomial.C (Polynomial.C ((2*a)⁻¹)) * (Polynomial.X - Polynomial.C Polynomial.X))
    (Polynomial.C (Polynomial.C ((2:K)⁻¹)) * (Polynomial.X + Polynomial.C Polynomial.X))

theorem coordinateChange_injective {K : Type*} [Field K] [CharZero K] (a : K) (ha : a ≠ 0) :
    Function.Injective (coordinateChange a) := by
  have hhalf : (Polynomial.C (Polynomial.C ((2 : K)⁻¹)) : Polynomial (Polynomial K)) * 2 = 1 := by
    have hh : (2 : K)⁻¹ * 2 = 1 := inv_mul_cancel₀ (by norm_num)
    simpa only [Polynomial.C_mul, Polynomial.C_ofNat, Polynomial.C_1] using congrArg (fun x : K => (Polynomial.C (Polynomial.C x) : Polynomial (Polynomial K))) hh
  have hainv : (Polynomial.C (Polynomial.C a) : Polynomial (Polynomial K)) * Polynomial.C (Polynomial.C a⁻¹) = 1 := by
    rw [← Polynomial.C_mul, ← Polynomial.C_mul, mul_inv_cancel₀ ha, Polynomial.C_1, Polynomial.C_1]
  have hc : (inverseCoordinateChange a).comp (coordinateChange a) =
      AlgHom.id K (Polynomial (Polynomial K)) := by
    apply Polynomial.algHom_ext'
    · apply Polynomial.algHom_ext
      simp [coordinateChange, inverseCoordinateChange]
      linear_combination hhalf * (Polynomial.C Polynomial.X) + Polynomial.C (Polynomial.C ((2:K)⁻¹)) * (Polynomial.C Polynomial.X - Polynomial.X) * hainv
    · simp [coordinateChange, inverseCoordinateChange]
      linear_combination hhalf * (Polynomial.X : Polynomial (Polynomial K)) + Polynomial.C (Polynomial.C ((2:K)⁻¹)) * (Polynomial.X - Polynomial.C Polynomial.X) * hainv
  have hleft : Function.LeftInverse (inverseCoordinateChange a) (coordinateChange a) := by
    intro f
    exact AlgHom.congr_fun hc f
  exact hleft.injective

theorem coordinateChange_degree_le {K : Type*} [Field K] (a : K)
    (f : Polynomial (Polynomial K)) :
    (coordinateChange a f).natDegree ≤ f.natDegree + yDegree f := by
  apply linear_substitution_degree_le (coordinateChange a).toRingHom
  · intro c; simp [coordinateChange]
  · simp [coordinateChange]
    all_goals
      exact (Polynomial.natDegree_add_le _ _).trans (max_le (by simp)
        (by rw [← Polynomial.C_mul, Polynomial.natDegree_C]; omega))
  · simp [coordinateChange]
    all_goals
      exact (Polynomial.natDegree_sub_le _ _).trans (max_le (by simp)
        (by rw [← Polynomial.C_mul, Polynomial.natDegree_C]; omega))

theorem coordinateChange_yDegree_le {K : Type*} [Field K] (a : K)
    (f : Polynomial (Polynomial K)) :
    yDegree (coordinateChange a f) ≤ f.natDegree + yDegree f := by
  apply linear_substitution_degree_le
    (Polynomial.Bivariate.swap.toRingHom.comp (coordinateChange a).toRingHom)
  · intro c; simp [coordinateChange, Polynomial.Bivariate.swap_C_C]
  · simp [coordinateChange, Polynomial.Bivariate.swap_X, Polynomial.Bivariate.swap_Y,
      Polynomial.Bivariate.swap_C_C]
    exact (Polynomial.natDegree_C_mul_le _ _).trans (by simp)
  · simp [coordinateChange, Polynomial.Bivariate.swap_X, Polynomial.Bivariate.swap_Y,
      Polynomial.Bivariate.swap_C_C]
    exact (Polynomial.natDegree_sub_le _ _).trans (max_le (by simp)
      ((Polynomial.natDegree_C_mul_le _ _).trans (by simp)))

theorem coordinateChange_eval {K : Type*} [Field K] (a u v : K)
    (f : Polynomial (Polynomial K)) :
    ((coordinateChange a f).map (Polynomial.evalRingHom v)).eval u =
      (f.map (Polynomial.evalRingHom (u-a*v))).eval (u+a*v) := by
  have hc : ((Polynomial.evalRingHom u).comp (Polynomial.mapRingHom (Polynomial.evalRingHom v))).comp
      (coordinateChange a).toRingHom =
      (Polynomial.evalRingHom (u+a*v)).comp (Polynomial.mapRingHom (Polynomial.evalRingHom (u-a*v))) := by
    ext n m <;> simp [coordinateChange]
  exact RingHom.congr_fun hc f

end MissingLinnik.Green







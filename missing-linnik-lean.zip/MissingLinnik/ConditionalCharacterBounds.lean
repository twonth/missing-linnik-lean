import MissingLinnik.CharacterBridge
import MissingLinnik.EffectiveTriangleBound

namespace MissingLinnik

/-- The shared missing classification statement, named for precise reporting
of the remaining proof obligation. This definition asserts no theorem. -/
def PrimitiveRealCharacterClassification : Prop :=
  ∀ (f : ℕ), 1 ≤ f → ∀ (ψ : DirichletCharacter ℝ f),
    ψ.IsPrimitive → ψ ≠ 1 → HasQuadraticRepresentative ψ

theorem green_effective_of_classification (h : PrimitiveRealCharacterClassification) :
    EffectiveAntiConcentration := by
  exact ⟨bridgeExponent quadraticExponent,
    bridgeExponent_computable quadraticExponent quadraticExponent_computable,
    antiConcentration_of_quadratic_representatives quadraticExponent green_quadratic_bounds h⟩

theorem vanDijk_effective_of_classification (h : PrimitiveRealCharacterClassification) :
    EffectiveAntiConcentration := by
  exact ⟨bridgeExponent quadraticExponent,
    bridgeExponent_computable quadraticExponent quadraticExponent_computable,
    antiConcentration_of_quadratic_representatives quadraticExponent vanDijk_quadratic_bounds h⟩

theorem triangle_effective_of_classification (h : PrimitiveRealCharacterClassification) :
    EffectiveAntiConcentration := by
  exact ⟨bridgeExponent triangleExponent,
    bridgeExponent_computable triangleExponent triangleExponent_computable,
    antiConcentration_of_quadratic_representatives triangleExponent triangle_quadratic_bounds h⟩

end MissingLinnik

import MissingLinnik.ProgressionCount
import Mathlib.Data.Nat.Totient

namespace MissingLinnik

open Finset

theorem sum_totient_common_divisors (P d e : ℕ) (hP : P ≠ 0)
    (hd : d ∣ P) (he : e ∣ P) :
    (∑ r ∈ P.divisors, if r ∣ d ∧ r ∣ e then (r.totient:ℝ) else 0) = d.gcd e := by
  simp_rw [← Nat.dvd_gcd_iff]
  rw [← Finset.sum_filter, Nat.divisors_filter_dvd_of_dvd hP ((Nat.gcd_dvd_left d e).trans hd)]
  exact_mod_cast Nat.sum_totient (d.gcd e)

theorem reciprocal_lcm_eq_gcd (d e : ℕ) (hd : d ≠ 0) (he : e ≠ 0) :
    (1:ℝ)/(d.lcm e) = (d.gcd e:ℝ)/((d:ℝ)*e) := by
  have hdR : (d:ℝ) ≠ 0 := by exact_mod_cast hd
  have heR : (e:ℝ) ≠ 0 := by exact_mod_cast he
  have hlR : (d.lcm e:ℝ) ≠ 0 := by exact_mod_cast (Nat.lcm_ne_zero hd he)
  have hh : (d.gcd e:ℝ)*(d.lcm e) = (d:ℝ)*e := by exact_mod_cast Nat.gcd_mul_lcm d e
  field_simp
  nlinarith only [hh]

/-- The diagonalization of Selberg's quadratic form in the manuscript's
notation, valid for arbitrary real weights on the divisors of P. -/
theorem selberg_diagonalization (P : ℕ) (hP : P ≠ 0) (ρ : ℕ → ℝ) :
    (∑ d ∈ P.divisors, ∑ e ∈ P.divisors, ρ d*ρ e/(d.lcm e)) =
      ∑ r ∈ P.divisors, (r.totient:ℝ)*
        (∑ d ∈ P.divisors, if r ∣ d then ρ d/d else 0)^2 := by
  have hterm (d : ℕ) (hd : d ∈ P.divisors) (e : ℕ) (he : e ∈ P.divisors) :
      ρ d*ρ e/(d.lcm e) = ∑ r ∈ P.divisors,
        if r ∣ d ∧ r ∣ e then (r.totient:ℝ)*(ρ d/d)*(ρ e/e) else 0 := by
    have hd0 : d ≠ 0 := ne_zero_of_dvd_ne_zero hP (Nat.dvd_of_mem_divisors hd)
    have he0 : e ≠ 0 := ne_zero_of_dvd_ne_zero hP (Nat.dvd_of_mem_divisors he)
    have hh := sum_totient_common_divisors P d e hP
      (Nat.dvd_of_mem_divisors hd) (Nat.dvd_of_mem_divisors he)
    calc
      _ = ((1:ℝ)/(d.lcm e))*(ρ d*ρ e) := by ring
      _ = ((d.gcd e:ℝ)/((d:ℝ)*e))*(ρ d*ρ e) := by rw [reciprocal_lcm_eq_gcd d e hd0 he0]
      _ = (∑ r ∈ P.divisors, if r ∣ d ∧ r ∣ e then (r.totient:ℝ) else 0)*
          (ρ d/d)*(ρ e/e) := by rw [hh]; ring
      _ = _ := by
        simp only [Finset.sum_mul]
        apply Finset.sum_congr rfl
        intro r hr
        split_ifs <;> simp
  calc
    _ = ∑ d ∈ P.divisors, ∑ e ∈ P.divisors, ∑ r ∈ P.divisors,
        if r ∣ d ∧ r ∣ e then (r.totient:ℝ)*(ρ d/d)*(ρ e/e) else 0 := by
      apply Finset.sum_congr rfl
      intro d hd
      exact Finset.sum_congr rfl (fun e he => hterm d hd e he)
    _ = ∑ r ∈ P.divisors, ∑ d ∈ P.divisors, ∑ e ∈ P.divisors,
        if r ∣ d ∧ r ∣ e then (r.totient:ℝ)*(ρ d/d)*(ρ e/e) else 0 := by
      trans ∑ d ∈ P.divisors, ∑ r ∈ P.divisors, ∑ e ∈ P.divisors,
        if r ∣ d ∧ r ∣ e then (r.totient:ℝ)*(ρ d/d)*(ρ e/e) else 0
      · exact Finset.sum_congr rfl (fun d _ => Finset.sum_comm)
      · exact Finset.sum_comm
    _ = _ := by
      apply Finset.sum_congr rfl
      intro r hr
      simp only [pow_two, Finset.sum_mul, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro d hd
      apply Finset.sum_congr rfl
      intro e he
      split_ifs <;> simp_all <;> ring

end MissingLinnik

import MissingLinnik.SelbergDiagonal

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped ArithmeticFunction.Moebius

/-- Complementing divisors turns a sum over multiples into an ordinary
divisor sum. -/
theorem sum_over_divisor_multiples (P r : ℕ) (hP : P ≠ 0) (hr : r ∣ P)
    (f : ℕ → ℝ) :
    (∑ d ∈ P.divisors, if r ∣ d then f (P/d) else 0) =
      ∑ k ∈ (P/r).divisors, f k := by
  rw [← Nat.sum_div_divisors P (fun d => if r ∣ d then f (P/d) else 0)]
  have he : (∑ d ∈ P.divisors, if r ∣ P/d then f (P/(P/d)) else 0) =
      ∑ d ∈ P.divisors, if d ∣ P/r then f d else 0 := by
    apply Finset.sum_congr rfl
    intro d hd
    have hdP := Nat.dvd_of_mem_divisors hd
    have hiff : r ∣ P/d ↔ d ∣ P/r := by
      rw [Nat.dvd_div_iff_mul_dvd hdP, Nat.dvd_div_iff_mul_dvd hr, Nat.mul_comm]
    simp only [hiff, Nat.div_div_self hdP hP]
  rw [he, ← Finset.sum_filter,
    Nat.divisors_filter_dvd_of_dvd hP (Nat.div_dvd_of_dvd hr)]

/-- The inverse upper divisor transform. -/
noncomputable def upperMobiusWeight (P : ℕ) (g : ℕ → ℝ) (d : ℕ) : ℝ :=
  (d:ℝ) * ∑ x ∈ (P/d).divisorsAntidiagonal, (μ x.1:ℝ) * g (P/x.2)

theorem upperMobiusWeight_transform (P r : ℕ) (hP : P ≠ 0) (hr : r ∣ P)
    (g : ℕ → ℝ) :
    (∑ d ∈ P.divisors, if r ∣ d then upperMobiusWeight P g d/d else 0) = g r := by
  let f : ℕ → ℝ := fun n => ∑ x ∈ n.divisorsAntidiagonal, (μ x.1:ℝ)*g (P/x.2)
  have hinv : ∀ n > 0, ∑ k ∈ n.divisors, f k = g (P/n) :=
    ArithmeticFunction.sum_eq_iff_sum_mul_moebius_eq.mpr (fun n _ => rfl)
  have he : (∑ d ∈ P.divisors, if r ∣ d then upperMobiusWeight P g d/d else 0) =
      ∑ d ∈ P.divisors, if r ∣ d then f (P/d) else 0 := by
    apply Finset.sum_congr rfl
    intro d hd
    have hdR : (d:ℝ) ≠ 0 := by exact_mod_cast (Nat.pos_of_mem_divisors hd).ne'
    simp only [upperMobiusWeight, mul_div_cancel_left₀ _ hdR]
    rfl
  rw [he, sum_over_divisor_multiples P r hP hr f,
    hinv (P/r) (Nat.pos_of_dvd_of_pos (Nat.div_dvd_of_dvd hr) (Nat.pos_of_ne_zero hP)),
    Nat.div_div_self hr hP]

theorem upperMobiusWeight_one (P : ℕ) (hP : P ≠ 0) (g : ℕ → ℝ) :
    upperMobiusWeight P g 1 = ∑ d ∈ P.divisors, (μ d:ℝ)*g d := by
  simp only [upperMobiusWeight, Nat.cast_one, one_mul, Nat.div_one,
    ]
  rw [Nat.sum_divisorsAntidiagonal (fun a b => (μ a:ℝ)*g (P/b))]
  apply Finset.sum_congr rfl
  intro d hd
  rw [Nat.div_div_self (Nat.dvd_of_mem_divisors hd) hP]

theorem upperMobiusWeight_abs_le (P d : ℕ) (hP : P ≠ 0) (hd : d ∣ P)
    (g : ℕ → ℝ) :
    |upperMobiusWeight P g d| ≤ (d:ℝ)*∑ r ∈ P.divisors, |g r| := by
  have hsub : (P/d).divisors ⊆ P.divisors := by
    intro k hk
    exact Nat.mem_divisors.mpr ⟨(Nat.dvd_of_mem_divisors hk).trans (Nat.div_dvd_of_dvd hd),hP⟩
  have hsum : |∑ x ∈ (P/d).divisorsAntidiagonal, (μ x.1:ℝ)*g (P/x.2)| ≤
      ∑ r ∈ P.divisors, |g r| := by
    rw [Nat.sum_divisorsAntidiagonal' (fun a b => (μ a:ℝ)*g (P/b))]
    calc
      _ ≤ ∑ k ∈ (P/d).divisors, |(μ ((P/d)/k):ℝ)*g (P/k)| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ k ∈ (P/d).divisors, |g (P/k)| := by
        apply Finset.sum_le_sum
        intro k hk
        rw [abs_mul]
        have hm : |(μ ((P/d)/k):ℝ)| ≤ 1 := by exact_mod_cast (ArithmeticFunction.abs_moebius_le_one (n := (P/d)/k))
        simpa using mul_le_mul_of_nonneg_right hm (abs_nonneg (g (P/k)))
      _ ≤ ∑ k ∈ P.divisors, |g (P/k)| :=
        Finset.sum_le_sum_of_subset_of_nonneg hsub (fun _ _ _ => abs_nonneg _)
      _ = _ := Nat.sum_div_divisors P (fun r => |g r|)
  simpa only [upperMobiusWeight, abs_mul, abs_of_nonneg (Nat.cast_nonneg d : (0:ℝ) ≤ d)] using
    mul_le_mul_of_nonneg_left hsum (Nat.cast_nonneg d)

theorem upperMobiusWeight_support (P d R : ℕ) (hP : P ≠ 0) (hd : d ∣ P)
    (g : ℕ → ℝ) (hg : ∀ r, R < r → g r = 0) (hdR : R < d) :
    upperMobiusWeight P g d = 0 := by
  unfold upperMobiusWeight
  rw [Nat.sum_divisorsAntidiagonal' (fun a b => (μ a:ℝ)*g (P/b))]
  have hs : (∑ k ∈ (P/d).divisors, (μ ((P/d)/k):ℝ)*g (P/k)) = 0 := by
    apply Finset.sum_eq_zero
    intro k hk
    have hkP : k ∣ P := (Nat.dvd_of_mem_divisors hk).trans (Nat.div_dvd_of_dvd hd)
    have hdk : d ∣ P/k := by
      rw [Nat.dvd_div_iff_mul_dvd hkP, Nat.mul_comm]
      exact (Nat.dvd_div_iff_mul_dvd hd).mp (Nat.dvd_of_mem_divisors hk)
    have hle : d ≤ P/k := Nat.le_of_dvd
      (Nat.pos_of_dvd_of_pos (Nat.div_dvd_of_dvd hkP) (Nat.pos_of_ne_zero hP)) hdk
    rw [hg _ (hdR.trans_le hle), mul_zero]
  rw [hs, mul_zero]

end MissingLinnik

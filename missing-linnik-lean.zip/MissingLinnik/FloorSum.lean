import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace MissingLinnik

theorem sum_range_real_id (R : ℕ) :
    (∑ r ∈ Finset.range R, (r : ℝ)) = (R : ℝ) * (R - 1) / 2 := by
  induction R with
  | zero => simp
  | succ R ih => rw [Finset.sum_range_succ, ih]; push_cast; ring

/-- A uniform explicit error for the row valuation sum. -/
theorem floor_sum_lower (R p : ℕ) (hp : 0 < p) :
    (R : ℝ) * (R - 1) / (2 * p) - R ≤
      ∑ r ∈ Finset.range R, ((r / p : ℕ) : ℝ) := by
  have hpR : (0 : ℝ) < p := by exact_mod_cast hp
  have hterm (r : ℕ) : (r : ℝ) ≤ (p : ℝ) * (r / p : ℕ) + p := by
    have hn : r ≤ p * (r / p) + p := by
      have hm := Nat.mod_lt r hp
      have he := Nat.mod_add_div r p
      omega
    exact_mod_cast hn
  have hs := Finset.sum_le_sum (s := Finset.range R) (fun r _ => hterm r)
  rw [sum_range_real_id] at hs
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_const,
    Finset.card_range, nsmul_eq_mul] at hs
  apply (mul_le_mul_iff_left₀ hpR).mp
  have he : ((R : ℝ) * (R - 1) / (2 * p) - R) * p =
      (R : ℝ) * (R - 1) / 2 - R * p := by field_simp <;> ring
  rw [he]
  nlinarith

end MissingLinnik



import MissingLinnik.SieveDensityBound

namespace MissingLinnik

open Finset

noncomputable def roughCount (N z : ℕ) : ℕ :=
  ((Finset.range N).filter (fun n => ∀ p ∈ Nat.primesLE z, ¬p ∣ n)).card

noncomputable def roughProgressionCount (N q b z : ℕ) : ℕ :=
  (((Finset.range N).filter (fun n => Nat.ModEq q n b)).filter
    (fun n => ∀ p ∈ Nat.primesLE z, ¬p ∣ n)).card

theorem rough_count_sieve (N z h : ℕ) (hz : 2 ≤ z) (hh : 17 ≤ h) :
    |(roughCount N z:ℝ)-(N:ℝ)*sieveDensity (Nat.primesLE z)| ≤
      16*Real.exp (32-(h:ℝ))*(N:ℝ)*sieveDensity (Nat.primesLE z)+(z:ℝ)^(5*h) := by
  have hs := rough_numbers_sieve N 1 0 z h (by omega) hz (by omega) (by simp) hh
  simpa only [Nat.ModEq,Nat.mod_one,Finset.filter_true,Nat.totient_one,Nat.cast_one,div_one,roughCount] using hs

theorem rough_discrepancy_sieve (N q b z h : ℕ) (hq : 0 < q) (hz : 2 ≤ z)
    (hqz : q ≤ z) (hb : b.Coprime q) (hh : 17 ≤ h) :
    |(roughProgressionCount N q b z:ℝ)-(roughCount N z:ℝ)/q.totient| ≤
      32*Real.exp (32-(h:ℝ))*((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)+
        2*(z:ℝ)^(5*h) := by
  have ha := rough_numbers_sieve N q b z h hq hz hqz hb hh
  have ht := rough_count_sieve N z h hz hh
  have hφ : (0:ℝ) < q.totient := by exact_mod_cast Nat.totient_pos.mpr hq
  have hφ1 : (1:ℝ) ≤ q.totient := by exact_mod_cast Nat.totient_pos.mpr hq
  have hscaled := div_le_div_of_nonneg_right ht hφ.le
  have hrem : (z:ℝ)^(5*h)/q.totient ≤ (z:ℝ)^(5*h) :=
    div_le_self (by positivity) hφ1
  have he : (roughProgressionCount N q b z:ℝ)-(roughCount N z:ℝ)/q.totient =
      ((roughProgressionCount N q b z:ℝ)-((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z))-
      ((roughCount N z:ℝ)-(N:ℝ)*sieveDensity (Nat.primesLE z))/q.totient := by ring
  rw [he]
  have htri := abs_sub
    ((roughProgressionCount N q b z:ℝ)-((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z))
    (((roughCount N z:ℝ)-(N:ℝ)*sieveDensity (Nat.primesLE z))/q.totient)
  rw [abs_div,abs_of_pos hφ] at htri
  change |(roughProgressionCount N q b z:ℝ)-((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)| ≤ _ at ha
  have he' : (16*Real.exp (32-(h:ℝ))*(N:ℝ)*sieveDensity (Nat.primesLE z)+(z:ℝ)^(5*h))/q.totient =
      16*Real.exp (32-(h:ℝ))*((N:ℝ)/q.totient)*sieveDensity (Nat.primesLE z)+(z:ℝ)^(5*h)/q.totient := by ring
  rw [he'] at hscaled
  linarith

theorem rough_discrepancy_log_bound (N q b z h : ℕ) (hq : 0 < q) (hz : 2 ≤ z)
    (hqz : q ≤ z) (hb : b.Coprime q) (hh : 17 ≤ h) :
    |(roughProgressionCount N q b z:ℝ)-(roughCount N z:ℝ)/q.totient| ≤
      32*Real.exp (32-(h:ℝ))*(N:ℝ)/(q.totient*Real.log z)+2*(z:ℝ)^(5*h) := by
  have hs := rough_discrepancy_sieve N q b z h hq hz hqz hb hh
  have hv := mul_le_mul_of_nonneg_left (sieveDensity_le_inv_log z hz)
    (show 0 ≤ 32*Real.exp (32-(h:ℝ))*((N:ℝ)/q.totient) by positivity)
  have he : 32*Real.exp (32-(h:ℝ))*((N:ℝ)/q.totient)*(Real.log (z:ℝ))⁻¹ =
      32*Real.exp (32-(h:ℝ))*(N:ℝ)/(q.totient*Real.log z) := by ring
  rw [he] at hv
  linarith

end MissingLinnik

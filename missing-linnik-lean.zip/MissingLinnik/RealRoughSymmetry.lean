import MissingLinnik.GlobalRoughSymmetry

namespace MissingLinnik

open Finset ArithmeticFunction

noncomputable def roughQ (q c Y : ℕ) (x : ℝ) : ℝ := roughSelbergClassSum (Nat.floor x) q c Y

theorem selbergKernel_one : selbergKernel 1=0 := by
  simp [selbergKernel,logWeight_apply,ArithmeticFunction.mul_apply]

theorem roughQ_small (q c Y : ℕ) (hY : 2≤Y) (x : ℝ) (hx : x≤Y) : roughQ q c Y x=0 := by
  unfold roughQ roughSelbergClassSum
  apply Finset.sum_eq_zero
  intro n hn
  obtain ⟨hn,hr,_⟩ := Finset.mem_filter.mp hn
  have hnY : n≤Y := by
    have hnf := (Finset.mem_Icc.mp hn).2
    by_cases hx0 : 0≤x
    · exact_mod_cast (show (n:ℝ)≤Y from
        (show (n:ℝ)≤Nat.floor x by exact_mod_cast hnf).trans ((Nat.floor_le hx0).trans hx))
    · have hf : Nat.floor x=0 := Nat.floor_of_nonpos (le_of_not_ge hx0)
      omega
  have hn1 := (isRough_small_iff Y n hY hnY).mp hr
  simp [hn1,selbergKernel_one]

theorem rough_two_real (q k c : ℕ) (hq : 2≤q) (hk : 1≤k) (hc : c.Coprime q)
    (x : ℝ) (hx : 1≤x) :
    |roughQ q c (q^(170*k)) x-(Real.log x)^2/q.totient| ≤
      (10:ℝ)^42*Real.log ((q^(170*k):ℕ):ℝ)*Real.log x/q.totient := by
  let Y := q^(170*k)
  have hqY : q≤Y := by
    exact (show q=q^1 by simp).trans_le (Nat.pow_le_pow_right (by omega : 1≤q) (by omega))
  have hY : 2≤Y := hq.trans hqY
  have hlY := log_nat_ge_half Y hY
  have hφ : (0:ℝ)<q.totient := by exact_mod_cast Nat.totient_pos.mpr (show 0<q by omega)
  have hlx := Real.log_nonneg hx
  change |roughQ q c Y x-(Real.log x)^2/q.totient| ≤ (10:ℝ)^42*Real.log Y*Real.log x/q.totient
  by_cases hxY : x≤Y
  · rw [roughQ_small q c Y hY x hxY,zero_sub,abs_neg,abs_of_nonneg (by positivity)]
    apply div_le_div_of_nonneg_right _ hφ.le
    have hl := Real.log_le_log (by linarith : 0<x) hxY
    have hm := mul_le_mul_of_nonneg_right hl hlx
    have hh := mul_le_mul_of_nonneg_right (show (1:ℝ)≤10^42 by norm_num)
      (show 0≤Real.log (Y:ℝ)*Real.log x by positivity)
    nlinarith only [hm,hh]
  · have hNY : Y≤Nat.floor x := Nat.le_floor (le_of_not_ge hxY)
    have hh := rough_selberg_two (Nat.floor x) q k c hq hk hc hNY
    have hg := log_floor_gap x hx
    have hlN : 0≤Real.log (Nat.floor x:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤Nat.floor x by omega))
    have hgap : |(Real.log (Nat.floor x:ℝ))^2-(Real.log x)^2|≤2*Real.log x := by
      rw [abs_of_nonpos (by nlinarith [hg.1])]
      have hm := mul_le_mul_of_nonneg_right hg.2 (show 0≤Real.log x+Real.log (Nat.floor x:ℝ) by positivity)
      nlinarith only [hm,hg.1]
    have he : roughQ q c Y x-(Real.log x)^2/q.totient =
        (roughSelbergClassSum (Nat.floor x) q c Y-(Real.log (Nat.floor x:ℝ))^2/q.totient)+
        ((Real.log (Nat.floor x:ℝ))^2-(Real.log x)^2)/q.totient := by unfold roughQ; ring
    rw [he]
    apply (abs_add_le _ _).trans
    rw [abs_div,abs_of_pos hφ]
    apply (add_le_add hh (div_le_div_of_nonneg_right hgap hφ.le)).trans
    rw [← add_div]
    apply div_le_div_of_nonneg_right _ hφ.le
    have hm := mul_le_mul_of_nonneg_left (show Real.log (Nat.floor x:ℝ)≤Real.log x by linarith [hg.1])
      (show 0≤(10:ℝ)^41*Real.log Y by positivity)
    have hbig : (10:ℝ)^41*Real.log Y+2 ≤ (10:ℝ)^42*Real.log Y := by nlinarith only [hlY]
    have hscaled := mul_le_mul_of_nonneg_right hbig hlx
    nlinarith only [hm,hscaled]

end MissingLinnik


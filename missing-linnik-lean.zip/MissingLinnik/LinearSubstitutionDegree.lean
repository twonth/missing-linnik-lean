import MissingLinnik.BivariateDegree
import Mathlib.Algebra.Polynomial.BigOperators
import Mathlib.Tactic.Linarith

namespace MissingLinnik.Green

open Polynomial

theorem double_monomial_expansion {K : Type*} [CommRing K]
    (f : Polynomial (Polynomial K)) :
    f = ∑ r ∈ f.support, ∑ s ∈ (f.coeff r).support,
      Polynomial.monomial r (Polynomial.monomial s ((f.coeff r).coeff s)) := by
  conv_lhs => rw [← f.sum_monomial_eq, Polynomial.sum_def]
  apply Finset.sum_congr rfl
  intro r _
  conv_lhs => rw [← (f.coeff r).sum_monomial_eq, Polynomial.sum_def, map_sum]

theorem linear_substitution_degree_le {K : Type*} [CommRing K]
    (φ : Polynomial (Polynomial K) →+* Polynomial (Polynomial K))
    (hC : ∀ c : K, φ (Polynomial.C (Polynomial.C c)) = Polynomial.C (Polynomial.C c))
    (hx : (φ Polynomial.X).natDegree ≤ 1)
    (hy : (φ (Polynomial.C Polynomial.X)).natDegree ≤ 1)
    (f : Polynomial (Polynomial K)) : (φ f).natDegree ≤ f.natDegree + yDegree f := by
  classical
  have hm (r s : ℕ) (c : K) :
      (φ (Polynomial.monomial r (Polynomial.monomial s c))).natDegree ≤ r + s := by
    have he : φ (Polynomial.monomial r (Polynomial.monomial s c)) =
        Polynomial.C (Polynomial.C c) * φ (Polynomial.C Polynomial.X) ^ s * φ Polynomial.X ^ r := by
      simp only [← Polynomial.C_mul_X_pow_eq_monomial, map_mul, map_pow, hC]
    rw [he]
    have h1 := Polynomial.natDegree_mul_le (p := Polynomial.C (Polynomial.C c))
      (q := φ (Polynomial.C Polynomial.X) ^ s)
    have h2 := Polynomial.natDegree_mul_le
      (p := Polynomial.C (Polynomial.C c) * φ (Polynomial.C Polynomial.X) ^ s)
      (q := φ Polynomial.X ^ r)
    have hp1 := Polynomial.natDegree_pow_le (p := φ (Polynomial.C Polynomial.X)) (n := s)
    have hp2 := Polynomial.natDegree_pow_le (p := φ Polynomial.X) (n := r)
    simp only [Polynomial.natDegree_C] at h1
    nlinarith
  conv_lhs => rw [double_monomial_expansion f, map_sum]
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro r hr
  rw [map_sum]
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro s hs
  have hr' := Polynomial.le_natDegree_of_mem_supp r hr
  have hs' := (Polynomial.le_natDegree_of_mem_supp s hs).trans (coeff_natDegree_le_yDegree f r)
  exact (hm r s _).trans (Nat.add_le_add hr' hs')

end MissingLinnik.Green


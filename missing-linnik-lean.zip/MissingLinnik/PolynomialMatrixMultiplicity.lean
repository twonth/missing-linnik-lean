import MissingLinnik.DeterminantDivisibility
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Algebra.Polynomial.FieldDivision

namespace MissingLinnik

/-- A rank drop of k at a specialization forces a zero of order at least k
in the determinant. This is the linear-algebra step in Green's resultant lemma. -/
theorem pow_nullity_dvd_polynomial_det {K ι : Type*} [Field K]
    [Fintype ι] [DecidableEq ι] (M : Matrix ι ι (Polynomial K)) (a : K) :
    (Polynomial.X - Polynomial.C a) ^
      (Fintype.card ι - ((Polynomial.evalRingHom a).mapMatrix M).rank) ∣ M.det := by
  classical
  let E := (Polynomial.evalRingHom a).mapMatrix M
  obtain ⟨V, U, e, hV, hU, hnormal⟩ := Matrix.exists_rank_normal_form E
  let Q := Polynomial.C.mapMatrix V * M * Polynomial.C.mapMatrix U
  let height : ι → ℕ := fun i => Sum.elim (fun _ => 0) (fun _ => 1) (e i)
  have hsum : (∑ i, height i) = Fintype.card ι - E.rank := by
    have hh := e.sum_comp (Sum.elim (fun _ : Fin E.rank => (0 : ℕ))
      (fun _ : Fin (Fintype.card ι - E.rank) => (1 : ℕ)))
    simpa [height, Fintype.sum_sum_type] using hh
  have hEval : (Polynomial.evalRingHom a).mapMatrix Q = V * E * U := by
    apply Matrix.ext
    intro i j
    simp [Q, E, Matrix.mul_apply, Polynomial.eval_finsetSum, Polynomial.eval_mul]
  have hrow : ∀ i j, (Polynomial.X - Polynomial.C a) ^ height i ∣ Q i j := by
    intro i j
    cases he : e i with
    | inl k => simp [height, he]
    | inr k =>
      simp only [height, he, Sum.elim_inr, pow_one]
      rw [Polynomial.dvd_iff_isRoot]
      have hh := congrArg (fun N : Matrix ι ι K => N i j) (hEval.trans hnormal)
      cases he' : e j <;>
        simpa [Polynomial.IsRoot, Matrix.submatrix_apply, he, he', Matrix.fromBlocks] using hh
  have hdiv := row_prime_powers_dvd_det Q (Polynomial.X - Polynomial.C a) height hrow
  rw [hsum, Matrix.det_mul, Matrix.det_mul, ← RingHom.map_det, ← RingHom.map_det] at hdiv
  have hVC : IsUnit (Polynomial.C V.det) :=
    ((Matrix.isUnit_iff_isUnit_det V).mp hV).map Polynomial.C
  have hUC : IsUnit (Polynomial.C U.det) :=
    ((Matrix.isUnit_iff_isUnit_det U).mp hU).map Polynomial.C
  exact hVC.dvd_mul_left.mp (hUC.dvd_mul_right.mp hdiv)

end MissingLinnik




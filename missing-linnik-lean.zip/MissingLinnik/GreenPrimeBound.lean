import MissingLinnik.GreenWindowBound
import MissingLinnik.PrimeWindowDecomposition
import MissingLinnik.FloorParameters

namespace MissingLinnik.Green

open Classical

/-- Green's argument with explicit parameters and both omitted prime ranges.
The larger constant covers the small-X case uniformly. -/
theorem prime_set_bound (k X : ℕ) (hk : 8 ≤ k) (hX : 1 ≤ X)
    (d : ℤ) (hd : ∀ n : ℤ, d ≠ n*n)
    (a : ℂ) (ha : a^2=d) (q : ℝ) (hq : 1 ≤ q) (haq : ‖a‖^2 ≤ q)
    (P : Finset ℕ) (hprime : ∀ p ∈ P, p.Prime) (hupper : ∀ p ∈ P, p ≤ X)
    (hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1) :
    (∑ p ∈ P, Real.log p / p) ≤
      (1/2+8/(k:ℝ))*Real.log X + Real.log q + 128*(k:ℝ)^2 := by
  have hl4 : Real.log (4:ℝ) ≤ 2 := by
    have hl2 := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    rw [show (4:ℝ)=2^2 by norm_num, Real.log_pow]
    norm_num
    linarith
  have hlogX : 0 ≤ Real.log (X:ℝ) := Real.log_nonneg (by exact_mod_cast hX)
  have hlogq : 0 ≤ Real.log q := Real.log_nonneg hq
  by_cases hlarge : 64*k^2 ≤ X
  · let m := X/k^2
    have hk0 : 0 < k := by omega
    have hm : 64 ≤ m := (Nat.le_div_iff_mul_le (pow_pos hk0 2)).mpr (by nlinarith)
    have hkX : k^2 ≤ X := by nlinarith
    obtain ⟨hm1,hR,_,hXR,_⟩ := floor_parameter_bounds k X hk hkX
    have hmid := window_prime_bound k m hk hm d hd a ha q hq haq
      (P.filter (fun p => k^2 ≤ p ∧ p ≤ k*m))
      (fun p hp => hprime p (Finset.mem_filter.mp hp).1)
      (fun p hp => (Finset.mem_filter.mp hp).2.1)
      (fun p hp => (Finset.mem_filter.mp hp).2.2)
      (fun p hp => hinert p (Finset.mem_filter.mp hp).1)
    have hS : 0 < k*m := by positivity
    have hXS : X ≤ 2*k*(k*m) := by dsimp only [m]; nlinarith
    have hext := prime_window_extension P k (k*m) X hS hprime hupper hXS _ hmid
    have hlogR : Real.log ((k:ℝ)^2*m) ≤ Real.log X := by
      apply Real.log_le_log (by positivity)
      exact_mod_cast hR
    have hlog := mul_le_mul_of_nonneg_left hlogR (show (0:ℝ) ≤ 1/2+8/(k:ℝ) by positivity)
    have herr := mul_le_mul_of_nonneg_right hl4 (show (0:ℝ) ≤ (k:ℝ)^2+2*k by positivity)
    have hkr : (8:ℝ) ≤ k := by exact_mod_cast hk
    nlinarith [sq_nonneg ((k:ℝ)-8)]
  · have hsmall := prime_mass_small_le P X hprime hupper
    have herr := mul_le_mul_of_nonneg_right hl4 (show (0:ℝ) ≤ X by positivity)
    have hXsmall : (X:ℝ) ≤ 64*(k:ℝ)^2 := by exact_mod_cast (show X ≤ 64*k^2 by omega)
    have hmain : 0 ≤ (1/2+8/(k:ℝ))*Real.log X := by positivity
    nlinarith

end MissingLinnik.Green

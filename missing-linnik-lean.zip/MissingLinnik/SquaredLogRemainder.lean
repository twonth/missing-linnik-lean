import MissingLinnik.QuadraticMassWeighting

namespace MissingLinnik

open Finset

theorem coefficient_second_log_moment (c : ℕ → ℝ) (hc : c 0=0) (K : ℝ) (hK : 0≤K)
    (hmertens : ∀ t : ℝ, 1≤t → |coefficientMass c t-Real.log t|≤K)
    (x : ℝ) (hx : 1≤x) :
    |(∑ n ∈ Icc 0 (Nat.floor x), (Real.log n)^2*c n)-(Real.log x)^3/3| ≤ 4*K*(Real.log x)^2 := by
  have hh := quadratic_mass_log_weight (fun n : ℕ => Real.log n*c n) (by simp)
    (1/2) (2*K) (by positivity)
    (fun t ht => by
      have hm := coefficientLogMoment_estimate c hc K hmertens t ht
      convert hm using 1 <;> simp only [coefficientMass,coefficientLogMoment] <;> ring)
    x hx
  have he : coefficientLogMoment (fun n : ℕ => Real.log n*c n) x =
      ∑ n ∈ Icc 0 (Nat.floor x), (Real.log n)^2*c n := by
    unfold coefficientLogMoment
    apply Finset.sum_congr rfl
    intro n hn
    ring
  rw [he] at hh
  convert hh using 1 <;> congr 1 <;> ring

theorem squared_log_remainder_estimate (c : ℕ → ℝ) (hc : c 0=0) (K : ℝ) (hK : 0≤K)
    (hmertens : ∀ t : ℝ, 1≤t → |coefficientMass c t-Real.log t|≤K)
    (x : ℝ) (hx : 1≤x) :
    |(∑ n ∈ Icc 1 (Nat.floor x), c n*(Real.log (x/n))^2)-(Real.log x)^3/3| ≤ 9*K*(Real.log x)^2 := by
  have he : (∑ n ∈ Icc 1 (Nat.floor x), c n*(Real.log (x/n))^2) =
      (Real.log x)^2*coefficientMass c x-2*Real.log x*coefficientLogMoment c x+
      ∑ n ∈ Icc 0 (Nat.floor x), (Real.log n)^2*c n := by
    unfold coefficientMass coefficientLogMoment
    rw [sum_Icc_zero_eq_one hc,
      sum_Icc_zero_eq_one (f := fun n : ℕ => Real.log n*c n) (by simp),
      sum_Icc_zero_eq_one (f := fun n : ℕ => (Real.log n)^2*c n) (by simp),
      Finset.mul_sum,Finset.mul_sum,← Finset.sum_sub_distrib,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro n hn
    have hn0 : (n:ℝ)≠0 := by exact_mod_cast (show n≠0 by have := (mem_Icc.mp hn).1; omega)
    rw [Real.log_div (by linarith : x≠0) hn0]
    ring
  have h0 := abs_le.mp (hmertens x hx)
  have h1 := abs_le.mp (coefficientLogMoment_estimate c hc K hmertens x hx)
  have h2 := abs_le.mp (coefficient_second_log_moment c hc K hK hmertens x hx)
  have h0l := mul_le_mul_of_nonneg_left h0.1 (sq_nonneg (Real.log x))
  have h0u := mul_le_mul_of_nonneg_left h0.2 (sq_nonneg (Real.log x))
  have h1l := mul_le_mul_of_nonneg_left h1.1 (show 0≤2*Real.log x by positivity [Real.log_nonneg hx])
  have h1u := mul_le_mul_of_nonneg_left h1.2 (show 0≤2*Real.log x by positivity [Real.log_nonneg hx])
  rw [he]
  apply abs_le.mpr
  constructor <;> nlinarith only [h0l,h0u,h1l,h1u,h2.1,h2.2]

end MissingLinnik

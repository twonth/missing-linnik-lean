import MissingLinnik.UniformRoughDiscrepancy
import MissingLinnik.WeightedDiscrepancy

namespace MissingLinnik

open Finset
open scoped Classical

abbrev IsRough (z n : ℕ) : Prop := ∀ p ∈ Nat.primesLE z, ¬p ∣ n

theorem isRough_one (z : ℕ) : IsRough z 1 := by
  intro p hp hdiv
  exact (Nat.mem_primesLE.mp hp).2.ne_one (Nat.dvd_one.mp hdiv)

theorem not_isRough_zero (z : ℕ) (hz : 2 ≤ z) : ¬IsRough z 0 := by
  intro h
  exact h 2 (Nat.mem_primesLE.mpr ⟨hz,Nat.prime_two⟩) (dvd_zero _)

theorem isRough_small_iff (z n : ℕ) (hz : 2 ≤ z) (hn : n ≤ z) : IsRough z n ↔ n = 1 := by
  constructor
  · intro h
    by_contra hn1
    by_cases hn0 : n = 0
    · exact not_isRough_zero z hz (hn0 ▸ h)
    have hp := Nat.minFac_prime hn1
    exact h n.minFac (Nat.mem_primesLE.mpr
      ⟨(Nat.minFac_le (Nat.pos_of_ne_zero hn0)).trans hn,hp⟩) (Nat.minFac_dvd n)
  · rintro rfl
    exact isRough_one z

noncomputable def roughResidueCoefficient (q b z n : ℕ) : ℝ :=
  (if IsRough z n ∧ Nat.ModEq q n b then 1 else 0)-
    (if IsRough z n then 1 else 0)/(q.totient:ℝ)

noncomputable def roughResidueCoefficientAboveOne (q b z n : ℕ) : ℝ :=
  roughResidueCoefficient q b z n-(if n=1 then roughResidueCoefficient q b z 1 else 0)

theorem roughResidueCoefficient_one_abs (q b z : ℕ) (hq : 0 < q) :
    |roughResidueCoefficient q b z 1| ≤ 1 := by
  have hφ : (1:ℝ) ≤ q.totient := by exact_mod_cast Nat.totient_pos.mpr hq
  have hi : 1/(q.totient:ℝ) ≤ 1 := (div_le_one (by linarith)).mpr hφ
  have hi0 : 0 ≤ 1/(q.totient:ℝ) := by positivity
  unfold roughResidueCoefficient
  change |(if IsRough z 1 ∧ Nat.ModEq q 1 b then 1 else 0)-(if IsRough z 1 then 1 else 0)/(q.totient:ℝ)| ≤ 1
  rw [if_pos (isRough_one z)]
  split_ifs <;> apply abs_le.mpr <;> constructor <;> linarith

theorem roughResidueCoefficientAboveOne_small (q b z n : ℕ) (hz : 2 ≤ z) (hn : n ≤ z) :
    roughResidueCoefficientAboveOne q b z n = 0 := by
  unfold roughResidueCoefficientAboveOne
  by_cases hn1 : n = 1
  · simp [hn1]
  · have hr : ¬IsRough z n := fun h => hn1 ((isRough_small_iff z n hz hn).mp h)
    simp [roughResidueCoefficient,hr,hn1]

theorem sum_roughResidueCoefficient (N q b z : ℕ) :
    (∑ n ∈ Finset.range N, roughResidueCoefficient q b z n) =
      (roughProgressionCount N q b z:ℝ)-(roughCount N z:ℝ)/q.totient := by
  classical
  unfold roughResidueCoefficient
  rw [Finset.sum_sub_distrib,← Finset.sum_div]
  have h1 : (∑ n ∈ Finset.range N, if IsRough z n ∧ Nat.ModEq q n b then (1:ℝ) else 0) =
      (roughProgressionCount N q b z:ℝ) := by
    rw [← Finset.sum_filter]
    simp only [Finset.sum_const,nsmul_eq_mul,mul_one]
    congr 1
    unfold roughProgressionCount
    congr 1
    ext n
    simp only [IsRough,Finset.mem_filter]
    tauto
  have h2 : (∑ n ∈ Finset.range N, if IsRough z n then (1:ℝ) else 0) = (roughCount N z:ℝ) := by
    rw [← Finset.sum_filter]
    simp only [Finset.sum_const,nsmul_eq_mul,mul_one,roughCount]
  rw [h1,h2]

theorem sum_roughResidueCoefficientAboveOne (q b z : ℕ) (x : ℝ) (hx : 1 ≤ x) :
    (∑ n ∈ Finset.Icc 0 (Nat.floor x), roughResidueCoefficientAboveOne q b z n) =
      (roughProgressionCount (Nat.floor x+1) q b z:ℝ)-
      (roughCount (Nat.floor x+1) z:ℝ)/q.totient-roughResidueCoefficient q b z 1 := by
  classical
  rw [← Nat.range_succ_eq_Icc_zero]
  unfold roughResidueCoefficientAboveOne
  rw [Finset.sum_sub_distrib,sum_roughResidueCoefficient]
  have hmem : 1 ∈ Finset.range (Nat.floor x+1) := Finset.mem_range.mpr (by
    have hh : 1 ≤ Nat.floor x := Nat.le_floor (by simpa using hx)
    omega)
  simp [hmem]

theorem weighted_rough_coefficient_eq (q b z : ℕ) (N : ℕ) :
    (∑ n ∈ Finset.Icc 0 N, logSquareOver n*roughResidueCoefficientAboveOne q b z n) =
      ∑ n ∈ Finset.Icc 0 N, logSquareOver n*roughResidueCoefficient q b z n := by
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hn1 : n = 1
  · simp [hn1,logSquareOver]
  · simp [roughResidueCoefficientAboveOne,hn1]

end MissingLinnik







import MissingLinnik.RoughBrunTitchmarsh
import MissingLinnik.DirichletFourier

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

noncomputable def unitResidue (q n : ℕ) : (ZMod q)ˣ :=
  if h : n.Coprime q then ZMod.unitOfCoprime n h else 1

theorem unitResidue_coe (q n : ℕ) (hn : n.Coprime q) : (unitResidue q n:ZMod q)=n := by
  simp only [unitResidue,dif_pos hn,ZMod.coe_unitOfCoprime]

theorem modEq_unitResidue (q n : ℕ) [NeZero q] (hn : n.Coprime q) (u : (ZMod q)ˣ) :
    Nat.ModEq q n (u:ZMod q).val ↔ unitResidue q n=u := by
  rw [← ZMod.natCast_eq_natCast_iff,ZMod.natCast_zmod_val,← unitResidue_coe q n hn]
  exact Units.val_inj

noncomputable def unitArithmeticMass {q : ℕ} (f : ArithmeticFunction ℝ) (x : ℝ) (u : (ZMod q)ˣ) : ℝ :=
  arithmeticClassSum f q (u:ZMod q).val x

theorem unitArithmeticMass_nonneg {q : ℕ} (f : ArithmeticFunction ℝ) (hf : ∀ n,0≤f n)
    (x : ℝ) (u : (ZMod q)ˣ) : 0≤unitArithmeticMass f x u := arithmeticClassSum_nonneg f hf _ _ _

theorem unitArithmeticMass_weighted_sum {q : ℕ} [NeZero q] (f : ArithmeticFunction ℝ)
    (hf : ∀ n, f n≠0 → n.Coprime q) (x : ℝ) (H : (ZMod q)ˣ → ℝ) :
    (∑ u,unitArithmeticMass f x u*H u)=
      ∑ n ∈ Icc 1 (Nat.floor x), f n/(n:ℝ)*H (unitResidue q n) := by
  unfold unitArithmeticMass arithmeticClassSum
  simp only [Finset.sum_filter,Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hfn : f n=0
  · simp [hfn]
  · simp only [modEq_unitResidue q n (hf n hfn),ite_mul,zero_mul]
    simp

theorem unitArithmeticMass_total {q : ℕ} [NeZero q] (f : ArithmeticFunction ℝ)
    (hf : ∀ n, f n≠0 → n.Coprime q) (x : ℝ) :
    (∑ u : (ZMod q)ˣ,unitArithmeticMass f x u)=∑ n ∈ Icc 1 (Nat.floor x), f n/(n:ℝ) := by
  simpa only [mul_one] using unitArithmeticMass_weighted_sum f hf x (fun _ : (ZMod q)ˣ => 1)

theorem unitArithmeticMass_mono {q : ℕ} (f : ArithmeticFunction ℝ) (hf : ∀ n,0≤f n)
    (x y : ℝ) (hxy : x≤y) (u : (ZMod q)ˣ) : unitArithmeticMass f x u≤unitArithmeticMass f y u := by
  unfold unitArithmeticMass arithmeticClassSum
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro n hn
    obtain ⟨hn,hm⟩ := Finset.mem_filter.mp hn
    exact Finset.mem_filter.mpr ⟨mem_Icc.mpr ⟨(mem_Icc.mp hn).1,
      (mem_Icc.mp hn).2.trans (Nat.floor_mono hxy)⟩,hm⟩
  · intro n hn _; exact div_nonneg (hf n) (Nat.cast_nonneg _)

theorem inverseResidue_unit (q d : ℕ) [NeZero q] (hd : d.Coprime q) (u : (ZMod q)ˣ) :
    inverseResidue q (u:ZMod q).val d=(((unitResidue q d)⁻¹*u : (ZMod q)ˣ):ZMod q).val := by
  unfold inverseResidue
  rw [ZMod.natCast_zmod_val,Units.val_mul,← ZMod.inv_coe_unit,unitResidue_coe q d hd,mul_comm]

theorem unitArithmeticMass_convolution {q : ℕ} [NeZero q] (f g : ArithmeticFunction ℝ)
    (hf : ∀ n, f n≠0 → n.Coprime q) (x : ℝ) (u : (ZMod q)ˣ) :
    unitArithmeticMass (f*g) x u=∑ d ∈ Icc 1 (Nat.floor x),
      f d/(d:ℝ)*unitArithmeticMass g (x/d) ((unitResidue q d)⁻¹*u) := by
  unfold unitArithmeticMass
  rw [arithmeticClassSum_convolution _ _ q _ (NeZero.pos q) hf]
  apply Finset.sum_congr rfl
  intro d hd
  by_cases hfd : f d=0
  · simp only [hfd,zero_div,zero_mul]
  · rw [inverseResidue_unit q d (hf d hfd)]

theorem arithmetic_mul_support_coprime {q : ℕ} (f g : ArithmeticFunction ℝ)
    (hf : ∀ n, f n≠0 → n.Coprime q) (hg : ∀ n, g n≠0 → n.Coprime q)
    (n : ℕ) (hn : (f*g) n≠0) : n.Coprime q := by
  rw [ArithmeticFunction.mul_apply] at hn
  obtain ⟨a,ha,hnz⟩ := Finset.exists_ne_zero_of_sum_ne_zero hn
  have hd := hf a.1 (left_ne_zero_of_mul hnz)
  have hm := hg a.2 (right_ne_zero_of_mul hnz)
  rw [← (Nat.mem_divisorsAntidiagonal.mp ha).1]
  exact hd.mul_left hm

end MissingLinnik

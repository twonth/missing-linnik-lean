import MissingLinnik.SelbergComparison

namespace MissingLinnik

open Finset ArithmeticFunction
open scoped Classical

noncomputable def roughMangoldtCoefficient (Y n : ℕ) : ℝ :=
  if IsRough Y n then vonMangoldt n/(n:ℝ) else 0

noncomputable def roughMangoldtMass (Y : ℕ) (x : ℝ) : ℝ :=
  ∑ n ∈ Icc 0 (Nat.floor x), roughMangoldtCoefficient Y n

theorem roughMangoldtCoefficient_nonneg (Y n : ℕ) : 0≤roughMangoldtCoefficient Y n := by
  unfold roughMangoldtCoefficient
  split_ifs <;> positivity [vonMangoldt_nonneg (n := n)]

theorem roughMangoldtCoefficient_zero (Y : ℕ) : roughMangoldtCoefficient Y 0=0 := by
  simp [roughMangoldtCoefficient]

theorem nonrough_mangoldt_bound (Y N : ℕ) (hY : 2≤Y) :
    (∑ n ∈ Icc 1 N, if IsRough Y n then 0 else vonMangoldt n/(n:ℝ)) ≤ Real.log Y+150 := by
  have hpoint (n : ℕ) : (if IsRough Y n then (0:ℝ) else vonMangoldt n/(n:ℝ)) ≤
      (if n∈Nat.primesLE Y then Real.log n/(n:ℝ) else 0)+properPrimePowerWeight n/(n:ℝ) := by
    by_cases hp : n.Prime
    · by_cases hn : n≤Y
      · have hmem := Nat.mem_primesLE.mpr ⟨hn,hp⟩
        simp only [hmem,ite_true,properPrimePowerWeight,hp,div_zero,zero_div,add_zero]
        split_ifs
        · exact div_nonneg (Real.log_nonneg (by exact_mod_cast hp.one_le)) (Nat.cast_nonneg _)
        · rw [vonMangoldt_apply_prime hp]
      · have hr : IsRough Y n := by
          intro p hpm hdiv
          have hpn : p=n := (hp.eq_one_or_self_of_dvd p hdiv).resolve_left (Nat.mem_primesLE.mp hpm).2.ne_one
          exact hn (hpn ▸ (Nat.mem_primesLE.mp hpm).1)
        rw [if_pos hr]
        have hpp := properPrimePowerWeight_nonneg n
        split_ifs <;> positivity
    · simp only [properPrimePowerWeight,hp,ite_false]
      have hmem : n∉Nat.primesLE Y := fun h => hp (Nat.mem_primesLE.mp h).2
      rw [if_neg hmem,zero_add]
      split_ifs <;> first | exact le_rfl | positivity [vonMangoldt_nonneg (n := n)]
  have hsum := Finset.sum_le_sum (fun n (_ : n∈Icc 1 N) => hpoint n)
  rw [Finset.sum_add_distrib,← Finset.sum_filter] at hsum
  have hprime : (∑ n ∈ (Icc 1 N).filter (fun n => n∈Nat.primesLE Y), Real.log n/(n:ℝ)) ≤
      ∑ n ∈ Nat.primesLE Y, Real.log n/(n:ℝ) := by
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · intro n hn
      exact (Finset.mem_filter.mp hn).2
    · intro n hn _
      exact div_nonneg (Real.log_nonneg (by exact_mod_cast (Nat.mem_primesLE.mp hn).2.one_le)) (Nat.cast_nonneg _)
  have hpp := proper_prime_power_mass_le N
  have hset : Icc 1 N = Ioc 0 N := by ext n; simp only [mem_Icc,mem_Ioc]; omega
  rw [hset] at hsum
  rw [hset] at hprime
  have hm := (abs_le.mp (prime_weighted_mertens Y (by omega))).2
  rw [hset]
  linarith

theorem rough_mangoldt_mertens (Y : ℕ) (hY : 2≤Y) (x : ℝ) (hx : 1≤x) :
    |roughMangoldtMass Y x-Real.log x| ≤ Real.log Y+157 := by
  have hN : 1≤Nat.floor x := Nat.le_floor (by simpa using hx)
  have hm := abs_le.mp (mangoldt_weighted_mertens (Nat.floor x) hN)
  have hg := log_floor_gap x hx
  have he : roughMangoldtMass Y x+
      (∑ n ∈ Icc 1 (Nat.floor x), if IsRough Y n then 0 else vonMangoldt n/(n:ℝ)) =
      ∑ n ∈ Ioc 0 (Nat.floor x), vonMangoldt n/(n:ℝ) := by
    unfold roughMangoldtMass
    rw [sum_Icc_zero_eq_one (roughMangoldtCoefficient_zero Y),← Finset.sum_add_distrib]
    have hset : Icc 1 (Nat.floor x) = Ioc 0 (Nat.floor x) := by ext n; simp only [mem_Icc,mem_Ioc]; omega
    rw [hset]
    apply Finset.sum_congr rfl
    intro n hn
    unfold roughMangoldtCoefficient
    split_ifs <;> ring
  have hn := nonrough_mangoldt_bound Y (Nat.floor x) hY
  have hn0 : 0≤(∑ n ∈ Icc 1 (Nat.floor x), if IsRough Y n then (0:ℝ) else vonMangoldt n/(n:ℝ)) := by
    apply Finset.sum_nonneg
    intro n hn
    split_ifs <;> positivity [vonMangoldt_nonneg (n := n)]
  have hlY : 0≤Real.log (Y:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤Y by omega))
  apply abs_le.mpr
  constructor <;> linarith

end MissingLinnik

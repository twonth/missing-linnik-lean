import LinearTriangle
import MissingLinnik.PropositionTwo
import MissingLinnik.QuadraticRoot

namespace MissingLinnik.CurrentPaper

set_option maxHeartbeats 800000

/-- The appendix's one-parameter estimate, with an absolute explicit constant.
The internal triangular slope is 1024*t; there is still only one free parameter. -/
theorem one_parameter (t f : ℕ) (ht : 3 ≤ t) (hf : 2 ≤ f)
    (ψ : DirichletCharacter ℝ f) (hprim : ψ.IsPrimitive)
    (x : ℝ) (hx : (f : ℝ)^(t^2) ≤ x) :
    negativePrimeMass ψ x ≤ (1/2 + 70000/(t:ℝ))*Real.log x := by
  classical
  have htr : (3:ℝ) ≤ t := by exact_mod_cast ht
  have ht0 : (0:ℝ) < t := by linarith
  have hfr : (2:ℝ) ≤ f := by exact_mod_cast hf
  have hf1 : (1:ℝ) ≤ f := by linarith
  have hx1 : 1 ≤ x := (one_le_pow₀ hf1).trans hx
  obtain ⟨d,hdq,hchar⟩ := montgomeryVaughan_representative f (by omega) ψ
  obtain ⟨a,ha,hasize⟩ := exists_quadratic_root d
  let T := (Finset.range (Nat.floor x+1)).filter
    (fun p => Nat.Prime p ∧ ψ (p:ZMod f) = -1)
  let P := T.erase 2
  have hprime : ∀ p ∈ P, p.Prime := by
    intro p hp
    exact (Finset.mem_filter.mp (Finset.mem_erase.mp hp).2).2.1
  have hupper : ∀ p ∈ P, (p:ℝ) ≤ x := by
    intro p hp
    have hh := Finset.mem_range.mp (Finset.mem_filter.mp (Finset.mem_erase.mp hp).2).1
    exact (show (p:ℝ) ≤ ⌊x⌋₊ by exact_mod_cast (show p ≤ ⌊x⌋₊ by omega)).trans
      (Nat.floor_le (by linarith))
  have hinert : ∀ p (hp : p ∈ P), @legendreSym p ⟨hprime p hp⟩ d = -1 := by
    intro p hp
    exact hchar p (hprime p hp) (Finset.mem_erase.mp hp).1
      (Finset.mem_filter.mp (Finset.mem_erase.mp hp).2).2.2
  have hh := prime_set_bound_linear (1024*t) ⌊x⌋₊ (by omega)
    (Nat.le_floor (by simpa using hx1)) d a ha (f:ℝ) hf1
    (by rw [hasize]; exact_mod_cast hdq) P hprime
    (fun p hp => Nat.le_floor (hupper p hp)) hinert
  have hlog := Real.log_le_log
    (show (0:ℝ) < ⌊x⌋₊ by exact_mod_cast (show 0 < ⌊x⌋₊ by
      have hflo : 1 ≤ ⌊x⌋₊ := Nat.le_floor (by simpa using hx1); omega))
    (Nat.floor_le (by linarith : 0 ≤ x))
  have hm := mul_le_mul_of_nonneg_left hlog
    (show (0:ℝ) ≤ 1/2+2048/((1024*t:ℕ):ℝ) by positivity)
  have hlog2 : Real.log (2:ℝ) ≤ 1 := by
    have := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    linarith
  have hsplit : negativePrimeMass ψ x ≤ (∑ p ∈ P, Real.log p/p)+1/2 := by
    change (∑ p ∈ T, Real.log p/p) ≤ _
    by_cases h2 : 2 ∈ T
    · have he := Finset.sum_erase_add T (fun p : ℕ => Real.log p/p) h2
      dsimp only [P]
      norm_num at he
      linarith
    · simp only [P,Finset.erase_eq_of_notMem h2]
      linarith
  have hlogf : 1/2 ≤ Real.log (f:ℝ) := by
    have hh := Real.one_sub_inv_le_log_of_pos (by norm_num : (0:ℝ)<2)
    have hm := Real.log_le_log (by norm_num : (0:ℝ)<2) hfr
    norm_num at hh
    linarith
  have hscale := Real.log_le_log (pow_pos (by linarith : (0:ℝ)<f) _) hx
  rw [Real.log_pow] at hscale
  push_cast at hh hm hscale
  have hcoef : 2048 / (1024*(t:ℝ)) = 2/(t:ℝ) := by field_simp; ring
  rw [hcoef] at hh hm
  have hpre : negativePrimeMass ψ x ≤
      (1/2+2/(t:ℝ))*Real.log x + Real.log f + 32768*(t:ℝ)+1/2 := by
    linarith
  have hsmall : (t:ℝ)*Real.log f ≤ Real.log x := by
    nlinarith [mul_nonneg (show 0 ≤ (t:ℝ)^2-t by nlinarith) (show 0 ≤ Real.log (f:ℝ) by linarith)]
  have hlarge : (t:ℝ)^2/2 ≤ Real.log x := by nlinarith
  apply (mul_le_mul_iff_right₀ ht0).mp
  have hpre' := mul_le_mul_of_nonneg_right hpre (le_of_lt ht0)
  have htwo : (2/(t:ℝ))*(t:ℝ) = 2 := div_mul_cancel₀ _ (ne_of_gt ht0)
  have hseven : (70000/(t:ℝ))*(t:ℝ) = 70000 := div_mul_cancel₀ _ (ne_of_gt ht0)
  nlinarith [htwo,hseven]

#print axioms MissingLinnik.CurrentPaper.one_parameter
end MissingLinnik.CurrentPaper